import hashlib,json,os,pathlib,subprocess,tempfile,time
root=pathlib.Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
out=pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes/first-refusal-mutants-R1');out.mkdir(exist_ok=False)
subject='4cf5c2b30a2f55c254ff924c4317f389fa5fa56e'
subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w',text=True).strip()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
mutants=[('history','integration','url-run-composed.test.ts','finally { history.mockClear(); }','finally { /* mutant: omit history clear */ }','observes actual descriptor guards'),('store','integration','url-machine-store.ts','options.onRefusal?.(Object.freeze({ ...refusal, operationMilliseconds }));','void refusal;','bounds unprofiled effects'),('inspection','unit','url-design-product.ts','observer({ phase, termination, deadline: Number.isSafeInteger(deadline) ? deadline! : null });','void phase;','preserves bounded JSON record prototypes')]
results=[]
tmp=pathlib.Path(tempfile.mkdtemp(prefix='f3m-',dir='/home/orca/.tmp'));tmp.chmod(0o700)
for name,project,file,old,new,pattern in mutants:
 p=root/'packages/polaris-dossier/src'/file;original=p.read_bytes();text=original.decode();assert text.count(old)==1
 testfile=file if file.endswith('.test.ts') else file[:-3]+'.test.ts'
 command=['node','node_modules/vitest/vitest.mjs','run','--project',project,'packages/polaris-dossier/src/'+testfile,'--testNamePattern='+pattern,'--reporter=json','--outputFile='+str(out/(name+'.json'))]
 try:
  p.write_text(text.replace(old,new));start=time.monotonic()
  with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env={**os.environ,'TMPDIR':str(tmp)},stdout=log,stderr=subprocess.STDOUT)
  d=json.loads((out/(name+'.json')).read_text())
  result={'name':name,'candidateCommit':subject,'cloneBase':base,'path':str(p.relative_to(root)),'candidateSha256':hashlib.sha256(original).hexdigest(),'old':old,'new':new,'command':command,'exit':r.returncode,'elapsedSeconds':time.monotonic()-start,'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':d['numPendingTests']}
  results.append(result);print(json.dumps(result),flush=True)
  assert r.returncode!=0 and d['numFailedTests']>=1
 finally:p.write_bytes(original)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
