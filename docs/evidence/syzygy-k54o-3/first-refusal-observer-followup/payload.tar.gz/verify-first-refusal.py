"""Exercise the frozen candidate in the disposable verification clone only."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import tempfile
import time

home = Path('/home/orca/.tmp/f3-native-admission-fixes')
candidate = home / 'first-refusal-composition-candidate'
root = Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
out = home / 'first-refusal-focused-R1'
out.mkdir(exist_ok=False)
binding = json.loads((candidate / 'bindings.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == binding['base']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
for row in binding['files']:
    target = root / row['path']
    assert sha(target.read_bytes()) == row['baseSha256']
    raw = (candidate / 'candidate' / row['path']).read_bytes()
    assert sha(raw) == row['candidateSha256']
    target.write_bytes(raw)
scratch = Path(tempfile.mkdtemp(prefix='f3-v-', dir='/home/orca/.tmp'))
scratch.chmod(0o700)
env = os.environ.copy()
env.update(TMPDIR=str(scratch), VITEST_MAX_THREADS='1', VITEST_MIN_THREADS='1',
           VITEST_MAX_FORKS='1', VITEST_MIN_FORKS='1')
commands = [
    ('typecheck', ['npm', 'run', 'typecheck', '--', '--pretty', 'false']),
    ('product-unit', ['node', 'node_modules/vitest/vitest.mjs', 'run', '--project', 'unit',
                      'packages/polaris-dossier/src/url-design-product.test.ts',
                      '--reporter=default', '--reporter=json', '--outputFile=' + str(out / 'product-unit.json')]),
    ('store-observer-integration', ['node', 'node_modules/vitest/vitest.mjs', 'run', '--project', 'integration',
                                   'packages/polaris-dossier/src/url-machine-store.test.ts',
                                   'packages/polaris-dossier/src/url-run-composed.test.ts',
                                   '--testNamePattern=protected URL machine lifecycle files|bounded restoration observer',
                                   '--reporter=default', '--reporter=json', '--outputFile=' + str(out / 'store-observer-integration.json')]),
]
results = {'base': binding['base'], 'candidateFiles': binding['files'],
           'candidatePatchSha256': binding['patchSha256'], 'clone': str(root), 'scratch': str(scratch),
           'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands': []}
for name, command in commands:
    began = time.monotonic()
    with (out / (name + '.log')).open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    record = {'name': name, 'command': command, 'exit': process.returncode,
              'elapsedSeconds': time.monotonic() - began, 'logSha256': sha((out / (name + '.log')).read_bytes())}
    results['commands'].append(record)
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
