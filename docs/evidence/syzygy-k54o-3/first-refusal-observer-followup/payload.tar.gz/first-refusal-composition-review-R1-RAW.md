PASS

Fresh independent SOURCE review R1 — first-refusal composition

[Inferred] PASS for the frozen five-file source candidate within the requested review scope. No actionable revision finding identified. This verdict is a source review, not an execution, performance, recovery, or gate-pass claim.

Scope and binding

[Observed] Reviewed /home/orca/.tmp/f3-native-admission-fixes/first-refusal-composition-candidate, using baseline 22662df725480fa50e547bd28d361760ff5df944 in /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w. Git object reads confirmed the five baseline file bodies are byte-identical at runtime baseline 9c878b13f5ea7b819b4817517c675810d4b0f23c. Scripted SHA-256 verification matched each candidate and baseline binding. Independently generated the complete five-file unified diff in memory and compared it byte-for-byte with candidate.patch. A second SHA-256 sweep using sha256sum matched the candidate hashes at review completion.

[Observed] Candidate SHA-256 bindings, paths relative to candidate/:

- packages/polaris-dossier/src/url-machine-store.ts: 5a926ed31da2cbc5bb631b5a0a061e5d41e2e034dd1cafdf6b8f4215fe3b754a
- packages/polaris-dossier/src/url-machine-store.test.ts: a7661ccafd624b06ae33bf95cc59d3c4952210ccfb4f0317932458830ef8e58a
- packages/polaris-dossier/src/url-design-product.ts: 2e5b5f3c67b42d5e262827bd4c70e02f272b58548a9d426b7f1da83fb9391e79
- packages/polaris-dossier/src/url-design-product.test.ts: 8f1ed9883b767b86a7958bc85e789ccee9b0d01bba946079487fd3d1b9358935
- packages/polaris-dossier/src/url-run-composed.test.ts: 0cc7d0baeba24550d4133168a273c223273f1f0435fb0d05f3c875f7dcbe25cd

[Observed] Other frozen artifact hashes:

- bindings.json: ab8de090050c83f0eb05a21c60051b8b6abccb5f038a697442fbd7164f884d81
- candidate.patch: 77de920ed66c24bbbd4b6d0748c31785a2c5ba6c07f7b0c1837fd4d5137d6e7f
- parse-only.json: ef0a11798dff14bf821c819d9cb89c942b153cbe8149fe667263c5093a9bd696

[Observed] Read the baseline AGENTS.md, the engineering-bar and test-rigor skills, and the narrowly relevant adopted engineering, testing, review, observability, and trust-and-evidence text. Governing expectations include CC-BAR-1's canonical bar, CC-TEST-1 ("A defect fix includes a test that fails on the pre-fix behavior and passes on the fixed behavior"), CC-TEST-2's retained-evidence distinction, and the doctrine statement "An LLM assertion is Inferred, never Observed". Repository operating instructions were used as procedure, not cited as authority. Prior review verdicts were not used.

Store guard metadata

[Inferred] url-machine-store.ts:455–485 retains the original short-circuit order: active check; optional staging.current() call; clock(); comparison to the operation deadline; performance.now() only if that deadline comparison passes; comparison to the original operationMilliseconds. Splitting the original disjunction does not add a successful-path clock or authority sample. The same refused() construction and outer fail-closed handling remain. The new observer runs only after the selected guard has already failed, with exceptions caught locally. refusalReported is set before observer invocation, preventing a throwing or synchronously reentering observer from reporting that held operation again.

[Inferred] url-machine-store.ts:680–700 retains the original Promise.race inputs, timer registration location, sample order, delay expression, uncertain/active state changes, refusal rejection, catch result, and cleanup. The stored elapsed and remaining values are the timer-scheduling samples, not a claim about firing time or which bound won. The comment states this limit. No timer or lease duration was increased.

[Observed] The refusal payload construction contains only closed phase/reason values and numeric bound/sample fields; it includes no path, subject, body, binding, capability, or raw error. The object is frozen. Sampling exceptions and non-selected refusal sites remain outside this narrowly named diagnostic; the API does not claim to explain every store failure.

Product inspection

[Inferred] url-design-product.ts:288–345 preserves the original conjunction's call and await sequence: current(); optional awaited sample/current(); stable(); awaited rendererCurrent(); current() or awaited sample/current(); stable(); current(); materialize(); final current(). Each short-circuit exits at the same predicate. The catch still assigns retired, and terminateProduct still removes the same entry with the same cause. Using its existing returned termination exposes the actual terminal classification without another authority or clock sample.

[Observed] inspectUrlDesignProduct retains its public two-argument signature. The callback is attached to ProductEntry during validation, selected only for inspection, and invoked after termination. Its payload is phase, termination, and the previously recorded deadline or null. It receives no source material or error. The callback invocation is inside a separate try/catch. The no-entry early return has no retained observer; inert reads and synchronous rechecks do not start emitting inspection diagnostics.

[Inferred] A thrown synchronous diagnostic callback cannot replace a successful value, original refusal/null outcome, or terminal classification at either new production seam. This statement is scoped to the documented trusted synchronous callback contract; it is not a claim about arbitrary host code that deliberately mutates unrelated authority.

Composition and bounded retention

[Observed] url-run-composed.test.ts:493–500 installs the product callback without another product inspection. The AsyncLocalStorage frame receives at most one inspection refusal, with three explicitly selected fields; the previous callback receives the original refusal object. Validation wiring at 2380–2384 calls the captured original validate exactly once and returns its original promise. Cold preparation at 2486 onward remains the existing scenario and production call path.

[Observed] Store wiring at 3053–3069 retains the currentAsync wrapper's existing calls and promise observer. New store metadata retains the first 32 records plus an omitted count and an observation timestamp, and forwards the original record to any existing onRefusal. The production callback boundary catches a throwing downstream observer. No additional authority check or filesystem/network/provider call is introduced by this wiring. The responseStopReason addition copies a closed enum from the existing response-admitted record; url-ordered-design-audit.ts:45–46 declares tool_use/end_turn, and its reader validates the response payload before the writer's protected append.

[Inferred] No cache is promoted to authority, and the candidate does not remove or bypass a guard. The reviewed changes concern diagnostics and test-observer retention. The existing four composed scenarios and existing timeout values are retained.

Four FileHandle spy histories

[Observed] The only production-bound call sites of withoutObserverHistory are the read/write/sync/stat prototype spies installed together at url-run-composed.test.ts:1278–1286. The helper at 1212–1215 uses synchronous try/finally and does not await, replace a return, wrap a promise, or catch/replace the original error. The same original.apply(this, args) call and observeAppendStage wrapper remain.

[Observed] Inspected installed @vitest/spy 3.2.7 and tinyspy 4.0.4 directly, not a remembered or web-documented implementation. Source bindings:

- node_modules/@vitest/spy/dist/index.js: 601f8723b3673fea5b7ab54d599c29bdd94a4aaf22888681d41375d4b554fe1e
- node_modules/tinyspy/dist/index.js: 1694395db833db3892ddbdac83d9614ff3b5bdc63cd78b70d653a4f7ba0460d6
- node_modules/@vitest/spy/package.json: 71c7a2a0b747125cf83aad2009eb40b9ba4b28d0866406178ee4cd131bb0238b
- node_modules/tinyspy/package.json: 7e78b77f1d3ca418c431900bb94b650482f2d010d0943e51f39674d34092c4ce

[Observed] @vitest/spy/dist/index.js:91–109 records receiver/order before implementation and mockClear resets state, instances, contexts, and invocations. Implementation removal occurs separately in mockReset at 111–115. tinyspy/dist/index.js:23–24 resets calls/results/resolves, and 44–55 captures p = results.length before invoking the implementation, rethrows the same synchronous error, attaches settlement handlers to an original native Promise, appends the result after implementation returns, and returns that original promise/value.

[Inferred] For these native FileHandle promises, synchronous clearing leaves one final result entry and empty argument/receiver/order history. Pending calls write settlement results using their already captured p, which is 0 for an initially empty history or 1 after the preceding completed wrapper call. Multiple unresolved promises therefore overwrite at most the two settlement slots rather than accumulating a slot per operation. Ordinary synchronous reentry during invoke also preserves this bound: nested invocations finish and clear before the outer finally clears again; the outermost result is appended afterward. The helper adds no new settlement listener or continuation. This is a bound on retained spy-history entries, not a measured byte or latency bound.

[Observed] Swept the complete 3,347-line composed file for prototype/FileHandle references and mock history access using rg, then independently enumerated literal occurrences in Python. The four prototype references are the unrelated Object.prototype reader check at 613 and this installation at 1279/1282/1283. The 15 .mock. accesses occur at 1936–1941, 1946, 1969 (the new separate local boundary spy), 2229 and 2301 (audit/append fixtures), 2479/3113/3144 (claim spies), and 2775/3263 (ordered begin spies). The two vi.mocked calls are session launch boundaries at 1147/1163. The FileHandle spy variable remains local to its installation. There is no history consumer of those four spies in this file. afterEach at 224–237 restores mocks, and the inspected Vitest setup/config adds no generic mock-history consumer. This absence claim is limited to this test file and its installed setup, rather than unrelated tests or arbitrary future harnesses.

Test quality and retained scope

[Observed] Reviewed the complete patch, including each changed assertion block. A separate removed-line sweep found no removed expect(...) line across the five-file patch; direct diff review confirmed the previous assertions and four composed scenario entries remain. Existing tests are extended for expiry, staging-current refusal, timer refusal, immutable metadata, observer failure isolation, and inspection classification. There are no newly declared test blocks in the diff. The product parameter table gains one concrete case, renderer exception, so the case-count delta is +1; the observer identity/history exercise extends an existing local test and adds no native scenario.

[Inferred] The renderer-exception case earns that increase under test-rigor rule 10: a rejected renderer promise reaches the exception catch, distinct from a renderer returning false. It would catch a regression that classifies that exception as renewable expiry after the clock crosses the deadline, or reports its phase as a normal renderer refusal. Existing final retired-state and refresh-not-called assertions remain, so the diagnostic assertion does not replace the behavior assertion.

[Inferred] The local history exercise at 1923–1970 protects the installed-spy seam against dropped clearing, wrong promise/value identity, receiver loss, changed fulfillment/rejection values, and replaced synchronous errors. Its 40 overlapping promises are worthwhile because a sequential-only test would miss late settlement repopulation. Synchronous reentry is assessed from installed source here, not claimed as an executed fixture.

Limitations

[Unknown] Native timing, memory savings, completed native performance/recovery, typecheck, test execution, and mutation-test results for this composition remain Unknown. No tests, typecheck, build, runtime helper, capture, native process, network call, or provider call was run during this review. The retained parse-only artifact was inspected as supplied report content and was not promoted into an executed verification claim. Only static source reads, git object reads, textual comparisons, and digest checks were performed; no candidate or primary source was edited.

[Inferred] No identified risk floor is weakened by these source changes. The diagnostic payload restrictions preserve the security boundary, and this source verdict grants no release/deployment permission or native-success status. Subsequent verification remains necessary under CC-TEST-1/2 and CC-BAR-2. Any later byte change must be noted beside this digest-bound report.
