Verdict: PASS

[Observed] Review scope: fresh, source-only independent review of machine-peer-bytes-scratch-preparation-c245-R2, subject/base c245385ae2c5d043f4f14b13b14e92ad7fd40b3a. This verdict binds only the bytes below. The candidate product and test bytes match the current uncommitted files in /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w at review time. No product edits, execution, tests, builds, compilation, recovery probes or performance measurements were performed. Only source/declaration reads, static source comparison/counting and scripted hashing were performed; this raw review was created outside the preparation directory and is not to be overwritten.

Frozen subject SHA-256 bindings

- candidate/packages/polaris-dossier/src/url-machine-peer.ts: 031ced551de6c59d9227a0de4e584a2c5cf0b9db2e472540aaf1994019e682bd (39,191 bytes).
- candidate/packages/polaris-dossier/src/url-machine-peer.test.ts: bc7bd1fc28709d48e779feec0da35b0b459f4e3486c8a3f2dbfdc5577f113960 (37,825 bytes).
- original/packages/polaris-dossier/src/url-machine-peer.ts: 9cc616fa96ca062b9a0a012c1a4df6f7f0659a770946d490f996934696644804 (38,532 bytes).
- original/packages/polaris-dossier/src/url-machine-peer.test.ts: 599b15e9ec04e1ffed3ca63cf69f6e645064a3d43c9201e3265832a553f9da3e (35,541 bytes).
- candidate.patch: 3da35c168f5a0fbaa1e6c6da940ec4b7e7bf843128e9f04e7593a5b1b3b63fd2 (7,229 bytes).
- bindings.json: 17b40d016bf8c0f7cba7e4ce9f702ead95de8f9845f55d0069769d1d541b56ed.
- PREPARATION.md: 103bdd84d2c0d517f318c64b592f33171615a37f87fca16d6a6520f473d7c364.

Source findings and acceptance assessment

[Inferred] PASS for scratch ownership and bounds (product lines 96–123). The pool has a single module-private idle slot. A borrower clears it before its first read. Reentrant reads cannot borrow the active outer buffer; their returned idle buffer competes with the outer scratch by length, retaining one largest idle buffer. The call-site population is sample/stat (maximum 8192), check/mountinfo and check/cmdline (maximum 2097152), and capture/mountinfo (maximum 2097152); therefore retained scratch is at most 2097153 bytes. There is no public scratch export or additional cache/authority state.

[Inferred] PASS for exact read semantics. The borrowed backing buffer is viewed as subarray(0, maximum + 1), retaining the old maximum-plus-one request ceiling even when a smaller read borrows the largest buffer. The loop retains the original offset, remaining-count request, null position, zero-count EOF break, length accumulation and greater-than-maximum refusal. Open flags and open placement are unchanged. Descriptor close is attempted in finally before the inner finally can return scratch to the pool, including read, copy and refusal failures. No subsequent filesystem read is replaced by retained bytes. The new Buffer.alloc(length) plus bounded copy returns an exact-length independent buffer, excluding stale trailing bytes. Deadline, identity, namespace, command, mount, policy, authority and native-helper predicates outside bytesAt are unchanged by the product diff. Authentication/security code is touched; its security floor is preserved rather than weakened.

[Observed] The two source versions each contain 12 direct it declarations and six it.each matrices, with cardinalities 2, 4, 2, 2, 2, 3: 18 declarations expanding to 27 runtime cases. This count was inspected by declaration enumeration and independently computed from source. Test titles and matrix inputs are unchanged. The changed genuine lifecycle case retains the original admission, forged-peer rejection, denied write, single successful audited effect and revocation assertions. Its original successful boundary assertion remains and is exercised twice. No additional test declaration was introduced.

[Inferred] PASS for meaningful alias regression protection (test lines 476–528). The filesystem observer forwards to actual.readSync before invoking its callback. During an actual mountinfo read, it invokes the actual mediation boundary once recursively; active scratch sharing would corrupt the outer mountinfo bytes and invalidate the real boundary/hash result. The Buffer.equals observer identifies and retains the actual cmdline return receiver with a copied baseline. A following real stat read compares that retained return against the baseline, so returning pooled storage would expose later scratch corruption. Assertions require reentry, nested authorization, small/large view sizes and the post-return ownership check to occur. The callback is cleared and the spy restored in finally; afterEach also clears the callback. These are source-level adequacy judgments, not mutation-run results.

[Inferred] PASS for plausibility of the R2 static type correction. The typed variable comparison: Pick<Buffer, 'equals'> references the same actual Buffer.prototype object; it is not a copied object or replacement receiver. originalEquals is captured before spying, and both the predicate and delegated call retain their actual this and arguments. The installed @types/node/buffer.d.ts declares equals(otherBuffer: Uint8Array): boolean. The installed @vitest/spy/dist/index.d.ts derives Methods<T> from callable properties and spyOn<T, M> yields MockInstance<T[M]> for this ordinary method; mockImplementation uses Parameters<T> and ReturnType<T>. The explicit Pick therefore provides a concrete callable equals property and fits the implementation accepting Uint8Array and returning boolean, while avoiding the reported any receiver inference. This reasoning does not claim compilation PASS.

Governing references

[Observed] Read and applied the adopted engineering/testing/security policies and security doctrine; the source-only scope cannot establish CC-BAR-2's completed verification. CC-TEST-2: “A report is a report fact.” CC-TEST-1: “A defect fix includes a test that fails on the pre-fix behavior and passes on the fixed behavior”. SEC-1: “Loopback location alone never proves a client's identity.” SEC-5: “Secrets are never indexed.” No owner-class security relaxation is present in this patch.

Reference SHA-256 values:
- .syzygy/governance/policies/craft-and-care/engineering-bar.md: 7427a66662976a287648731e724fa454ece3ea683767b99f01e8637dc87e1ce6.
- .syzygy/governance/policies/craft-and-care/testing-and-verification.md: 8157c0c63ff27341365c9c29e0f620bd7eb7b986fd40432e9c5a30891d3e0782.
- .syzygy/governance/policies/craft-and-care/security-and-secrets.md: 8fa55e65daaf95eb26dc476f70eb2a30fd5e744e92982a4533f374257a7120c8.
- .syzygy/governance/doctrine/security.md: 9d3f46528e37143ae1d63c755c7a50c6a5b139d28bef5c9de45d62b5c1ac71bf.

Limitations

[Unknown] R2 runtime, compilation and mutation outcomes remain unexecuted in this review. R1 owning-case success and TS2769 failure are reported preparation facts, not newly established gate evidence. The task-provided recovery status remains 600s FAIL; this source verdict supplies no recovery success or speed claim. Fresh authorized validation of these exact R2 bytes is still required. No blocking source finding was identified within the stated acceptance scope.
