[Observed] R2 preparation only; no operator/product command executed here. R1 and its terminal receipts remain untouched. R1 owning27/27 passed but shared typecheck failed TS2769; it is not a complete positive baseline.

Subject base c245385ae2c5d043f4f14b13b14e92ad7fd40b3a with exactly the two reviewed unstaged R2 files; no staged/untracked changes. Product031ced55 unchanged. R2 corrects only the spy receiver static type; candidate-bindings.json and external R2 preparation originals/candidates/patch are fully SHA/length bound by manifest.json.

Owning runs original npm run typecheck FIRST; only on success runs the complete integration url-machine-peer.test.ts under the inherited single worker settings. Completion requires both stages plus all27 exact assertions passing, no skips, full source equality and child/TMP cleanup. Frozen names27, declarations18 and matrices[2,4,2,2,2,3] are inherited from R1; r2-title-inheritance.json proves the exact complete-file receiver-only delta and byte-identical literal titles/declarations without another AST sweep.

After fresh review PASS and root GO:

    python3 /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-operators-c245-R2/owning.py --output /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-owning-c245-execution-2

Only after terminal complete:true with R2 typecheck+27/27:

    python3 /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-operators-c245-R2/mutant.py --mutant borrow-exclusion --owning-receipt /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-owning-c245-execution-2/terminal.json --output /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-mutant-c245-execution-1
    python3 /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-operators-c245-R2/mutant.py --mutant owned-copy --owning-receipt /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-owning-c245-execution-2/terminal.json --output /home/orca/.tmp/f3-native-admission-fixes/machine-peer-scratch-mutant-c245-execution-2

Controls remain exact one-fragment mutations of product031: borrow-exclusion and owned-copy. R2 anchors move one line: borrow516/520, owned502/516. Require exactly one intended selected failure and26 selection skips; never treat zero-test/hook/load errors as a kill. Each control requires the same R2 manifest-bound complete positive receipt, preserves other sources, restores candidate exactly, drains owned descendants and removes its private TMP. New outside output must not already exist; output numbering may be increased to another unused exact prefix if necessary. Original command watchdogs and all predicate/read/cap checks remain.

[Unknown] R2 validation/mutant outcomes, performance and full recovery acceptance remain unmeasured by this preparation. No benchmark/proof packaging here.
