# Independent source review

Verdict: PASS

[Inferred] PASS is limited to the frozen source candidate and the acceptance criteria supplied for this review. No actionable source/test-design revision was identified. This is not an execution, typecheck, gate, performance, recovery, adoption, or merge verdict.

## Subject and immutable scope

[Observed] Subject recorded in bindings.json: c245385ae2c5d043f4f14b13b14e92ad7fd40b3a. Preparation directory: /home/orca/.tmp/f3-native-admission-fixes/machine-peer-bytes-scratch-preparation-c245. Review reads the frozen originals, candidate files, candidate.patch, bindings.json and PREPARATION.md; the source acceptance scope is exactly these two files:

| File | Original SHA-256 | Candidate SHA-256 |
|---|---|---|
| packages/polaris-dossier/src/url-machine-peer.ts | 9cc616fa96ca062b9a0a012c1a4df6f7f0659a770946d490f996934696644804 | 031ced551de6c59d9227a0de4e584a2c5cf0b9db2e472540aaf1994019e682bd |
| packages/polaris-dossier/src/url-machine-peer.test.ts | 599b15e9ec04e1ffed3ca63cf69f6e645064a3d43c9201e3265832a553f9da3e | b93746c8539350a92daac2fcdf0ea38b5e31af1a621ada54e74bf845bb20f9a1 |

[Observed] Additional byte bindings recomputed with Python hashlib:

- candidate.patch: 89bed1386853af53cd3090f99b732c5d7eb91efd5e104afc3aaaafcc96b6ebb6
- bindings.json: 9e8fc9b3af24a467b137d93be7bf22f8600aa9814ca7be40bf5659a85836ce57
- PREPARATION.md: d8c460a501085fdab928a43eca29bedaa412bde5a892bd44be5393f241bf76c2

[Observed] Reconstructing a unified diff independently with Python difflib reproduces candidate.patch exactly. The product prefix and suffix outside the added private scratch declaration/comment and bytesAt replacement compare byte-identical; the product export-statement sequence also compares identical. Thus the complete patch, over its two-file denominator, changes no manifest, export map or build-input file. No primary-tree or preparation-directory edits were made.

## Governing references

The following defined clauses were read in /home/orca/orca/projects/syzygy and guide this review:

- SEC-1, .syzygy/governance/doctrine/security.md: “Non-browser agent and CLI clients are admitted only through an explicit machine-client authentication mechanism”.
- RFC5-7(d), .syzygy/governance/contracts/rfcs/RFC-0005/admission-and-boundary.md: “an OS-mediated local channel with kernel-verified peer identity”.
- CC-TEST-2, .syzygy/governance/policies/craft-and-care/testing-and-verification.md: “Gate claims require retained, resolvable gate artifacts”.
- CC-TEST-5, the same file: “Verification scope is declared”.
- CC-PERF-3, .syzygy/governance/policies/craft-and-care/performance-and-visual-discipline.md: “Any claim that a change improves or regresses performance carries a retained measurement artifact with its conditions, or it is labeled [Unknown].”
- trust-and-evidence.md: “An LLM assertion is Inferred, never Observed”.

The engineering-bar and test-rigor skills were applied as review guidance. This review does not adopt any prepared bytes or establish authority from a candidate path/banner.

## Product reasoning

[Inferred] In candidate url-machine-peer.ts:99–121, openSync retains its original flags and occurs before scratch acquisition. Acquisition removes the one idle reference before any readSync can reenter; an active outer scratch is therefore unavailable to the nested check. A smaller idle buffer is discarded in favor of the required allocation. Each completed invocation returns its scratch only after closeSync has been attempted, including when reading, the cap check, result allocation/copy, or close itself throws. A close failure still escapes and overrides a pending success/read error as in the original finally. An open failure borrows nothing.

[Inferred] The read view is always scratch.subarray(0, maximum + 1), including when the retained backing store is larger. The loop still begins at offset zero, requests the remaining view length, uses null position, advances only by the actual count, stops at EOF or the full maximum+1 view, and refuses length > maximum. The source has four calls: sample at 8192, check's mountinfo and cmdline at procBytes, and capture's mountinfo at procBytes. procBytes remains 2,097,152. Existing private callers thus bound a single scratch to 2,097,153 bytes.

[Inferred] Successful results use Buffer.alloc(length) plus a copy of exactly the filled prefix. Neither oversized backing bytes nor stale tails escape, and a later borrower cannot overwrite the owned result. Nested invocations can temporarily own multiple buffers; only one idle buffer survives, selected by largest length, with equal-sized candidates leaving the existing idle buffer. This is a bounded storage-reuse mechanism, not a cache of authority, syscall results or current-check outcomes.

[Inferred] check/current/capture/mediate predicates, process and namespace comparisons, kernel attestation, current store/lease checks, deadlines, audit, installed-image verification, revocation and scope checks are unchanged outside the private read allocation/copy lifecycle. No additional filesystem predicate/read or skipped validation is introduced by product code.

[Observed] PREPARATION.md explicitly states the memory tradeoff: “Module idle memory retention is intentionally up to2MiB+1”. [Inferred] That buffer can survive idle for the module/process lifetime; this review accepts this explicit tradeoff within the supplied scope. It makes no claim about total process memory, active nested memory, GC improvement or allocation throughput.

## Test reasoning

[Observed] Both frozen files contain the same declaration/name sequence: 18 declarations, comprising 12 direct cases and six matrices with sizes 2, 4, 2, 2, 2, 3. This is 27 statically expanded cases in each file, a net declaration/case delta of zero. Direct declaration enumeration and the exact reconstructed diff both establish preservation of the declaration population; these are not runtime result counts.

[Inferred] The existing “captures a genuine isolated descendant and authorizes its scoped effect against actual protected lifecycle files” case retains its old identity/copy rejection, protected publication/read, wrong-scope refusal, permitted effect/result, audit/effect count, and subsequent revocation assertions. The existing positive boundary assertion remains and is invoked twice, inside the same authorized effect.

[Inferred] The fs boundary wrapper (test:29–39) delegates to actual.readSync before invoking afterRead synchronously with its actual count. The lifecycle extension (test:485–521) arms only inside the real mediate effect, resolves each actual descriptor through readlinkSync, and invokes that supplied boundary while an outer mountinfo read is active. The reentered flag is set first, preventing recursive reinvocation. Both nested permission and the outer mediate result must succeed. This exercises nested check(state), including stat/mountinfo/cmdline reads, rather than calling a private helper or substituting filesystem results.

[Inferred] The exact 8193 and 2,097,153 view-length expectations reject handing a large borrowed backing store directly to a small stat read. Removing the idle-buffer exclusion would allow the warmed outer mount buffer to be borrowed by nested reads and overwrite the still-active mount bytes; the nested/outer success requirements make that a meaningful failure scenario. This is a source mutation thought experiment, not an executed mutation result.

[Inferred] commandBytes is copied from the actual cmdline read. The equals spy delegates to the original Buffer.equals and retains the actual production receiver only when its bytes equal that cmdline input; retainedCommand is a separate Buffer.from copy. A later actual stat read compares that retained production result with the independent copy. The checkedOwnedReturn assertion requires this comparison to occur. Returning a scratch-backed subarray would let a later stat overwrite the captured cmdline result and fail the check. The observer therefore checks owned-return stability through the genuine lifecycle rather than proving only that a test-owned copy remains stable. Detection remains unexecuted here.

[Inferred] afterRead is cleared in the local finally and afterEach; equals.mockRestore executes in the local finally when the mediated work or assertions fail. The callback's armed/guard state is also reset by its inner finally. Exceptions swallowed by production mediation still fail the expected successful mediate result, and postconditions require the reentry and retained-byte checks to have occurred.

## Evidence limits and next verification

[Observed] This review ran only source reads and Python text/digest/diff inspection. It ran no product, tests, build, native helper, probe, benchmark or CPU-profile execution. No test/performance/recovery PASS is claimed. [Unknown] Type correctness, actual lifecycle execution, mutation failure controls and before/after performance remain unverified by this review.

[Inferred, coordinator-supplied context only] The earlier 0028 profile's reported 7.584 seconds of sampled FastBuffer leaf attribution to bytesAt motivates bounded investigation; GC and 600-second critical-path attribution remain Unknown. The reported c245 ordinary run reached four forwards and no final assertions before its 600-second failure. This candidate is a bounded repair target, not evidence that those failures are cured. Later performance verification must exercise the genuine peer/current lifecycle with retained measurements; a private read-file microbenchmark would not settle that claim.
