"""Prepared exact paired render capture; imports start no product or command."""
import argparse, ctypes, difflib, fcntl, hashlib, json, os, re, signal, stat, subprocess, sys, tempfile, time
from pathlib import Path, PurePosixPath
HERE = Path(__file__).resolve().parent
BASE = Path('/home/orca/.tmp')
PRIMARY = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
SUBJECT = '1ef23447df5c69fb1418f5c226bf6abd925e15ff'
MAIN = '4b86e4285e7c78ddf049f64c9a3fd95fc0952cf3'
SUBJECT_TREE = '41a2332805a28da913b8454aa1b7793bb1a22bc8'
MAIN_TREE = '512f80e3ccbab7542462ac303a2197302c34ef2e'
RUNTIME = 'packages/polaris-dossier/dist/runtime'
NODE = Path('/home/orca/.nvm/versions/node/v24.6.0/bin/node')
sha = lambda data: hashlib.sha256(data).hexdigest()


def git_at(root, *args):
    return subprocess.check_output(['git','-C',str(root),*args])

def require(ok, reason):
    if not ok: raise RuntimeError(reason)

def checkpoint(out, name, value):
    temporary = out / (name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temporary, out / name)

class Interrupted(Exception): pass

def interrupt(sig, frame): raise Interrupted(str(sig))

def drain(child, reaped):
    if child is not None:
        if child.poll() is None:
            try: os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError: pass
            try: child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                if child.poll() is None:
                    try: os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                child.wait(timeout=5)
        else: child.wait()
    deadline = time.monotonic() + 10; sent = {}
    while True:
        try: pid, status_ = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError: return True
        if pid:
            reaped.append({'pid': pid, 'status': status_}); continue
        # These are unreaped children of this operator/subreaper; reserved PIDs
        # are checked with waitpid again before any signal is sent.
        for raw in Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text().split():
            pid = int(raw)
            try: got, status_ = os.waitpid(pid, os.WNOHANG)
            except ChildProcessError: continue
            if got: reaped.append({'pid': got, 'status': status_}); continue
            now = time.monotonic()
            try:
                if pid not in sent: os.kill(pid, signal.SIGTERM); sent[pid] = now
                elif now - sent[pid] >= .25: os.kill(pid, signal.SIGKILL)
            except ProcessLookupError: pass
        require(time.monotonic() < deadline, 'owned-descendant-drain-deadline')
        time.sleep(.01)

def snapshot_at(root):
    require(root.resolve(strict=True) == root,'source-root-alias-refused')
    paths = sorted(set(git_at(root, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').split(b'\0')) - {b''})
    rows = []
    for raw in paths:
        name = os.fsdecode(raw); p = root / name
        require(p.parent.resolve(strict=True) == p.parent and root in p.parents,'source-parent-alias-refused:' + name)
        try:
            first = p.lstat()
        except FileNotFoundError:
            rows.append({'path': name, 'state': 'missing'}); continue
        if stat.S_ISLNK(first.st_mode):
            data = os.fsencode(os.readlink(p)); kind = 'symlink'
        elif stat.S_ISREG(first.st_mode):
            data = p.read_bytes(); kind = 'file'
        else:
            raise RuntimeError('unexpected-source-kind:' + name)
        second = p.lstat()
        require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns, first.st_ctime_ns) ==
                (second.st_dev, second.st_ino, second.st_size, second.st_mtime_ns, second.st_ctime_ns), 'source-changed-during-snapshot:' + name)
        rows.append({'path': name, 'state': kind, 'mode': stat.S_IMODE(second.st_mode), 'bytes': len(data), 'sha256': sha(data)})
    return {'head': git_at(root, 'rev-parse', 'HEAD').decode().strip(),
            'status': git_at(root, 'status', '--porcelain=v1', '-z', '--untracked-files=all').decode(),
            'population': len(rows), 'rows': rows,
            'rowsSha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}

def regular_bytes(path):
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode), 'bound-file-not-regular:' + str(path))
    data = path.read_bytes(); second = path.lstat()
    require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns, first.st_ctime_ns) ==
            (second.st_dev, second.st_ino, second.st_size, second.st_mtime_ns, second.st_ctime_ns), 'bound-file-read-drift:' + str(path))
    return data

def file_row(root, name):
    relative = PurePosixPath(name)
    require(isinstance(name, str) and str(relative) == name and relative.parts and not relative.is_absolute()
            and all(part not in ('', '.', '..') for part in relative.parts) and '\\' not in name, 'unsafe-bound-relative-path')
    path = root / name
    require(root.resolve(strict=True) == root and path.parent.resolve(strict=True) == path.parent and root in path.parents, 'bound-file-parent-alias')
    data = regular_bytes(path)
    return {'path': name, 'bytes': len(data), 'sha256': sha(data)}

def ignored_runtime_snapshot(root):
    directory = root / RUNTIME
    if not directory.exists():
        require(not directory.is_symlink(), 'runtime-root-dangling-link')
        return {'state': 'absent'}
    require(directory.resolve(strict=True) == directory and directory.is_dir(), 'runtime-root-alias')
    rows = []
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), 'runtime-link-refused')
        if path.is_dir():
            rows.append({'path': str(path.relative_to(directory)), 'state': 'directory', 'mode': stat.S_IMODE(path.stat().st_mode)})
        else:
            row = file_row(directory, str(path.relative_to(directory))); row.update(state='file', mode=stat.S_IMODE(path.stat().st_mode)); rows.append(row)
    return {'state': 'directory', 'mode': stat.S_IMODE(directory.stat().st_mode), 'rows': rows,
            'rowsSha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}

def source_inputs():
    inputs = json.loads((HERE / 'input-bindings.json').read_text())
    source = Path(inputs['redis']['path'])
    require(git_at(source, 'rev-parse', 'HEAD').decode().strip() == inputs['redis']['commit'], 'Redis-head-binding')
    require(not git_at(source, 'status', '--porcelain=v1', '-z', '--untracked-files=all'), 'Redis-must-remain-clean')
    listing = git_at(source, 'ls-tree', '-r', '-l', '-z', '--full-tree', 'HEAD')
    require(sha(listing) == inputs['redis']['treeListingSha256'] and listing.count(b'\0') == inputs['redis']['entries'], 'Redis-metadata-binding')
    for key in ('config', 'draft'):
        row = inputs[key]; raw = regular_bytes(Path(row['path']))
        require(sha(raw) == row['sha256'] and len(raw) == row['bytes'], 'frozen-input-binding:' + key)
    return inputs

def sealed_preflight(subject):
    require(subject == SUBJECT, 'explicit-fixed-subject-required')
    manifest_raw = regular_bytes(HERE / 'preparation-manifest.json'); manifest = json.loads(manifest_raw)
    for row in manifest['files']:
        raw = regular_bytes(HERE / row['path'])
        require(sha(raw) == row['sha256'] and len(raw) == row['bytes'], 'sealed-packet-drift:' + row['path'])
    for row in manifest['externalBindings']:
        raw = regular_bytes(Path(row['path']))
        require(sha(raw) == row['sha256'] and len(raw) == row['bytes'], 'historical-binding-drift')
    require(git_at(PRIMARY, 'rev-parse', 'HEAD').decode().strip() == subject, 'primary-exact-head')
    require(not git_at(PRIMARY, 'status', '--porcelain=v1', '-z', '--untracked-files=all'), 'primary-must-be-clean')
    require(git_at(PRIMARY, 'rev-parse', SUBJECT + '^{tree}').decode().strip() == SUBJECT_TREE, 'subject-tree-binding')
    require(git_at(PRIMARY, 'rev-parse', MAIN + '^{tree}').decode().strip() == MAIN_TREE, 'main-tree-binding')
    bindings = json.loads((HERE / 'source-bindings.json').read_text())
    require(len(bindings['rows']) == 23, '23-named-source-population')
    for row in bindings['rows']:
        for key, commit in [('main', MAIN), ('subject', SUBJECT)]:
            expected = row[key]
            result = subprocess.run(['git', '-C', str(PRIMARY), 'cat-file', 'blob', commit + ':' + row['path']], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            if expected['state'] == 'absent': require(result.returncode != 0, 'named-absence-binding')
            else: require(result.returncode == 0 and sha(result.stdout) == expected['sha256'] and len(result.stdout) == expected['bytes'], 'named-source-binding:' + key + ':' + row['path'])
    require(not any(name in os.environ for name in ('NODE_OPTIONS', 'NODE_PATH')) and not any(name.startswith('SYZYGY_') for name in os.environ), 'inherited-product-override-refused')
    for row in manifest['toolIdentities']:
        path = Path(row['requestedPath']).resolve(strict=True); raw = regular_bytes(path)
        require(str(path) == row['path'] and len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'tool-identity-binding')
    verify_bound_runtime()
    return manifest, source_inputs()

def verify_bound_runtime():
    # Bind the unchanged observed cd78 build inputs on the exact successor; never treat it as either
    # future capture clone's native closure or force a historical input count.
    bound = json.loads(regular_bytes(HERE / 'runtime-evidence.json'))
    raw = regular_bytes(PRIMARY / RUNTIME / 'manifest.json')
    require(sha(raw) == bound['manifest']['sha256'] and len(raw) == bound['manifest']['bytes'], 'observed-primary-runtime-manifest-drift')
    actual = json.loads(raw)
    for population, root in [('inputs', PRIMARY), ('files', PRIMARY / RUNTIME)]:
        rows = actual[population]
        require(len({row['path'] for row in rows}) == len(rows), 'observed-runtime-duplicate-path')
        for row in rows:
            require(file_row(root, row['path']) == row, 'observed-primary-runtime-byte-drift:' + row['path'])

def inventory(directory):
    require(directory.resolve(strict=True) == directory and directory.is_dir(), 'artifact-root-alias')
    require(not any(path.is_symlink() for path in directory.rglob('*')), 'artifact-symlinks-refused')
    paths = sorted(str(path.relative_to(directory)) for path in directory.rglob('*') if path.is_file())
    independent = sorted(os.fsdecode(raw)[len(str(directory)) + 1:] for raw in subprocess.check_output(['find', str(directory), '-type', 'f', '-print0']).split(b'\0') if raw)
    require(paths == independent, 'independent-artifact-path-census')
    return [file_row(directory, name) for name in paths]

def capture_receipt(out, arm, commit, tree, inputs):
    checkout = out / arm; result = out / (arm + '-capture')
    require(git_at(checkout, 'rev-parse', 'HEAD').decode().strip() == commit and git_at(checkout, 'rev-parse', 'HEAD^{tree}').decode().strip() == tree, 'capture-exact-commit-tree')
    require(not git_at(checkout, 'status', '--porcelain=v1', '-z', '--untracked-files=all'), 'capture-source-drift')
    reports = {stage: json.loads(regular_bytes(result / (stage + '.json'))) for stage in ('init', 'brief', 'check', 'render')}
    for stage, expected in [('init', 'initialized'), ('brief', 'issued'), ('check', 'passed'), ('render', 'rendered')]:
        require(reports[stage]['outcome'] == expected, 'actual-stage-refusal:' + arm + ':' + stage)
    rendered = reports['render']; run = Path(rendered['run']); site = Path(rendered['site'])
    require(run.parent == result / 'state' and run.name.startswith('run-') and site == run / 'site/0', 'capture-run-site-location')
    require(all(report['run'] == str(run) for report in reports.values()), 'one-run-across-actual-stages')
    require(rendered['draftRevision'] == 0 and rendered['designReview']['counts'] is False and rendered['fidelityReview']['counts'] is False, 'uncounted-revision-zero-capture')
    require(sha(regular_bytes(run / 'drafts/rev-0.json')) == inputs['draft']['sha256'], 'whole-checked-draft-binding')
    record = json.loads(regular_bytes(run / 'run.json'))
    require(record['subject']['pinnedRevision']['commit'] == inputs['redis']['commit'], 'run-Redis-revision-binding')
    policy = next(row for row in json.loads((HERE / 'obligations.json').read_text())['policies'] if row['arm'] == ('main' if commit == MAIN else 'subject'))
    actual_policy = record['subject']['screeningPolicy']
    expected_policy = {'path': policy['selectedPath'], 'commit': commit, 'policyId': policy['policyId'], 'policyVersion': policy['policyVersion'], 'sha256': policy['sha256']}
    require(actual_policy == expected_policy, 'actual-selected-policy-run-binding')
    obligations = json.loads((HERE / 'obligations.json').read_text())
    machine = json.loads(regular_bytes(site / 'machine.json')); disclosures = machine['disclosure']
    require(len({row['id'] for row in disclosures}) == len(disclosures), 'machine-disclosure-identities')
    by_id = {row['id']: row for row in disclosures}; arm_key = 'main' if commit == MAIN else 'subject'
    for identity in ('mode', 'source-screening-boundary'):
        require(by_id[identity] == obligations['disclosures'][arm_key][identity], 'actual-source-backed-machine-disclosure')
    require('effectiveRun' not in machine, 'operator-capture-has-no-URL-effectiveRun')
    companion = run / 'raw-read-disclosure.json'
    require(not (site / 'raw-read-disclosure.json').exists(), 'raw-companion-is-run-root-only')
    if commit == MAIN:
        require(not companion.exists() and 'raw-read-disclosure' not in by_id, 'main-has-no-F3-companion')
    else:
        sidecar = json.loads(regular_bytes(companion))
        require(set(sidecar) == {'schemaVersion', 'runId', 'declaredProvider', 'authorHandoff'}
                and sidecar['schemaVersion'] == 'polaris-dossier-raw-read-disclosure/1' and sidecar['runId'] == run.name
                and sidecar['declaredProvider'] == record['declared']['agentProvider'] and sidecar['authorHandoff'] == 'unknown', 'actual-raw-companion-unknown-handoff')
        require(by_id['raw-read-disclosure'] == obligations['rawReadItem'], 'actual-Unknown-raw-read-risk-disclosure')
    site_rows = inventory(site); run_rows = inventory(run)
    html = [row['path'] for row in site_rows if row['path'].endswith('.html')]
    require(rendered['pages'] == len(html), 'actual-render-report-HTML-census')
    size = json.loads(regular_bytes(site / 'size-report.json')); dossier = json.loads(regular_bytes(site / 'dossier.json'))
    measured = [row['path'] for row in size['pages']]
    require(len(set(measured)) == len(measured) and set(measured) == set(html) - {'size-report.html'}, 'actual-measured-page-population')
    require({row['path'] for row in dossier['pages']} == set(measured), 'actual-dossier-page-manifest')
    # The native URL runtime is not built by the ordinary static-render recipe.
    # Report only a manifest actually present; never import or fabricate its old closure.
    runtime_manifest = checkout / RUNTIME / 'manifest.json'
    runtime = {'state': 'absent', 'closure': 'Unknown'}
    if runtime_manifest.exists():
        raw = regular_bytes(runtime_manifest); m = json.loads(raw)
        runtime = {'state': 'present-unverified-runtime', 'sha256': sha(raw), 'bytes': len(raw), 'declaredInputs': len(m['inputs']), 'declaredOutputs': len(m['files']), 'closure': 'Unknown; runtime inputs/outputs not verified by this static capture'}
    return {'commit': commit, 'tree': tree, 'checkout': str(checkout), 'run': str(run), 'site': str(site), 'stageOutcomes': {key: value['outcome'] for key, value in reports.items()},
            'siteFiles': site_rows, 'runFiles': run_rows, 'populations': {'siteFiles': len(site_rows), 'htmlFiles': len(html), 'measuredPages': len(measured), 'numericMetricCells': 'Unknown; raw HTML/JSON retained for a separately reviewed actual-cell census'},
            'policyBinding': actual_policy, 'runtime': runtime, 'uncountedDesignFidelity': True, 'numericMasking': False, 'sourceEffectAttribution': 'ATTRIBUTION_REQUIRED'}

def pair_inventory(out, arms):
    left, right = arms
    by_arm = [{row['path']: row for row in arm['siteFiles']} for arm in arms]
    paths = sorted(set(by_arm[0]) | set(by_arm[1])); changed = []; patch = []
    for name in paths:
        before, after = by_arm[0].get(name), by_arm[1].get(name)
        if before == after: continue
        changed.append({'path': name, 'before': before, 'after': after, 'disposition': 'ATTRIBUTION_REQUIRED'})
        a = b'' if before is None else regular_bytes(Path(left['site']) / name)
        b = b'' if after is None else regular_bytes(Path(right['site']) / name)
        try:
            delta = difflib.unified_diff(a.decode('utf8').splitlines(keepends=True), b.decode('utf8').splitlines(keepends=True), fromfile='main/' + name, tofile='subject/' + name)
            for line in delta:
                patch.append(line if line.endswith('\n') else line + '\n\\ No newline at end of file\n')
        except UnicodeDecodeError:
            patch.append('Binary difference retained as original captured bytes: ' + name + '\n')
    (out / 'all-site-byte-differences.patch').write_text(''.join(patch))
    return {'state': 'ATTRIBUTION_REQUIRED', 'currentMainEquivalenceClaim': False, 'syntheticExpectedSiteCreated': False, 'normalizationApplied': False,
            'sitePathDifference': {'mainOnly': sorted(set(by_arm[0]) - set(by_arm[1])), 'subjectOnly': sorted(set(by_arm[1]) - set(by_arm[0]))},
            'changedSiteFiles': changed, 'sitePathPopulation': len(paths), 'runPathDifference': {'mainOnly': sorted({r['path'] for r in left['runFiles']} - {r['path'] for r in right['runFiles']}), 'subjectOnly': sorted({r['path'] for r in right['runFiles']} - {r['path'] for r in left['runFiles']})},
            'requiredNext': 'Complete human/machine/raw-read/Unknown/glossary/review/source-line and numeric-cell verification plus exact source-effect dispositions on these frozen actual outputs. Historical parsers remain separate; no denominator or CSS normalization is accepted here.'}

def execute():
    parser = argparse.ArgumentParser(description='Exact root-owned paired static capture; fresh source review and released heavy slot required.')
    parser.add_argument('--subject', required=True); parser.add_argument('--output', required=True)
    parser.add_argument('--heavy-slot-released', action='store_true', required=True)
    args = parser.parse_args(); out = Path(args.output).absolute()
    require(out.parent == BASE and out.name.startswith('f3-final-render-pair-') and not out.exists() and not out.is_symlink(), 'new-private-output-required')
    require(BASE.resolve(strict=True) == BASE, 'output-parent-alias'); out.mkdir(mode=0o700)
    receipt = {'state': 'INCOMPLETE', 'subject': args.subject, 'main': MAIN, 'commands': [], 'reaped': [], 'errors': [], 'captureComplete': False, 'completeAttribution': False, 'genuineAcceptance': False, 'arms': []}
    lock = None; child = None; primary_before = None; runtime_before = None; inputs_before = None; tmp = None; handlers = {}
    def run(label, command, cwd, env):
        nonlocal child
        row = {'label': label, 'argv': command, 'cwd': str(cwd)}; receipt['commands'].append(row); checkpoint(out, 'progress.json', receipt)
        with (out / (label + '.log')).open('xb') as log:
            child = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try: row['returncode'] = child.wait()
            finally: checkpoint(out, 'progress.json', receipt)
        require(drain(child, receipt['reaped']), 'between-arm-child-drain'); child = None
        return row['returncode']
    try:
        lock = open(BASE / 'f3-final-render-pair.lock', 'a+b'); fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest, inputs_before = sealed_preflight(args.subject)
        receipt['manifestSha256'] = sha((HERE / 'preparation-manifest.json').read_bytes())
        primary_before = snapshot_at(PRIMARY); checkpoint(out, 'primary-before.json', primary_before)
        runtime_before = ignored_runtime_snapshot(PRIMARY); checkpoint(out, 'primary-runtime-before.json', runtime_before)
        checkpoint(out, 'input-before.json', inputs_before)
        libc = ctypes.CDLL(None, use_errno=True)
        if libc.prctl(36, 1, 0, 0, 0): raise OSError(ctypes.get_errno(), 'subreaper')
        handlers = {sig: signal.signal(sig, interrupt) for sig in (signal.SIGINT, signal.SIGTERM)}
        tmp = Path(tempfile.mkdtemp(prefix='f3-render-pair-owned-', dir=str(BASE))); tmp.chmod(0o700); receipt['privateTmp'] = str(tmp)
        env = dict(os.environ); env.update(PATH=str(NODE.parent) + os.pathsep + env.get('PATH', ''), TMPDIR=str(tmp), TMP=str(tmp), TEMP=str(tmp))
        recipe = out / 'run-capture-admission.sh'; recipe.write_bytes(regular_bytes(HERE / 'run-capture-admission.sh')); recipe.chmod(0o400)
        receipt['copiedRecipeSha256'] = sha(recipe.read_bytes())
        owned_inputs = out / 'inputs'; owned_inputs.mkdir(mode=0o700)
        receipt['copiedInputs'] = []
        for key, name in [('config', 'config.json'), ('draft', 'frozen-draft-v4.json')]:
            expected = inputs_before[key]; raw = regular_bytes(Path(expected['path']))
            require(len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], 'input-copy-source-drift:' + key)
            target = owned_inputs / name
            with target.open('xb') as stream: stream.write(raw)
            target.chmod(0o400)
            require(regular_bytes(target) == raw, 'owned-input-copy-drift:' + key)
            receipt['copiedInputs'].append(file_row(owned_inputs, name))
        for arm, commit, tree in [('main-4b86', MAIN, MAIN_TREE), ('final-1ef234', SUBJECT, SUBJECT_TREE)]:
            require(not (out / arm).exists() and not (out / (arm + '-capture')).exists(), 'new-arm-paths-required')
            require(snapshot_at(PRIMARY) == primary_before and source_inputs() == inputs_before, 'between-arm-primary-or-input-drift')
            require(run(arm, ['/bin/bash', str(recipe), arm, commit], out, env) == 0, 'capture-recipe-failure:' + arm)
            value = capture_receipt(out, arm, commit, tree, inputs_before); receipt['arms'].append(value); checkpoint(out, arm + '-receipt.json', value)
        pair = pair_inventory(out, receipt['arms']); checkpoint(out, 'pair-attribution-required.json', pair)
        receipt['captureComplete'] = True; receipt['state'] = 'ATTRIBUTION_REQUIRED'
    except BaseException as failure:
        receipt['errors'].append({'phase': 'operation', 'type': type(failure).__name__, 'message': str(failure)})
    finally:
        mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
        try:
            try: receipt['noOwnedChildren'] = drain(child, receipt['reaped']); child = None
            except BaseException as failure: receipt['errors'].append({'phase': 'drain', 'type': type(failure).__name__, 'message': str(failure)})
            if primary_before is not None:
                try:
                    after = snapshot_at(PRIMARY); checkpoint(out, 'primary-after.json', after); require(after == primary_before, 'primary-source-or-status-drift')
                    runtime = ignored_runtime_snapshot(PRIMARY); checkpoint(out, 'primary-runtime-after.json', runtime); require(runtime == runtime_before, 'primary-ignored-runtime-drift')
                    checkpoint(out, 'input-after.json', source_inputs()); require(source_inputs() == inputs_before, 'input-drift')
                    receipt['primaryAndInputsUnchanged'] = True
                except BaseException as failure: receipt['errors'].append({'phase': 'freeze', 'type': type(failure).__name__, 'message': str(failure)})
            receipt['privateTmpEntries'] = [] if tmp is None else [p.name for p in sorted(tmp.iterdir())]
            if tmp is not None and not receipt['privateTmpEntries'] and receipt.get('noOwnedChildren'):
                try: tmp.rmdir(); receipt['privateTmpEmptyRemoved'] = True
                except OSError as failure: receipt['errors'].append({'phase': 'empty-owned-TMP-cleanup', 'type': type(failure).__name__, 'message': str(failure)})
            receipt['retention'] = 'Both owned clean clones and all raw captures retained. Nonempty owned TMP retained and named; no broad deletion.'
            if receipt['errors'] or not receipt.get('noOwnedChildren') or not receipt.get('primaryAndInputsUnchanged'): receipt['state'] = 'INCOMPLETE'; receipt['captureComplete'] = False
            # Capture/clone files are inventoried per arm. Keep terminal artifact
            # indexing limited to our immediate log and receipt files.
            receipt['operatorArtifacts'] = [file_row(out, p.name) for p in sorted(out.iterdir()) if p.is_file() and p.name != 'terminal.json']
            checkpoint(out, 'terminal.json', receipt)
        finally:
            for sig, previous in handlers.items(): signal.signal(sig, previous)
            signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            if lock is not None: lock.close()
    print(json.dumps({'state': receipt['state'], 'captureComplete': receipt['captureComplete'], 'completeAttribution': False, 'receipt': str(out / 'terminal.json'), 'sha256': sha((out / 'terminal.json').read_bytes()), 'errorCount': len(receipt['errors'])}))
    return 3 if receipt['state'] == 'ATTRIBUTION_REQUIRED' else 1
