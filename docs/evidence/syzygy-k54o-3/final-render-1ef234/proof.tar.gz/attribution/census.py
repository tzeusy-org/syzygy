#!/usr/bin/env python3
"""Read captured artifacts and source data only; never import or execute product code."""
import argparse
import collections
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import sys

PAIR = Path('/home/orca/.tmp/f3-final-render-pair-1ef234-main4b-R2-1')
PACKET = Path('/home/orca/.tmp/f3-final-render-execution-cd78c7-main4b86-R2')
EXPECTED_TERMINAL = '7aa732179ff8e3f9a08911dbd7263f9b6b9734fc8c7f55e838fdf65c5f4cc519'
VOID = set('area base br col embed hr img input link meta source track wbr'.split())
TOKEN = re.compile(r'<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<![^>]*>|</\s*([A-Za-z][\w-]*)\s*>|<([A-Za-z][\w-]*)((?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*)>')
ATTR = re.compile(r'([^\s=/>"\x27]+)(?:\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\s>"\x27]+)))?')
TERM = re.compile(r'<span class="term-pop"[^>]*>.*?(?:<span class="visually-hidden ev">)?<span class="marking [a-z-]+">[^<]*</span>(?:</span>)?</span>', re.S)
REVIEW_OPEN = '<aside class="review-status" data-review-status-region="review-status" aria-label="Review status">'
JS_WS = ''.join(chr(i) for i in [*range(9,14),32,160,5760,*range(8192,8203),8232,8233,8239,8287,12288,65279])
WORDS = re.compile('[^' + re.escape(JS_WS) + ']+')
ENTITY = re.compile(r'&(?:#(\d{1,7})|#[xX]([0-9a-fA-F]{1,6})|([A-Za-z]+));')
NAMED = {'amp':'&','lt':'<','gt':'>','quot':'"','apos':"'",'nbsp':chr(160)}

def require(ok, why):
    if not ok:
        raise AssertionError(why)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    require(path.is_file() and not path.is_symlink(), 'regular-file-required:' + str(path))
    before = path.stat(); raw = path.read_bytes(); after = path.stat()
    require((before.st_ino,before.st_mtime_ns,before.st_size) == (after.st_ino,after.st_mtime_ns,after.st_size), 'read-drift:' + str(path))
    return raw

def load(path):
    return json.loads(read(path))

def row(path, root=None):
    raw = read(path)
    return {'path': str(path if root is None else path.relative_to(root)), 'bytes':len(raw), 'sha256':sha(raw)}

def inventory(root):
    paths = sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())
    require(not any(p.is_symlink() for p in root.rglob('*')), 'symlink-in-inventory')
    other = sorted(x.decode()[len(str(root))+1:] for x in subprocess.check_output(['find',str(root),'-type','f','-print0']).split(b'\0') if x)
    require(paths == other, 'independent-find-census')
    return [row(root/name,root) for name in paths]

def decode(raw):
    def sub(m):
        if m[3]: return NAMED.get(m[3],m[0])
        n = int(m[1],10) if m[1] else int(m[2],16)
        return chr(n) if n <= 0x10ffff and not 0xd800 <= n <= 0xdfff else m[0]
    return ENTITY.sub(sub,raw)

def attrs(raw):
    return {m[1].lower():decode(next((v for v in m.groups()[1:] if v is not None),'')) for m in ATTR.finditer(raw)}

class Document:
    """Lossless element ranges over captured HTML; no serialization or rewriting."""
    def __init__(self,text):
        self.text=text; self.nodes=[]; stack=[]
        for m in TOKEN.finditer(text):
            if m[1]:
                found = next((i for i in range(len(stack)-1,-1,-1) if self.nodes[stack[i]]['tag']==m[1].lower()),None)
                if found is not None:
                    for n in stack[found:]: self.nodes[n].update(close=m.start(),end=m.end())
                    stack=stack[:found]
            elif m[2]:
                tag=m[2].lower(); n={'tag':tag,'attrs':attrs(m[3]),'start':m.start(),'openEnd':m.end(),'close':m.end(),'end':m.end(),'parent':stack[-1] if stack else None}
                self.nodes.append(n)
                if tag not in VOID and not m[3].rstrip().endswith('/'): stack.append(len(self.nodes)-1)
    def select(self,tag=None,key=None,value=None):
        return [n for n in self.nodes if (tag is None or n['tag']==tag) and (key is None or key in n['attrs'] and (value is None or n['attrs'][key]==value))]
    def raw(self,n): return self.text[n['start']:n['end']]
    def inner(self,n): return self.text[n['openEnd']:n['close']]
    def plain(self,n): return html.unescape(TOKEN.sub('',self.inner(n)))
    def descendants(self,n,tag): return [v for v in self.nodes if v['tag']==tag and n['openEnd']<=v['start']<n['close']]

class IndependentTables(HTMLParser):
    """Second parser for table metric population, independent of Document."""
    def __init__(self):
        super().__init__(convert_charrefs=True); self.rows=[]; self.current=None; self.cell=None; self.text=[]; self.in_table=0
    def handle_starttag(self,tag,at):
        if tag=='table': self.in_table+=1
        if self.in_table and tag=='tr': self.current=[]
        if self.in_table and tag in ('td','th'): self.cell=tag; self.text=[]
    def handle_data(self,data):
        if self.cell: self.text.append(data)
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell:
            self.current.append((self.cell,''.join(self.text))); self.cell=None
        if tag=='tr' and self.current is not None: self.rows.append(self.current); self.current=None
        if tag=='table': self.in_table-=1

def measured(text):
    require(text.count(REVIEW_OPEN)==1,'one-review-region')
    start=text.index(REVIEW_OPEN);end=text.index('</aside>',start)+len('</aside>')
    excluded=[{'kind':'review-status','start':start,'end':end,'bytes':len(text[start:end].encode()),'sha256':sha(text[start:end].encode())}]
    # This is the renderer's declared measurement projection only, never an
    # equivalence normalization. Original bytes remain separately frozen.
    without=text[:start]+text[end:]
    matches=list(TERM.finditer(without))
    excluded.extend({'kind':'term-pop','startInReviewlessProjection':m.start(),'endInReviewlessProjection':m.end(),'bytes':len(m[0].encode()),'sha256':sha(m[0].encode())} for m in matches)
    return TERM.sub('',without),excluded

def metrics(text):
    stack=[];by=collections.Counter();unlabelled=0;last_zero=None;cursor=0;offset=0
    def add(raw):
        nonlocal unlabelled
        n=len(WORDS.findall(decode(re.sub(r'\r\n?','\n',raw))))
        level=next((v[1] for v in reversed(stack) if v[1] is not None),None)
        if level is None: unlabelled+=n
        elif n: by[level]+=n
    while True:
        m=TOKEN.search(text,offset)
        if m is None: break
        add(text[cursor:m.start()]);cursor=m.end();offset=cursor
        if m[1]:
            at=next((i for i in range(len(stack)-1,-1,-1) if stack[i][0]==m[1].lower()),None)
            if at is not None:
                if any(v[1]=='0' for v in stack[at:]): last_zero=len(text[:cursor].encode())
                stack=stack[:at]
        elif m[2]:
            tag=m[2].lower();at=attrs(m[3]);lev=at.get('data-reading-level');lev=lev if lev is not None and re.fullmatch(r'(?:0|[1-9]\d{0,2})',lev) else None
            if tag in VOID or m[3].rstrip().endswith('/'): continue
            if tag in ('script','style','textarea','title'):
                end=re.search('</'+tag+r'\s*>',text[cursor:],re.I)
                finish=len(text) if end is None else cursor+end.end()
                if tag=='textarea': stack.append((tag,lev));add(text[cursor:len(text) if end is None else cursor+end.start()]);stack.pop()
                cursor=finish;offset=finish
            else: stack.append((tag,lev))
    add(text[cursor:])
    return {'bytes':len(text.encode()),'wordsByReadingLevel':dict(by),'unlabelledWords':unlabelled,'bytesThroughFirstLevel':last_zero}

def json_diff(a,b,path=''):
    if type(a)!=type(b): return [{'path':path,'before':a,'after':b}]
    if isinstance(a,dict):
        out=[]
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b:out.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k),'kind':'add-or-remove'})
            else:out.extend(json_diff(a[k],b[k],path+'/'+k))
        return out
    if isinstance(a,list):
        if path=='/disclosure': return json_diff({v['id']:v for v in a},{v['id']:v for v in b},path)
        if len(a)!=len(b): return [{'path':path,'before':a,'after':b}]
        return [v for i,(x,y) in enumerate(zip(a,b)) for v in json_diff(x,y,path+'/'+str(i))]
    return [] if a==b else [{'path':path,'before':a,'after':b}]

def numeric_census(text,size,dossier):
    doc=Document(text);tables=doc.select('table');rows=[];cells=[];seen_depth=[];seen_pages=[]
    for ti,table in enumerate(tables):
        headers=[doc.plain(n) for n in doc.descendants(table,'th')]
        for ri,tr in enumerate(doc.descendants(table,'tr')):
            tds=doc.descendants(tr,'td')
            if not tds:continue
            require(len(tds)==len(headers),'metric-row-width'); vals=[doc.plain(n) for n in tds];identity=tds[0]
            if headers==['Link depth','Pages','Bytes','Words']:
                source=next(v for v in size['perPageDepth'] if str(v['depth'])==vals[0]);seen_depth.append(source['depth']);expected=[source[k] for k in ['depth','pages','bytes','words']];pointers=['/perPageDepth/'+str(size['perPageDepth'].index(source))+'/'+k for k in ['depth','pages','bytes','words']]
            elif headers==['Page','Depth','Bytes','Words']:
                links=doc.descendants(identity,'a');require(len(links)==1,'one-measured-page-link');path=links[0]['attrs']['href'];seen_pages.append(path);source=next(v for v in size['pages'] if v['path']==path);require(any(v['path']==path and v['depth']==source['depth'] for v in dossier['pages']),'dossier-row-binding');expected=[None,source['depth'],source['bytes'],sum(source['wordsByReadingLevel'].values())+source['unlabelledWords']];pointers=[None]+['/pages/'+str(size['pages'].index(source))+'/'+k for k in ['depth','bytes','wordsByReadingLevel+unlabelledWords']]
            else:raise AssertionError('unclassified-metric-table:'+repr(headers))
            for ci,(td,val,want,pointer) in enumerate(zip(tds,vals,expected,pointers)):
                if want is None:continue
                require(re.fullmatch(r'\d+',val) is not None and int(val)==want,'numeric-HTML-JSON-binding')
                cells.append({'table':ti,'row':ri,'column':ci,'header':headers[ci],'value':int(val),'sourcePointer':pointer,'htmlByteStart':len(text[:td['start']].encode()),'htmlByteEnd':len(text[:td['end']].encode()),'rawSha256':sha(doc.raw(td).encode())})
            rows.append({'table':ti,'row':ri,'values':vals})
    require(sorted(seen_depth)==sorted(v['depth'] for v in size['perPageDepth']),'complete-depth-row-population')
    require(sorted(seen_pages)==sorted(v['path'] for v in size.get('pages',[])),'complete-page-row-population')
    other=IndependentTables();other.feed(text);independent=[int(v) for rr in other.rows for tag,v in rr if tag=='td' and re.fullmatch(r'\d+',v)]
    require(independent==[v['value'] for v in cells],'independent-numeric-parser')
    return {'tables':len(tables),'dataRows':len(rows),'cells':cells,'independentNumericCells':len(independent)}

def selftest():
    # Predicate-specific failures use in-memory fixtures; frozen artifacts and
    # source files are never mutated.
    base='<html><body>'+REVIEW_OPEN+'x</aside><header data-reading-level="0">one two</header><p>three &amp; four</p></body></html>'
    projected,_=measured(base);m=metrics(projected);require(m['wordsByReadingLevel']=={'0':2} and m['unlabelledWords']==3,'metric-positive-fixture')
    def rejects(fn):
        try:fn()
        except (AssertionError,KeyError,StopIteration):return True
        return False
    require(rejects(lambda:measured(base+REVIEW_OPEN+'y</aside>')),'duplicate-region-negative')
    require(rejects(lambda:measured(base.replace(REVIEW_OPEN,''))),'missing-region-negative')
    table='<table><tr><th>Link depth</th><th>Pages</th><th>Bytes</th><th>Words</th></tr><tr><td>0</td><td>1</td><td>22</td><td>3</td></tr></table>'
    numeric_census(table,{'perPageDepth':[{'depth':0,'pages':1,'bytes':22,'words':3}]},{'pages':[]})
    require(rejects(lambda:numeric_census(table.replace('>22<','>23<'),{'perPageDepth':[{'depth':0,'pages':1,'bytes':22,'words':3}]},{'pages':[]})),'wrong-cell-negative')
    require(rejects(lambda:numeric_census(table.replace('<td>22</td>',''),{'perPageDepth':[{'depth':0,'pages':1,'bytes':22,'words':3}]},{'pages':[]})),'missing-cell-negative')
    require(rejects(lambda:numeric_census(table.replace('<tr><td>0</td><td>1</td><td>22</td><td>3</td></tr>',''),{'perPageDepth':[{'depth':0,'pages':1,'bytes':22,'words':3}]},{'pages':[]})),'whole-row-omission-negative')
    require(rejects(lambda:numeric_census(table.replace('</table>','<tr><td>0</td><td>1</td><td>22</td><td>3</td></tr></table>'),{'perPageDepth':[{'depth':0,'pages':1,'bytes':22,'words':3}]},{'pages':[]})),'duplicate-row-negative')
    return ['whole-row-omission-refused','duplicate-row-refused','positive-word-level','duplicate-review-region-refused','missing-review-region-refused','wrong-numeric-value-refused','missing-numeric-cell-refused']

def run(out):
    terminal_raw=read(PAIR/'terminal.json');require(sha(terminal_raw)==EXPECTED_TERMINAL,'terminal-digest');terminal=json.loads(terminal_raw)
    require(terminal['state']=='ATTRIBUTION_REQUIRED' and terminal['captureComplete'] and not terminal['completeAttribution'] and terminal['errors']==[] and terminal['noOwnedChildren'] and terminal['primaryAndInputsUnchanged'],'terminal-checkpoint')
    before={'operator':[row(v,PAIR) for v in sorted(PAIR.iterdir()) if v.is_file()], 'arms':[]}
    result={'terminalSha256':EXPECTED_TERMINAL,'packetManifest':row(PACKET/'preparation-manifest.json'),'selftests':selftest(),'arms':[]}
    for arm in terminal['arms']:
        runroot=Path(arm['run']);site=Path(arm['site']);frozen=inventory(runroot);require(frozen==arm['runFiles'],'run-receipt-drift');sites=inventory(site);require(sites==arm['siteFiles'],'site-receipt-drift');before['arms'].append({'root':str(runroot),'files':frozen})
        htmls=sorted(v['path'] for v in sites if v['path'].endswith('.html'));size=load(site/'size-report.json');dossier=load(site/'dossier.json');machine=load(site/'machine.json');require({v['path'] for v in size['pages']}==set(htmls)-{'size-report.html'}=={v['path'] for v in dossier['pages']},'actual-measured-path-population')
        measured_rows=[];page_checks=[];claims=[];source_lines=[];all_disclosures=[]
        for name in htmls:
            raw=read(site/name);text=raw.decode();doc=Document(text);main=doc.select('main');require(len(main)==1,'one-main');require(main[0]['attrs']['data-disclosure-ids'].split()==[v['id'] for v in machine['disclosure']],'every-page-machine-disclosure-ids')
            regions=doc.select('aside','data-review-status-region','review-status');require(len(regions)==1,'one-review-status');status=[v for v in doc.select('li','data-disclosure-id') if regions[0]['openEnd']<=v['start']<regions[0]['close']];require([(v['attrs']['data-disclosure-id'],doc.plain(v)) for v in status]==[(v['id'],v['text']+' ['+v['label']+']') for v in machine['reviewStatus']],'every-page-review-parity')
            for n in doc.select(key='data-claim-id'):claims.append({'page':name,'id':n['attrs']['data-claim-id'],'epistemic':n['attrs'].get('data-epistemic'),'unknownReason':n['attrs'].get('data-unknown-reason')})
            if name.startswith('sources/'):
                lines=doc.select(key='id');lines=[n for n in lines if re.fullmatch(r'L\d+',n['attrs']['id'])];source_lines.append({'path':name,'lineElements':len(lines),'lineElementBytesSha256':sha(''.join(doc.raw(n) for n in lines).encode()),'lineIds':[n['attrs']['id'] for n in lines]})
            for n in doc.select('li','data-disclosure-id'):
                if n not in status:all_disclosures.append({'id':n['attrs']['data-disclosure-id'],'label':n['attrs'].get('data-label'),'text':doc.plain(n),'page':name,'rawSha256':sha(doc.raw(n).encode())})
            page_checks.append({'path':name,'styleSha256':[sha(doc.raw(v).encode()) for v in doc.select('style')],'prefixThroughMainStartSha256':sha(text[:main[0]['start']].encode()),'mainOpening':text[main[0]['start']:main[0]['openEnd']],'mainInnerSha256':sha(doc.inner(main[0]).encode()),'suffixAfterMainSha256':sha(text[main[0]['close']:].encode()),'reviewRegionSha256':sha(doc.raw(regions[0]).encode()),'runSentenceSha256':[sha(doc.raw(v).encode()) for v in doc.select('p','class','run-sentence')]})
            if name!='size-report.html':
                projected,excluded=measured(text);metric=metrics(projected);expected=next(v for v in size['pages'] if v['path']==name)
                require(all(metric[k]==expected[k] for k in ['bytes','wordsByReadingLevel','unlabelledWords']),'actual-measurement-profile:'+name)
                measured_rows.append({'path':name,'rawBytes':len(raw),'rawSha256':sha(raw),'measurementProjectionSha256':sha(projected.encode()),'excluded':excluded,**metric})
        for c in machine['claims']:
            matches=[v for v in claims if v['page']==c['page'] and v['id']==c['id']]
            require(len(matches)==1 and all(matches[0][k]==c.get(k) for k in ['epistemic','unknownReason']),'human-machine-claim:'+c['id'])
        expected_disclosures=[{'id':v['id'],'label':v['label'],'text':v['text']+(' ['+v['label']+']' if v['label'] else ''),'page':'appendix.html'} for v in machine['disclosure']]
        require([{k:v[k] for k in ['id','label','text','page']} for v in all_disclosures]==expected_disclosures,'appendix-machine-disclosure-parity')
        for n in size['pages']:
            require(next(v['depth'] for v in dossier['pages'] if v['path']==n['path'])==n['depth'],'dossier-depth')
        for group in size['perPageDepth']:
            members=[v for v in size['pages'] if v['depth']==group['depth']]
            require(group=={'depth':group['depth'],'pages':len(members),'bytes':sum(v['bytes'] for v in members),'words':sum(sum(v['wordsByReadingLevel'].values())+v['unlabelledWords'] for v in members)},'depth-aggregation')
        require(sum(v['bytes'] for v in measured_rows)==size['totalBytes'],'measured-total-bytes');entry=next(v for v in measured_rows if v['path']==dossier['entryPage']);require(size['firstReadingLevel']['entryPageBytes']==entry['bytes'] and size['firstReadingLevel']['bytesThroughFirstLevel']==entry['bytesThroughFirstLevel'] and size['firstReadingLevel']['words']==entry['wordsByReadingLevel'].get('0'),'first-reading-level')
        numeric=numeric_census(read(site/'size-report.html').decode(),size,dossier)
        result['arms'].append({'commit':arm['commit'],'run':str(runroot),'site':str(site),'actualSiteFiles':len(sites),'actualHtmlFiles':len(htmls),'actualMeasuredPages':len(measured_rows),'numeric':numeric,'measurementRows':measured_rows,'pageChecks':page_checks,'humanClaims':claims,'machineClaims':len(machine['claims']),'sourceLines':source_lines,'disclosures':all_disclosures,'siteFiles':sites})
    result['jsonDifferences']={name:json_diff(load(Path(terminal['arms'][0]['site'])/name),load(Path(terminal['arms'][1]['site'])/name)) for name in ['dossier.json','machine.json','size-report.json','derived-structure.json']}
    before['captureRoots']=[{'root':str(Path(a['run']).parent.parent),'files':inventory(Path(a['run']).parent.parent)} for a in terminal['arms']]
    before['ownedInputs']=inventory(PAIR/'inputs')
    after={'captureRoots':[{'root':a['root'],'files':inventory(Path(a['root']))} for a in before['captureRoots']],'ownedInputs':inventory(PAIR/'inputs'),'operator':[row(v,PAIR) for v in sorted(PAIR.iterdir()) if v.is_file()],'arms':[{'root':v['root'],'files':inventory(Path(v['root']))} for v in before['arms']]}
    require(before==after,'capture-drift-during-analysis');result['frozenInputsUnchanged']=True
    (out/'freeze.json').write_text(json.dumps(before,indent=2)+'\n');(out/'census.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'arms':[{'commit':a['commit'],'siteFiles':a['actualSiteFiles'],'htmlFiles':a['actualHtmlFiles'],'measuredPages':a['actualMeasuredPages'],'numericMetricCells':len(a['numeric']['cells']),'humanClaims':len(a['humanClaims']),'machineClaims':a['machineClaims']} for a in result['arms']],'frozenInputsUnchanged':True,'output':str(out)}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);parser.add_argument('--selftest',action='store_true');args=parser.parse_args()
    if args.selftest:print(json.dumps(selftest()))
    else:
        require(args.output is not None and args.output.is_dir(),'existing-analysis-output-required');run(args.output)
