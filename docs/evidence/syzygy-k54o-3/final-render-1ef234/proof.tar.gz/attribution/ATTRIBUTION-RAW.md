# Actual final-render pair attribution — 1ef234 / main4b86
Assessment: ATTRIBUTED WITH LIMITATIONS
Terminal SHA-256: 7aa732179ff8e3f9a08911dbd7263f9b6b9734fc8c7f55e838fdf65c5f4cc519
Subject: 1ef23447df5c69fb1418f5c226bf6abd925e15ff; diagnostic main 4b86e4285e7c78ddf049f64c9a3fd95fc0952cf3

[Observed] Both ordinary captures reached the retained ATTRIBUTION_REQUIRED checkpoint, exit 3. The exact terminal reports captureComplete true, completeAttribution false, errors [], noOwnedChildren true and primaryAndInputsUnchanged true. This analysis does not change that terminal or any captured source/output.

[Observed] Independent rglob/find enumeration and byte hashing confirm each arm has 50 actual site files, 46 HTML pages and 45 measured pages. Two distinct HTML parsers independently enumerate 147 numeric table metric cells per arm from the actual size-report HTML. Each cell binds its actual value to its JSON field and dossier page/depth row. The historical 46/50/45/147 populations were not used as acceptance constants. The coincidence with historical counts is an observed result.

[Observed] The independent measurement implementation remeasured every one of the 45 source-defined page projections per arm: emitted bytes remain frozen separately, while the report's declared measurement profile excludes its review region and glossary hover entries. Every measured byte count, reading-level word count, unlabelled-word count, first-reading-level offset, depth aggregation and total matches the captured size-report JSON. This measurement projection is not applied to site equivalence or used to discard output differences. The executable census retains each emitted identity, measurement identity and excluded-span identity.

[Observed] Exactly 50 numeric cells change: the 45 measured-page byte cells, the appendix word cell, three depth-byte aggregate cells, and the depth-1 word aggregate cell. The measured total rises by 1,167 bytes: 44 pages add 20 bytes each in their main disclosure identity list and the appendix adds 287 bytes. The appendix adds 23 measured words from its revised disclosures. Other per-page word counts and reading-level distributions are unchanged. The 50 cell records each carry both HTML cell identities, the exact JSON pointer, numeric delta and contributing measured source rows in numeric-cell-differences.json. First-reading summary paragraph byte values change consistently with those same rows.

[Observed] All 50 actual site paths have dispositions in attribution.json: 49 changed and one byte-identical (dossier.json). The complete changed-path population matches the independent operator pair report. Every changed HTML token is retained as an exact before/after byte range and value: 190 changed token spans across the 46 pages. The original 1,921,260-byte all-site-byte-differences.patch remains frozen and retained. No synthetic expected site is created and no CSS, chrome, source, numeric value or disclosure is normalized away.

[Inferred] The 49 changed files are attributable to the following exact sources and run inputs, with both source-file digests and located quoted source lines retained in attribution.json:

- All 46 HTML pages: the main data-disclosure-ids list adds raw-read-disclosure, derived from local.disclosure by dossier-site.ts. Other main attributes are unchanged. This adds 20 bytes per page.
- appendix.html: render.ts changes the operator-mode and screening-boundary sentences and includes describeRawReadDisclosure from raw-read-disclosure.ts; the new risk item has label Unknown, unknown author handoff, unobserved transmissions wording and the declared provider. Its selected-policy disclosure projects the bound v4 policy rather than main's v3 policy. Together with the main attribute, the file grows by 287 bytes.
- index.html and maps/directories.html: each run's kept derived record has its own capturedAt instant from check.ts/encodeDerivedRecord. derived-structure.json differs only in capturedAt; the corresponding digest and visible timestamp project into these pages. Their other derived facts, source revision and numeric values are unchanged. These differences retain their own run evidence; they are not described as current-main equivalence.
- maps/ci.html, maps/units.html and maps/infrastructure.html: their note projects the actual selected policy version, v3 for main and v4 for subject; the policy id is unchanged. The JSON digest bindings are checked separately.
- size-report.html and size-report.json: report the actual measured changes described above; no allowance or cell mask is applied.
- machine.json: exactly seven JSON-pointer deltas: the selected manifest-policy version/digest, derived-record digest, operator-mode text, screening-boundary text, selected-policy disclosure text and the added raw-read Unknown item. Its other fields are equal. The file grows by 232 bytes.
- derived-structure.json: the two capturedAt instants differ at the check step; its serialized length is unchanged. All other JSON members are identical.
- dossier.json: byte-identical. Remaining changed HTML files carry only the 20-byte main disclosure-identity addition. The full emitted site byte delta is 1,419 bytes, accounted for by 46*20, the appendix's additional 267, and machine.json's 232.

[Observed] Human/machine parity checks cover 222 claims per arm, including epistemic marking and Unknown reasons. Machine claims, sources/anchors, quotations, local pages, counts, withheld elements, glossaryShown and reviewStatus values are unchanged between arms. Every page's disclosure identity list matches its arm's machine disclosure order; all appendix disclosure text/labels and every page's review region match their machine records. Both reviews remain explicitly uncounted/Unknown. Both arms retain the Event-loop, PSYNC and Hash-slot glossary definitions required by the sealed obligations. The glossary and review main interiors remain byte-identical; no new historical A303 +33 allowance is granted.

[Observed] Subject has the exact F3-only run-root raw-read-disclosure.json companion, with unknown authorHandoff and declaredProvider openai; main has none and neither site contains one. The raw risk item matches the sealed R2 obligation exactly. Actual run policy bindings match all five required fields (path, selected commit, id, version, digest), and machine manifest policies match the corresponding id/version/digest.

[Observed] The complete CSS/style blocks, bytes before main, bytes after main, run-sentence regions and review regions are byte-identical for all 46 HTML pairs. Twenty-five source leaf pages contain 32,560 line elements per arm; their ids and complete rendered line bytes are identical, preserving source-line/continuation/citation content. Full source-page main interiors are unchanged. The seven changed main interiors are exactly appendix, index, four map pages and size report, with their changes retained and dispositioned above.

[Observed] Frozen run inventories contain 60 main and 61 subject files. Raw stage JSON/stdout/stderr/install/build logs, owned input copies, operator receipts, full site files and the original diff are additionally inventoried. The census and attribution checks rehashed retained output inventories and confirmed no changes during analysis. All subject source reads were from the retained exact clones and checked against their bound Git blobs; the review wrote only new analysis artifacts outside the primary and captured pair.

[Observed] Proportional in-memory controls reject changed/missing numeric cells, whole-row omissions, duplicate rows, duplicate/missing review regions, unbound CSS/text changes, and unrelated main-attribute changes. These controls do not mutate the captured files or product source. Scripts are executable and read captured data only; the only imported analysis module is the sibling census.py, never product code.

[Unknown] Fresh independent review of the newly authored census/attribution tools and their exact artifacts remains outstanding before reliance on the attribution completion. Browser layout, focus/interaction behavior and screenshot comparison were not examined. Counted rendered-design/fidelity acceptance, native/runtime closure and genuine ordinary-worker recovery remain outside this result. No provider or product command, browser action or heavy execution ran here. This assessment is not a product-acceptance claim and does not replace the failed/incomplete native recovery evidence.

The read-only rerun commands are:

```sh
python3 /home/orca/.tmp/f3-final-render-1ef234-attribution-R1/census.py --selftest
python3 /home/orca/.tmp/f3-final-render-1ef234-attribution-R1/census.py --output /home/orca/.tmp/f3-final-render-1ef234-attribution-R1
python3 /home/orca/.tmp/f3-final-render-1ef234-attribution-R1/attribution.py --selftest
python3 /home/orca/.tmp/f3-final-render-1ef234-attribution-R1/attribution.py
```
