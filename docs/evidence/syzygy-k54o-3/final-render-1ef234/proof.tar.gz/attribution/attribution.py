#!/usr/bin/env python3
"""Read-only attribution of the frozen actual pair. Writes analysis artifacts only."""
import argparse
import collections
import difflib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('census',HERE/'census.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
REQ=c.require
SOURCE_REFS={
 'main-disclosure-identities':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',934,'local.disclosure.map(item => item.id).join'),
 'operator-mode':('packages/polaris-dossier/src/render.ts',1286,'Authoring mode is operator-agent.'),
 'screening-boundary':('packages/polaris-dossier/src/render.ts',1289,'Syzygy screens the Git objects and artifacts'),
 'raw-read-unknown-risk':('packages/polaris-dossier/src/raw-read-disclosure.ts',48,'describeRawReadDisclosure'),
 'selected-policy':('packages/polaris-dossier/src/render.ts',1297,'screening-policy-binding'),
 'manifest-policy-projection':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',1753,'bound screening policy'),
 'derived-record-instant-and-digest':('packages/polaris-dossier/src/derived-record.ts',40,'encodeDerivedRecord'),
 'derived-human-projection':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',1504,'const record = `sha256:${derived.sha256}`'),
 'derived-map-projection':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',1612,'derived.capturedAt'),
 'numeric-measurement-projection':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',1305,'const measured ='),
 'reader-cost-aggregation':('packages/polaris-generation-core/src/dossier-evaluation.ts',70,'export function readerCost'),
 'metric-table-projection':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',1315,'cost.perPageDepth.map'),
 'machine-projection':('apps/three-surface-poc/src/polaris-generation/dossier-site.ts',1323,'disclosure: local.disclosure'),
}

def tokens(text):
    out=[];at=0
    for m in c.TOKEN.finditer(text):
        if m.start()>at:out.append((text[at:m.start()],at,m.start()))
        out.append((m[0],m.start(),m.end()));at=m.end()
    if at<len(text):out.append((text[at:],at,len(text)))
    REQ(''.join(v[0] for v in out)==text,'lossless-token-coverage')
    return out

def variable_segments(text,variables):
    """Retain literal and named-value segments; do not construct altered HTML."""
    if not variables:return [('literal',text)]
    pattern=re.compile('|'.join(re.escape(v) for _,v in sorted(variables,key=lambda x:-len(x[1]))));out=[];at=0
    lookup={v:k for k,v in variables}
    for m in pattern.finditer(text):
        out.append(('literal',text[at:m.start()]));out.append(('bound-value',lookup[m[0]]));at=m.end()
    out.append(('literal',text[at:]));return out

def bound_change(a,b,left,right):
    x=variable_segments(a,left);y=variable_segments(b,right)
    return x==y and any(k=='bound-value' for k,_ in x)

def main_attrs(a,b,left_ids,right_ids):
    x=c.Document(a).select('main');y=c.Document(b).select('main');REQ(len(x)==len(y)==1,'one-main-opening')
    xx=x[0]['attrs'];yy=y[0]['attrs'];REQ(xx['data-disclosure-ids'].split()==left_ids and yy['data-disclosure-ids'].split()==right_ids,'disclosure-identity-order')
    REQ({k:v for k,v in xx.items() if k!='data-disclosure-ids'}=={k:v for k,v in yy.items() if k!='data-disclosure-ids'},'unattributed-main-attribute')
    REQ(bound_change(a,b,[('ids',xx['data-disclosure-ids'])],[('ids',yy['data-disclosure-ids'])]),'unattributed-main-opening-byte')

def source_rows(arms):
    paths=sorted({v[0] for v in SOURCE_REFS.values()}|{'packages/polaris-dossier/src/check.ts','packages/polaris-generation-core/src/dossier-page-scan.ts','apps/three-surface-poc/src/polaris-generation/dossier-render-local.ts','packages/polaris-dossier/src/policy-snapshot.ts'})
    out=[]
    for path in paths:
        armrows={}
        for arm in arms:
            checkout=Path(arm['checkout']); probe=subprocess.run(['git','-C',str(checkout),'cat-file','blob',arm['commit']+':'+path],capture_output=True)
            if probe.returncode:
                REQ(path=='packages/polaris-dossier/src/raw-read-disclosure.ts' and arm==arms[0] and not (checkout/path).exists(),'unexpected-source-absence');armrows[arm['commit']]={'state':'absent'};continue
            raw=c.read(checkout/path);REQ(raw==probe.stdout,'source-byte-drift:'+path);armrows[arm['commit']]={'bytes':len(raw),'sha256':c.sha(raw)}
        out.append({'path':path,'arms':armrows})
    return out

def nearest(doc,offset,key=None,tag=None):
    nodes=[v for v in doc.nodes if v['start']<=offset<v['end'] and (key is None or key in v['attrs']) and (tag is None or v['tag']==tag)]
    return min(nodes,key=lambda n:n['end']-n['start']) if nodes else None

def same_key(a,b,key):
    return a is not None and b is not None and a['attrs'].get(key)==b['attrs'].get(key)

def run():
    report=c.load(HERE/'census.json');freeze=c.load(HERE/'freeze.json');term=c.load(c.PAIR/'terminal.json');arms=term['arms'];paths=[Path(a['site']) for a in arms];m=[c.load(p/'machine.json') for p in paths];d=[c.load(p/'derived-structure.json') for p in paths];pol=[v['computedMaps']['manifests']['screeningPolicy'] for v in m];ob=c.load(c.PACKET/'obligations.json')
    source=source_rows(arms)
    REQ(c.json_diff(d[0],d[1])==[{'path':'/capturedAt','before':d[0]['capturedAt'],'after':d[1]['capturedAt']}],'derived-record-unattributed-fields')
    derived_sha=[c.sha(c.read(p/'derived-structure.json')) for p in paths]
    for i in range(2):
        REQ(m[i]['derivedStructure']['sha256']==derived_sha[i],'machine-derived-digest')
        REQ(len(m[i]['claims'])==len(report['arms'][i]['humanClaims']),'bidirectional-claim-population')
        for x in ob['A303Definitions']:REQ(x['requiredBothArms'] in c.read(paths[i]/'glossary.html').decode(),'A303-definition:'+x['id'])
        byid={v['id']:v for v in m[i]['disclosure']};arm='main' if i==0 else 'subject'
        for key in ['mode','source-screening-boundary']:REQ(byid[key]==ob['disclosures'][arm][key],'source-backed-disclosure')
        binding=c.load(Path(arms[i]['run'])/'run.json')['subject']['screeningPolicy'];wanted=ob['policies'][i]
        REQ(binding=={'path':wanted['selectedPath'],'commit':arms[i]['commit'],'policyId':wanted['policyId'],'policyVersion':wanted['policyVersion'],'sha256':wanted['sha256']},'actual-five-field-policy-binding')
        REQ(pol[i]=={'policyId':binding['policyId'],'policyVersion':binding['policyVersion'],'sha256':binding['sha256']},'machine-manifest-policy')
        REQ(byid['screening-policy-binding']=={'id':'screening-policy-binding','text':f"Screening policy {binding['policyId']} {binding['policyVersion']}, digest {binding['sha256']}; its selected commit is stored run provenance.",'label':'Inferred'},'human-machine-policy-text')
        record=c.load(Path(arms[i]['run'])/'derived/rev-0.json');REQ(record==d[i],'kept-derived-record-site-binding')
    companion=Path(arms[1]['run'])/'raw-read-disclosure.json';side=c.load(companion)
    REQ(side=={'schemaVersion':'polaris-dossier-raw-read-disclosure/1','runId':Path(arms[1]['run']).name,'declaredProvider':'openai','authorHandoff':'unknown'},'subject-companion')
    REQ(not (Path(arms[0]['run'])/'raw-read-disclosure.json').exists() and all(not (p/'raw-read-disclosure.json').exists() for p in paths),'companion-scope')
    REQ(next(v for v in m[1]['disclosure'] if v['id']=='raw-read-disclosure')==ob['rawReadItem'],'raw-read-risk-and-Unknown')
    manifest_rows={v['path']:v for v in c.load(c.PACKET/'preparation-manifest.json')['files']}
    REQ(c.row(c.PACKET/'obligations.json',c.PACKET)==manifest_rows['obligations.json'],'sealed-obligation-drift')
    values_left=[('derived-sha',derived_sha[0]),('capturedAt',d[0]['capturedAt']),('policy-version',pol[0]['policyVersion']),('policy-digest',pol[0]['sha256'])]
    values_right=[('derived-sha',derived_sha[1]),('capturedAt',d[1]['capturedAt']),('policy-version',pol[1]['policyVersion']),('policy-digest',pol[1]['sha256'])]
    diffs=[];dispositions=[];changed=0;html_spans=0
    site_names=sorted(set(v['path'] for v in arms[0]['siteFiles'])|set(v['path'] for v in arms[1]['siteFiles']))
    REQ(site_names==sorted(v['path'] for v in arms[0]['siteFiles'])==sorted(v['path'] for v in arms[1]['siteFiles']),'actual-site-path-equality')
    for name in site_names:
        raw=[c.read(p/name) for p in paths];ident=[c.row(p/name,p) for p in paths]
        if raw[0]==raw[1]:dispositions.append({'path':name,'disposition':'BYTE_IDENTICAL','identities':ident});continue
        changed+=1;effects=[]
        if name.endswith('.html'):
            text=[v.decode() for v in raw];docs=[c.Document(v) for v in text];tt=[tokens(v) for v in text];checks=[next(v for v in a['pageChecks'] if v['path']==name) for a in report['arms']]
            for key in ['styleSha256','prefixThroughMainStartSha256','suffixAfterMainSha256','reviewRegionSha256','runSentenceSha256']:REQ(checks[0][key]==checks[1][key],'unattributed-CSS-chrome-review-run-sentence:'+name+':'+key)
            main_attrs(checks[0]['mainOpening'],checks[1]['mainOpening'],[v['id'] for v in m[0]['disclosure']],[v['id'] for v in m[1]['disclosure']])
            if name=='appendix.html':
                opcodes=difflib.SequenceMatcher(None,[v[0] for v in tt[0]],[v[0] for v in tt[1]],autojunk=False).get_opcodes()
            else:
                REQ(len(tt[0])==len(tt[1]),'unattributed-token-population:'+name);opcodes=[('equal' if a[0]==b[0] else 'replace',i,i+1,i,i+1) for i,(a,b) in enumerate(zip(*tt))]
            for kind,i,j,k,l in opcodes:
                if kind=='equal':continue
                a=''.join(v[0] for v in tt[0][i:j]);b=''.join(v[0] for v in tt[1][k:l]);pos=[tt[0][i][1] if i<len(tt[0]) else len(text[0]),tt[1][k][1] if k<len(tt[1]) else len(text[1])];nodes=[nearest(doc,off,'data-disclosure-id') for doc,off in zip(docs,pos)]
                if a.startswith('<main ') and b.startswith('<main '):effect='main-disclosure-identities'
                elif name=='appendix.html':
                    identities={n['attrs']['data-disclosure-id'] for n in nodes if n is not None}
                    if 'mode' in identities:effect='operator-mode'
                    elif 'source-screening-boundary' in identities or 'raw-read-disclosure' in identities:effect='screening-boundary-and-raw-read-unknown-risk'
                    elif identities=={'screening-policy-binding'} and bound_change(a,b,values_left,values_right):effect='selected-policy'
                    else:raise AssertionError('unattributed-appendix-token:'+repr([a[:80],b[:80],identities]))
                elif name=='size-report.html':
                    nn=[nearest(doc,off,tag='td') for doc,off in zip(docs,pos)]
                    if all(n is not None for n in nn) and a.isdigit() and b.isdigit():effect='metric-table-projection'
                    elif 'bytes and' in a and 'bytes and' in b:effect='first-reading-and-total-metric-projection'
                    else:raise AssertionError('unattributed-size-report-token:'+repr([a,b]))
                elif bound_change(a,b,values_left,values_right):
                    effect='derived-human-projection' if any(v in a for v in [derived_sha[0],d[0]['capturedAt']]) else 'manifest-policy-projection'
                else:raise AssertionError('unattributed-HTML-token:'+name+':'+repr([a[:100],b[:100]]))
                html_spans+=1;effects.append(effect)
                ranges=[]
                for s,start,seq,lo,hi in zip(text,pos,tt,[i,k],[j,l]):
                    end=seq[hi-1][2] if hi>lo else start
                    ranges.append({'charStart':start,'charEnd':end,'byteStart':len(s[:start].encode()),'byteEnd':len(s[:end].encode())})
                diffs.append({'path':name,'kind':kind,'ranges':ranges,'before':a,'after':b,'effect':effect})
        else:
            actual=report['jsonDifferences'][name]
            if name=='derived-structure.json':REQ(len(actual)==1 and actual[0]['path']=='/capturedAt','derived-only-time');effects=['derived-record-instant-and-digest']
            elif name=='machine.json':
                allowed={'/computedMaps/manifests/screeningPolicy/policyVersion','/computedMaps/manifests/screeningPolicy/sha256','/derivedStructure/sha256','/disclosure/mode/text','/disclosure/raw-read-disclosure','/disclosure/screening-policy-binding/text','/disclosure/source-screening-boundary/text'};REQ({v['path'] for v in actual}==allowed,'unattributed-machine-JSON');effects=['machine-projection','selected-policy','raw-read-unknown-risk','derived-record-instant-and-digest']
            elif name=='size-report.json':effects=['numeric-measurement-projection','reader-cost-aggregation']
            else:raise AssertionError('unattributed-site-JSON:'+name)
            diffs.append({'path':name,'jsonDifferences':actual,'effects':effects})
        dispositions.append({'path':name,'disposition':'ATTRIBUTED','identities':ident,'byteDelta':len(raw[1])-len(raw[0]),'effects':dict(collections.Counter(effects))})
    # All machine source anchors, glossary and review records remain literal JSON
    # values, independently corroborated by byte-identical source/main regions.
    for field in ['claims','sources','glossaryShown','reviewStatus','quotations','localPages','counts','withheldElements']:
        REQ(m[0][field]==m[1][field],'unattributed-machine-field:'+field)
    source_lines=report['arms'][0]['sourceLines'];REQ(source_lines==report['arms'][1]['sourceLines'],'source-line-or-continuation-drift')
    for arm in freeze['arms']+freeze.get('captureRoots',[]):REQ(c.inventory(Path(arm['root']))==arm['files'],'frozen-run-drift-after-attribution')
    REQ(c.inventory(c.PAIR/'inputs')==freeze['ownedInputs'],'owned-input-drift')
    REQ([c.row(v,c.PAIR) for v in sorted(c.PAIR.iterdir()) if v.is_file()]==freeze['operator'],'frozen-operator-drift-after-attribution')
    resolved_refs={}
    for key,(path,_,needle) in SOURCE_REFS.items():
        matches=[]
        for arm in arms:
            f=Path(arm['checkout'])/path
            if f.exists():
                lines=c.read(f).decode().splitlines();found=[{'line':i+1,'quote':line} for i,line in enumerate(lines) if needle in line]
                matches.append({'commit':arm['commit'],'path':path,'sha256':c.sha(c.read(f)),'matches':found})
        REQ(any(v['matches'] for v in matches),'unresolved-source-reference:'+key);resolved_refs[key]=matches
    effect_refs={key:[key] for key in SOURCE_REFS}
    effect_refs['first-reading-and-total-metric-projection']=['reader-cost-aggregation','metric-table-projection']
    effect_refs['screening-boundary-and-raw-read-unknown-risk']=['screening-boundary','raw-read-unknown-risk']
    pair=c.load(c.PAIR/'pair-attribution-required.json');REQ(sorted(v['path'] for v in dispositions if v['disposition']=='ATTRIBUTED')==sorted(v['path'] for v in pair['changedSiteFiles']),'independent-changed-file-population')
    summary={'effectSourceReferenceKeys':effect_refs,'state':'ACTUAL_PAIR_SOURCE_EFFECT_ATTRIBUTION_COMPLETE_REQUIRES_INDEPENDENT_TOOL_REVIEW','terminalSha256':c.sha(c.read(c.PAIR/'terminal.json')),'sourceRows':source,'sourceReferences':resolved_refs,'sitePathPopulation':len(site_names),'changedSiteFiles':changed,'byteIdenticalSiteFiles':len(site_names)-changed,'htmlChangedTokenSpans':html_spans,'allFileDispositions':dispositions,'rawDifferences':diffs,'sourceLeafPages':sum(bool(v['lineElements']) for v in source_lines),'sourceLineElements':sum(v['lineElements'] for v in source_lines),'actualNumericMetricCellsPerArm':[len(a['numeric']['cells']) for a in report['arms']],'changedNumericCells':sum(x['value']!=y['value'] for x,y in zip(report['arms'][0]['numeric']['cells'],report['arms'][1]['numeric']['cells'])),'totalMeasuredByteDelta':sum(v['bytes'] for v in report['arms'][1]['measurementRows'])-sum(v['bytes'] for v in report['arms'][0]['measurementRows']),'emittedSiteByteDelta':sum(v['bytes'] for v in arms[1]['siteFiles'])-sum(v['bytes'] for v in arms[0]['siteFiles']),'frozenInputsUnchanged':True,'normalizationApplied':False,'syntheticExpectedSiteCreated':False,'productAcceptanceClaim':False,'limitations':['Static artifacts only; no browser layout or interaction verification.','Census/attribution tools authored during this analysis require fresh independent review before reliance.','This result does not repair or accept native ordinary recovery.']}
    (HERE/'attribution.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k] for k in ['state','sitePathPopulation','changedSiteFiles','byteIdenticalSiteFiles','htmlChangedTokenSpans','actualNumericMetricCellsPerArm','changedNumericCells','sourceLeafPages','sourceLineElements','totalMeasuredByteDelta','emittedSiteByteDelta','frozenInputsUnchanged']}))

def selftest():
    REQ(bound_change('record aaa','record bbb',[('digest','aaa')],[('digest','bbb')]),'bound-change-positive')
    REQ(not bound_change('color:red; record aaa','color:blue; record bbb',[('digest','aaa')],[('digest','bbb')]),'CSS-change-must-not-disappear')
    REQ(not bound_change('record aaa and text','record bbb and hidden',[('digest','aaa')],[('digest','bbb')]),'unbound-text-must-not-disappear')
    x='<main id="content" data-disclosure-ids="mode">';y='<main id="content" data-disclosure-ids="mode raw-read-disclosure">';main_attrs(x,y,['mode'],['mode','raw-read-disclosure'])
    try:main_attrs(x,y.replace('id="content"','id="changed"'),['mode'],['mode','raw-read-disclosure'])
    except AssertionError:pass
    else:raise AssertionError('main-extra-attribute-negative')
    print(json.dumps(['bound-source-value-positive','CSS-mutation-refused','unbound-text-mutation-refused','main-attribute-mutation-refused']))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--selftest',action='store_true');args=p.parse_args()
    selftest() if args.selftest else run()
