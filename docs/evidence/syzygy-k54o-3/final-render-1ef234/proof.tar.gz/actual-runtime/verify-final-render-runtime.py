import hashlib, json, pathlib, subprocess

BASE = pathlib.Path('/home/orca/.tmp/f3-final-render-pair-1ef234-main4b-R2-1')
out = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes/final-render-runtime-closure-1ef234.json')
terminal = json.loads((BASE / 'terminal.json').read_text())
assert terminal['captureComplete'] and terminal['primaryAndInputsUnchanged'] and terminal['noOwnedChildren']
arms = []
for arm in terminal['arms']:
    root = pathlib.Path(arm['checkout'])
    git = lambda *args: subprocess.check_output(['git', '-C', str(root), *args])
    assert git('rev-parse', 'HEAD').decode().strip() == arm['commit']
    assert not git('status', '--porcelain=v1', '-z', '--untracked-files=all')
    runtime = root / 'packages/polaris-dossier/dist/runtime'
    manifest = runtime / 'manifest.json'
    record = {'commit': arm['commit'], 'tree': arm['tree'], 'checkout': str(root)}
    if not manifest.exists():
        record.update(state='absent', nativeExecution='Unknown')
        arms.append(record)
        continue
    raw = manifest.read_bytes()
    data = json.loads(raw)
    assert hashlib.sha256(raw).hexdigest() == arm['runtime']['sha256']
    rows = []
    for population, parent in [('inputs', root), ('files', runtime)]:
        names = [r['path'] for r in data[population]]
        assert names and len(names) == len(set(names))
        for row in data[population]:
            name = pathlib.PurePosixPath(row['path'])
            assert not name.is_absolute() and '..' not in name.parts and str(name) == row['path']
            p = parent / name
            body = p.read_bytes()
            actual = hashlib.sha256(body).hexdigest()
            independent = subprocess.check_output(['sha256sum', '--', str(p)]).decode().split()[0]
            assert len(body) == row['bytes'] and actual == independent == row['sha256']
            item = dict(row, population=population)
            if population == 'inputs':
                tree_entry = git('ls-tree', '-z', arm['commit'], '--', row['path'])
                if tree_entry:
                    blob = git('cat-file', 'blob', arm['commit'] + ':' + row['path'])
                    assert blob == body
                    item['gitBlobSha256'] = hashlib.sha256(blob).hexdigest()
            rows.append(item)
    assert manifest.read_bytes() == raw
    record.update(state='build-byte-closure-verified', manifestSha256=hashlib.sha256(raw).hexdigest(),
                  inputs=len(data['inputs']), outputs=len(data['files']),
                  verifiedRows=len(rows), gitTrackedInputs=sum('gitBlobSha256' in r for r in rows), rows=rows,
                  nativeExecution='Unknown; static render does not establish role execution or recovery')
    arms.append(record)
result = {'terminal': str(BASE / 'terminal.json'),
          'terminalSha256': hashlib.sha256((BASE / 'terminal.json').read_bytes()).hexdigest(),
          'arms': arms,
          'correction': 'The reviewed preparation claimed the static recipe did not build native URL runtime. Actual npm run build produced it in the F3 arm; main has no manifest. Reviewed preparation remains immutable; this actual-byte sweep supersedes that execution hypothesis.'}
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'arms': [{k: v for k, v in a.items() if k != 'rows'} for a in arms]}))
