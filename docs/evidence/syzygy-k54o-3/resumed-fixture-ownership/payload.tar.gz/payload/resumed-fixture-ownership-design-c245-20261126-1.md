# Resumed fixture ownership gap — outside-only design

[Observed] Source subject c245385ae2c5d043f4f14b13b14e92ad7fd40b3a at /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w. No primary edits, tests, probes, builds or product execution. This is a source-bound repair design, not PASS, a prepared patch, scope adoption, or evidence of full recovery.

## Concrete defect

[Observed] url-run-composed.test.ts:230 executes cleanup callbacks in reverse registration order. The fixture close is registered at 2823, initial controller stop at 2964, policy-Git close at 3015. The resumed start wrapper stores a newly returned runtime in resumedControllers (3285-3303) but registers no cleanup for it. The resumed runPolarisCli promise is awaited inline at 3346 and is not retained by a cleanup callback. The catch at 3462 stops and joins only the original controller/loop. The four scenario definitions and their test deadlines remain at 2437 and 3502.

[Observed] f.close first sets its live authority false, then removes hidden, fixture and socket directories (url-run-composed.testkit.ts:232). Vitest timeout does not interrupt an async test body's pending CLI work: the retained c245 record demonstrates afterEach started at 608274.082559ms, firstRuntimeFailure binding-changed at 608753.197162ms, failure-cleanup at 608982.790413ms. The original test failed at 600000ms and fixture removal also reported ENOTEMPTY for fixture/runs. Four Design forwards occurred; finalProductAssertions/liveFinals/coldFinals are 0.

[Inferred] Fixture authority withdrawal and removal can race the still-running resumed controller/CLI after timeout. The late binding-changed does not identify the original pre-timeout cause. This is a separate test-lifetime defect worth correcting without changing product behavior or acceptance timing.

## Required ownership and join order

[Inferred] Keep the repair in test ownership. Install one cleanup owner immediately before entering the existing main try at 3025, after existing policy-Git registration, so reverse cleanup runs this owner before shared resources and fixture disposal. Keep the original cases and assertion lines. The owner retains: cleanupRequested, the resumed CLI promise, any resumed startup promise/runtime, the exact new generation snapshot once published, and a settlement barrier resolved in a finally after the existing full try/catch (after 3500). It is harmless when no resumed invocation began.

[Inferred] Assign and retain the resumed CLI promise before awaiting it. Cleanup first marks cleanupRequested, then requests the exact owned generation's protected stop when available and initiates idempotent stop on any acquired resumed runtime. It must join resumed startup (if in flight), resumed runtime stop, the CLI promise, and the existing scenario try/catch settlement barrier before returning. Awaiting the CLI alone is insufficient: its normal waiter resumes the test, which can fail the exit assertion at 3362 and perform async audit/evidence work in 3441-3500. Joining the finally barrier includes those writes. Resolving that barrier must be unconditional; it must not depend on CLI success or an assertion passing.

[Inferred] Every acquired runtime must be registered synchronously on acquisition, before awaiting sample diagnostics. If cleanupRequested is already true when startup resolves, immediately stop that late runtime and join its stop before returning it to the CLI. A pending startup cannot be treated as an empty runtime list. Stop and join failures must be collected while other owned joins are still attempted, then surfaced as cleanup failure; do not catch-and-forget them. A cleanup-triggered CLI numeric failure is not itself a new cleanup error: the original test remains timed out/failed, and its normal assertions still run. A rejected CLI promise must remain observable.

## Exact-generation stop and early startup

[Observed] Production supervise awaits prepareStoppedSupervisor before saving the new state and opening its stop offer (polaris.ts:659-676). Preparation generates a new stopGeneration at 585 and clears historical stopped at 632-636. Thus --stop during earlier bootstrap can only see historical stopped state; it cannot stop a future generation. runPolarisCli --stop also re-reads whichever state is latest (525-531), so using it blindly in cleanup does not pin the owned generation.

[Inferred] In the existing startResumed interception, capture the persisted new SupervisorState at wrapper ENTRY, before the first startup await. Production has synchronously published that state and stop offer immediately before invoking this wrapper. Check run/runId/declaration identity and require the generation to differ from the original fixture generation. Retain this snapshot for requestUrlSupervisorStop(stateRoot, snapshot). That API independently verifies generation, declaration, named offer and live binding (url-supervisor-state.ts:221-237,337-357); it cannot mark a replacement generation. Do not request using the original stopped state.

[Inferred] If cleanup began before wrapper entry, capture/request the newly published offer on entry and refuse to start the runtime; the production CLI catch/finally then releases its credential, stop handle, policy-Git scope and recovery claim. If startup was already in flight, the captured offer is available for the cleanup request, and a later returned runtime follows the immediate-stop rule above. If the CLI completes before an offer exists, join its completion normally. If the captured generation has already closed, distinguish that same generation's persisted terminal state from a changed/unavailable generation; a changed generation is an ownership failure, not permission to stop the replacement. Direct runtime.stop alone does not join CLI state/seal writes (polaris.ts:1582-1624 and outer finally683-686).

## Limits that prevent an unqualified correction claim

[Observed] Integration hookTimeout is 30000ms (vitest.config.ts:44). Pre-runtime recovery preparation exposes no cancellation handle to this test. Joining it may exceed that hook budget; retained prior preparation intervals exceeded 30 seconds. No timeout or deadline increase is proposed.

[Inferred] A timeout race must never release fixture disposal while joins remain pending. Keep f.close behind the real owner join, not Promise.race success. Also ensure afterAll's recoveryHost.root removal (test225) cannot run past a timed-out afterEach while this same owned task is pending: it must await the retained cleanup join, or fail and retain the root on unresolved ownership. Simply fixing afterEach's local runtime list without this outer disposal consideration is not a complete guarantee for timeout during early bootstrap. This ordering can preserve safety when a hook itself fails, but prompt completion within its unchanged 30-second budget remains Unknown.

[Unknown] No runtime validation establishes that a final implementation settles early-bootstrap, in-flight-runtime, active-CLI and post-CLI-diagnostic cases before hook expiry. A fresh review must assess exact bytes and test these failure seams without weakening assertions, swallowing cleanup failures, increasing limits, or attributing the original 600-second recovery failure to teardown. This design deliberately provides no invented PASS and no speculative product/performance fix.

## Bindings

[Observed] Source SHA-256, paths relative to source root:

- packages/polaris-dossier/src/url-run-composed.test.ts: bf6c2da5785db51ef61cbbd6fc58ac592fd03fd8031336bb69e5f83a4d1e1e82
- packages/polaris-dossier/src/polaris.ts: 8a26c1cab1785cb0e71768cb0fe40b452c5cfe6bbcfb3a66f780f6f78a01110d
- packages/polaris-dossier/src/url-run-sessions.ts: 1116c471ca2de89b4daaf7e4f1dc7e40d79f4afc82cf4d02195796a7126700e8
- packages/polaris-dossier/src/url-supervisor-state.ts: 1cc0f3b8f8b2df6554d5373ab310398aa6e218369bd7d734a502e067b26e1c50
- vitest.config.ts: a3b641bca9bfba4241a482443c7594e59959e395fffce8ed9c9cfcac6860ce10

[Observed] Retained inputs under /home/orca/.tmp/f3-native-admission-fixes/native-scratch-final-recovery-c245-execution-1:

- subject.json: 4e9a9327f28ee5e2f4bbfe02c41c48352430f76dbb2990d2eaed2764e3578998
- result.json: 6017ba4921f93ba97688ddf460777104be4b7a36d3d016b35b9123197f58afe7
- extracted-observations/native-finished.json: 6c2adc1071ade0eba1858d6c0c571027557861c5deb3ae103500a8be8048c6fe
- extracted-observations/finished.json: d1e30293218067e409f24556191dd827fc021820818ec9ba28966bc21dde3569

[Observed] Additional source binding: packages/polaris-dossier/src/url-run-composed.testkit.ts SHA-256 748f848bdcf4f8a862266cd8ddfd8db1191ea20d470b0b0334f17b36e1f21fc9.

[Observed] Retained recovery.log SHA-256: d258cc299786c4e480646bf735a5e2ec7917f8642d1c1c5bf7311f147372085f.
