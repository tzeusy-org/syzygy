#!/usr/bin/env python3
"""Package completed retained hosted5797 evidence; no provider call here."""
import calendar, collections, datetime, gzip, hashlib, io, json, pathlib, re, subprocess, tarfile, time
BASE=pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
SRC=BASE/'hosted-5797-completed-R1'
DEST=BASE/'hosted-5797-proof-final-R1'
ROOT=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
SUBJECT='5797a5a4b59c1e4238412216f976cfbe8c0050ec'
SYNTHETIC='e68905f25dbf2986e413fad66d32e78869979e2b'
MAIN='b739924d6c968bbea50f1d87122a69f3428523bd'
def sha(data):return hashlib.sha256(data).hexdigest()
def dual(path):
    assert path.is_file() and not path.is_symlink(),str(path)
    data=path.read_bytes()
    assert sha(data)==subprocess.run(['sha256sum',str(path)],check=True,capture_output=True,text=True).stdout.split()[0]
    return data
def load(path):return json.loads(dual(path))
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
sealed=[]
for line in (SRC/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert pathlib.PurePosixPath(name).name==name and sha(dual(SRC/name))==digest
    sealed.append(name)
assert sorted(p.name for p in SRC.iterdir())==sorted(sealed+['SHA256SUMS'])
assert len(sealed)==6
summary=load(SRC/'summary.json')
assert summary['subject']==SUBJECT
computed=[]
second=[]
for family,pop in [('node',10),('governance',6)]:
    run=load(SRC/(family+'-run.json'))
    jobs=load(SRC/(family+'-jobs.json'))
    assert run['head_sha']==SUBJECT and run['status']=='completed' and run['conclusion']=='success'
    assert run['id']==summary['runs'][family]
    assert len(jobs['jobs'])==jobs['total_count']==pop
    assert len({j['id'] for j in jobs['jobs']})==pop
    for job in jobs['jobs']:
        assert job['run_id']==run['id'] and job['head_sha']==SUBJECT
        assert job['status']=='completed' and job['conclusion']=='success'
        seconds=(datetime.datetime.fromisoformat(job['completed_at'].replace('Z','+00:00'))-
                 datetime.datetime.fromisoformat(job['started_at'].replace('Z','+00:00'))).total_seconds()
        other=calendar.timegm(time.strptime(job['completed_at'],'%Y-%m-%dT%H:%M:%SZ'))-calendar.timegm(time.strptime(job['started_at'],'%Y-%m-%dT%H:%M:%SZ'))
        assert seconds==other
        item=dict(workflow=family,id=job['id'],name=job['name'],conclusion=job['conclusion'],seconds=seconds)
        computed.append(item);second.append((job['id'],other))
assert computed==summary['jobs']
assert len(computed)==len(set(j['id'] for j in computed))==summary['population']==summary['success']==16
assert len(second)==16 and all(j['conclusion']=='success' for j in computed)
over=[j for j in computed if j['seconds']>420]
assert summary['budgetSeconds']==420 and over==summary['overBudget']
assert len(over)==1 and over[0]['name']=='node (integration, stop-resume)' and over[0]['seconds']==484
assert next(j for j in computed if j['name']=='checks (reconciliation selftest)')['seconds']==327
raw=dual(SRC/'stop-resume-job.log');lines=raw.decode().splitlines()
readback=load(BASE/'hosted-5797-selected-log-readback.json')
assert readback['logSha256']==sha(raw) and readback['lineCount']==len(lines)==2439
for selection in readback['selected']:assert lines[selection['line']-1]==selection['text']
assert len(readback['selected'])==10
flat=re.sub(r'\x1b\[[0-9;]*m','',raw.decode())
flat=re.sub(r'\\u001b\[[0-9;]*m','',flat)
assert SYNTHETIC in flat and 'Merge '+SUBJECT+' into '+MAIN in flat
assert '1 passed' in flat and '6 skipped' in flat and '(7)' in flat and '407450' in flat and '413.98s' in flat
api=load(BASE/'hosted-5797-synthetic-commit-api.json')
assert api['sha']==SYNTHETIC and [p['sha'] for p in api['parents']]==[MAIN,SUBJECT]
receipt=load(BASE/'d10-main-f4bb-proof-checkpoint-actual-commit.json')
assert receipt['commit']==SUBJECT
raw_commit=subprocess.check_output(['/usr/bin/git','-C',str(ROOT),'cat-file','commit',SUBJECT])
tree1=next(line.split()[1].decode() for line in raw_commit.splitlines() if line.startswith(b'tree '))
tree2=subprocess.check_output(['/usr/bin/git','-C',str(ROOT),'rev-parse',SUBJECT+'^{tree}'],text=True).strip()
assert tree1==tree2==receipt['tree']==api['tree']['sha']
identity=dict(metadataHead=SUBJECT,checkoutCommit=SYNTHETIC,checkoutParents=[MAIN,SUBJECT],
    checkoutTree=api['tree']['sha'],publishedSubjectTree=tree1,treeEquivalent=True,
    apiURL=api['url'],providerCalls=1,providerScope='One explicitly authorized read-only commit API call, retained separately',
    apiSha256=sha(dual(BASE/'hosted-5797-synthetic-commit-api.json')),
    methods=['Retained API commit tree matches exact subject raw commit header','Independent git rev-parse tree plus actual commit receipt'],
    repositoryCleanOrCurrentHeadClaim=False)
assert not DEST.exists();DEST.mkdir();payload=DEST/'payload';payload.mkdir()
sources=[]
def copy(path,name):
    data=dual(path);target=payload/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    assert dual(target)==data==path.read_bytes()
    sources.append(dict(path=name,source=str(path),bytes=len(data),sha256=sha(data)))
for name in sorted(sealed+['SHA256SUMS']):copy(SRC/name,'completed-hosted/'+name)
for name in ['hosted-5797-selected-log-readback.json','hosted-5797-synthetic-commit-api.json','d10-main-f4bb-proof-checkpoint-actual-commit.json']:
    copy(BASE/name,'binding-records/'+name)
copy(pathlib.Path(__file__),'assembly/assemble-hosted-5797-proof-R1.py')
dump(payload/'TREE-IDENTITY.json',identity)
dump(payload/'ASSESSMENT.json',dict(subject=SUBJECT,tree=tree1,metadataHead=SUBJECT,checkout=SYNTHETIC,
    workflows=dict(node=dict(jobs=10,success=10),governance=dict(jobs=6,success=6)),
    totalJobs=16,totalSuccess=16,allJobDurationsMatchTwoMethods=True,
    budgetSeconds=420,overBudget=over,
    composedCase=dict(source='retained raw log; no hosted Vitest JSON invented',passed=1,failed=0,skipped=6,total=7,selectedCasePrintedMs=407450,vitestPrintedSeconds=413.98),
    causalPerformanceImprovement='Unknown; no controlled timing comparison',
    later52fbOwning='Separate later subject; root reported typecheck failed before baseline/mutants, not accepted by this hosted5797 checkpoint',
    fullFinalAcceptance='Not established'))
(payload/'README.md').write_text('''# Completed hosted5797 checkpoint

[Observed] Published head5797a5a4b59c1e4238412216f976cfbe8c0050ec passes both hosted workflows: Node run45931279306 has10/10 successful completed jobs; governance run45931279311 has6/6. The complete16-job population matches each API total_count, unique job IDs and the retained summary. Every duration independently agrees between datetime subtraction and calendar UTC epoch arithmetic. Only stop-resume484s exceeds the unchanged420s bar; reconciliation327s and the other14 jobs remain within it. Successful execution is distinct from timing-budget acceptance.

[Observed] The raw stop-resume job log reports one selected genuine case PASS407450ms, six selection skips/7 total, one passed file and413.98s Vitest duration. The exact2439-line log and the existing ten selected-line readback are retained unchanged. No hosted Vitest JSON or structured case receipt is manufactured from console prose.

[Observed] Workflow metadata head5797 differs from executed synthetic checkout e68905f25dbf2986e413fad66d32e78869979e2b. One explicitly authorized read-only GitHub commit API call confirms parents b739924d6c968bbea50f1d87122a69f3428523bd then5797. Its tree4f5942039ac057d9957d59334ccd684188b97fa3 equals the exact published subject tree, independently checked from the raw Git commit header, git rev-parse and actual commit receipt. TREE-IDENTITY.json binds this mapping; there is no claim about the current primary HEAD or current live main ref.

[Unknown] A general runtime improvement, causal benefit from D10 or scheduling changes, full420-second compliance and complete final F3 acceptance. These are results for5797's exact tree under those hosted conditions. Later52fb is a distinct local source subject whose owning typecheck failed before baseline/mutants, as separately reported by root; this earlier hosted success does not accept that later observer change or relabel any local failure.

[Observed] Six original hosted evidence files plus their seal, selected readback, API response, actual checkpoint receipt and assembly definition are copied with complete source/member hash checks. Archive members have safe normalized relative paths,mtime0,uid/gid0,mode0644. Byte-identical deterministic rebuild and every-member readback are checked. No primary/source/ledger/status edit, test/build/product/native execution or further provider request occurs during assembly. Private TMP, fixture bodies, dependencies and unused earlier supplement are excluded.
''')
dump(payload/'SOURCE-INDEX.json',sources)
files=sorted((p.relative_to(payload).as_posix(),p.read_bytes()) for p in payload.rglob('*') if p.is_file())
def pack():
    raw=io.BytesIO()
    with tarfile.open(fileobj=raw,mode='w',format=tarfile.USTAR_FORMAT) as tar:
        for name,data in files:
            rel=pathlib.PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and str(rel)==name
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
            tar.addfile(info,io.BytesIO(data))
    out=io.BytesIO()
    with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0) as stream:stream.write(raw.getvalue())
    return out.getvalue()
packed=pack();assert pack()==packed;(DEST/'proof.tar.gz').write_bytes(packed)
members=[]
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
    assert tar.getnames()==[name for name,_ in files]
    for m,(name,data) in zip(tar.getmembers(),files):
        assert m.isfile() and m.mode==0o644 and m.uid==m.gid==m.mtime==0
        assert tar.extractfile(m).read()==data
        members.append(dict(path=name,bytes=len(data),sha256=sha(data)))
index=dict(subject=SUBJECT,archiveSha256=sha(packed),archiveBytes=len(packed),memberCount=len(members),memberReadbackHashes=len(members),sourceDualHashCount=len(sources),deterministicRebuildEqual=True,members=members)
dump(DEST/'ARCHIVE-INDEX.json',index)
(DEST/'SHA256SUMS').write_text(''.join(sha(dual(p))+'  '+p.relative_to(DEST).as_posix()+'\n' for p in sorted(DEST.rglob('*')) if p.is_file()))
checked=subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=DEST,capture_output=True,text=True,check=True)
print(json.dumps({**{k:v for k,v in index.items() if k!='members'},'independentFinalChecksumRows':len(checked.stdout.splitlines())},indent=2))
