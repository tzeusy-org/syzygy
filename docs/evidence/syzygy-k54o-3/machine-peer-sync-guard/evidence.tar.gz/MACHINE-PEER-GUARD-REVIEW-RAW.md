# Independent source review: machine peer guard pin
Verdict: PASS
Reviewed base: d8e1bf97b94989d767d47a0c1abc76ab9db48749
Binding SHA-256: 8b07435802623a631f87a60f2a157d15b3ec991483cfeb51cad67f4acb898ff2

Review date: 2026-11-25. Scope: frozen outside candidate only; source review, no test, build, native helper, or heavy execution. Reviewer did not author the candidate and received its artifact, governing references, and acceptance criteria. No repository, git, remote, or bead mutation was performed. This raw is retained outside the repository under CC-REV-6.

## Subject and binding

Packet: /home/orca/.tmp/f3-native-admission-fixes/machine-peer-guard-pin-candidate/

Primary read-only repository: /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| original-guard.ts | 36655 | bf4350f3d795ffa2862b7aac8114e407eaeea919e5c3701bbe6ac99e5a402cc4 |
| candidate-guard.ts | 36655 | dd49203268bb2282a6d0bb749547bc7989847ca6e79943a180921519854b7baa |
| old-peer.ts | 38140 | 2a1f0067d10f2fdef2ec96716166bd7e9785bb4667aafa580aa90f7fadd56cfb |
| current-peer.ts | 38414 | e484b8649debcfb170f456fd69172d651635bc380b79a19191fd469ecedc410c |
| binding.json | independently hashed | 8b07435802623a631f87a60f2a157d15b3ec991483cfeb51cad67f4acb898ff2 |
| prepare.mjs | independently hashed | 466efe80879561d764183e99bf576848efcce9db4f4d919daa2584fe0af1e3f3 |
| peer-context.diff | independently hashed | fd936ccabae5f729a46a14577c99a31c084f8b47084c8843c81ff0e59a80e850 |

[Observed] Independent Buffer lengths and SHA-256 computations matched the four source-file binding entries. git show established original-guard.ts and current-peer.ts equal their exact base blobs; old-peer.ts equals the module blob at predecessor 9c878b13f5ea7b819b4817517c675810d4b0f23c. The retained peer-context.diff equals a freshly read git diff over that predecessor and the base. git rev-parse reported the named base and git status --short was empty both when entering and finishing the read-only review.

[Observed] prepare.mjs reads those exact git blobs, checks worktree source agreement, computes the printer hashes, requires one runNative declaration and one direct spawnSync call, verifies unchanged native function/call fingerprints, and writes only this outside packet. I inspected its source; I did not run its writer. Independent verification used the TypeScript 5.9.3 parser/printer directly, not an import of the candidate or peer module.

## Governing references and acceptance

The references were read from the named base, except the skill texts, which were read from the supplied skill locations.

- SEC-3, .syzygy/governance/doctrine/security.md: "A sandbox is an execution profile: default-deny, isolated credentials" and "resource limits, and gates on destructive operations." The repair must preserve the native execution admission restrictions.
- CC-REV-1, .syzygy/governance/policies/craft-and-care/review-and-documentation.md: "Changes touching any of three classes get one review by an independent, fresh-context reviewer." Class 1 includes execution. This is that source review for the guard pin, not a review of A-236's full feature.
- CC-REV-6, same file: "Raw reviewer output is stored unchanged before synthesis."
- CC-TEST-1, .syzygy/governance/policies/craft-and-care/testing-and-verification.md: "A defect fix includes a test that fails on the pre-fix behavior and passes on the fixed behavior"; the existing owning guard and old-pin negative control provide the relevant regression seam.
- CC-TEST-2, same file: "Gate claims require retained, resolvable gate artifacts." This source verdict asserts no runtime test result.
- CC-BAR-1/2, .syzygy/governance/policies/craft-and-care/engineering-bar.md, and canonical engineering-bar/test-rigor: proportional verification, regression protection, explicit scope, and governed suite growth apply.
- A-236, .syzygy/governance/decisions/AGENT-ADOPTIONS.md: the adopted preparation/effect separation is the context for the changed peer module. Its whole feature is outside this one-literal review.

Acceptance: refresh only MACHINE_PEER_SOURCE to the exact current whole-module printer fingerprint; keep the synchronous spawnSync call and entire runNative exact; retain limits, prlimit, held-image verification, CPU reservation and capacity checks; preserve admission predicates and mutation controls; assess the existing full owning suite plus old-pin negative control without adding tests.

## Findings and reasoning

[Observed] candidate-guard.ts equals original-guard.ts after exactly one replacement of the MACHINE_PEER_SOURCE literal at line 113. An independent unified diff confirms that one changed line. The exact source equality establishes that the rest of both 36,655-byte guard files, including the admission predicates and mutation controls, is unchanged.

[Observed] Independent comment-removing TypeScript printer SHA-256 values reproduced binding.json:

| Fingerprint | Predecessor | Current |
| --- | --- | --- |
| Whole peer module | b164581a02191c9e1f7f2c1099247da81f54188b54dc19ece89a58807e86bf3c | 8724db73c9203533510f1cdca9156672988e511fe792eef72ea549b0828dabcd |
| runNative | eaea431fc96b3a5e276b1080b564a86f93df006af408ec52893c2fb142426e47 | eaea431fc96b3a5e276b1080b564a86f93df006af408ec52893c2fb142426e47 |
| Sole direct spawnSync call | a91baeff25ce94e5c56a9306b460dd766124f95c695fd8cc626019e67953e87f | a91baeff25ce94e5c56a9306b460dd766124f95c695fd8cc626019e67953e87f |

[Observed] runNative's raw declaration text is also identical. Comparing corresponding parsed top-level statement text found changes only in urlMachinePeerCaptureMilliseconds and mediateUrlMachinePeer, matching the retained two-hunk diff: preparation uses nativePreparationMilliseconds, and the trusted continuation invokes the one-use beginEffect transition. No helper or limit statement used by runNative differs between the two peer files.

[Observed] current-peer.ts lines 198-215 retain pinnedFile(program.executable, program.sha256, programBytes); executable mode and uid checks; opening the held image with O_NOFOLLOW; file identity comparison before and after execution; charging 2,000,000 microseconds before spawn; /usr/bin/prlimit with --cpu=1:1 and /proc/self/fd/4; fixed listener/prepare/read modes; the bounded 1000 ms timeout, SIGKILL, controlled LANG, and chunkBytes + 512 maximum output; stderr/error/signal refusal; and finally-closing the descriptor. URL_MACHINE_PEER_LIMITS, pinnedFile, sameFile and the surrounding native verification source are unchanged. This refresh admits the current adopted context without relaxing these restrictions.

[Observed] candidate-guard.ts lines 238-280 still require the whole module fingerprint together with the exact admitted call fingerprint, consume that call once, report missing sites, and leave unrecognized/duplicate calls flagged. Lines 359-407 retain the existing mutation controls, including machine timeout, digest comparison, chunk bound, CPU hard limit, removal of capacity charging, and undercharging. The owning suite's import-closure census remains unchanged.

[Inferred] The existing full owning guard suite plus an old-pin negative control are adequate for this one-constant repair. The suite's real source/import-closure assertion is the regression test: with the stale literal it must refuse the changed module; with the replacement it should admit that exact module while its unchanged mutation assertions continue to refuse weakening. A new test would duplicate this existing behavior. Net test delta is 0 added, 0 removed, established by exact guard equality apart from the constant and confirmed by the line diff. This is reuse of existing regression coverage, not a CC-TEST-1 exception.

[Inferred] PASS for the reviewed source scope. No revise-severity source finding. The material risk is approving a broader module pin that accidentally admits changed native behavior; the independent complete-source comparison, exact runNative/call equality, unchanged helper/limit statements, and retained mutation controls address that risk for these bound bytes.

[Unknown] Runtime results for the repaired guard and the old-pin negative control were not established by this review. Root owns their execution and retained evidence. Additional execution logs placed beside the frozen packet during review are outside this verdict's reviewed subject and were not relied upon. No claim is made about full checks, native acceptance, or deployment readiness.
