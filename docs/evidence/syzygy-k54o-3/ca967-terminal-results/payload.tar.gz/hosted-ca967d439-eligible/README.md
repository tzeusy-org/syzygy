# Hosted eligible recovery failure — ca967d439

[Observed] Exact published subject ca967d439b4e78ab0f1a347b578f4d7a95f2f696; node run45495398096, failed job138806342960. Raw log SHA-25673376ecf8f7f4c374e1f464ee63f69325662cb2ef53b2a106bf3548b798b700f. The published passive observer source hashes todd3de76e5c99bfb4ebfbd5c75f0842d332e2badfd10223841f370c00e87e1791. Raw API metadata, log, extracted diagnostics and published source archives are retained.

[Observed] Cold preparation accepted in3106.569873ms with no observed preparation predicate refusal. One proof was issued with4716ms left, returned with4715ms. Resumed render reached admission at9262.539074ms; admission remained pending when render refused at11538.982823ms,2276.443749ms later. The product lease still had48304ms, and the final artifact authority revalidation accepted. CLI resumed exit1 triggered the test assertion. Extra fixture proof-walk removal has not established successful completion.

[Inferred] Source requires a successful genuine continuation assertion before reaching admission. The observed pending admission at producer refusal supports expiry of the existing bounded race before admission settled. The source race uses min(product deadline, proof deadline). This does not identify a failed private validation predicate or prove its eventual result.

[Unknown] The passive WeakMap claim arguments are retained only in memory, not serialized by this failure path. Exact natural assertion/claim call count, argument identity and nested start/end times cannot be recovered from this log. Success-only exact-claim assertions were not reached. The cold preparation observer is not a trace of the subsequent validator. selected-diagnosis.json preserves those distinctions and exact scalar timings.
