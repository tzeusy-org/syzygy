#!/usr/bin/env python3
"""Preparation only until explicitly invoked after terminal and root reconciliation are complete."""
import argparse
import gzip
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
SUBJECT = 'f4bbffea3582817e01cc7dc7eece6aed51472090'
TREE = '63ffa8665a26c4e0e94f656b8cfd72d2edf3453e'
OUTPUT = BASE / 'ordinary-recovery-f4bbff-1'
OPERATOR = BASE / 'ordinary-recovery-f4bbff-R1'
EXPECTED_RAW = {'build.log', 'progress.json', 'recovery.log', 'vitest.json',
                'runtime-before-test.json', 'runtime-after-test.json', 'runtime-final.json'}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

def safe(name):
    p = pathlib.PurePosixPath(name)
    require(not p.is_absolute() and p.parts and '..' not in p.parts and str(p) == name, 'unsafe member ' + name)
    require(not any(x in {'.git', 'node_modules', 'tmp', 'TMP', '__pycache__'} for x in p.parts), 'excluded path ' + name)
    require(p.suffix != '.pyc', 'excluded bytecode ' + name)

def dual_hash(rows):
    """Independently hash original files with sha256sum; no project command is run."""
    done = subprocess.run(['sha256sum', '--', *[r['source'] for r in rows]], capture_output=True, text=True)
    require(done.returncode == 0, 'sha256sum failed: ' + done.stderr)
    got = {line.split(None, 1)[1].lstrip('*'): line.split(None, 1)[0] for line in done.stdout.splitlines()}
    for row in rows:
        data = pathlib.Path(row['source']).read_bytes()
        require(len(data) == row['bytes'] and digest(data) == row['sha256'] == got.get(row['source']),
                'source drift: ' + row['source'])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-reconciliation', type=pathlib.Path, required=True,
                        help='Completed independent JSON naming subject, tree and terminalSha256.')
    parser.add_argument('--analysis', type=pathlib.Path,
                        help='Optional completed analysis file, explicitly named and hash-bound by reconciliation.analysisSha256.')
    parser.add_argument('--destination', type=pathlib.Path, required=True,
                        help='New direct child of the outside-primary evidence base; existing directories are refused.')
    args = parser.parse_args()
    reconciliation = read_json(args.root_reconciliation)
    terminal_path = OUTPUT / 'terminal.json'
    require(terminal_path.is_file() and not terminal_path.is_symlink(), 'terminal absent/unsafe; do not read active output')
    terminal_bytes = terminal_path.read_bytes()
    terminal = json.loads(terminal_bytes)
    require(terminal.get('complete') is True, 'terminal is not complete; no proof created')
    require(terminal.get('subject') == SUBJECT and terminal.get('tree') == TREE, 'wrong terminal subject/tree')
    require(reconciliation.get('subject') == SUBJECT and reconciliation.get('tree') == TREE, 'wrong reconciliation subject/tree')
    require(reconciliation.get('terminalSha256') == digest(terminal_bytes), 'root reconciliation does not bind exact terminal')
    destination = args.destination.resolve()
    require(destination.parent == BASE.resolve() and not destination.exists(), 'destination must be a new direct child of evidence base')
    safe(destination.name)

    raw = terminal.get('rawFiles')
    require(isinstance(raw, list) and len(raw) == 7, 'expected seven terminal-declared raw files')
    require({r['path'] for r in raw} == EXPECTED_RAW and len({r['path'] for r in raw}) == len(raw), 'wrong/duplicate raw manifest')
    # Two independent flat censuses, neither walks private TMP.
    census1 = {p.name for p in OUTPUT.iterdir() if p.is_file()}
    with __import__('os').scandir(OUTPUT) as entries:
        census2 = {e.name for e in entries if e.is_file(follow_symlinks=False)}
    require(census1 == census2 == EXPECTED_RAW | {'terminal.json'}, 'unexpected or missing completed raw files')
    for row in raw:
        safe(row['path'])
        source = OUTPUT / row['path']
        require(not source.is_symlink(), 'raw symlink refused')
        data = source.read_bytes()
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'raw manifest mismatch: ' + row['path'])

    report = read_json(OUTPUT / 'vitest.json')
    population = {k: report.get(k) for k in ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'success']}
    assertions = [a for result in report.get('testResults', []) for a in result.get('assertionResults', [])]
    selected = [a for a in assertions if a.get('status') in {'passed', 'failed'}]
    require(len(assertions) == 7 and len(selected) == 1, 'not original seven-case/one-selected population')
    require(population['numTotalTests'] == 7 and population['numPendingTests'] == 6, 'not original one-selected/six-skipped report')
    require(population['numPassedTests'] + population['numFailedTests'] == 1, 'invalid selected result population')
    require(selected[0].get('title') == 'runs the genuine production pipeline to stop-resume', 'wrong selected case')

    phases = {r.get('name'): r for r in terminal.get('phases', [])}
    flags = {k: terminal.get(k) for k in ['sourceToolsUnchanged', 'runtimeUnchangedDuringCase', 'runtimeFinalUnchanged',
             'noOwnedChildren', 'forcedOwnedChildren', 'cleanupPendingSignals', 'cleanupErrors',
             'ordinaryConfiguredWorkers', 'testDeadlineMs', 'hookDeadlineMs']}
    fresh = {n: read_json(OUTPUT / n) for n in ['runtime-before-test.json', 'runtime-after-test.json', 'runtime-final.json']}
    fresh_equal = len({digest((OUTPUT / n).read_bytes()) for n in fresh}) == 1
    fresh_counts = {n: {'inputs': r.get('inputs'), 'outputs': r.get('outputs')} for n, r in fresh.items()}
    clean = all(flags[k] is True for k in ['sourceToolsUnchanged', 'runtimeUnchangedDuringCase', 'runtimeFinalUnchanged', 'noOwnedChildren'])
    clean = clean and all(flags[k] == [] for k in ['forcedOwnedChildren', 'cleanupPendingSignals', 'cleanupErrors'])
    original_limits = flags['ordinaryConfiguredWorkers'] is True and flags['testDeadlineMs'] == 600000 and flags['hookDeadlineMs'] == 30000
    pass_conditions = (terminal.get('accepted') is True and terminal.get('exitCode') == 0
        and phases.get('build', {}).get('exitCode') == 0 and phases.get('recovery', {}).get('exitCode') == 0
        and population == {'numTotalTests': 7, 'numPassedTests': 1, 'numFailedTests': 0, 'numPendingTests': 6, 'success': True}
        and terminal.get('counts') == population and terminal.get('selectedAssertion', {}).get('status') == 'passed'
        and selected[0].get('status') == 'passed' and clean and original_limits and fresh_equal
        and all(r == {'inputs': 367, 'outputs': 10} for r in fresh_counts.values()))
    if terminal.get('accepted') is True:
        require(pass_conditions, 'accepted terminal is inconsistent with PASS/cleanup/runtime evidence')
        outcome = 'PASS'
    else:
        require(terminal.get('accepted') is False, 'accepted flag missing/Unknown')
        outcome = 'FAIL (complete/unaccepted)'
    # A complete unaccepted run stays FAIL even if its selected case passed before a cleanup failure.
    admission = read_json(BASE / 'ordinary-f4bb-execution-admission.json')
    require(admission.get('subject') == SUBJECT and admission.get('tree') == TREE, 'wrong execution admission')
    require(digest((OPERATOR / 'SHA256SUMS').read_bytes()) == admission['operatorSealSha256'], 'operator seal mismatch')
    seal_paths = set()
    for line in (OPERATOR / 'SHA256SUMS').read_text().splitlines():
        wanted, name = line.split(None, 1)
        name = name.lstrip('*')
        safe(name)
        require(name not in seal_paths, 'duplicate operator seal row')
        seal_paths.add(name)
        require(digest((OPERATOR / name).read_bytes()) == wanted, 'operator member mismatch: ' + name)
    require({p.name for p in OPERATOR.iterdir() if p.is_file()} == seal_paths | {'SHA256SUMS'}, 'operator census mismatch')
    review = pathlib.Path('/home/orca/.tmp/f3-f4bb-original-operator-review-RAW.md')
    require(digest(review.read_bytes()) == admission['operatorReviewSha256'], 'operator raw-review mismatch')
    require(digest((BASE / 'root-f4bb-operator-seal-readback.json').read_bytes()) == admission['rootSealReadbackSha256'],
            'root operator-seal readback mismatch')
    require(terminal.get('operatorSha256') == digest((OPERATOR / 'run.py').read_bytes()), 'terminal runner mismatch')
    require(terminal.get('bindingsSha256') == digest((OPERATOR / 'bindings.json').read_bytes()), 'terminal bindings mismatch')

    sources = []
    def record(source, relative):
        safe(relative)
        source = pathlib.Path(source)
        require(source.is_file() and not source.is_symlink(), 'not a regular source: ' + str(source))
        data = source.read_bytes()
        sources.append({'path': relative, 'source': str(source), 'bytes': len(data), 'sha256': digest(data)})
    for p in sorted(OPERATOR.iterdir()):
        require(p.is_file(), 'unexpected operator directory')
        record(p, 'sealed-operator/' + p.name)
    for name in sorted(EXPECTED_RAW | {'terminal.json'}):
        record(OUTPUT / name, 'completed-original/' + name)
    record(review, 'reviews/' + review.name)
    for name in ['ordinary-f4bb-execution-admission.json', 'root-f4bb-operator-seal-readback.json',
                 'ordinary-f4bb-renewal-invocation.json', 'ordinary-f4bb-renewal.stdout', 'ordinary-f4bb-renewal.stderr',
                 'root-f4bb-doc-check-reconciliation.json']:
        record(BASE / name, 'completed-metadata/' + name)
    for folder in ['phase-ci-batch-proof-doc-check-1', 'phase-ci-batch-proof-doc-check-2']:
        for p in sorted((BASE / folder).iterdir()):
            if p.is_file():
                require(p.suffix == '.log' or p.name in {'progress.json', 'complete.json'}, 'unexpected doc-check file')
                record(p, 'completed-document-checks/' + folder + '/' + p.name)
    doc = read_json(BASE / 'root-f4bb-doc-check-reconciliation.json')
    require(doc.get('subject') == SUBJECT and doc.get('scopedAccepted') is True, 'wrong document-check reconciliation')
    for row in doc['rawDualHash']:
        data = (BASE / 'phase-ci-batch-proof-doc-check-2' / (row['name'] + '.log')).read_bytes()
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'document check mismatch')
    record(args.root_reconciliation, 'root-reconciliation.json')
    if args.analysis:
        require(reconciliation.get('analysisSha256') == digest(args.analysis.read_bytes()), 'analysis is not bound by root reconciliation')
        record(args.analysis, 'explicit-completed-analysis/' + args.analysis.name)
    record(pathlib.Path(__file__), 'assembly/assemble.py')
    record(pathlib.Path(__file__).with_name('CONTRACT.md'), 'assembly/CONTRACT.md')
    require(len({r['path'] for r in sources}) == len(sources), 'duplicate target')
    dual_hash(sources)

    references = []
    renewal = read_json(BASE / 'ordinary-f4bb-renewal-invocation.json')
    definition = pathlib.Path(renewal['argv'][1])
    require(digest(definition.read_bytes()) == renewal['scriptSha256'], 'renewal definition changed')
    references.append({'kind': 'renewal-definition-by-reference', 'path': str(definition),
                       'bytes': definition.stat().st_size, 'sha256': renewal['scriptSha256']})
    for name in ['fourth-tool-phase-proof-final-R1', 'hosted-ci-repair-rebalance-proof-final-R1', 'ordered-parent-batch-proof-final-R1']:
        p = BASE / name
        index = read_json(p / 'ARCHIVE-INDEX.json')
        require(digest((p / 'proof.tar.gz').read_bytes()) == index['archiveSha256'], 'prior proof archive drift')
        references.append({'kind': 'prior-proof-by-reference', 'path': str(p / 'proof.tar.gz'),
                           'bytes': index['archiveBytes'], 'sha256': index['archiveSha256'],
                           'indexSha256': digest((p / 'ARCHIVE-INDEX.json').read_bytes())})

    destination.mkdir()
    payload = destination / 'payload'
    payload.mkdir()
    for row in sources:
        target = payload / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(pathlib.Path(row['source']).read_bytes())
        require(digest(target.read_bytes()) == row['sha256'], 'copy mismatch')
    evidence = {'subject': SUBJECT, 'tree': TREE, 'terminalSha256': digest(terminal_bytes), 'outcome': outcome,
                'terminalAccepted': terminal.get('accepted'), 'terminalExitCode': terminal.get('exitCode'),
                'reportPopulation': population, 'selectedCase': selected[0], 'retainedFlags': flags,
                'freshRuntimeCaptures': fresh_counts, 'freshRuntimeCapturesEqual': fresh_equal,
                'historicalPrebuildTerminalRuntimeBefore': terminal.get('runtimeBefore'),
                'prebuildNote': 'Historical retention; never substitute for three fresh post-build captures.',
                'phaseCommandsAndDurations': terminal.get('phases'),
                'analysis': 'Explicit completed file retained' if args.analysis else 'Not supplied; initiating cause Unknown',
                'fullFinalGates': 'Not established by this proof', 'copiedSources': len(sources)}
    (payload / 'RESULT.json').write_text(json.dumps(evidence, indent=2) + '\n')
    (payload / 'SOURCE-INDEX.json').write_text(json.dumps(sources, indent=2) + '\n')
    (payload / 'PRIOR-REFERENCES.json').write_text(json.dumps(references, indent=2) + '\n')
    readme = ('# Completed original f4bb proof\n\n[Observed] Subject ' + SUBJECT + ', tree ' + TREE + '. Outcome: ' + outcome
        + '. The exact terminal, seven declared raw files and explicit independent root reconciliation are retained. '
        + 'The selected-case result and seven-case/one-selected/six-skipped denominator are in RESULT.json. '
        + 'FAIL is never promoted; PASS requires complete/accepted true, zero command exits, exact 1 PASS/6 skips/success and known-clean flags.\n\n'
        + '[Observed] Operator README/manifest standby labels describe frozen preparation time; actual admission and completed terminal own the later execution result. '
        + 'The operator, raw review, renewal records, prior failed document-check output and completed corrected document checks remain unchanged. '
        + 'Prebuild runtime retention is historical; three fresh captures are separate and their actual counts/equality are reported explicitly.\n\n'
        + '[Unknown] Missing flag values remain null/Unknown. This proof establishes no full final battery, hosted timing budget, generalized speedup or overall F3 acceptance. '
        + 'Any supplied analysis is explicitly named and hash-bound; absence yields initiating cause Unknown. Prior phase/CI/batch proofs and renewal definition are referenced by digest, not duplicated.\n\n'
        + '[Observed] Assembly executes no product, build, test, native helper or provider; no primary/ledger/status edit or publication occurs. '
        + 'Private TMP, observed fixture bodies, clones and dependencies are excluded. Every source/member is independently hashed; deterministic archive metadata uses mtime 0, uid/gid 0 and mode 0644.\n')
    (payload / 'README.md').write_text(readme)
    files = sorted((p for p in payload.rglob('*') if p.is_file()), key=lambda p: p.relative_to(payload).as_posix())
    members = [{'path': p.relative_to(payload).as_posix(), 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())} for p in files]
    def archive(path):
        with path.open('wb') as raw_stream:
            with gzip.GzipFile(filename='', fileobj=raw_stream, mode='wb', mtime=0, compresslevel=9) as gz:
                with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
                    for p, row in zip(files, members):
                        safe(row['path'])
                        data = p.read_bytes()
                        info = tarfile.TarInfo(row['path'])
                        info.size, info.mode, info.mtime = len(data), 0o644, 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        tf.addfile(info, io.BytesIO(data))
    output, rebuilt = destination / 'proof.tar.gz', destination / 'proof-rebuild.tar.gz'
    archive(output)
    archive(rebuilt)
    require(output.read_bytes() == rebuilt.read_bytes(), 'archive rebuild mismatch')
    rebuilt.unlink()
    expected = {r['path']: r for r in members}
    seen = []
    with tarfile.open(output, 'r:gz') as tf:
        for item in tf:
            safe(item.name)
            require(item.isfile() and item.name in expected and item.name not in seen, 'bad archive member')
            require(item.uid == item.gid == item.mtime == 0 and item.mode == 0o644, 'bad archive metadata')
            data = tf.extractfile(item).read()
            require(len(data) == expected[item.name]['bytes'] == item.size and digest(data) == expected[item.name]['sha256'], 'archive readback mismatch')
            seen.append(item.name)
    require(seen == sorted(expected), 'archive census/order mismatch')
    index = {'subject': SUBJECT, 'tree': TREE, 'terminalSha256': digest(terminal_bytes), 'outcome': outcome,
             'archiveBytes': output.stat().st_size, 'archiveSha256': digest(output.read_bytes()),
             'memberCount': len(members), 'memberReadbackHashes': len(seen),
             'sourceDualHashCount': len(sources), 'deterministicRebuildEqual': True, 'members': members}
    index_path = destination / 'ARCHIVE-INDEX.json'
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    checks = [(p, 'payload/' + p.relative_to(payload).as_posix()) for p in files] + [(output, 'proof.tar.gz'), (index_path, 'ARCHIVE-INDEX.json')]
    (destination / 'SHA256SUMS').write_text(''.join(digest(p.read_bytes()) + '  ' + name + '\n' for p, name in checks))
    checked = subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=destination, capture_output=True, text=True)
    require(checked.returncode == 0 and len(checked.stdout.splitlines()) == len(checks), 'independent package hash mismatch')
    dual_hash(sources)
    require(terminal_path.read_bytes() == terminal_bytes, 'terminal changed during assembly')
    print(json.dumps({k: v for k, v in index.items() if k != 'members'}, indent=2))

if __name__ == '__main__':
    main()

