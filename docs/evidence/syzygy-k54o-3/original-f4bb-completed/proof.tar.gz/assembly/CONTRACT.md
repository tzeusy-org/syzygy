# Completed original f4bb proof assembler — preparation contract

[Observed] Preparation only: assemble.py has not been invoked. No active ordinary-recovery-f4bbff-1 output has been read during preparation; no outcome, archive, index or proof seal has been created. Preparation inspected only the sealed operator, completed admission/renewal/doc metadata and a previous completed runtime record's schema.

Run only after the original process has terminated, terminal.complete is true, and root's independent reconciliation is complete:

    python3 /home/orca/.tmp/f3-native-admission-fixes/completed-original-f4bb-proof-preparation-R1/assemble.py \
      --root-reconciliation /ABSOLUTE/ACTUAL-COMPLETED-ROOT-RECONCILIATION.json \
      --destination /home/orca/.tmp/f3-native-admission-fixes/NEW-COMPLETED-PROOF-DIRECTORY

Optionally add --analysis /ABSOLUTE/ACTUAL-COMPLETED-ANALYSIS.json. Analysis is never guessed or auto-discovered. When supplied, its exact hash must equal root reconciliation's analysisSha256. When absent, the proof says initiating cause Unknown.

The required root reconciliation must name:

- subject: f4bbffea3582817e01cc7dc7eece6aed51472090
- tree: 63ffa8665a26c4e0e94f656b8cfd72d2edf3453e
- terminalSha256: the scripted digest of the actual complete terminal.json
- analysisSha256: required only if --analysis is supplied

No output artifact is opened before checking for a complete terminal; no logs/progress/runtime files are read if terminal is absent or incomplete. The destination must be a new direct child of the outside-primary evidence base. Existing directories are refused. Root reviews this script and supplies actual completed reconciliation; no owner phrase or new process gate is introduced.

The assembler checks the terminal-declared seven raw files plus terminal against two independent flat file censuses, exact sizes and hashlib/sha256sum hashes. It retains all eight completed outputs. It validates the original report's seven cases, one selected genuine stop-resume case and six selection skips.

PASS requires complete/accepted true, outer/build/recovery exits zero, exact report 1 passed/0 failed/6 skipped/7 total with success true, passed selected assertion, matching terminal counts, original workers/600000-ms case/30000-ms hooks, known-clean source/tools/runtime/children/cleanup flags and identical fresh captures with 367 inputs/10 outputs each. Any accepted terminal inconsistent with these facts is refused. Complete/accepted false remains FAIL (complete/unaccepted), even if a selected case passed before another failure; missing or adverse flags are retained and never normalized to clean.

The proof retains:

- Entire sealed ordinary-recovery-f4bbff-R1 operator and original raw operator review, admission and root seal readback.
- Completed renewal invocation/stdout/stderr; renewal script definition by verified path/size/SHA reference, without re-executing it or copying predecessor operator packets.
- Both historical failed and completed corrected proof-document check logs/records plus root-f4bb-doc-check-reconciliation.json. The prior unexpected-heading failure remains visible.
- Explicit root reconciliation and optional explicitly named analysis.
- Prior phase, CI and ordered-parent batch archives by verified archive/index hashes only.
- Assembly script/contract, original terminal/report/flags, actual phase argv/durations and the raw source index.

Historical terminal.runtimeBefore and operator prebuild-runtime.json are explicitly prebuild retention. They are never substituted for runtime-before-test.json, runtime-after-test.json and runtime-final.json from the fresh build. Actual fresh counts/equality are reported; absent flag values stay null/Unknown. No performance repair, CPU cause, full final gate or hosted timing acceptance is inferred.

At invocation, the new proof uses sorted safe relative regular-file members, mtime 0, uid/gid 0, mode 0644, gzip mtime 0 and a byte-identical rebuild. ARCHIVE-INDEX.json binds every member's size/SHA and the archive SHA. All members are read back, and original sources plus copied payload/archive/index receive independent sha256sum checks. Inputs are rechecked for drift before success. TMP, fixture bodies, dependencies and clones are excluded.

This script performs file reads/copies, hashing and archive assembly only. It does not run product code, builds, tests, fixtures, native helpers, renewal/operator commands or provider operations; it edits no primary/source/ledger/status file and does not publish or guess an adoption row.

