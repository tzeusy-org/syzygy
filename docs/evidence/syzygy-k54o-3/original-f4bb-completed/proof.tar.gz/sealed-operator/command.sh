#!/bin/sh
set -eu
SYZYGY_POC_BROWSER=/home/orca/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-f4bbff-R1/run.py --subject f4bbffea3582817e01cc7dc7eece6aed51472090 --output /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-f4bbff-1
