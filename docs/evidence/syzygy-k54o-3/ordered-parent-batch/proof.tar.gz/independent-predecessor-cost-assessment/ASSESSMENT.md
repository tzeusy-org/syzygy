# Actual 8198 fourth-tool cost and next decision

Subject `8198e8e34e394c8918a86db3dec02dc1ef1fa8f2`, tree `3f31393e0b5966ab9c3d23f80954b9742a427213`. This is an independent read-only assessment of the completed genuine failure. The existing analyzer was run against that completed record and was not changed. No product, test, fixture, native recovery, provider or primary-source execution/edit was performed.

[Observed] The original selected stop-resume case failed after **536206.948485 ms** under its unchanged **600000 ms** cap. Terminal is complete/unaccepted, source/tools/runtime exact, cleanup errors and forced children empty, no owned children remaining. All seven declared raw files plus terminal were size/hash-checked with `hashlib.sha256` and `sha256sum`; the flat eight-file population matches the manifest exactly. Eighteen immutable source blobs were similarly hash-bound. Independent analyzer output equals the root analysis byte-for-byte (SHA-256 `6586661e055ff8dd4d3f8854672b30c55bd696b9daaabe2160c44e63923e3066`). The production session/attempt/audit source bytes remain those assessed at 22b540; the actual fixture/testkit hashes match the reviewed phase observer.

## What the new spans establish

[Observed] Six identical first-boundary snapshots identify **tool turn 3, timer/timer**, associated with broker invocation four. Current CPU and remaining CPU at the timer are null/Unknown. Observer origin is **73373.995052 ms** absolute monotonic; tool admission is **430623.957241 ms** relative and timer is **460659.988251 ms** relative: **30036.031010 ms** elapsed. Host action is 430016.243–460664.892 ms. The complete failure census maps both retained invocation copies and all six fixed phase slots; these copies describe one invocation, not two executions.

| Portion of admitted tool through first timer | Elapsed ms | Status/meaning |
| --- | ---: | --- |
| Tool entry to reproduction start | 9100.596759 | Combined prefix; no exclusive delivery-completed cost |
| Reproduction, 439724.554–445512.169 | 5787.615 | returned |
| Gap to proof | 47.918 | Retained inter-call gap |
| Proof, 445560.087–446189.742 | 629.655 | returned |
| Gap to staging | 299.031 | Retained inter-call gap |
| Staging, 446488.773–454516.750 | 8027.977 | returned |
| Staging return to timer | 6143.238251 | Includes currentness and verdict store transaction below |

[Observed] These sequential portions sum to the actual local tool-to-timer elapsed interval. The three returned outcomes mean promise settlement; they do not independently prove validity, acceptance or eligibility. Subsequent entry into the verdict-staged store path does establish progression through the non-null checked staging branch in the actual source. No acknowledgment or terminal eligibility is proven.

## Material post-staging cost already retained

[Observed] Existing slots account for most of the post-staging interval without another timing patch:

| Retained span | Relative start–end ms | Elapsed ms |
| --- | --- | ---: |
| Staging return to tail tool-release-guard entry | 454516.750–454569.923 | 53.173 |
| Tail tool-release-guard | 454569.923–454836.839 | 266.916 |
| Before-release-current | 454837.208–455351.211 | 514.003 |
| Prepared-store-recheck before store append | 455351.799–456150.035 | 798.236 |
| Verdict-staged **store append** | 456160.443–460716.292 | 4555.849, rejected |

[Observed] Staging return to store append entry is **1643.693 ms**. The timer fires **4499.545251 ms into** the store append; it rejects **56.303749 ms after** the timer. The final audit-authority callback spans 460606.237–460716.043 ms and refuses after the timer. Its existing base-audit callback tail retains the first machine-effect check accepting through 460656.055926 ms and the later machine-effect check refusing at 460715.930794–460715.936756 ms. This refusal follows the initiating tool timer and host-action rejection; it is not evidence of an earlier initiating machine revocation.

| Verdict store append stage | Retained calls | Inclusive summed ms | Outcomes |
| --- | ---: | ---: | --- |
| Audit authority | 11 | 1671.709 | 10 accepted / 1 refused |
| Attempt authority | 5 | 2819.044 | 5 accepted |
| Write | 1 | 2.195 | accepted |
| Sync | 2 | 56.138 | accepted |
| Stat | 10 | 0.672 | accepted |
| Read | 12 | 0.562 | accepted |

[Observed] The 41 retained stage records are below the 96-record observer cap. The 16 audit/attempt authority intervals are nonoverlapping in this trace: an independent merged-interval calculation confirms their **4490.753 ms** union, **98.571%** of this store span. This is a material measured currentness path, not disk throughput or a small copying issue. Callback durations include their own nested work and waits and are not exclusive CPU.

[Observed] All five attempt callbacks accepted. Their 60 nested stage records include delivery assertions 911.245 ms, 15 machine-effect probes 782.735 ms, five runtime-authority probes 431.648 ms, ten sample waits 265.315 ms, ten machine-authority probes 245.641 ms, five lease probes 126.912 ms and ten budget checks 0.022 ms. These are already inside attempt-authority; adding them to 2819.044 ms would double-count elapsed work. Base-audit machine-effect tail records similarly nest within audit-authority. The tail drops older callbacks, so its constituent sums cannot describe all 11 audit checks.

[Observed] The store append itself rejects in this run. The writer also requires returned-reader verification, post-store currentness, another reread and deadline check (`url-ordered-design-writer.ts:78–85`). Neither store acceptance nor full writer completion can be claimed here. The remaining acknowledgment/release/terminal work was not completed or timed by this failure.

## What can and cannot be changed from this evidence

[Observed] The actual source explains the measured authority composition:

- `url-session-audit.ts:815–845` commits through independently checked entry and post-write, post-sync and post-prefix/read boundaries. The outer `io` wrapper at lines516–523 brackets its operation with base authority too.
- Ordered `checkAttemptCurrent` at lines1027–1032 performs base `checkCurrent`, the attempt callback, then base `checkCurrent` again, retaining attempt deadlines before/after.
- The actual base callback in `url-run-sessions.ts:331–332` brackets `options.current()` with machine-effect checks.
- The actual attempt callback in `url-run-ordered-attempt.ts:161–208` includes samples, run authority, machine effect, machine/lease authority and full protected delivery validation. These are the nested measured costs above.
- The audit API accepts an arbitrary `attemptCurrent` callback. Its type does not establish that every caller supplies the full base/run-policy checks. Replacing the bracketing base checks with that callback on the assumption that they are equivalent would weaken generic callers and change refusal order.
- `policy-snapshot.ts:142–156` already uses the admitted commit to batch committed-policy bytes in the common case, with fresh HEAD/ref and working-file checks. Suggesting another batch or persistent helper from these aggregate timings would not establish where its present cost lies.

[Inferred] The first **material supported optimization target** is the composition/implementation of these full authority checks around ordered audit I/O, and the 8.028-second ordinary staging path that invokes its own full proof/capture guards. This supersedes the unused-view-copy observation as a runtime-repair direction: the measured proof phase is only 0.630 seconds, and no copy cost explains the material append guard spans. A safe concrete optimization has **not** been established. Removing base/attempt checks, narrowing their protected denominator, reusing an earlier pass, moving work outside its bounded operation or increasing caps would not satisfy the stated preservation constraints. No production candidate is authored on that basis.

[Unknown] The 9.101-second pre-reproduction prefix cannot yet be assigned exclusively to the delivery-completed store transaction versus writer pre/post-currentness and subsequent stage entry guards. `latestAppend` is a single overwritten store trace (`url-run-composed.test.ts:1666–1686`). The complete decoded failure contains **3685 dictionaries / 2032 phase records** and **zero structured delivery-completed kind records**; a separate exact serialized-kind count also finds zero. The public audit trace retains 32/122 initial public appends and all 22 resumed public appends, but its wrapper observes `audit.append`, while ordered records use the private `enqueue` path at audit lines1035–1053. That public tail cannot recover the missing private trace. The first-refused store summary equals the latest verdict-staged summary, not a historical delivery-completed record.

[Inferred] The **smallest missing seam is retention of an existing trace**, not another generic profiler: retain the already-created `AppendTrace` when `record.kind === 'delivery-completed'`, alongside prepared/latest/first-refused, and expose that fixed reference through the existing failure summary. Its already-recorded authority/current subspans would reveal how much of the material prefix is that transaction. This requires no new clocks, CPU/authority samples, timing helper, body/error/path content, or genuine case. It still would not measure the whole writer wrapper, because `AppendTrace` is store-level; its pre/post currentness must remain explicitly outside that span. No such observer change is authored here. If the next decision instead concerns a specific native/policy constituent optimization, its exclusive contribution inside the measured authority callbacks is the missing fact; aggregate durations alone do not choose its implementation.

All original freshness entry/post-I/O/release guards, exact same-delivery proof, complete secret checks, terminal eligibility, finite caps and original genuine assertions remain constraints. Timer CPU is Unknown. Shared cumulative ledger deltas are never added to a local baseline or assigned as exclusive CPU. This failed run establishes a material authority path and a narrowly missing retained record; it does not establish a successful optimized run.

`measurements.json` contains the complete retained ordered-store stage/current traces and public audit append/callback metadata as safe scalars, plus exact partitions and population counts. `bindings.json` binds every raw file and inspected committed source. `analysis.json` is the independently reproduced analyzer output. No raw body, arbitrary error text or private fixture path is retained in these derived outputs.
