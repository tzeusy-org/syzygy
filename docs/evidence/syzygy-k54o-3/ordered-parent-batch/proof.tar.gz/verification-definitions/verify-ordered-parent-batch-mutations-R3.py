import ctypes,hashlib,json,os,signal,subprocess,tempfile,time
from pathlib import Path
root=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w');base=Path('/home/orca/.tmp/f3-native-admission-fixes')
out=base/'ordered-parent-batch-mutations-3'
node='/home/orca/.nvm/versions/node/v24.6.0/bin/node';npm='/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
file='packages/polaris-dossier/src/url-launch-history.test.ts';ledger='packages/polaris-dossier/src/url-origin-ledger.ts';artifacts='packages/polaris-dossier/src/url-run-artifacts.ts'
pattern=r'keeps a metadata-only event and rechecks after durability \(ordered\)$|returns a read-only receipt batch after exact bytes and final authority are checked$'
only=r'keeps a metadata-only event and rechecks after durability \(ordered\)$'
def main():
 out.mkdir();scratch=Path(tempfile.mkdtemp(prefix='pb-',dir='/home/orca/.tmp'));identity=scratch.lstat();env=dict(os.environ,TMPDIR=str(scratch),PATH=str(Path(node).parent)+':/usr/bin:/bin')
 assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
 subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
 originals={name:(root/name).read_bytes() for name in [ledger,artifacts]};steps=[];reaped=[]
 def run(name,argv,expectedFail=False):
  started=time.monotonic();log=out/(name+'.log')
  with log.open('wb') as stream:
   child=subprocess.Popen(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=180)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGKILL);child.wait();raise
  raw=log.read_bytes();row={'name':name,'argv':argv,'exit':code,'seconds':time.monotonic()-started,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  if name!='typecheck':
   d=json.loads((out/(name+'.json')).read_text());rows=[a for f in d['testResults'] for a in f['assertionResults']];active=[a for a in rows if a['status'] in ['passed','failed']]
   row['population']={k:d[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']};row['activeNames']=[a['fullName'] for a in active]
   assert len(rows)==d['numTotalTests'] and len(active)==(1 if expectedFail else 2)
   assert d['numPassedTests']==(0 if expectedFail else 2) and d['numFailedTests']==(1 if expectedFail else 0)
   if expectedFail:assert len(active[0]['failureMessages'])>0 and 'promise resolved' in '\n'.join(active[0]['failureMessages']) and 'url-launch-history.test.ts:554:' in '\n'.join(active[0]['failureMessages']) and 'AssertionError: promise resolved' in raw.decode()
   assert 'Unhandled Errors' not in raw.decode() and 'Unhandled Rejection' not in raw.decode()
  steps.append(row);(out/'progress.json').write_text(json.dumps({'subject':subject,'steps':steps},indent=2)+'\n');print(json.dumps(row),flush=True);assert code==(1 if expectedFail else 0)
 def vitest(name,files,selection):return [node,'node_modules/vitest/vitest.mjs','run','--project','integration',*files,'--testNamePattern='+selection,'--reporter=default','--reporter=json','--outputFile='+str(out/(name+'.json'))]
 try:
  assert json.loads((base/'root-parent-batch-focused-baseline-reconciliation.json').read_text())['subject']==subject
  source=originals[artifacts].decode();old='            ledger.inspectMetadata(parents.map(receipt => ({ receipt })));\n            for (const parent of parents) if (!inputParents.includes(parent)) inputParents.push(parent);'
  mutants=[('per-parent',artifacts,old,'            for (const parent of parents) { ledger.metadata(parent); if (!inputParents.includes(parent)) inputParents.push(parent); }'),('empty-batch',artifacts,'ledger.inspectMetadata(parents.map(receipt => ({ receipt })))','ledger.inspectMetadata([])')]
  lsource=originals[ledger].decode();start=lsource.index('  function inspectMetadata(');end=lsource.index('  function verifySubjects',start);region=lsource[start:end];assert region.count('    live();')==2
  mutants.append(('lost-exit',ledger,region,region.rsplit('    live();\n',1)[0]+region.rsplit('    live();\n',1)[1]))
  for name,path,old,new in mutants:
   if name=='per-parent':continue
   original=originals[path].decode();assert original.count(old)==1
   (out/(name+'-mutant.json')).write_text(json.dumps({'subject':subject,'path':path,'old':old,'new':new},indent=2)+'\n')
   (root/path).write_text(original.replace(old,new))
   try:run(name,vitest(name,[file],only),True)
   finally:(root/path).write_bytes(originals[path])
 finally:
  for name,raw in originals.items():(root/name).write_bytes(raw)
  until=time.monotonic()+10
  while True:
   try:pid,status=os.waitpid(-1,os.WNOHANG)
   except ChildProcessError:break
   if pid:reaped.append({'pid':pid,'status':status});continue
   assert time.monotonic()<until,'owned-child-still-active';time.sleep(.05)
  assert scratch.stat().st_uid==os.getuid()
  # The existing tempDir fixtures and Vitest own their removals; preserve leftovers as a refusal.
  leftovers=list(scratch.iterdir());assert all(p.name=='node-compile-cache' and p.is_dir() and not p.is_symlink() for p in leftovers)
  for p in scratch.rglob('*'):assert not p.is_symlink() and p.lstat().st_uid==os.getuid() and (p.is_dir() or p.is_file())
  import shutil
  for p in leftovers:shutil.rmtree(p)
  final=scratch.lstat();assert (final.st_dev,final.st_ino)==(identity.st_dev,identity.st_ino) and not scratch.is_symlink();scratch.rmdir()
  (out/'cleanup.json').write_text(json.dumps({'scratch':str(scratch),'leftovers':leftovers,'reaped':reaped,'sourceRestored':all((root/n).read_bytes()==r for n,r in originals.items())},indent=2)+'\n')
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
 for name,raw in originals.items():assert (root/name).read_bytes()==raw
 (out/'complete.json').write_text(json.dumps({'subject':subject,'steps':steps,'scopedAccepted':True,'exactSourceRestored':True,'ownedChildrenJoined':True,'reaped':reaped,'scratchRemoved':not scratch.exists()},indent=2)+'\n')
if __name__=='__main__':main()
