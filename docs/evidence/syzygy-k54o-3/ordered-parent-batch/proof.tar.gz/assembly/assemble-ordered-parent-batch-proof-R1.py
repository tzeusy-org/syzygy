#!/usr/bin/env python3
"""Copy completed evidence and assemble deterministic archives; executes no repository code."""
import collections
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tarfile

BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
SELF = BASE / 'assemble-ordered-parent-batch-proof-R1.py'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe(name):
    p = pathlib.PurePosixPath(name)
    assert not p.is_absolute() and p.parts and '..' not in p.parts and str(p) == name, name
    assert not any(x in {'.git', 'node_modules', '__pycache__', 'tmp', 'TMP'} for x in p.parts), name
    assert p.suffix != '.pyc', name
    return p

def verify_manifest(folder, filename='SHA256SUMS'):
    manifest = folder / filename
    for line in manifest.read_text().splitlines():
        digest, name = line.split(None, 1)
        name = name.lstrip('*')
        safe(name)
        assert sha((folder / name).read_bytes()) == digest, str(manifest) + ':' + name
    done = subprocess.run(['sha256sum', '--check', filename], cwd=folder, capture_output=True, text=True)
    assert done.returncode == 0, str(manifest) + ': ' + done.stderr

class Proof:
    def __init__(self, name):
        self.root = BASE / name
        self.root.mkdir(exist_ok=False)
        self.payload = self.root / 'payload'
        self.payload.mkdir()
        self.sources = []

    def file(self, source, relative):
        source = pathlib.Path(source)
        safe(relative)
        assert source.is_file() and not source.is_symlink(), str(source)
        data = source.read_bytes()
        target = self.payload / relative
        assert not target.exists(), str(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        assert target.read_bytes() == data and source.read_bytes() == data, str(source)
        self.sources.append({'path': relative, 'source': str(source), 'bytes': len(data), 'sha256': sha(data)})

    def tree(self, source, relative):
        source = pathlib.Path(source)
        assert source.is_dir() and not source.is_symlink(), str(source)
        files = sorted(p for p in source.rglob('*') if p.is_file())
        assert not any(p.is_symlink() for p in source.rglob('*')), str(source)
        for p in files:
            self.file(p, relative + '/' + p.relative_to(source).as_posix())
        return len(files)

    def write(self, relative, text):
        safe(relative)
        p = self.payload / relative
        assert not p.exists()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)

    def finish(self, readme, subject):
        self.file(SELF, 'assembly/assemble-ordered-parent-batch-proof-R1.py')
        self.write('README.md', readme)
        source_index = {'subject': subject, 'copiedFileCount': len(self.sources),
                        'copiedBytes': sum(x['bytes'] for x in self.sources), 'files': self.sources}
        self.write('SOURCE-INDEX.json', json.dumps(source_index, indent=2) + '\n')
        files = sorted((p for p in self.payload.rglob('*') if p.is_file()),
                       key=lambda p: p.relative_to(self.payload).as_posix())
        members = [{'path': p.relative_to(self.payload).as_posix(),
                    'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in files]
        expected = {row['path']: row for row in members}
        def archive(path):
            with path.open('wb') as raw:
                with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=9) as gz:
                    with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
                        for p, row in zip(files, members):
                            data = p.read_bytes()
                            info = tarfile.TarInfo(row['path'])
                            info.size = len(data)
                            info.mtime = 0
                            info.uid = info.gid = 0
                            info.uname = info.gname = ''
                            info.mode = 0o644
                            tf.addfile(info, io.BytesIO(data))
        output = self.root / 'proof.tar.gz'
        second = self.root / 'proof-rebuild.tar.gz'
        archive(output)
        archive(second)
        assert output.read_bytes() == second.read_bytes(), 'non-deterministic archive'
        second.unlink()
        seen = []
        with tarfile.open(output, 'r:gz') as tf:
            for item in tf:
                safe(item.name)
                assert item.isfile() and item.name in expected, item.name
                assert item.mode == 0o644 and item.uid == item.gid == item.mtime == 0
                assert item.uname == item.gname == ''
                data = tf.extractfile(item).read()
                row = expected[item.name]
                assert len(data) == row['bytes'] == item.size and sha(data) == row['sha256'], item.name
                seen.append(item.name)
        assert seen == sorted(expected) and len(seen) == len(set(seen))
        source_checks = subprocess.run(['sha256sum', *[r['source'] for r in self.sources]],
                                       capture_output=True, text=True)
        assert source_checks.returncode == 0
        actual_sources = {}
        for line in source_checks.stdout.splitlines():
            digest, name = line.split(None, 1)
            actual_sources[name.lstrip('*')] = digest
        for row in self.sources:
            assert actual_sources[row['source']] == row['sha256'], row['source']
        index = {'sourceIndependentSha256sumChecks': len(self.sources), 'subject': subject, 'archive': 'proof.tar.gz', 'archiveBytes': output.stat().st_size,
                 'archiveSha256': sha(output.read_bytes()), 'memberCount': len(members),
                 'copiedSourceFiles': len(self.sources), 'copiedSourceBytes': sum(x['bytes'] for x in self.sources),
                 'payloadBytes': sum(row['bytes'] for row in members),
                 'deterministicByteRebuildEqual': True, 'memberReadbackHashCount': len(seen),
                 'memberMode': '0644', 'memberMtime': 0, 'uid': 0, 'gid': 0,
                 'members': members}
        index_path = self.root / 'ARCHIVE-INDEX.json'
        index_path.write_text(json.dumps(index, indent=2) + '\n')
        checks = [(p, 'payload/' + p.relative_to(self.payload).as_posix()) for p in files]
        checks += [(output, 'proof.tar.gz'), (index_path, 'ARCHIVE-INDEX.json')]
        (self.root / 'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + name + '\n' for p, name in checks))
        verified = subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=self.root,
                                  capture_output=True, text=True)
        assert verified.returncode == 0
        assert len(verified.stdout.splitlines()) == len(checks)
        # Recheck every copied source after final assembly; never seal a drifting completed record.
        for row in self.sources:
            data = pathlib.Path(row['source']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['source']
        return {'root': str(self.root), 'archive': str(output), 'memberCount': len(members),
                'copiedFiles': len(self.sources), 'archiveBytes': output.stat().st_size,
                'archiveSha256': index['archiveSha256'], 'indexSha256': sha(index_path.read_bytes()),
                'sealSha256': sha((self.root / 'SHA256SUMS').read_bytes()),
                'independentSha256sumChecks': len(checks),
                'memberReadbackHashCount': len(seen), 'independentSourceSha256sumChecks': len(self.sources)}


receipt = json.loads((BASE / 'ordered-parent-batch-actual-commit.json').read_text())
assert receipt['head'] == 'c1bb89f89247770686209b688c8fac220e0031da'
source = BASE / 'ordered-review-parent-batch-8f8c024-R1'
bundle = json.loads((source / 'bundle-manifest.json').read_text())
assert len(bundle['files']) == 10
assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == {r['path'] for r in bundle['files']} | {'bundle-manifest.json'}
for row in bundle['files']:
    safe(row['path'])
    data = (source / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
assert sha((source / 'bundle-manifest.json').read_bytes()) == receipt['packetManifestSha256']
review = pathlib.Path(receipt['sourceReviewPath'])
assert sha(review.read_bytes()) == receipt['sourceReviewSha256']
root_complete_path = BASE / 'root-parent-batch-focused-complete-reconciliation.json'
complete = json.loads(root_complete_path.read_text())
assert complete['subject'] == receipt['head'] and complete['scopedRootAcceptance']
assert len(complete['rawDualHash']) == 17
allowed = {row['path'] for row in complete['rawDualHash']}
actual = {p.relative_to(BASE).as_posix()
          for name in ['ordered-parent-batch-focused-1', 'ordered-parent-batch-mutations-2', 'ordered-parent-batch-mutations-3']
          for p in (BASE / name).iterdir() if p.is_file()}
assert actual == allowed
for row in complete['rawDualHash']:
    safe(row['path'])
    data = (BASE / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
assessment = BASE / 'ordinary-recovery-8198e8-diagnosis-assessment-1'
verify_manifest(assessment)
verify_manifest(assessment, 'ADDENDUM-SHA256SUMS')

proof = Proof('ordered-parent-batch-proof-final-R1')
assert proof.tree(source, 'frozen-source-R1') == 11
proof.file(BASE / 'ordered-parent-batch-actual-commit.json', 'actual-commit/ordered-parent-batch-actual-commit.json')
proof.file(review, 'reviews/f3-ordered-parent-batch-R1-source-review-RAW.md')
for name in ['verify-ordered-parent-batch.py', 'verify-ordered-parent-batch-mutations-R2.py', 'verify-ordered-parent-batch-mutations-R3.py']:
    proof.file(BASE / name, 'verification-definitions/' + name)
for row in complete['rawDualHash']:
    proof.file(BASE / row['path'], 'focused-evidence/' + row['path'])
for name in ['root-parent-batch-focused-baseline-reconciliation.json',
             'root-parent-batch-per-parent-mutation-reconciliation.json',
             'root-parent-batch-focused-complete-reconciliation.json']:
    proof.file(BASE / name, 'root-reconciliations/' + name)
assert proof.tree(assessment, 'independent-predecessor-cost-assessment') == 8
phase = BASE / 'fourth-tool-phase-proof-final-R1'
phase_index = json.loads((phase / 'ARCHIVE-INDEX.json').read_text())
assert sha((phase / 'proof.tar.gz').read_bytes()) == phase_index['archiveSha256']
prior_reference = {'artifact': str(phase / 'proof.tar.gz'),
                   'archiveSha256': phase_index['archiveSha256'],
                   'archiveMemberCount': phase_index['memberCount'],
                   'archiveIndexSha256': sha((phase / 'ARCHIVE-INDEX.json').read_bytes()),
                   'scope': 'Previous completed observer/local8198failure proof; referenced, not duplicated. Only its independently sealed assessment and addendum are copied here.'}
proof.write('prior-phase-proof-reference.json', json.dumps(prior_reference, indent=2) + '\n')

readme = """# Ordered review-parent batch: actual source and scoped verification

[Observed] Actual commit c1bb89f89247770686209b688c8fac220e0031da, tree 8af0f537cc593a5529fcf7fe7e612550047373f5, parent 8f8c024940b7eabf1324a3180c4355593bc48187, changes only url-run-artifacts.ts and url-launch-history.test.ts. The complete frozen source packet carries ten bound files plus its bundle manifest; its raw fresh review records PASS for those bytes. The actual commit receipt binds the source packet and raw review hashes.

[Observed] Sampling changes from N per-parent prechecks to two fresh synchronous batch endpoint checks through the existing inspectMetadata seam. Every same branded receipt lookup and metadataOf screening/copy remains; ordered parent union, caps and design-origin checks remain. The batch neither awaits nor performs artifact I/O. Existing asynchronous proof/currentness/release, native authority, secret screening and resource caps remain intact; no authority cache is added. Test growth is zero declarations/files, extending one existing ordered-mode case.

[Observed] Actual typecheck passes in 21.470767565 seconds. Focused baseline selects two passing cases with 85 selection skips of 87: the ordered delivery-audit behavior and origin-ledger read-only batch behavior. The original R1 wrapper FAILED: its classifier treated skipped statuses as active and then its cleanup rejected normal node-compile-cache contents. No mutant ran in R1; its scratch cleanup was incomplete. Raw logs, progress, unchanged wrapper and independent root baseline reconciliation remain verbatim. This proof does not claim original-wrapper PASS.

[Observed] The R2 wrapper runs only the per-parent mutant. Its actual result is the intended one assertion failure with 59 selection skips of 60; root independently reconciles the owning test's expected rejection versus received staged verdict. The wrapper still FAILED because JSON's Error prefix differed from the log's AssertionError classifier, followed by a duplicate rmdir on already-removed scratch. Its cleanup record confirms exact source restoration, joined children and removed scratch. Its script, exact mutant definition, log, JSON result and cleanup remain unchanged; this is not an original R2 wrapper PASS.

[Observed] R3 runs only the two remaining mutants, empty-batch and lost-exit. Each produces the intended one failing owning assertion and 59 selection skips of 60. R3 completes scopedAccepted, with exact source restored, children joined and owned scratch removed. The complete root reconciliation independently accepts the three intended mutant outcomes and the two-case baseline, preserving both earlier wrapper failures.

[Observed] All 17 completed focused/mutation evidence files are retained exactly as root's declared raw population: R1 four, R2 four and R3 nine. Each mutant retains its exact old/new definition and actual source subject. All three verification scripts and all three independent root reconciliations are included. No TMP, clone, dependency, private fixture body or active output is included.

[Observed] The independent predecessor cost assessment and its correcting ADDENDUM are retained together. The later addendum traces the production ledger freshness callback to native checks and supports this existing bounded batch seam. The prior complete fourth-tool observer/local8198failure proof is referenced by exact archive/index hashes in prior-phase-proof-reference.json rather than duplicated.

[Unknown] The actual fourth-tool parent population N, exact removed check count for that invocation, timing benefit, genuine recovery improvement and full F3 acceptance. The original next case has not been invoked by this proof; no success is manufactured from source reasoning or narrow tests. Full final gates and hosted timing acceptance are not established here. No adoption ID is guessed.

[Observed] Packaging performs no source/ledger/primary edit, product, test, fixture, build, provider request, commit or push. Prior packets, raw verdicts, root records and archives remain unchanged. SOURCE-INDEX.json retains every copied source locator/size/hash. External ARCHIVE-INDEX.json binds safe normalized relative members and the archive SHA. Archive files use mtime 0, uid/gid 0 and mode 0644; a byte-identical rebuild, every member readback, and independent source/member sha256sum checks verify the package.
"""
result = proof.finish(readme, {'actualCommit': receipt['head'], 'actualTree': receipt['tree'],
                              'parent': receipt['parent'], 'scopedRootAcceptance': True,
                              'originalWrappers': {'R1': 'FAILED', 'R2': 'FAILED', 'R3': 'scopedAccepted'},
                              'performanceBenefit': 'Unknown', 'nextOriginalCase': 'not invoked by this proof',
                              'fullFinalGates': 'not established'})
(BASE / 'ordered-parent-batch-proof-final-R1-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

