PASS

Fresh independent source review: recovery latest-operation diagnostic.
Captured: 2026-11-25T05:54:41.494480+00:00
Reviewer: Codex fresh review subagent /root/review_recovery_diagnostic_ff651

Subject commit: ff65169e95dcfa7b14cf53494e8464202b29b914
Subject file: packages/polaris-dossier/src/url-run-composed.test.ts
Packet: /home/orca/.tmp/f3-native-admission-fixes/policy-worker-cpu-integration-ff651/diagnostic-patch-ff651

Subject SHA-256 bindings:

- README.md: 7760946aaa7d59f6dd57129d1e5f26986ab6a620974c33dd833a52359db30d63
- before.ts: de96b193f896b24de8ec1953d1b180086fd7b4cdb30ec4235c4a46d406f14249
- after.ts: 27a592f814fb685ec8c45159147f9517356291afbbdd17d1926129fe55009653
- bindings.json: d43346aa3d236b3ea6390a7acbe102ce483b0e80ad46249b3ebe2f6914c7fc28
- diagnostic.patch: 097a185ef67e5f39e26a14b55ab5570faa42733b31029d198713a0afc22e94fb

Consulted implementation source SHA-256 bindings:

- packages/polaris-dossier/src/url-ordered-design-session.ts: 65906032d8b0192c615fd68526bea5b6bfd8b76e604d75ee750f8503f8b0528d
- packages/polaris-dossier/src/url-ordered-design-work-budget.ts: 6904332379f22a294a73f5ae34a0555a2a05bcd50a3f163a0821f9a4773bf0b5
- packages/polaris-dossier/src/url-ordered-design-host.ts: 32df5239315d089d88db2eaeb6bc38ae94eca343452cc6126280903f2e6ba64f
- packages/polaris-dossier/src/session-broker.ts: e38ede1ae1395eb42b4c1bda4d1e37a305d55c75435d65e84bbeb436d99f5525
- packages/polaris-dossier/src/url-machine-peer.ts: e484b8649debcfb170f456fd69172d651635bc380b79a19191fd469ecedc410c
- packages/polaris-dossier/src/url-machine-instance.ts: d681f9d3220f8d3c466456ba6d9b35526866b5a78c7127ce05873603e8f0b271
- packages/polaris-dossier/src/url-run-ordered-attempt.ts: d4f08b0f81ffd24cb04950196d0c9a28d5c105e6f424b158e454cf6d9db53062

[Observed] Scope was the frozen before/after/patch/bindings/README packet, the exact committed test predecessor, and the genuine controller/ledger/host/broker/mediation seams needed to assess the diagnostic. The applicable engineering bar, trust-and-evidence doctrine, SEC-5, and CC-OBS-3/4 were read. No tests, native code, product commands, or packet scripts were executed. No repository files were changed. Python was used only for static byte comparisons, hashing, and retaining this review; git apply --check was read-only.

[Inferred] Verdict: PASS for the narrow test-observer patch as source-reviewed. There is no revision request. This verdict supplies neither a successful recovery run nor a typecheck result. CC-OBS-4 requires “enough structured context to narrow plausible causes”; CC-OBS-3 requires reduced fidelity to be explicit. The patch meets that purpose without a new control layer.

[Observed] Identity and behavior preservation: after.ts:1590–1613 calls the captured original startSessionBroker with the original socket, limits, machine and startupCurrent; the original invocation receives unchanged value and context. The existing release/revalidate/final-tool-budget observation is extended to later calls, with the original callbacks called once at their original boundary. after.ts:1629–1652 calls the captured original createOrderedDesignSession, adds only a reference to its existing workSnapshot closure, and returns that exact genuine controller. after.ts:1674–1705 calls the captured original mediation factory and keeps the genuine peer, operation, preflight, and boundary guard. No authority result is cached or substituted.

[Observed] The existing timed helper (after.ts:1369–1383) and brokerPhase (after.ts:1565–1588) call their callbacks synchronously, attach observation to genuine promises, return the original value/promise, and rethrow the original synchronous exception. The added settlement callback only reads the protected snapshot and sets observer metadata. No await, timer, race, lease extension, extra current() call, or budget sampling was added. Snapshot read exceptions become absent diagnostic metadata and cannot replace a product result or exception. As with the predecessor observer, incidental CPU/clock overhead exists; this is not a claim of identical physical timing.

[Observed] Read-only metadata: url-ordered-design-session.ts:546 exposes a closure returning workBudget?.snapshot() or null. url-ordered-design-work-budget.ts:337–339 freezes a new object containing state, the closed reason enum, five operation counters, last-sampled CPU/wall totals, expiresAt, and a fixed enforcement label. It does not invoke a clock or current(). The added trace fields contain only invocation ordinal, relative timestamps/outcome enums, fixed stage names, the genuine operation enum, and those snapshots. The operation vocabulary is declared at url-machine-instance.ts:11–18. Source inspection of each of the patch's eight replacement regions found no added body, stdin, argv, environment, stderr, or exception-text capture. Existing broker serialization already carries the trace in detailed and compact output (predecessor test:2514).

[Observed] Bounds and attribution: after.ts:1545–1556 declares fixed metadata slots and retains latestBrokerInvocation plus firstRefusedBrokerInvocation. ResumeBrokerStage has 16 named members (predecessor test:795–798); each invocation's stage dictionary overwrites a member instead of growing a timeline. The four work-snapshot slots are fixed. Each actual in-flight invocation also owns its closure/AsyncLocalStorage trace; the genuine broker limits concurrent pending work. The original invocation counter remains scalar. AsyncLocalStorage gives overlapping invocations their own stages and operation; fault metadata deliberately attaches to the latest invocation, not an asserted fault owner. A refused/rejected stage records its first stage name/snapshot within that trace. firstRefusedInvocation retains the first invocation whose outer original promise rejects; an invocation still pending at fault has no invented settlement. The genuine ordered host throws when mediation refuses (url-ordered-design-host.ts:157).

[Observed] First-call evidence is preserved: the exact original first-peer predicate remains, and the firstBrokerInvocation scope still covers only that peer's first invocation. brokerStages retains the first occurrence of each stage; per-invocation stages separately retain their latest occurrence. The global legacy tool-before-* labels remain coarse, first-call-oriented labels; their later-invocation slots do not establish a new semantic phase discriminator.

[Observed] Static verification: before.ts exactly matches git show ff65169e95dcfa7b14cf53494e8464202b29b914:packages/polaris-dossier/src/url-run-composed.test.ts. before/after/patch digests match bindings.json. diagnostic.patch exactly equals a freshly generated unified diff of before.ts and after.ts and targets one test file. git apply --check succeeds against the exact clean checkout. All eight binding replacements match once; reconstruction equals after.ts modulo indentation in the unchanged controller input block. This whitespace-only formatting step is present in the exact patch, so the patch and after.ts, not bindings.changes alone, are the byte-exact subject.

[Observed] Assertion and timing preservation was checked by two source methods: all 289 expect-containing lines are identical in sequence, and the patch's 95 added/removed lines contain no assertion line. The six timer-call expressions remain identical in sequence. The entire source suffix beginning at type SeenReceipt (after the observer) is byte-identical, preserving the actual test bodies, assertions, deadlines, and native runner timing. The new numeric literal in the type-only Parameters<...>[1] is not a runtime limit. Product limits and guard inputs are still forwarded unchanged. git status --porcelain=v1 remained empty.

[Inferred] Diagnostic interpretation: a ledger-originated CPU/detector/transform/audit failure retains its typed reason because stop() writes reason only while open; later retire() cannot overwrite it (url-ordered-design-work-budget.ts:242–244,336). Other controller/tool timer or direct-boundary failures can reach retirement before a typed ledger stop and leave reason retired. The packet explicitly states that retired alone does not prove a wall timeout. The snapshot contains last-sampled totals, not a fresh measurement at its capture timestamp. Latest native timing and stages can narrow the envelope; the patch cannot reconstruct an unexposed exact timer cause or prove the latest invocation owns a connection/server fault. These limits are honest and do not block the narrow diagnostic.

[Unknown] Compilation, native admission/recovery behavior, runtime diagnostic contents, observer overhead under load, and the precise cause of the hosted fault remain unverified by this source-only review. The implementation owner retains responsibility for proportional execution checks after application. This PASS must not be reported as a successful recovery or product-fix verdict.
