# Frozen source-only bb064 merge candidate

Candidate: `86e10de5bd7a1907ec697c15e8b68c8c316ccf5e`.
Tree: `8b4d2e44ca4d901c9a910af60f88d3077a56e018`.
First parent: published F3 `68ed9ee912f2302df1754ff5cfdeed6ac2d9e381`.
Second parent: pinned actual main `bb064295c160c7365d916eaf8a8cfd274914f516`.
Merge base: already integrated main `a9fe89c0d20dab58de29483d1a3c7a717b79fb6e`.
Outside clone: `w/`; branch `candidate-bb064-merge`. Both parents are ancestors of this candidate; it is a normal first-parent extension of published68ed. No primary/verification worktree or index was changed and nothing was pushed.

[Observed] This is source-only preparation. No project checker, test, helper, build, capture, canonical battery or native case was executed. Static Python AST parsing, exact bytes/Git object comparisons and whitespace checks were performed. Behavior, compiled runtime identities, timing and final acceptance remain Unknown. The earlier native649 result remains bound to649.

## Artifact and governing references

`binding.json` binds parents, candidate tree and all four shared source hashes. `initial-merge-log.json` and `initial-unmerged-stages.txt` preserve the two actual textual conflicts. `base/`, `ours/`, `theirs/`, `initial-auto-merge/` and `candidate/` retain all four shared files. `candidate-vs-ours.patch` and `candidate-vs-theirs.patch` are exact complete diffs. `GOVERNING-SOURCE-EXCERPTS-RAW.md` retains A306's exact adoption row and REQ034's brief-v20 clause from immutable bb06; the complete spec is in `w/` and the parent delta. No new governed requirement or adoption was authored.

The upstream range is exactly17 commits/26 paths (complete path census retained). Its complete doctrine tree is unchanged: `239797b0a1d973095a4047ec87c6a330648bf4bd`. The candidate retains doctrine as F3 had it. No workflow, render or native guard source changed upstream in this range. No new main was fetched or followed after pinnedbb06.

## Resolutions and explicit acceptance criteria

1. **Adoption ledger:** candidate equals ours bytes followed by exactly main's unchanged A306 row. The full238-row population is the exact unique union of ours237/main87; all local A239–A244 rows remain unchanged. Do not reword, reorder or duplicate inherited rows. No new adoption ID is assigned by this candidate.
2. **Brief and golden:** both automatically merged files were explicitly checked against the union of disjoint base→F3 and base→main line edits. Preserve F3's native/raw-read/compact-schema brief behavior and golden simultaneously with upstream v20's exact terminology paragraph, version and issuance-report/record expectations. Do not accept one parent's entire golden. Source proof binds both resulting hashes.
3. **Reconciliation:** retain every F3 executor, deterministic private result join, profiling helper, scoped read memo, cache-boundary fixture and ordinary canonical behavior. Add main's terminology constants, binding/census/generated/routes/input handling and complete `term_brief_cases` body unchanged. Historical034 construction strips both dependent edit-accounting and terminology rows, uses `historical-034`, and keeps the existing pooled19-family dispatch. Run the new terminology family exactly once through the established profiling helper after coverage-hold. Preserve every existing main historical-fixture adjustment. Do not strip the live adopted row from the real census.
4. **Complete byte census:** all22 upstream paths outside the four shared files equal bb06 byte-for-byte. All12258 paths outside the upstream26-path delta equal68ed byte-for-byte. The complete candidate population is12284 tracked paths, independently reconciled against ours plus upstream additions. No unrelated F3 file changed.

`static-source-proof.json` records the proof. For reconciliation,256 definitions untouched by main equal F3 exactly;13 definitions untouched by F3 equal main exactly. Four coupled functions (`census`, `check_generated`, `check_outcomes`, `check_routes`) retain exact main bodies and exact F3 decorators. `_selftest_cases` is AST-identical to F3 plus only the reviewed historical-row/prefix changes and one profiled terminology dispatch. Python source parses; this is not execution of the selftest.

## Required follow-up, without a green claim

Fresh independent source review must bind this exact commit/source packet and the criteria above. Root then integrates the exact reviewed candidate, records any required adoption/report, and runs owning brief tests/typecheck plus the actual full reconciliation selftest/canonical checks in an isolated committed clone. Recompute the actual complete witness denominator; do not reuse the predecessor's number after the upstream family addition. A trusted build must regenerate/verify runtime identities because `brief.ts` is a profile input. A newly composed final subject needs its own final/native/hosted receipts and reviewed exact-main render binding/capture; frozen R4 was not modified here. All such outcomes remain Unknown in this source packet.
