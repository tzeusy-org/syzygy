[Observed] Subject 64944deab26ddeec74c4d300bfd9aeb21e4703e5, tree 508be5c49052c7fc72f521985c164f597c3fc768. This independent diagnosis reads the completed log, the two complete compact JSON records, the frozen diagnostic candidate, and the subject clone's transport/audit sources. No tests, VM controls, builds, native work, mutations to runtime or repository, or authority probes were executed here.

[Observed] Outcome: RUNNER TIMEOUT. The terminal log reports “Test timed out in 600000ms” for stop-resume, one failed file / one selected failed case / six skipped cases. Source selects 600_000 for this scenario. Root's result receipt records exit 1 and elapsedSeconds 606.6674463748932. This is no runtime PASS. A runner timeout is the observed terminal reason; a root cause for cumulative time consumption remains [Unknown].

[Observed] Source binding: candidate url-run-composed.test.ts SHA256 6494b2e37a28e99bd6fe529e4050b66e6a54ae29b83a92ebf81b475d48fc86bc equals the execution clone's file byte-for-byte. Read transport SHA256 5baabf69a2eb14b5c7a5c29a0db7e556c2836e60ec391f3e7d6bd7aed363bdcd and audit SHA256 f6359eb4d2d694196f7836d88619b04e94ed5ae2bbab3f2c8659c3689fe71f47. Root owns the subject/repository authentication beyond these byte comparisons.

[Observed] The first complete compact record is line 651, 13,618 bytes including LF, SHA256 6c928e5576dac1cc2eee32a8ee4ee0be6ddb4110aa371a3109a0cb8e387ebbcc; observedMs 345347.381530, observerBeganMs 79507.065620. The finished compact record is line 1465, 16,736 bytes including LF, SHA256 b9204e7180395aef8a6f9b66031ec9befdad33054916744bb216b4628de34ce5; observedMs 605279.528518. Both JSON payloads were parsed completely, rather than inferred from tool-output truncation.

[Observed] Final cleanup.afterEachStartedMs is 605276.144640 and onTestFinishedEnteredMs is 605277.534395. afterEach begins 1.389755 ms before onTestFinished and 3.383878 ms before the compact snapshot. firstRuntimeFailure, firstSampleRefusal, terminal, and first-refused inference markers are absent in both compact payloads. The final sample counters are started=813, verified=813, confirmed=813, verifyRefused=0, verifyRejected=0, confirmRefused=0, confirmRejected=0. These are observed observer counters, not a new independent product census. Last confirmation settles at aligned 604938.297620 ms, 337.847020 ms before afterEach.

[Observed] Connection timestamps use the observer-relative clock, rounded to 0.001 ms; aligned timestamps below add observerBeganMs. The transport itself computes deadline = its internal performance.now() + limits.milliseconds. That internal began is not captured by this observer: open-start-plus-bound below is an estimate, and is not an exact captured deadline. The source maintains transport-current checks and a stream-destruction timer against that same deadline.

| Connection | Kind | Bound ms | Aligned open-start ms | Aligned open-settled ms | Estimated deadline ms |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | inference-bridge | 300000 | 136146.284620 | 144907.105620 | 436146.284620 |
| 2 | mcp-shim | 85000 | 234685.942620 | 239236.171620 | 319685.942620 |
| 3 | inference-bridge | 300000 | 265067.438620 | 269156.079620 | 565067.438620 |
| 4 | mcp-shim | 85000 | 437302.278620 | 442369.887620 | 522302.278620 |
| 5 | inference-bridge | 300000 | 482419.260620 | 487601.040620 | 782419.260620 |

[Observed] All five open/accept/capture/authorize stamps are accepted, with five calls in each transport counter. Connection 5's estimated timer end is 177139.732102 ms after the final snapshot. [Inferred] Its connection lifetime expiry does not explain this observed runner cutoff. Earlier connections' estimated deadlines preceding the snapshot do not establish a current-request refusal: no per-request identity/lifetime-to-inference binding or first-refusal marker was captured. Connection snapshots each include the same global latest sample by construction, so those samples do not prove every historical connection remained current.

[Observed] At the first snapshot inference count is 14, with ordinal 14 pending. At the finished snapshot count is 24, ordinal 23 mediate accepted (23945.583 ms), effect accepted (19573.623 ms), its audit accepted (19472.417 ms); ordinal 24 mediate remains pending before effect. The two compact populations directly retain accepted mediate outcomes for 18 distinct ordinals: 1–4, 7–13, 17–23. Ordinal 14 was only seen pending before eviction; 5, 6, 15, 16 are absent. Therefore a literal “23 accepted” claim is not established by this retained compact census. firstRefusedInference captures !result.ok and does not independently enumerate every discarded exception.

[Observed] Latest-two cost populations:

| Ordinal | Preparation wall ms | Preparation stage count/retained/omitted | Prepared-current wall ms | Boundary count/retained/omitted | Relay count |
| --- | ---: | --- | ---: | --- | ---: |
| 23 | 44.967 | 1/1/0 | 86.272 | 7/7/0 | 0 |
| 24 | 15228.506 | 64/64/0 | 106.510 | 3/3/0 | 0 |

[Observed] Ordinal 23 preparation has product-lease 44.799 ms, open/102629 ms remaining; its prepared-current lease remains open/102499. Ordinal 24 preparation includes reproduce 11903.856 ms (one call), read-reproduced-delivery 1286.723 ms (one), delivery-assertion 702.085 ms (two, max375.343), machine-authority 727.700 ms (16,max51.915), receipt-preflight 400.253 ms (one), runtime-authority 288.810 ms(two), wait-for-samples168.756 ms(two), and product-lease98.578 ms(two). Latest reported lease within preparation is open/78330 ms remaining; the subsequent prepared-current is accepted, open/130936 ms remaining, machine-authority50.584 ms and product-lease55.591 ms. [Inferred] The 24th preparation performed reproduction while prior lease capacity was finite; actual lease expiry is not demonstrated. No Boolean currentness caching proposal follows from this evidence.

[Observed] Ordinal 23 boundaries: parent-current three completed/sum757.239 ms/max289.105; kernel-peer three/sum69.895/max27.688; peer-audit one/488.552. Ordinal 24 boundaries: parent-current two including one pending and one completed203.780 ms; kernel-peer one13.834 ms. No relay phases retained for either. A pending stamp has no captured start/end projection, so its exact pending duration cannot be reconstructed from the aggregate.

[Observed] Complete ordered append costs (milliseconds; phase sums inclusive):

| Phase | Prepared count | Prepared sum | Prepared max | Latest send-attempt count | Latest sum | Latest max |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| audit-authority | 12 | 3384.170 | 352.093 | 12 | 3772.746 | 566.057 |
| attempt-authority | 5 | 5855.172 | 1616.188 | 5 | 6343.879 | 1768.956 |
| stat | 10 | 1.483 | 0.250 | 10 | 0.976 | 0.129 |
| read | 8 | 1.039 | 0.166 | 10 | 0.905 | 0.137 |
| write | 1 | 0.262 | 0.262 | 1 | 0.151 | 0.151 |
| sync | 2 | 69.082 | 53.147 | 2 | 33.789 | 18.249 |

[Observed] Prepared append wall9359.326 ms, 38/38 stages, zero omitted; six-phase sum9311.208, arithmetic residual48.118 ms. Latest completed append wall10226.697 ms, 40/40 stages, zero omitted; sum10152.446, arithmetic residual74.251 ms. Each has five attemptCurrent calls, five retained, zero observer omissions, one projected, four projection omissions. Latest projected prepared attemptCurrent wall1046.474 ms; latest projected send attemptCurrent wall1768.937 ms. The latter's 12/12 stages comprise wait-for-samples2/sum382.085/max191.385, runtime-authority1/401.190, machine-effect3/sum289.634/max106.056, budget2/.006, machine-authority2/sum84.236/max44.385, product-lease1/41.629, delivery-assertion1/346.551, all completed without refusal/rejection in that projection.

[Observed] The largest individual newly observed cost stage among these latest-two preparations and append phase maxima is reproduce11903.856 ms. Append attempt-authority dominates the measured complete append aggregate. These are elapsed durations, not CPU timings. Preparation's summed inclusive phase time15576.956 exceeds wall15228.506 by348.450 ms, directly demonstrating overlap.

[Inferred] The small append arithmetic residual does not establish a small uninstrumented remainder: authority can include file I/O, attempt-current contains its own current subphases, and reproduce nests other current phases. The audit source serially performs checkCurrent, attemptCurrent, checkCurrent; aggregate snapshots remove the individual start/end intervals required to compute a disjoint union. A remaining CPU hot path outside observed stages is [Unknown]. An exact critical-path partition cannot be recovered from these projections. This corrects an earlier provisional message inferring “no large unexplained remainder” from the small arithmetic residual.

[Observed] Preservation outside the repository: independent-clock-diagnosis/check-all.log.gz is a deterministic gzip (mtime0) of all404858 original log bytes, decompression compared byte-for-byte. Original log SHA256 acf9bd08601d64621e7fbbf2c3bd923d5b17e53d3aa9d5e6bc9015acf5699da6; gzip SHA256 cd2ad649c201b2bab0323ff122627a55c95c5da1c13f7561825fca10a9206ce1. Both compact lines are retained verbatim, along with derived.json and an artifact manifest. Full native-cut137092-byte snapshot SHA256 dfd8a41fade3df590c553fc734f9c7ff2d58209f63bc0f65ef2e6e9dadbd8749 is also retained as deterministic gzip and verified by byte comparison. Native runtime and product authority semantics were left unmodified.
