# Exact committed source excerpts — read-only audit

Fetched subject: `bb064295c160c7365d916eaf8a8cfd274914f516`. Each excerpt is source, not a review verdict.


## packages/polaris-dossier/src/brief.ts

```text
42:  * Inferred. */
43: 
44: /** v20 (syzygy-fnry.18 AC4): brief v19 with terminology ID instructions in the understanding record.
45:  * v19 (REQ-polaris-generation-034 version 2.26, syzygy-5dhm.41): brief v16 with draft schema v13 and the one worth-knowing paragraph
46:  * (`WORTH_KNOWING_PARAGRAPH`) immediately after the Poles paragraph, and this line changed. v17 and v18 are the numbers adopted version
47:  * 2.23 and the open version 2.24 give their briefs; neither is implemented here.
48:  * v16 (REQ-polaris-generation-034 version 2.20): brief v15 with schema v10 and the hero paragraph after relation types.
49:  * v15 (REQ-polaris-generation-034 version 2.19, syzygy-3efd.28): brief v14 with draft schema v9 and the one relation-types paragraph
50:  * (`RELATION_TYPES_PARAGRAPH`) immediately after the subsections paragraph, and this line changed. v14 (REQ-polaris-generation-034 version 2.16, syzygy-3efd.50): brief v13 with draft schema v8 and the one subsections paragraph
51:  * (`SUBSECTIONS_PARAGRAPH`) immediately after the figure-kinds paragraph, and this line changed. v13 (the index-and-task-routes change): brief v12 with the task-routes section (`TASK_ROUTES_RULE`) added after the Poles and this line
52:  * changed, and nothing else. v12 (REQ-polaris-generation-034 version 2.5): brief v11 with draft schema v7 and the one figure-kinds paragraph
53:  * (`FIGURE_KINDS_PARAGRAPH`) immediately after the thesis-basis paragraph. v11 (version 2.4) added schema v6 and `THESIS_BASIS_PARAGRAPH`. */
54: export const BRIEF_VERSION = 'polaris-dossier-brief-v20';
55: const HERO_PARAGRAPH = 'Name the dossier\'s hero in `hero`: `{"figure": "<diagram id>"}` for one diagram whose `home` is `{"kind": "overview"}` and whose `kind` is `flow`, `lifecycle`, `state-machine`, `boundary`, `dependency` or `placement`, showing the project\'s main parts and what surrounds them. Syzygy draws it first on the overview, after the introduction and any open questions. Where no such figure would be true, write `{"omitted": <block>}` instead, one inferred or unknown block saying why; the overview shows that reason where the figure would stand. A draft that does neither is refused.';
56: 
```

```text
199:     '',
200:     WORTH_KNOWING_PARAGRAPH,
201:     '',
202:     '## Task routes',
203:     '',
204:     TASK_ROUTES_RULE,
205:     '',
206:     '## The understanding record',
207:     '',
208:     `Before the argument, write \`understanding\`: the subject's ${UNDERSTANDING_ITEMS.map((item) => `\`${item}\``).join(', ')}. Each holds at least one item. An item is \`inferred\`, with its statement, its scope and at least one citation, or \`unknown\`, with a reason from the list below and the citations you considered, if any; an item you cannot establish is an \`unknown\` entry, never left out. Syzygy checks each item as it checks a claim block and renders the record as your self-reported understanding, labelled Inferred; that you formed it before drafting the argument is your report.`,
209:     '',
210:     'For each term in `understanding.terminology`, write one item. Set its `id` to the term as a reader writes it, keeping capitalization and hyphens and replacing each space with one underscore. For example, use `append-only_file` for "append-only file" and `AOF` for "AOF". If the spelling has a literal underscore, the resulting ID is invalid, or the ID is already used elsewhere in the draft, choose a valid, unused ID and keep the exact term in the item\'s `statement`. For example, use an unused `io` as the ID for "I/O" and write "I/O" in the statement. Omit comma-separated lists. Keep `u-` if it is part of the term, as in `u-boot`, and do not add it as an ID prefix.',
211:     '',
212:     '## Voice',
213:     '',
214:     'These rules shape how the dossier sounds. No check enforces them; the rendered-design review asks whether each page reads as a person explaining the project.',
215:     '',
```


## openspec/changes/dossier-brief-terminology/proposed/polaris-generation/spec.md

```text
148: A draft in schema `polaris-dossier-local-draft-v13` (version 2.26) is a schema-v10 draft in every respect but two optional members, the worth-knowing mark. A claim block labelled Inferred MAY carry `worthKnowing`, a boolean; `true` marks the block as worth knowing, a fact about this project, stated in one of a section's own paragraphs and cited, that an engineer new to the project would not guess from the kind of project it is, and `false` marks nothing. Each item of `poles` MAY carry `worthKnowingNone`, a text of 1 to 8000 characters saying why no block of that Pole's sections carries the mark. The v13 schema document admits `worthKnowing` on the claim-block forms labelled Inferred and on no other form, so that the member on a block of another label, on a non-normative block or on a presentation element, a `worthKnowing` that is not a boolean and an empty `worthKnowingNone` are each a `schema` finding. For a v13 draft Syzygy SHALL report a repair finding of kind `worth-knowing` at the path of the block's `worthKnowing` member, naming the block's identity where it has one, for each block labelled Inferred that carries `worthKnowing: true` and: is not one of a section's own paragraphs, a block at `$.sections[<i>].paragraphs[<j>]`, with the detail `` only a block that is one of a section's own paragraphs carries the worth-knowing mark: not a child, an element's claim, a subsection, a deep dive, the introduction or a route step ``; cites no source, with the detail `` a worth-knowing block states a fact about the project and cites at least one source ``; or carries the judgement mark, with the detail `` a worth-knowing block states a fact about the project, never your own judgement: drop one of the two marks ``. A block that fails more than one raises each, in that order. Schema v13 descends from schema v10, not from schema v11 or v12: the containment kind of version 2.23 and the model and views of version 2.24 are not members of v13, so a v13 draft that carries one has a `schema` finding there, and a later version that joins either to the worth-knowing mark SHALL give that schema, and the brief that issues it, a new number, never v13 or v19.
149: 
150: For a v13 draft, and for no draft of an earlier schema, check's report SHALL carry in its `readerAdvice` a member `worthKnowing`, a list of advisories `{"at", "marked", "detail"}`; like the rest of that advice it sets no outcome, is no finding, and is written into no check record and no rendered page. It counts, for each Pole in the draft's order, the blocks carrying `worthKnowing: true` among the own paragraphs of the Pole's sections, each section counted once, in the first Pole that names it; a draft with no `poles` is one group, at `$.sections`, holding every section. A group that counts none, where its Pole carries no `worthKnowingNone`, gets one advisory with the detail `` <name> marks no block worth knowing: mark one to 3 cited facts a newcomer would not guess from the kind of project this is, or, where none meets that test, say why in its `worthKnowingNone` ``, or, for the group at `$.sections`, which has no place for a reason, `` the draft marks no block worth knowing: mark one to 3 cited facts a newcomer would not guess from the kind of project this is, where any meets that test; a draft with no Poles has no place to say why none does, so this advice stands until one is marked ``, and a group that counts more than three gets one with the detail `` <name> marks <n> blocks worth knowing, past 3: keep the ones a newcomer would least guess and drop the mark from the rest ``, where `<name>` is `the Pole "<label>"`, the Pole's label written as a JSON string, or `the draft`, `<n>` is the count, `marked` is the count and `at` is `$.poles[<index>]` or `$.sections`. Three is a ceiling, never a quota: a group that counts one to three gets no advisory, and a Pole's reason excuses a count of none, never a count above three.
151: 
152: On each page of a v13 draft that draws sections, the blocks carrying `worthKnowing: true` among the own paragraphs of the produced sections that page draws, each lifted only where it renders Inferred on the counted fidelity review's support, carries no judgement mark, is no withheld item and matches no secret detector, SHALL render once, in the draft's order, in one callout placed before the page's on-page contents list and its first section, and not again in their section. The landing page's callout holds the why section's marked blocks, or every section's in a draft with no `poles`; a Pole page's holds those of the sections that page draws. The callout is the element `<aside class="callout callout-important worth-knowing" id="worth-knowing" aria-label="Worth knowing"><p class="callout-title"><span class="callout-tone">Worth knowing</span> What a newcomer would not guess</p>…</aside>`, holding after that title, for each marked block, a `<div class="worth-knowing-item">` that holds the block rendered as it renders in its section, with its label, citations, anchors and every disclosure that qualifies it, and then `<p class="worth-knowing-from">In <a href="…">…</a></p>`, whose link names the block's section by its title and leads to it, as `#section-<id>` where the section is on the same page. Each marked block is a claim of the page its callout is on, and `machine.json` names that page for it. A page whose drawn sections mark no block renders no callout, except that the page of a Pole carrying `worthKnowingNone`, or for a Pole with no page of its own the landing page, renders in the callout's place the Syzygy-written element `<aside class="callout callout-note worth-knowing" id="worth-knowing" data-worth-knowing="none" aria-label="Worth knowing"><p class="callout-title"><span class="callout-tone">Worth knowing</span> None found</p><p>The authoring session reports that no fact in this part meets the test of what a newcomer would not guess (Inferred, self-reported).</p></aside>`; the Pole's reason itself is rendered on no page and in no machine form. The callout carries no script and no style of its own beyond the callout classes every page already has. Where the draft layer is withheld, no callout renders and no marked block is moved. A marked block that is not lifted, among them every Unknown and every withheld block and every block of a draft no counted review covers, renders in its section exactly as an unmarked block does, and counts toward no callout; a page whose drawn sections lift none renders no `worth-knowing-item`. A v13 draft that marks no block and gives no reason renders, apart from its schema version, as the same draft in schema v10 renders it.
153: 
154: Brief v19 SHALL issue schema v13; it is brief v16 changed only in its version line, its draft-schema line, which names schema v13 and that schema's digest, and one paragraph placed immediately before its task-routes heading, `## Task routes`, which reads: "Mark, in each Pole, one to three blocks worth knowing: set `worthKnowing` to true on a cited Inferred block, one of a section's own paragraphs, that states a fact about this project an engineer new to it would not guess from the kind of project it is, such as a default, a limit, an ordering or a choice unlike that of similar projects. A marked block cites at least one source and is never a judgement; check refuses one that is not a section's own paragraph, cites nothing or carries the judgement mark. Three is a ceiling, never a quota: where no fact in a Pole meets that test, mark none and say why in that Pole's `worthKnowingNone`, which Syzygy never renders. Syzygy renders the marked blocks of a page in one callout headed "Worth knowing" near its top, each linked to its section, and says on a Pole's page when none was found; check advises a Pole that marks none without a reason, or more than three. A draft with no `poles` counts as one Pole and has no place to say why it marks none." Every statement above of what brief v16 carries, equals or differs by holds of brief v19 apart from those three differences. The inventory session SHALL receive the same request: the inventory brief, from version 2.26 `polaris-dossier-inventory-brief-v4`, issues inventory schema `polaris-dossier-local-inventory-v2`, which is inventory schema `polaris-dossier-local-inventory-v1` with one more entry kind, `worth-knowing`, placed before `other` and glossed in the brief as "a fact it states about itself that an engineer new to the project would not guess from the kind of project it is, such as a default, a limit, an ordering or a choice unlike that of similar projects; look for one to three in each major part of the project, and record none where you find none, never one made to fill a quota". An inventory in schema v1 is still accepted and checked against the v1 kinds alone, so an entry of kind `worth-knowing` in one is a `schema` finding at its `kind`. A `worth-knowing` entry is covered, omitted or uncovered by the inventory-coverage rule exactly as an entry of any other kind is, so that a fact the inventory records and the draft never cites surfaces as an uncovered entry; whether the draft marks it is compared by no rule.
155: 
156: Brief v20 SHALL issue schema `polaris-dossier-local-draft-v13`. For the same run it SHALL equal brief v19 except for its `polaris-dossier-brief-v20` version line and one paragraph immediately after the existing paragraph under `## The understanding record`, before `## Voice`. That paragraph SHALL read exactly as follows.
157: 
158: For each term in `understanding.terminology`, write one item. Set its `id` to the term as a reader writes it, keeping capitalization and hyphens and replacing each space with one underscore. For example, use `append-only_file` for "append-only file" and `AOF` for "AOF". If the spelling has a literal underscore, the resulting ID is invalid, or the ID is already used elsewhere in the draft, choose a valid, unused ID and keep the exact term in the item's `statement`. For example, use an unused `io` as the ID for "I/O" and write "I/O" in the statement. Omit comma-separated lists. Keep `u-` if it is part of the term, as in `u-boot`, and do not add it as an ID prefix.
159: 
160: The successful issuance report and author brief record SHALL both name that same v20 version. The record SHALL bind the issued brief and schema by their digests. Existing draft ID acceptance, the Index, glossary rendering, the inventory brief, the schema and the provider mode remain governed by their inherited rules. The terminology paragraph is author guidance.
161: 
162: A draft in schema v12 or earlier SHALL be checked and rendered exactly as version 2.24 checks and renders it, the same findings and the same bytes of every page, of `machine.json` and of every record check writes, except that a `field-version` finding stands in place of the `schema` finding at each `worthKnowing` member anywhere in the draft, with the detail `` `worthKnowing` needs draft schema polaris-dossier-local-draft-v13 ``, and at each Pole's `worthKnowingNone`, with the detail `` `worthKnowingNone` needs draft schema polaris-dossier-local-draft-v13 ``; wherever this requirement says that a draft of an earlier schema is checked or rendered exactly as an earlier version checks or renders it, that exception holds too. Its report carries no `worthKnowing` advice and its pages no `worth-knowing` callout. The provider mode is unaffected: the provider stages' closed draft schema gains neither member, and the rendered bytes the provider golden pins do not change.
```


## scripts/check_spec_reconciliation.py

```text
11368:     declared_source_composition_cases(witnesses, failures)
11369:     url_source_cases(tmp, base, witnesses, failures)
11370:     # These cases reconstruct historical REQ-034 floors where the prerequisites
11371:     # for edit accounting and the terminology brief cannot exist.
11372:     figure_base = base
11373:     if edit_account_rows(base) or term_brief_rows(base):
11374:         figure_base = Path(tmp) / "historical-034"
11375:         shutil.copytree(base, figure_base)
11376:         ledger = figure_base / AGENT_ADOPTIONS
11377:         rows = ledger.read_text().splitlines(keepends=True)
11378:         ledger.write_text("".join(line for line in rows
11379:                                   if not is_edit_account_row(line) and not is_term_brief_row(line)))
11380:     for case in (figure_cases, derived_cases, ledger_cases, kinds_cases, manifests_cases,
11381:                  repairs_cases, maps_cases, bounds_cases, corr_cases, coverage_cases,
11382:                  infra_cases, findpages_cases, subsec_cases, reltype_cases, hero_cases,
11383:                  readers_cases, cont_cases, model_cases, worth_cases):
11384:         case(tmp, figure_base, witnesses, failures)
11385:     edit_account_cases(tmp, base, witnesses, failures)
11386:     poc_d10_cases(base, witnesses, failures)
11387:     reach_cases(tmp, base, witnesses, failures)
11388:     readmit_cases(tmp, base, witnesses, failures)
11389:     raw_read_cases(tmp, base, witnesses, failures)
11390:     treeread_cases(tmp, base, witnesses, failures)
11391:     verify_cases(tmp, base, witnesses, failures)
11392:     qfile_cases(tmp, base, witnesses, failures)
11393:     covhold_cases(tmp, base, witnesses, failures)
11394:     term_brief_cases(tmp, base, witnesses, failures)
11395:     # Two cases a one-file mutation cannot express. A second record of the
11396:     # same version fails R1 by its own finding; --regenerate refuses an
```


## PROJECT-STATUS.md

```text
252:     (syzygy-5dhm.41) lands with it; v13 is schema v10 plus the mark and brief v19 is brief v16 plus one paragraph.
253:     [Question-file amendment 2.27](openspec/changes/dossier-question-file) is agent-adopted in A-304.
254:     It replaces REQ-polaris-generation-033 again (16 to 18 scenarios): the run record names the question file, the one
255:     source of reader questions, by format, version and digest; its held-out part records opaque evaluator key identifiers, digests and counts
256:     and leaves the Redis comparison pending genuinely blind lists; its code (syzygy-5dhm.21) lands with it.
257:     *(2026-11-25: the predecessor figure "546 scenarios" is superseded by that
258:     amendment; all 39 identities remain.)*
259:     [Coverage-hold amendment 2.28](openspec/changes/dossier-coverage-hold) is agent-adopted in A-305.
260:     [Terminology-brief amendment](openspec/changes/dossier-brief-terminology) is agent-adopted in A-306.
261:     It replaces REQ-polaris-generation-035 over its run-tree read-bounds version 2.18
262:     (40 to 46 scenarios). Packet issuance waits while a listed inventory entry lacks an
263:     outcome. The refusal carries the selected pair. The supervisor keeps the repair
264:     instruction in the bounded author notice and records a send after both pane operations succeed.
265:     *(2026-11-25: this supersedes the predecessor figure of 548 scenarios and retains all 39 requirement identities.)*
266:     *(2026-11-24: the predecessor figure "539 scenarios" is superseded by that
267:     amendment; all 39 identities remain.)*
```
