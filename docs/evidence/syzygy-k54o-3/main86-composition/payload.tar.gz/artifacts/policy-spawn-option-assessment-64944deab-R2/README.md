[Observed] R2 is a minimal outside permission correction; R1 remains frozen. After creating the new output directory and its TMPDIR, run-witness.py explicitly chmods each0700 and asserts exact07777mode bits equal0700 before any fixture execution. Only these fresh outside paths change modes. Witness/fixture functions are byte-identical. Outside Vitest config root is rebound to R2; no other executable behavior changes.

Root may execute:

    python3 /home/orca/.tmp/f3-native-admission-fixes/policy-spawn-option-assessment-64944deab-R2/run-witness.py /home/orca/.tmp/f3-native-admission-fixes/policy-current-witness-649-low

Actual existing fixture and eight actual committedUrlPoliciesCurrent calls remain unchanged. No driver implementation. [Unknown] Operator outcomes remain unexecuted by this worker. permission-source-proof.json binds the exact static delta.
