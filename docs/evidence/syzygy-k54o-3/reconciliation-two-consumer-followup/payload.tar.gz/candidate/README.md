# Two standalone read-consumer memo scopes

Outside-only candidate, prepared against clean source at `c52b682c705c98d59ef391458fb0dd7fa6580ec7`. Original/candidate/patch/harness hashes and exact decorator-removal mutants are bound in `binding.json`. Nothing is applied, committed, adopted or executed. The native case retains its heavy slot.

The patch adds only `@_read_memo_scope()` to `check_generated` and `check_routes`. The full module AST is identical after removing those exact two added decorators. All fixture bodies, run predicate order, `_per_run` deepcopy and `_FILES_OVERRIDE` bypass, memo restoration and D10 state restoration are unchanged. No family is wrapped and no parallel setting changes. Canonical test population growth is zero.

[Observed] Hosted 9c job138823853861, run45500976279, succeeded in493 seconds; its selftest step took483 seconds and actual profile total was482.435986 seconds. It reported566/566 mutants and113/113 controls at tested merge0dfd683baeef. That exceeds420 seconds. Setup/postprocessing account for about10 seconds, so execution is the material cost. `hosted-timing-context.json` contains actual selected profiles and exact metadata timestamps; its raw-log-digest limitation is explicit.

[Observed] Prefix mutants cost227.196 seconds, entry fixtures36.327, URL fixtures32.759 and edit-account fixtures31.097. Prior ca967 profile total was366.487 seconds, with prefix169.407, entry27.925, URL25.150 and edit23.664. Checker bytes are identical at ca967,9c and this preparation subject (SHA25665ab0c346b962ebe62bac592271181161d877aaaba5fe13e9e09f38c55f6ef51). Broadly slower execution is observed; attributing it specifically to runner contention is Inferred because input trees also differ. Concurrent edition worker durations are not serial wall costs.

[Observed/source] `check_generated`5029–5245 and `check_routes`5267–5806 each contain27 direct binding call sites. They have no invocation scope. `run`5962 owns one, so calls from run already share it. Standalone calls from fixture functions do not: `_per_run`5945–5958 bypasses its memo whenever `_RUN_MEMO` is None. Each such consumer can repeatedly re-derive predecessor bindings. For example, edit_account_cases9257–9290 calls check_routes for eight independent route assertions after fixture mutations. Each call is a read-only interval; its scope must end before the next write. The two decorators do precisely that using the existing context manager3101–3116.

[Unknown] The profiles do not isolate either consumer's elapsed share. This patch does not alter the dominant prefix phase, already under scoped run. No timing benefit or420-second success is claimed. Actual scoped consumer measurements must establish whether this is worth adopting.

## Prepared verification, not executed

`verify_real_consumers.py` is a standalone opt-in harness for a clean clone. It imports the frozen original/candidate against the clone's real scripts and scratch inputs, prepares the existing synthetic-candidate fixture, and derives its census once. It then runs10 complete real consumer calls plus2 early exception controls, without run(), canonical selftest, builds or parallel-policy changes:

- Original/candidate generated and route consumers must produce identical complete reports, findings and examined-count lines. Original repeated-D10-state calls are a required canary; candidate must call actual D10 state exactly once per unchanged fixture invocation. Both timings are recorded.
- A changed CAP1 governing-dependency digest must fail R4; a deleted exact route row must fail R5. Exact dynamically selected old/new bytes are retained. Restoring either fixture must restore the complete prior report in a fresh invocation.
- Removing either newly added decorator must expose repeated real D10 state calls while preserving report semantics. Exact source old/new fragments are already frozen in binding.json.
- A unique original read exception at each consumer's first read must propagate as the same object, with the original memo/override/D10 identities restored.

The harness refuses a dirty clone, wrong subject, unknown checker source, changed frozen payloads, nonunique mutation targets, missing canaries or output inside the repository. It writes only private fixture mutations and an explicitly selected outside result JSON. Import source hashes and actual commit are recorded. It was AST-parsed only; no imports or checks were executed during preparation.

After fresh review and slot release, the intended invocation is:

```sh
python3 /home/orca/.tmp/f3-native-admission-fixes/reconciliation-two-read-consumers-candidate/verify_real_consumers.py --repo <clean-clone> --subject <exact-clone-HEAD> --output <outside-result.json>
```

Acceptance requires all scoped outcomes and canaries, plus non-speculative measured consumer improvement. Review and re-run the existing meaningful memo boundary/override/deepcopy restoration controls if their helper scope changes (this patch changes no helper bytes). Before completion/adoption acceptance, the actual full canonical selftest still must pass in a clean clone with its full679-witness population/order and expected outcomes, followed by exact published hosted timing under420 seconds. The current failed budget is not waived and an isolated local improvement is not hosted acceptance.
