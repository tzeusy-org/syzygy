#!/usr/bin/env python3
"""Opt-in scoped real-consumer verification. Never runs the project selftest.
Only disposable fixture files are changed. Review before execution.
"""
import argparse
import ast
import copy
import functools
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import types

PACKET = Path(__file__).resolve().parent
NAMES = ('check_generated', 'check_routes')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_source(text, name, repo):
    module = types.ModuleType(name)
    module.__file__ = str(repo / 'scripts/check_spec_reconciliation.py')
    sys.modules[name] = module
    exec(compile(text, module.__file__, 'exec'), module.__dict__)
    return module


def invoke(module, name, tree, population):
    d10 = importlib.import_module('d10_supersession')
    original_state = d10.state
    previous = (module._RUN_MEMO, module._SIGNED_MEMO, module._FILES_OVERRIDE)
    calls = 0

    @functools.wraps(original_state)
    def counted(root):
        nonlocal calls
        calls += 1
        return original_state(root)

    d10.state = counted
    report = module.Report()
    began = time.monotonic_ns()
    try:
        getattr(module, name)(tree, copy.deepcopy(population), report)
        return {'elapsedMs': (time.monotonic_ns() - began) / 1_000_000,
                'd10StateCalls': calls, 'lines': report.lines,
                'findings': report.findings, 'failed': sorted(report.failed)}
    finally:
        restored = (module._RUN_MEMO is previous[0]
                    and module._SIGNED_MEMO is previous[1]
                    and module._FILES_OVERRIDE is previous[2]
                    and d10.state is counted)
        d10.state = original_state
        if not restored:
            raise AssertionError('consumer failed to restore existing memo/override/D10 state')


def result_only(result):
    return {key: result[key] for key in ('lines', 'findings', 'failed')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--subject', required=True,
                        help='exact clean clone HEAD expected for this execution')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    output = args.output.resolve()
    if output == repo or repo in output.parents:
        raise ValueError('output must be outside the repository')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    if head != args.subject:
        raise ValueError('subject commit differs')
    if subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo):
        raise ValueError('verification requires a clean clone')
    binding = json.loads((PACKET / 'binding.json').read_text())
    original = (PACKET / 'original-check_spec_reconciliation.py').read_text()
    candidate = (PACKET / 'check_spec_reconciliation.py').read_text()
    if digest(original.encode()) != binding['originalSha256'] or digest(candidate.encode()) != binding['candidateSha256']:
        raise ValueError('frozen source digest differs')
    if digest((repo / binding['path']).read_bytes()) not in (binding['originalSha256'], binding['candidateSha256']):
        raise ValueError('clone checker bytes differ from reviewed original/candidate')
    sys.path.insert(0, str(repo / 'scripts'))
    baseline = load_source(original, '_reconciliation_baseline', repo)
    selected = load_source(candidate, '_reconciliation_candidate', repo)
    imports = {str(p.relative_to(repo)): digest(p.read_bytes())
               for p in sorted((repo / 'scripts').glob('*.py'))}
    results = {'executionSubjectCommit': head, 'preparedAgainst': binding['subjectCommit'],
               'binding': binding, 'pythonScriptSubjects': imports, 'measurements': {},
               'mutants': [], 'exceptionControls': [],
               'scope': '10 real consumer calls plus2 early exception controls; no run() or canonical selftest'}
    with tempfile.TemporaryDirectory(prefix='reconciliation-consumers-') as scratch:
        tree = Path(scratch) / 'base'
        baseline.scratch(repo, tree)
        baseline._propose_candidate(tree)
        population, findings = selected.census(tree)
        if findings:
            raise AssertionError('fixture census is not clean')
        baseline_results, candidate_results = {}, {}
        for name in NAMES:
            before = invoke(baseline, name, tree, population)
            after = invoke(selected, name, tree, population)
            if before['failed'] or result_only(before) != result_only(after):
                raise AssertionError(f'{name}: baseline/candidate clean report differs or fails')
            if before['d10StateCalls'] <= 1:
                raise AssertionError(f'{name}: actual repeated-state canary not exposed')
            if after['d10StateCalls'] != 1:
                raise AssertionError(f'{name}: invocation did not share exactly one actual D10 state')
            baseline_results[name], candidate_results[name] = before, after
            results['measurements'][name] = {'baseline': before, 'candidate': after}

        generated = tree / f'{selected.CHANGES}/{selected.CAP1_CHANGE}/GOVERNING-DEPENDENCIES.md'
        text = generated.read_text()
        matches = list(selected.DEPS_SOURCE.finditer(text))
        if len(matches) != 1:
            raise AssertionError('generated-source mutation target is not unique')
        match = matches[0]
        old = match.group(1)
        new = ('1' if old[0] == '0' else '0') + old[1:]
        changed = text[:match.start(1)] + new + text[match.end(1):]
        generated.write_text(changed)
        try:
            got = invoke(selected, 'check_generated', tree, population)
            if not any('source digest is not the current' in f for f in got['findings'].get('R4', [])):
                raise AssertionError('fresh generated invocation accepted mutated source digest')
            results['measurements']['generated-after-fixture-mutation'] = got
            results['mutants'].append({'id': 'generated-source-digest', 'path': str(generated.relative_to(tree)),
                                       'old': old, 'new': new, 'expected': 'R4:source digest is not the current', 'caught': True})
        finally:
            generated.write_text(text)
        restored = invoke(selected, 'check_generated', tree, population)
        if result_only(restored) != result_only(candidate_results['check_generated']):
            raise AssertionError('generated scope retained stale findings after restoration')
        results['measurements']['generated-after-restoration'] = restored

        readme = tree / selected.OPENSPEC_README
        text = readme.read_text()
        change = selected.CHILDREN[0]['change']
        rows = [line for line in text.splitlines(keepends=True) if line.startswith(f'| [`{change}`](')]
        if len(rows) != 1:
            raise AssertionError('route mutation target is not unique')
        old = rows[0]
        readme.write_text(text.replace(old, '', 1))
        try:
            got = invoke(selected, 'check_routes', tree, population)
            if not any(f'rows for tracked change `{change}`, expected 1' in f for f in got['findings'].get('R5', [])):
                raise AssertionError('fresh route invocation accepted missing route row')
            results['measurements']['routes-after-fixture-mutation'] = got
            results['mutants'].append({'id': 'missing-route-row', 'path': selected.OPENSPEC_README,
                                       'old': old, 'new': '', 'expected': f'R5:rows for tracked change `{change}`, expected 1', 'caught': True})
        finally:
            readme.write_text(text)
        restored = invoke(selected, 'check_routes', tree, population)
        if result_only(restored) != result_only(candidate_results['check_routes']):
            raise AssertionError('route scope retained stale findings after restoration')
        results['measurements']['routes-after-restoration'] = restored

        for name in NAMES:
            old = f'@_read_memo_scope()\ndef {name}(root, pop, report):'
            new = f'def {name}(root, pop, report):'
            if candidate.count(old) != 1:
                raise AssertionError('decorator mutation target is not unique')
            mutant = load_source(candidate.replace(old, new, 1), f'_reconciliation_mutant_{name}', repo)
            got = invoke(mutant, name, tree, population)
            if got['d10StateCalls'] <= 1:
                raise AssertionError(f'{name}: removed-decorator mutation survived state-call predicate')
            if result_only(got) != result_only(baseline_results[name]):
                raise AssertionError('performance mutation unexpectedly changed checker reports')
            results['mutants'].append({'id': f'remove-{name}-scope', 'subjectCommit': head,
                                       'old': old, 'new': new,
                                       'expected': 'd10StateCalls >1 while original findings unchanged',
                                       'caught': True, 'measurement': got})

            sentinel = RuntimeError('owned consumer exception')
            read_text = selected.read_text
            target = selected.OPENSPEC_README if name == 'check_routes' else f'{selected.CHANGES}/{selected.CAP1_CHANGE}/GOVERNING-DEPENDENCIES.md'
            def raising(root, rel, *, _target=target):
                if rel == _target:
                    raise sentinel
                return read_text(root, rel)
            selected.read_text = raising
            try:
                try:
                    invoke(selected, name, tree, population)
                except RuntimeError as error:
                    if error is not sentinel:
                        raise AssertionError('consumer replaced original exception')
                else:
                    raise AssertionError('consumer swallowed original exception')
            finally:
                selected.read_text = read_text
            results['exceptionControls'].append({'consumer': name, 'sameException': True,
                                                  'memoD10AndOverrideRestored': True})
    results['passed'] = True
    results['limitations'] = ['scoped consumer observations only; canonical679 witnesses not executed',
                              'timing values apply to this clone/run only; hosted420s budget still requires actual validation',
                              'does not change or time prefix-mutants; process-pool policy unchanged']
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({'passed': True, 'output': str(output), 'subject': head,
                      'measurements': {k: {'baselineMs': v['baseline']['elapsedMs'], 'candidateMs': v['candidate']['elapsedMs'],
                                           'baselineStateCalls': v['baseline']['d10StateCalls'], 'candidateStateCalls': v['candidate']['d10StateCalls']}
                                       for k, v in results['measurements'].items() if 'baseline' in v},
                      'mutantsCaught': len(results['mutants']), 'exceptionControls': len(results['exceptionControls'])}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
