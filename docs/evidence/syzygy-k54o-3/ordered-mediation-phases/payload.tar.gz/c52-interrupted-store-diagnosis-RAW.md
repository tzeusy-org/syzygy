# Exact-head c52 interrupted failure: source-only diagnosis

[Observed] Subject c52b682c705c98d59ef391458fb0dd7fa6580ec7, tree43daf0272d0fc72533d9d84a3eab349d5767a8c3, read from subject.json. Retained clone HEAD and every quoted/read source file match that commit byte-for-byte; worktree porcelain was empty before and after inspection. Source/evidence byte counts and scripted SHA256s are in c52-interrupted-store-diagnosis-bindings.json. Computed intervals are in c52-interrupted-store-diagnosis-metrics.json. No execution, tests, probes, capture, build, source mutation, provider or network calls were performed.

[Observed] Genuine stop-resume exited1 after338.385724s, one numbered Vitest worker, peak RSS489892KiB. The resumed render completed in8995.493494ms; admission accepted and no producer refusal. All9 retained inference mediation/effect pairs accepted. The first broker invocation later refused. This report diagnoses that interrupted case only; successful eligible recovery reported separately by the parent is outside this evidence population.

[Observed] Actual store callback, not a wrapper timeout: phase=check-deadline, reason=operation-limit, elapsed30060.55445399997ms, operation30000ms, runRemaining6895552ms. The timer callback did not win. The later transport-unavailable/inspection failure is the propagated outcome. Metadata does not include operation ID or throwing stack.

## Enclosing operation and call order

[Inferred from exact source plus the single broker event] The failing guard belongs to the ordered Design MCP dossier_step store.exclusive envelope. This is the first prepared result, after the nine accepted inference calls. The envelope starts before filesystem lock/state work; it includes fresh peer verification, canonical/projection read and binding checks, peer audit append, reattestation, controller issueReply, prepared audit persistence, fresh current checks and synchronous broker/native release guards. It is not an inference9 failure and not a render admission failure.

[Observed source] Ordered profiles select transcript.nativeEffectMilliseconds in url-machine-store.ts:797; session-profile.ts:36 binds URL_ORDERED_NATIVE_EFFECT_MILLISECONDS, and url-product-read-limits.ts:1 defines30000. Store checkDeadline uses monotonic elapsed while the original run uses clock(). The independent FIFO admission occurs before runLocked's began; lock acquisition and held work occur after began. The finite contention1000 and FIFO30000 are distinct ceilings, not the winning refusal here.

[Observed source] runLocked starts work immediately, then installs its timer via Promise.race after work reaches its first suspension. That first path reaches awaited io/checkAsync during anchor setup, before the effect callback. Therefore the source does not support saying all30 seconds happened before timer installation. A synchronous or promise continuation guard can win before a due timer gets a turn. [Unknown] The exact synchronous block that crossed the threshold and the precise throwing call stack; the callback records neither.

[Inferred] The final retained tool-release-guard accepted at247268.189 relative diagnostic milliseconds; the next host statement invokes boundary(), which calls check(state) then lease.sampleCurrent(), whose checkDeadline can produce the recorded refusal. Host action rejected at247463.989. This is the strongest local candidate for the throwing boundary. The source/metadata does not establish an exact stack. No broker release/release-check/final-budget stage is retained, so no successful actual reply is established.

## Timings without double counting

[Observed] Broker invoke48368.707ms contains mediate-peer47520.687ms, which contains host-action25424.579ms. Host action contains prepared append13814.857ms. These are inclusive nested intervals, not additive costs. The store's30060.554ms envelope and host action imply about4635.975ms outside host action inside the store interval; there is no direct common-origin store-start stamp or phase counter, so that residual is an approximation, not a measured per-stage attribution.

[Observed] Serial host stages: before-plan current1808.132ms; transfer bounds145.724ms; plan work hold0.959ms; create budget0.473ms; before-audit guard587.075ms; prepared store append13814.808ms (wrapper; detailed append timing13814.857ms); prepared-store-recheck2277.741ms; controller before-release current2531.421ms; synchronous release guard664.070ms. The time before append also includes the writer's own current/read/candidate checks; do not assign its entire gap to one uninstrumented function.

[Observed] Detailed prepared append and latest append are equal copies of the SAME record. Across that one append:12 audit-authority calls total4652.849ms and5 attempt-authority calls total9093.016ms, all accepted. Their top-level spans are serial and disjoint, totaling13745.865ms (about99.50% of13814.857ms). Descriptor spans:10 stat1.840ms,8 read0.955ms,1 write0.333ms,2 sync59.058ms. Summed descriptor spans62.186ms overlap in parallel read/stat batches; their interval union is60.739ms. Descriptor spans do not cover every synchronous stat/read/CPU operation in the full chain.

[Observed] Inside those5 attempt calls:10 sample waits1606.607ms;5 runtime authority1657.448ms;15 machine-effect samples2025.111ms;10 machine-authority samples691.108ms;10 budget samples0.063ms;5 product lease checks323.680ms;5 delivery assertions2380.914ms. These nested measurements are INCLUDED in9093.016ms; they must not be added to it. Full current checks outside the append have their own enclosing timings; total fresh source/claim invocations for the whole store body cannot be counted from this trace because wrappers are selectively retained. Bootstrap storeAuthority counts stop observing after machine creation and do not measure this late effect.

## Causal interpretation and repair constraint

[Inferred] The measured dominant work is repeated fresh authority/product/delivery validation inside the durable append, not slow descriptor writes or a failed renderer. The five attempt checks are deliberately separated by actual asynchronous boundaries: final prefix scan/before write; after write; after file sync; after directory sync; after final identity scan. The12 audit callbacks are enclosing I/O pre/post2 plus pre/post around those5 awaited attempt checks10. Reusing one result across these awaits would cache authority. Policy checks include live ref/HEAD/working-byte reads; claim checks include held OS lease/marker/fresh stopped bytes/live run predicates. A cached pass cannot authorize later writes or reply release.

[Observed source] The native store's30s aggregate encloses a controller operation independently declared30s (all operation envelopes in url-run-ordered-attempt.ts:327), with additional serial preparation and final guards. Thus a tool operation can remain within its own30s and exhaust the outer30s. The failure demonstrates that composition, not proof that a particular replacement numerical ceiling is sufficient. Removing earlier same-continuation processingCurrent calls could change refusal ordering/transient-refusal semantics; it is not a proven preservation fix. No patch is claimed correct or performance-verified here.

[Proposed design, Inferred] Explicitly split ordered native preparation and actual effect, retaining each finite30s cap and deriving an absolute outer60s from their sum. Introduce a trusted one-use phase transition immediately before the original first boundary/effect callback. Bound lock/state/audit/reattest preparation by its30s phase; keep callback, subsequent boundary and store postcheck within the original30s actual-effect phase. The total starts before lock work and never resets; all phase and total deadlines remain clipped to original run/client/instance expiry. Reserve whole mediation/product capacity before starting. Selecting30s for this newly named preparation phase is a new agent resource decision using the existing ordered capture/setup allowance; capture itself remains30s. It is not an already-adopted semantic split. The separate design report states coherent broker/planner requirements. Fresh independent review and measured regression/native interrupted execution remain required before implementation acceptance.

[Unknown] Native interrupted recovery after that proposed change, full-suite outcome, performance gain, provider compatibility and final production capture. Four test spy histories were cleared in this subject, but this record supports no causal RSS/performance claim for that change.

## Exact source excerpts


url-machine-store.ts:471 (exact subject)
```typescript
      const checkDeadline = (): number => {
        if (!active) { reportRefusal({ phase: 'check-deadline', reason: 'inactive' }); throw refused(); }
        if (staging?.current !== undefined && staging.current() !== true) {
          reportRefusal({ phase: 'check-deadline', reason: 'staging-current' }); throw refused();
        }
        const now = clock();
        if (now >= deadline) {
          reportRefusal({ phase: 'check-deadline', reason: 'run-deadline', runRemainingMs: deadline - now }); throw refused();
        }
        const operationElapsedMs = performance.now() - began;
        if (operationElapsedMs >= operationMilliseconds) {
          reportRefusal({ phase: 'check-deadline', reason: 'operation-limit', operationElapsedMs,
            runRemainingMs: deadline - now }); throw refused();
        }
        return now;
      };
      const check = (): number => {
        checkDeadline();
        live();
        return checkDeadline();
      };
```

url-machine-store.ts:665 (exact subject)
```typescript
        const operating = operation({ check, checkWork, reverify, anchored: verifyAnchors,
          state: async () => (await stateSnapshot()).state, stateSnapshot, write });
        shareTerminalEntry = false;
        await operating;
        check();
        if (allocation) {
          // The slot is durable. Keep lock cleanup and witness admission
          // inside the same deadline as the allocation.
          await rmdir(`${base}/lock`); await heldRoot.sync();
          await reverify(); check(); verifyNamedRoots(); checkDeadline();
        }
        return true;
      });
      activeWork.add(work);
      void work.then(() => activeWork.delete(work), () => activeWork.delete(work));
      try {
        return await Promise.race([work, new Promise<never>((_, reject) => {
          const operationElapsedMs = performance.now() - began;
          const operationRemaining = operationMilliseconds - operationElapsedMs;
          const runRemainingMs = deadline - clock();
          const timerDelayMs = Math.max(1, Math.min(operationRemaining, runRemainingMs));
          timer = setTimeout(() => {
            uncertain = true; active = false;
            reportRefusal({ phase: 'timer', reason: 'timer-fired', operationElapsedMs, runRemainingMs, timerDelayMs });
            reject(refused());
          }, timerDelayMs);
        })]);
      } catch { uncertain = true; return false; }
      finally {
        clearTimeout(timer); active = false;
        // An unresolved protected write leaves its lock. No successor steals it.
        if (!allocation && held && !uncertain && pending.size === 0) {
          await rmdir(`${base}/lock`).catch(() => { uncertain = true; });
```

url-machine-store.ts:791 (exact subject)
```typescript
    const exclusive = async (clientId: string, deadline: number, operation: (lease: UrlMachineStoreLease) => Promise<void>,
      effectProfile?: NativeSessionProfile, publication?: StagedBoundary, terminalRead = false): Promise<boolean> => {
      if (!digest(clientId) || (effectProfile !== undefined && !isNativeSessionProfile(effectProfile))) return false;
      const orderedEffect = effectProfile !== undefined && isOrderedDesignSessionProfile(effectProfile);
      const ordinaryEffect = effectProfile !== undefined && !orderedEffect;
      const synchronousOrdinaryRead = ordinaryEffect && currentAsync === undefined && publication === undefined && !terminalRead;
      const operationMilliseconds = orderedEffect
        ? effectProfile.transcript.nativeEffectMilliseconds : ordinaryEffect ? ORDINARY_NATIVE_EFFECT_MILLISECONDS
          : terminalRead && currentAsync !== undefined ? ASYNC_TERMINAL_READ_MILLISECONDS
            : publication?.operationMilliseconds ?? URL_MACHINE_STORE_LIMITS.operationMilliseconds;
      if (!positive(operationMilliseconds) || operationMilliseconds > 30_000) return false;
      return withLock(deadline, async ({ check, checkWork, anchored, state, stateSnapshot, write }) => {
        if (effectProfile !== undefined) {
          const audit = (await state()).clients.find(client => client.clientId === clientId)?.audit.at(-1);
          if (!audit || audit.profileSha256 !== effectProfile.digest || audit.role !== effectProfile.input.binding.role
            || audit.runId !== effectProfile.input.binding.run) throw refused();
```

url-machine-store.ts:916 (exact subject)
```typescript
        const sampleCurrent = (): number | null => { try { return check(); } catch { return null; } };
        await operation(Object.freeze({ now: () => live(), current: () => sampleCurrent() !== null,
          sampleCurrent, read, preflightCanonical, advance }));
        if (phase !== 0 && phase !== 5) throw refused();
      }, { operationMilliseconds, ordinaryEffect, staging: publication, terminalRead });
```

url-machine-peer.ts:478 (exact subject)
```typescript
    if (preflight !== undefined && (!isOrderedDesignSessionProfile(options.profile)
      || !(await preflight.prepare()) || check(state) >= context.deadline || !preflight.current())) return { ok: false };
    const completed = await options.store.exclusive(context.clientId, context.deadline, async lease => {
      try {
      const now = await current(state), snapshot = await lease.read();
      if (!snapshot || !snapshot.canonical || snapshot.anchor.kind !== 'committed' || !lease.current()
        || !equal(snapshot.anchor.head.binding, options.binding) || !equal(snapshot.anchor.head, snapshot.audit)
        || !equal(snapshot.projection, snapshot.anchor.head.record) || sha256(snapshot.canonical) !== snapshot.anchor.head.record.sha256) throw refused();
      const decoded = readUrlMachineClient(snapshot.canonical, { ...context, now });
      if (!decoded.ok) throw refused();
      const record = decoded.record, active = record.instances.at(-1)!;
      if (!equal(active.verifier, peer.verifier) || record.revokedAt !== null || active.retiredAt !== null || active.revokedAt !== null
        || !record.scopes.includes(operation) || now < Date.parse(record.issuedAt) || now >= Date.parse(record.expiresAt)
        || now < Date.parse(active.issuedAt) || now >= Date.parse(active.expiresAt)) throw refused();
      await options.audit({ event: 'machine-peer-effect', clientId: record.clientId, instanceId: active.instanceId, revision: record.revision,
        runId: record.runId, role: record.role, operation, processIdentitySha256: peer.verifier.processIdentitySha256,
        channelIdentitySha256: peer.verifier.channelIdentitySha256, at: now });
      // Native reattestation can start a fresh inspection. Settle that sample
      // before the synchronous effect guards, within the same held lease.
      await current(state, true);
      const effectiveUntil = Math.min(context.deadline, Date.parse(record.expiresAt), Date.parse(active.expiresAt));
      const boundary = (): boolean => {
        try {
          if (check(state) >= effectiveUntil) return false;
          const now = lease.sampleCurrent === undefined ? lease.current() ? lease.now() : null : lease.sampleCurrent();
          return now !== null && now < effectiveUntil;
        } catch { return false; }
      };
      if (!boundary()) throw refused();
      const value = await effect(boundary);
      if (!boundary()) throw refused();
      result = { ok: true, value };
```

url-ordered-design-host.ts:144 (exact subject)
```typescript
      const result = await context.mediate(operation, async boundary => {
        if (!boundary()) throw refused();
        await selectedController().issueReply(value, (reply, revalidate, finalToolBudgetCheck) => {
          const text = canonical(reply), identity = { digest: sha256(text), bytes: Buffer.byteLength(text) };
          const receipt: ReplyIdentity = Object.freeze({ ...identity, toolUseId: call.id,
            id: `tool-${sha256(canonical({ call, reply: identity }))}` });
          if (replies.has(call.id)) throw refused();
          revalidate?.();
          if (!boundary()) throw refused();
          release(reply, () => { revalidate?.(); if (!boundary()) throw refused(); }, finalToolBudgetCheck);
          replies.set(call.id, receipt);
          issuedCall = null;
        });
      }, input.productPreflight);
```

url-session-audit.ts:834 (exact subject)
```typescript
        const tail = await io(deadline, async () => {
          await inspectIdentities(deadline);
          await checkEffectCurrent(deadline);
          const full = await writeRow(role, row.bytes, deadline, checkBoundary);
          await checkEffectCurrent(deadline);
          await segments.get(role)!.file.sync();
          await checkEffectCurrent(deadline);
          await directory.sync();
          await checkEffectCurrent(deadline);
          await inspectIdentities(deadline, { ...full, role });
          if (checkEffectCurrent !== checkCurrent) await checkEffectCurrent(deadline);
          return full;
        });
```

url-session-audit.ts:1027 (exact subject)
```typescript
      const checkAttemptCurrent = async (deadline: number): Promise<void> => {
        if (!(Date.now() < attemptDeadline)) throw refused();
        await checkCurrent(deadline);
        const allowed = await wait(track('callback', attemptCurrent), deadline);
        await checkCurrent(deadline);
        if (allowed !== true || !(Date.now() < attemptDeadline)) throw refused();
      };
      const held: Array<{ record: OrderedDesignStoredRecord; read: (charge?: boolean) => Uint8Array }> = [];
      const writer = createOrderedDesignAuditWriter({ profile: orderedDesignProfile, plan, principal: input.principal }, {
        current: async () => { await checkAttemptCurrent(performance.now() + limits.milliseconds); return true; },
        append: async record => {
```

url-run-ordered-attempt.ts:140 (exact subject)
```typescript
  const current = async (effectHorizon?: () => number): Promise<boolean> => {
    // Resumed runtime authority includes synchronous Git and claim checks.
    // Let a pending census finish before starting that work.
    if (closed) return false;
    if (input.generation !== undefined && delivery !== null && isUrlSessionProcess(child)
      && !(await input.waitForSamples())) return false;
    if (closed || !(await input.current()) || sessionMachineEffectCurrent() === false) return false;
    // Bootstrap has no controller yet; activation still gates every send/tool.
    if (delivery === null) return input.machine.current();
    // Activation and the first parsed request can wake in consecutive turns.
    // Drain before reading the full delivery proof for a live child.
    if (isUrlSessionProcess(child)) {
      await yieldToPoll();
      if (!(await input.waitForSamples())) return false;
    }
    if (!processingCurrent()) return false;
    return checkUrlOrderedProductCurrent({
      product: render!.product,
```

url-run-ordered-attempt.ts:327 (exact subject)
```typescript
    const envelope = { cpuMicroseconds: 64_000_000, wallMilliseconds: 30_000, auditReadBytes: 500_000_000,
      inputCodeUnits: 8_388_608, secretCodeUnits: 103_000_000, secretCalls: 524_361, activeCodeUnits: 16_777_216, activeCalls: 32 };
    const enforcement: OrderedDesignWorkEnforcement = { runtimeSha256: input.runtime.inputTreeSha256, workerSha256: program.worker.sha256,
      operations: { request: envelope, response: envelope, tool: envelope, audit: envelope, terminal: envelope },
      relayMilliseconds: 300_000, brokerMilliseconds: 85_000 };
    writer = input.audit.beginOrderedDesignAudit(plan, current, bytes => {
```
