from pathlib import Path
import datetime,hashlib,json,os,subprocess,tempfile,time
scratch=Path('/home/orca/.tmp/f3-native-admission-fixes');candidate=scratch/'ordered-mediation-phase-candidate';root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w');out=scratch/'ordered-mediation-phase-focused-R1';out.mkdir(exist_ok=False);b=json.loads((candidate/'bindings.json').read_text());sha=lambda data:hashlib.sha256(data).hexdigest();assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b'';base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert len({f['path'] for f in b['files']})==12
for f in b['files']:
 assert sha((root/f['path']).read_bytes())==f['baselineSha256'];assert sha((candidate/'candidate'/f['path']).read_bytes())==f['candidateSha256']
for f in b['files']:(root/f['path']).write_bytes((candidate/'candidate'/f['path']).read_bytes())
tmp=Path(tempfile.mkdtemp(prefix='p-',dir='/home/orca/.tmp'));tmp.chmod(0o700);env={**os.environ,'TMPDIR':str(tmp),'VITEST_MAX_THREADS':'1','VITEST_MIN_THREADS':'1','VITEST_MAX_FORKS':'1','VITEST_MIN_FORKS':'1'}
vitest=['node','node_modules/vitest/vitest.mjs','run'];folder='packages/polaris-dossier/src/'
commands=[('typecheck',['npm','run','typecheck','--','--pretty','false']),('profile-planning-unit',vitest+['--project','unit',folder+'session-profile.test.ts',folder+'url-ordered-design-work-budget.test.ts']),('store-peer-integration',vitest+['--project','integration',folder+'url-machine-store.test.ts',folder+'url-machine-peer.test.ts']),('product-lease-integration',vitest+['--project','integration',folder+'url-run-artifacts.test.ts','--testNamePattern=reserves native time on an immutable']),('launch-profile-integration',vitest+['--project','integration',folder+'session-launch.test.ts','--testNamePattern=compiles the independently named design profile|checks exact canonical ordered result|refuses forged preparation/profile|selects inspection ceilings'])]
result={'baseCommit':base,'candidateBase':b['baseCommit'],'candidateBindingSha256':sha((candidate/'bindings.json').read_bytes()),'files':b['files'],'scope':'exact reviewed12fileoverlay in disposableclean-base clone; no nativecase/fullgate claim','tmpdir':str(tmp),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
for name,command in commands:
 if name!='typecheck':command+=['--reporter=default','--reporter=json','--outputFile='+str(out/(name+'.json'))]
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'exit':r.returncode,'elapsedSeconds':time.monotonic()-start,'logSha256':sha((out/(name+'.log')).read_bytes())};result['commands'].append(record);(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(record),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
