# Independent combined design, source and test review
Verdict: PASS
Reviewed baseline: c52b682c705c98d59ef391458fb0dd7fa6580ec7
Candidate patch SHA-256: b50e8d2a092b4d430fb953eb06051fa760ac2f63bd96d0c7f19c07bc4303fd6c

[Observed] Subject: the frozen ordered-mediation-phase-candidate packet, its complete 12-file TypeScript baseline/candidate diff, DESIGN.md and governing-excerpts.md. Review used static source inspection, Git object reads, byte hashes and diff reconstruction. No candidate imports, tests, typecheck, build, helper, control, native, provider or network execution occurred. No primary edits were made. The engineering-bar and test-rigor skill instructions and supplied repository AGENTS.md were read.

[Inferred] Findings: no actionable design, source or test defect identified in this frozen candidate. PASS is the verdict for this source review. It does not establish executable correctness, native completion, a successful interrupted recovery, performance, or a final capture.

[Observed] Exact binding verification: 12 baseline SHA-256/size pairs and 12 candidate SHA-256/size pairs match bindings.json; reconstructing unified diffs from those 12 pairs reproduces candidate.patch byte-for-byte. A second sweep uses Git blob identity for each baseline/current file and sha256sum for each candidate. Both sweeps cover the same enumerated 12 files. The 12 current runtime/test files in the supplied review repository still equal c52. The source HEAD observed during the binding sweep was 6f76ce59547af6f5c57112454d2b310d95b2af15; that is provenance only. The review remains bound to c52 and the frozen candidate hashes.

[Observed] Governing provenance: the five governing/dependency files match their frozen sourceClone hashes. The adoption-log binding c8dfb66e13c23fd4e42799df22941f16e0c7587c0d18d227b0d87af370f572a0 is from that later sourceClone, whereas c52's entire adoption log hashes to ae3ad55b5c29add6e513860d6ef172711b3f50a1ee398392653ee139215c2b3f. The exact A-14 row is present unchanged in c52 and agrees with the frozen quotation. Each quoted specification paragraph at lines 277, 291, 775, 783, 785 and 789 was compared against the c52 Git object and matches. This provenance distinction does not change the runtime baseline.

[Inferred] Design assessment: the proposed numeric envelope is an explicit resource-policy change requiring its stated agent adoption. REQ-polaris-generation-035 says to reserve "finite expiring capacity for the remaining supported path" and to do so "without extending the recorded original deadline or lowering the ordinary role caps." REQ-polaris-generation-048 requires "finite registry/audit I/O/output/lock/operation wall limits under the original deadline." The frozen design's finite serial preparation30s/effect30s/absolute60s treatment is consistent with those quoted constraints; these clauses do not themselves prescribe 30s as a universal whole-operation cap. A-14 records the governing specification adoption. No owner-class change is introduced by the reviewed delta.

[Observed] Source assessment:

- url-machine-store.ts:465-637 starts the outer monotonic clock once before held-lock work, uses the same captured caller/run deadline, and checks the absolute operation cap before the active phase cap. Preparation uses the original began instant; effect receives a new origin only through beginEffect. The transition marks itself consumed before the fresh check, so a duplicate or reentrant call invalidates active state instead of renewing capacity. check() samples clocks around the live synchronous authority check; the transition then independently checks that its effect origin is still inside preparation. armTimer clears/replaces the old timer with the minimum of remaining original run, absolute operation and current phase capacity. Original synchronous checks continue to guard against a delayed timer callback.
- url-machine-store.ts:637-751 retains the original I/O wrapping, pending tracking, active-work tracking, work race and uncertain-lock cleanup behavior. Timer refusal deactivates the lease and marks it uncertain; unresolved protected work retains the lock. The transition does not acquire a replacement lease, release a lock, reset began, change a caller deadline, or change I/O/byte/admission/lock caps. Preparation-only trusted reads remain within preparation30s. Ordinary and unprofiled selection remain20s and5s respectively.
- url-machine-peer.ts:472-519 retains fresh currentness, exact scope, committed canonical/projection/audit binding, current record/instance expiry, durable audit and forced native reattestation before beginning the effect phase. beginEffect is added after await current(state,true) and immediately before the original first boundary. The original await effect(boundary), post-effect boundary, result assignment and guarded final return remain in order. Missing transition support for a genuine ordered profile refuses. Record/instance expiry and peer identity still gate each actual effect boundary.
- session-profile.ts authenticates only factory-issued WeakSet members, freezes the profile, and includes profile8's three timing fields and updated identity in canonical bytes/digest. Spreads, clones and claimed fields cannot gain that identity. The store compares durable audit profile/run/role bindings before exposing the lease; a retained profile7 digest cannot silently gain profile8 authority.
- url-product-read-limits.ts derives mediation60s from two30s constants and ordered product120s from existing render60s plus mediation60s. render.ts retains its60s producer cap and original issued product deadline. url-run-ordered-attempt.ts uses mediation60s for prospective coverage; no transition renews a product lease. The source retains caller/original-run clipping and record/instance/transport/broker refusals.
- url-ordered-design-session.ts supplies the authenticated transcript mediation bound to reservation. url-ordered-design-work-budget.ts validates the bound inside the existing broker parent and retains one broker charge per turn. Broker85s, relay300s and operation envelope calculations remain unchanged. The independent transport connection lifetime can be tighter because its origin precedes the broker parser/invocation timer; the design acknowledges this limitation and preserves that refusal.
- New refusal fields are fixed enum/numeric phase diagnostics. The reviewed additions do not include source paths, canonical record bodies, credentials or captured request content.

[Observed] Test-source assessment: five new test declarations expand to13 cases: eight serial phase scenarios, two suspended-phase timer scenarios, one reentrant transition scenario, one retained profile7 credential scenario, and one mediation/planner scenario. The patch removes no test declarations. Existing ordinary/unprofiled/profile-bound limits, caller deadline clipping, product expiry/mutation/irreversibility, ordinary render limit, and genuine composed completion assertions remain. Existing product/launch/composed expectations are adjusted to the new profile/lease envelope rather than replacing the result assertions.

[Inferred] This adds-only growth is justified by newly introduced behavior: separate phase clocks, rearmed timers, a one-use transition, the identity bump and broker-envelope inclusion. The cases catch distinct plausible faults, including charging preparation against effect, omitting either phase check, retaining the preparation timer into the effect, renewed duplicate transitions, reentrant authority callbacks, withdrawn/original-deadline continuation, silently upgraded profile7 credentials, and double-charged or excessive mediation planning. Expected phase diagnostics are literals. Suspended tests control the external clock and invoke the captured timer callback; they assert refusal and revoked continuation instead of sleeping for30s. Their evidence remains source-level until run. Existing protected-I/O interruption and uncertain-lock tests cover the retained cleanup machinery; this review does not claim those tests passed.

[Unknown] Native interrupted recovery, completion, performance, full-suite status and final capture for profile8. Applying these exact bytes, recording the resource adoption, running proportional checks, and executing the genuine interrupted case remain implementation-owner work. The unchanged broker/transport limit may independently refuse a run even when this store phase split succeeds.

[Observed] Scripted bindings follow. The complete independent binding report is /home/orca/.tmp/f3-native-admission-fixes/ordered-mediation-phase-independent-bindings.json, SHA-256 c1b3346b2b2013e05ffbe553149241f5beb31315c530ee7018267828332fa0d1. The JSON below is copied mechanically from that report; its c52 adoption-log mismatch is explicitly resolved by dependenciesAtFrozenSourceClone and the provenance paragraph above.

```json
{
  "baseCommit": "c52b682c705c98d59ef391458fb0dd7fa6580ec7",
  "baseTree": "43daf0272d0fc72533d9d84a3eab349d5767a8c3",
  "currentHead": "6f76ce59547af6f5c57112454d2b310d95b2af15",
  "bindingsSha256": "2c01a5e7810b2f7864f6c424bbf49fbf9004150cc9f62a65cc4793deccf54b28",
  "files": [
    {
      "path": "packages/polaris-dossier/src/session-launch.test.ts",
      "baseBytes": 119619,
      "baseSha256": "67b75a5d3b4945d02e79f8b5c335c32dcbe15b4aba17d4876165f98b106006ee",
      "candidateBytes": 119854,
      "candidateSha256": "c01f69603a9433ad08cd3dcd517e8f54a413e31c5d691f5d990894bcc91f2a4e",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/session-profile.ts",
      "baseBytes": 22442,
      "baseSha256": "6fb93ce4f0b829f3110094ea09e59abff0feeb050f776a6e687134b7943366c2",
      "candidateBytes": 22684,
      "candidateSha256": "c40ad6030bdc4f91d7b0b25649a211c6966ec6557a4f62f91d751d8e324966b2",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-machine-peer.ts",
      "baseBytes": 38140,
      "baseSha256": "2a1f0067d10f2fdef2ec96716166bd7e9785bb4667aafa580aa90f7fadd56cfb",
      "candidateBytes": 38414,
      "candidateSha256": "e484b8649debcfb170f456fd69172d651635bc380b79a19191fd469ecedc410c",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-machine-store.test.ts",
      "baseBytes": 94600,
      "baseSha256": "a7661ccafd624b06ae33bf95cc59d3c4952210ccfb4f0317932458830ef8e58a",
      "candidateBytes": 101849,
      "candidateSha256": "88061fd7d526a5fc6a261579720651ec6e7d44c1e6a08309d18da42506463976",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-machine-store.ts",
      "baseBytes": 62441,
      "baseSha256": "5a926ed31da2cbc5bb631b5a0a061e5d41e2e034dd1cafdf6b8f4215fe3b754a",
      "candidateBytes": 65750,
      "candidateSha256": "28e2074c28a21d21e9deef4c30d56a00b8ae9734777505ebdd028286e6044f40",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-ordered-design-session.ts",
      "baseBytes": 37349,
      "baseSha256": "68c7f5015ef316461accee889ca8f6d31daa29de54d5da02228b81e357569253",
      "candidateBytes": 37426,
      "candidateSha256": "65906032d8b0192c615fd68526bea5b6bfd8b76e604d75ee750f8503f8b0528d",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-ordered-design-work-budget.test.ts",
      "baseBytes": 25946,
      "baseSha256": "93b1f46140e0a2e42aa1f4638b95c985fac8632fd6477de8b7c7d4eaa92cd462",
      "candidateBytes": 26862,
      "candidateSha256": "5fdb34e9089460de256ba9bbb1edfdc87060bf97cd8a737e8d7d394312729253",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-ordered-design-work-budget.ts",
      "baseBytes": 20900,
      "baseSha256": "eb06df2578525dc316c8bd0383aaab34211306daa415738713b3fb9987e59d50",
      "candidateBytes": 21298,
      "candidateSha256": "6904332379f22a294a73f5ae34a0555a2a05bcd50a3f163a0821f9a4773bf0b5",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-product-read-limits.ts",
      "baseBytes": 722,
      "baseSha256": "103aacefcde3769194f2b4c1e5b20a72e257388d586d1a837643206b0b44d50d",
      "candidateBytes": 1130,
      "candidateSha256": "bc653a3a8913b8e0c2843105b00d2a8a3ad6e48c665acd07a49eec682239d112",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-run-artifacts.test.ts",
      "baseBytes": 150166,
      "baseSha256": "e2153e505cbee0f9164c16b5f4a200127202f11d27bba55a770e0dfd80b0357e",
      "candidateBytes": 150171,
      "candidateSha256": "4a25a7ff5717fdaa0e241e2db41bd9d564ca08e4ccfbeeafdfda247d09a42f0a",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-run-composed.test.ts",
      "baseBytes": 222727,
      "baseSha256": "0cc7d0baeba24550d4133168a273c223273f1f0435fb0d05f3c875f7dcbe25cd",
      "candidateBytes": 222729,
      "candidateSha256": "d4a8155506722cad0d989bc24401a9bcde4c2485beb99531f43e53683fd58139",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    },
    {
      "path": "packages/polaris-dossier/src/url-run-ordered-attempt.ts",
      "baseBytes": 22379,
      "baseSha256": "4553a3c3b01efc6372f49363cc8ceaa637d72bf8c4d96beff5e3bad9d0c34ec4",
      "candidateBytes": 22382,
      "candidateSha256": "d4f08b0f81ffd24cb04950196d0c9a28d5c105e6f424b158e454cf6d9db53062",
      "baseMatchesBinding": true,
      "candidateMatchesBinding": true,
      "currentRuntimeMatchesBaseline": true
    }
  ],
  "inputs": [
    {
      "path": "candidate.patch",
      "bytes": 32642,
      "sha256": "b50e8d2a092b4d430fb953eb06051fa760ac2f63bd96d0c7f19c07bc4303fd6c",
      "matchesBinding": true
    },
    {
      "path": "DESIGN.md",
      "bytes": 9134,
      "sha256": "73af31796e0e21300140e37fff719cb132b9f07e1440361871d75a28a14a0274",
      "matchesBinding": true
    },
    {
      "path": "governing-excerpts.md",
      "bytes": 11580,
      "sha256": "d6ee2e3bd3c178c80934f25f83484980896b8c07ddfca9211c0ee1f5e1318ebf",
      "matchesBinding": true
    }
  ],
  "dependencies": [
    {
      "path": "openspec/changes/dossier-url-declared-source-run/proposed/polaris-generation/spec.md",
      "bytes": 213529,
      "sha256": "e30836f902361c74943cc0cf69ae907a3e9d678a542b27676677e47c8a5fa865",
      "matchesBinding": true
    },
    {
      "path": ".syzygy/governance/decisions/AGENT-ADOPTIONS.md",
      "bytes": 236757,
      "sha256": "ae3ad55b5c29add6e513860d6ef172711b3f50a1ee398392653ee139215c2b3f",
      "matchesBinding": false
    },
    {
      "path": "packages/polaris-dossier/src/render.ts",
      "bytes": 111567,
      "sha256": "317c79ff74fa63bbbbafc61fd6646849a01b9390d40134fb1d16d82884b75087",
      "matchesBinding": true
    },
    {
      "path": "packages/polaris-dossier/src/session-broker.ts",
      "bytes": 8985,
      "sha256": "e38ede1ae1395eb42b4c1bda4d1e37a305d55c75435d65e84bbeb436d99f5525",
      "matchesBinding": true
    },
    {
      "path": "packages/polaris-dossier/src/session-machine-transport.ts",
      "bytes": 13565,
      "sha256": "5baabf69a2eb14b5c7a5c29a0db7e556c2836e60ec391f3e7d6bd7aed363bdcd",
      "matchesBinding": true
    }
  ],
  "regeneratedPatchMatches": true,
  "secondMethod": [
    {
      "path": "packages/polaris-dossier/src/session-launch.test.ts",
      "baseBlob": "2ac1da62bf49108ca14113acb170b9cebc7daeb6",
      "currentBlob": "2ac1da62bf49108ca14113acb170b9cebc7daeb6",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/session-profile.ts",
      "baseBlob": "258b4d6ced28289a53daadbb4f90a320d61a0e2b",
      "currentBlob": "258b4d6ced28289a53daadbb4f90a320d61a0e2b",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-machine-peer.ts",
      "baseBlob": "4ff6f052f06a0c5c0655a58f00312c6d84f1e85a",
      "currentBlob": "4ff6f052f06a0c5c0655a58f00312c6d84f1e85a",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-machine-store.test.ts",
      "baseBlob": "c149595aba49c6331ed3a2e781416133d4696171",
      "currentBlob": "c149595aba49c6331ed3a2e781416133d4696171",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-machine-store.ts",
      "baseBlob": "27ccc92ec6504f5090687f46241a59f12350df09",
      "currentBlob": "27ccc92ec6504f5090687f46241a59f12350df09",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-ordered-design-session.ts",
      "baseBlob": "7ff4196c14e8ea33a40706e0fe49b4f8bfa821ea",
      "currentBlob": "7ff4196c14e8ea33a40706e0fe49b4f8bfa821ea",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-ordered-design-work-budget.test.ts",
      "baseBlob": "55308dd072aec4538653c76a51927871243dce37",
      "currentBlob": "55308dd072aec4538653c76a51927871243dce37",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-ordered-design-work-budget.ts",
      "baseBlob": "13e32e1cf40fc8a3dc072943811a4fdda02150ee",
      "currentBlob": "13e32e1cf40fc8a3dc072943811a4fdda02150ee",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-product-read-limits.ts",
      "baseBlob": "14c5f63264e19b79eb63b5fff205979f4bd333b0",
      "currentBlob": "14c5f63264e19b79eb63b5fff205979f4bd333b0",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-run-artifacts.test.ts",
      "baseBlob": "9a55add4dbefc7ef83ced5b8129dca9780829667",
      "currentBlob": "9a55add4dbefc7ef83ced5b8129dca9780829667",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-run-composed.test.ts",
      "baseBlob": "963590e4932856f51745fbd167ab5d9fd32dad73",
      "currentBlob": "963590e4932856f51745fbd167ab5d9fd32dad73",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    },
    {
      "path": "packages/polaris-dossier/src/url-run-ordered-attempt.ts",
      "baseBlob": "073c7f02cab11de97c8cfddb83e64e677ee0eac6",
      "currentBlob": "073c7f02cab11de97c8cfddb83e64e677ee0eac6",
      "blobMatches": true,
      "candidateSha256sumMatches": true
    }
  ],
  "dependenciesAtFrozenSourceClone": [
    {
      "path": "openspec/changes/dossier-url-declared-source-run/proposed/polaris-generation/spec.md",
      "source": "/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w/openspec/changes/dossier-url-declared-source-run/proposed/polaris-generation/spec.md",
      "bytes": 213529,
      "sha256": "e30836f902361c74943cc0cf69ae907a3e9d678a542b27676677e47c8a5fa865",
      "matchesBinding": true
    },
    {
      "path": ".syzygy/governance/decisions/AGENT-ADOPTIONS.md",
      "source": "/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w/.syzygy/governance/decisions/AGENT-ADOPTIONS.md",
      "bytes": 237503,
      "sha256": "c8dfb66e13c23fd4e42799df22941f16e0c7587c0d18d227b0d87af370f572a0",
      "matchesBinding": true
    },
    {
      "path": "packages/polaris-dossier/src/render.ts",
      "source": "/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w/packages/polaris-dossier/src/render.ts",
      "bytes": 111567,
      "sha256": "317c79ff74fa63bbbbafc61fd6646849a01b9390d40134fb1d16d82884b75087",
      "matchesBinding": true
    },
    {
      "path": "packages/polaris-dossier/src/session-broker.ts",
      "source": "/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w/packages/polaris-dossier/src/session-broker.ts",
      "bytes": 8985,
      "sha256": "e38ede1ae1395eb42b4c1bda4d1e37a305d55c75435d65e84bbeb436d99f5525",
      "matchesBinding": true
    },
    {
      "path": "packages/polaris-dossier/src/session-machine-transport.ts",
      "source": "/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w/packages/polaris-dossier/src/session-machine-transport.ts",
      "bytes": 13565,
      "sha256": "5baabf69a2eb14b5c7a5c29a0db7e556c2836e60ec391f3e7d6bd7aed363bdcd",
      "matchesBinding": true
    }
  ],
  "bindingNotes": [
    "The adoption log was frozen from sourceClone after c52, not from the c52 git object; exact A-14 row is unchanged. Runtime/test bases are c52."
  ],
  "testDeclarationsAdded": 5,
  "testDeclarationsRemoved": 0,
  "newCasePopulation": {
    "serialPhaseCases": 8,
    "suspendedPhaseCases": 2,
    "reentrant": 1,
    "legacyCredential": 1,
    "planning": 1
  },
  "newCaseTotal": 13
}
```
