# Actual-image private-reference benchmark — one retained run

[Observed] Baseline clean 0e14c3439fb59cf5405e3306c6d8de671a49206d was compared with clean candidate 0116bb34204d552a9ee9f9e4905cea6dee29ab3e using their actual built dist modules. Candidate runtime manifest is 3e4b1fa3a6d89f399c7c7205bbfc329f9138ce8ee15664e529be43526f618e75. Both genuine runtime admissions succeeded before and after measurement; actual addon, supervisor and Git digests matched between variants and remained stable. The original build at 0116 succeeded beforehand with all 402 inputs and 10 outputs independently hash-verified.

[Observed] One benchmark run completed in 7.297859565005638 seconds: 96 warm pairs and 24 fresh-scope lifecycle pairs, 240 timed observations and 432 timed native commands (384 warm, 48 cold). Four separately retained constructor/first-HEAD/setup-ref observations add four first-HEAD and four setup-ref native commands. Each of ten case/memory populations contains 12 pairs and six runs in each order. All 240 timed child CPU aggregates are positive and paired output digests match.

| Population | Memory | Case | Baseline wall ms | Candidate wall ms | Wall change | Host CPU baseline → candidate ms | Child CPU baseline → candidate ms |
|---|---|---|---:|---:|---:|---:|---:|
| warm | ordinary | head-sync | 15.961 | 12.424 | -22.16% | 11.951 → 7.825 | 3.540 → 3.848 |
| warm | ordinary | head-async | 15.352 | 11.149 | -27.38% | 11.970 → 7.178 | 3.563 → 3.688 |
| warm | ordinary | refs-policy-refs-sync | 45.486 | 31.975 | -29.70% | 32.918 → 19.544 | 11.300 → 10.996 |
| warm | ordinary | refs-policy-refs-async | 45.023 | 33.376 | -25.87% | 38.653 → 28.625 | 11.466 → 11.805 |
| warm | retained-320MiB | head-sync | 16.969 | 11.657 | -31.30% | 11.947 → 5.031 | 3.771 → 3.707 |
| warm | retained-320MiB | head-async | 15.541 | 11.178 | -28.08% | 16.567 → 12.234 | 3.800 → 3.697 |
| warm | retained-320MiB | refs-policy-refs-sync | 46.218 | 34.882 | -24.53% | 32.447 → 21.140 | 11.655 → 11.809 |
| warm | retained-320MiB | refs-policy-refs-async | 48.499 | 36.335 | -25.08% | 42.090 → 33.753 | 11.688 → 11.786 |
| cold-lifecycle | ordinary | create-head-drain-close | 17.224 | 18.232 | +5.85% | 12.978 → 12.356 | 3.872 → 3.838 |
| cold-lifecycle | retained-320MiB | create-head-drain-close | 16.265 | 15.412 | -5.25% | 13.232 → 12.140 | 3.661 → 3.519 |

[Observed] Initial constructor and first-call costs were retained separately in each memory mode. Ordinary warmup order was baseline then candidate; retained320MiB order was candidate then baseline. Constructor child CPU is recorded as zero for all four observations. Combined timing includes intervening measurement bookkeeping; it need not equal the two isolated wall intervals.

| Memory | Variant | Constructor wall / host ms | First HEAD wall / host / child ms | Combined wall / host ms |
|---|---|---:|---:|---:|
| ordinary | baseline | 1.266 / 3.269 | 32.706 / 15.056 / 3.996 | 34.286 / 20.644 |
| ordinary | candidate | 1.024 / 4.111 | 19.034 / 16.990 / 4.344 | 20.260 / 21.329 |
| retained-320MiB | candidate | 3.681 / 4.338 | 16.063 / 9.379 / 4.259 | 19.929 / 13.909 |
| retained-320MiB | baseline | 0.612 / 2.629 | 18.961 / 19.599 / 4.713 | 19.743 / 22.408 |

[Observed] Cold scopes include complete creation, first synchronous HEAD, healthy drain and close. These are fresh scopes in the same JS process, not cold process, module or OS-cache observations. Their mean phase costs are retained below; raw observations also include phase CPU and all process memory metrics.

| Memory | Variant | Constructor wall / host ms | First HEAD wall / host ms | Drain+close wall / host ms |
|---|---|---:|---:|---:|
| ordinary | baseline | 0.454 / 1.091 | 16.427 / 11.550 | 0.169 / 0.151 |
| ordinary | candidate | 0.536 / 0.682 | 17.229 / 11.163 | 0.279 / 0.297 |
| retained-320MiB | baseline | 0.479 / 1.880 | 15.560 / 11.060 | 0.111 / 0.123 |
| retained-320MiB | candidate | 0.415 / 1.042 | 14.720 / 10.777 | 0.140 / 0.159 |

[Observed] The three authenticated image sizes sum to 4,601,400 bytes (31,608 addon +22,024 supervisor +4,547,768 Git). The frozen candidate source retains one private authenticated byte reference per image in each scope, filling the addon at construction and remaining images on first use, then clearing references on close. The per-check 1MiB read buffer remains. Clearing a reference does not promise immediate RSS reclamation.

| Memory | Shared paired-sample RSS range bytes | Shared arrayBuffers range bytes |
|---|---:|---:|
| ordinary | 107941888–145424384 | 4816338–71293041 |
| retained-320MiB | 431529984–498409472 | 343905287–420401051 |

[Observed] Raw warmup and cold-lifecycle records retain before/after RSS, heapUsed, external and arrayBuffers metrics; independent-verification.json also stores mean cold memory deltas. These belong to one process hosting both variants. Natural GC is visible, including negative memory deltas during capture. The retained320MiB buffer is synthetic; no global GC, heap, native-worker, cap or deadline override was used. Native timeout remained 10000ms.

[Observed] All 52 scopes were healthy, drained and closed. Full own-FD metadata populations were identical before and after (20 descriptors); all 48 cold samples matched their own before/after FD populations, and selected-image FD populations remained empty at final boundaries. The operator recorded no owned descendants and removed empty owned TMP. Both exact clean commits and all recorded source/operator/manifest bytes remained unchanged. Benchmark work made no source edit, build or test run. The preparation manifest remains untouched; exact executed identities and copied source/compiled-module/manifest bytes are retained in execution-1.

[Inferred] This bounded run supports a local warm-probe improvement: case mean wall time was 22.2–31.3% lower and host CPU was lower across the eight warm populations. Fresh-scope means were mixed: ordinary lifecycle was 5.85% slower, synthetic retained-memory lifecycle 5.25% faster. Initial capture and the additional 4.60MB live reference storage per fully used scope remain relevant trade-offs. The data does not establish end-to-end recovery timing or a general performance guarantee.

[Unknown] Genuine recovery acceptance, final full-suite result, final source/main/full acceptance and adoption. Both variants targeted the same baseline HEAD and actual base/origin policy checks; refs-policy-refs explicitly passed parent undefined because origin/main was absent, so those observations establish no parent authority. This was one approved run with no retry or population expansion.
