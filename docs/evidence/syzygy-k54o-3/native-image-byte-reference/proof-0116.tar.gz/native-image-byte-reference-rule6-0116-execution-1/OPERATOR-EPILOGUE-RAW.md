[Observed] outer except BaseException catches the intended sys.exit(0) after a complete receipt; SystemExit(0) is printed as setupOrInterruptError and wrapper exits1. No repeat was run.

The immutable results.json records both exact assertion kills and successful source/child/scratch cleanup before this epilogue error. The process return code was1, not0. Independent read-only final Git and SHA checks confirm clean expected0116 and both original source hashes. This addendum does not rewrite the original runner or receipt, and no mutation/test was repeated.
