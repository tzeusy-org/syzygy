# Exact 0e14 completed recovery profile assessment

[Observed] Subject `0e14c3439fb59cf5405e3306c6d8de671a49206d`. Terminal receipt reports exit 1 after 608.8201116580167 seconds, subject unchanged/clean, no owned children and private scratch removed. The retained log reports one failed recovery test, six explicit selection skips over seven cases, and the original 600000ms timeout. Finished metadata records 823/823 verified and confirmed native samples, no recorded sample/store refusals, three design forwards, and zero final-product assertions. This is continued slow progress, not a demonstrated native transport deadlock.

[Observed] All 8 completed profiles were analyzed: 3958606 samples in total. Each profile passed independent sample-first versus node-first recomputation for every node, exact frame identity and category, using signed integer microseconds. Frame/category inclusive weights count presence once per sample, including recursive frames. The three negative deltas are all −2µs in the owning worker, total −6µs; they remain signed in every total. Profile end minus start differs slightly from sampled-delta sum; exact discrepancies are retained. Cross-process totals are a population check, not additive elapsed time or CPU.

| Completed profile | Classification from frames/samples | Samples | Signed delta µs | Negative count / µs |
| --- | --- | ---: | ---: | ---: |
| CPU.20261125.164350.3699295.0.001.cpuprofile | root runner | 567111 | 608603595 | 0 / 0 |
| CPU.20261125.164351.3699447.0.001.cpuprofile | owning test worker | 558941 | 606777282 | 3 / -6 |
| CPU.20261125.164351.3699448.0.001.cpuprofile | idle pool worker | 566398 | 607816815 | 0 / 0 |
| CPU.20261125.164351.3699454.0.001.cpuprofile | idle pool worker | 566498 | 607812999 | 0 / 0 |
| CPU.20261125.164351.3699455.0.001.cpuprofile | idle pool worker | 566421 | 607807972 | 0 / 0 |
| CPU.20261125.164351.3699461.0.001.cpuprofile | idle pool worker | 566613 | 607805438 | 0 / 0 |
| CPU.20261125.164351.3699473.0.001.cpuprofile | idle pool worker | 566494 | 607799882 | 0 / 0 |
| CPU.20261125.165358.3812052.0.001.cpuprofile | short pool bootstrap | 130 | 151123 | 0 / 0 |

[Observed] The owning worker has sampled owning-test, policy, product and native frames. The root runner has Vite/Tinypool initialization frames. Five long-lived pool workers have Tinypool bootstrap frames, no sampled owning-test/product frames, and greater than 99% idle weight. The short final process has pool-bootstrap frames and only 130 samples; its exact spawning purpose is [Unknown]. Classification did not use filename/PID position alone.

[Observed] Worker signed denominator is 606777282µs. The following leaf partition is disjoint and sums exactly to that denominator and all 558941 samples. These are V8 sampling weights, including waits and scheduling; native runSync self weight is not a measurement of exclusive addon CPU or kernel CPU.

| Disjoint sampled leaf/ancestry bucket | Signed µs | Samples |
| --- | ---: | ---: |
| idle | 35176804 | 32406 |
| garbage-collector | 28674763 | 26407 |
| image-validation-hash-update-self | 157817269 | 150561 |
| native-runSync-leaf-unresolved-native-wait | 174524867 | 162106 |
| other-hash-update-self | 19981292 | 18665 |
| other-sampled-leaf | 109940713 | 97299 |
| image-validation-read-leaf | 53716034 | 46231 |
| image-validation-FastBuffer-self | 20144115 | 18868 |
| image-validation-other | 6801425 | 6398 |

[Observed] The main SHA cost is the new executable-image currentness path: Hash.update self under native-image current is 157817269µs; read leaf is 53716034µs; FastBuffer self is 20144115µs. All native-image current ancestry totals 238478843µs; the exact inner hold/current frame totals 238105157µs. Buffer.alloc inclusive within this ancestry is 17581912µs and overlaps FastBuffer self, so it cannot be added. Global GC is 28674763µs; attribution of all GC to these buffers is [Unknown]. A buffer-only change therefore targets approximately 20.144s of sampled allocation leaf weight, with uncertain secondary effects, and cannot claim the 157.817s SHA weight as savings.

[Observed] Sync committedUrlPoliciesCurrent inclusive is 381403936µs; sync/async frame-presence union is 408316110µs. Cold stopped-claim current/currentAsync union is 183655094µs (the synchronous current frame alone 168268217µs). These contain policy/native/image work and are not additive costs. Example sampled path: session effect/claim current → committedUrlPoliciesCurrent → runGit → scope runSync → native wrapper runSync; descendants split between openJob/hold/current → SHA/read/allocation and the blocking native call. Product-verification module ancestry totals 69181327µs and also nests policy/current work.

[Observed] Crypto update with runtime-file ancestry totals 3586382µs; the nearest runtime-file caller accounts for 3381302µs of crypto-update self. Runtime module ancestry is 5212966µs. [Inferred] Source has its direct hash.update loop in readNodeDigest; async continuation stacks omit suspended callers, so these numbers are not a complete inclusive wall-time measurement of readUrlRuntime. They nevertheless distinguish the 157.817s executable-image hashing hotspot from an unsupported claim that all SHA samples rehash Node. The separate operator boundary measurement (12 cases/mode) found roughly 15ms native calls, 41–43ms three-command transport and 116ms full-runtime wall / 180–186ms host CPU, with no transport RSS regression at retained 320MiB. That measurement is separate evidence, not a subtraction from this run.

[Observed] Historical 00f9 summary has spawnSync self 383462280µs, spawn self 88161949µs, sync-policy inclusive 393441501µs and GC 13068129µs; its two negative deltas total −8µs. Current sync-policy inclusive remains large (381403936µs), but the sampled stack now splits between native wait and extensive fresh image verification. This is a hotspot change, not a paired causal speedup estimate: source, completed-profile population and progress differ. Historical summary digest and exact selected values are in summary.json.

[Inferred] The narrow first step is a paired boundary experiment replacing repeated scratch allocation while leaving every digest/read/stat/currentness call intact; measured allocation contribution is limited as above. The larger measured candidate is replacing repeated SHA recomputation with complete fresh byte equality against a private, SHA-authenticated expected-image snapshot. Byte equality to the authenticated image implies the current digest predicate and does not cache a policy/ref verdict. It requires a separate source/behavior review and paired measurement; no recovery cure or deadline change follows from this profile alone.

[Observed] Frozen source binding covers 18 files: working SHA256, exact 0e14 Git-object bytes and independent sha256sum all agree. Source behavior: hold/current fully reads each image with 1MiB Buffer.alloc, hashes all returned bytes, checks exact EOF/size and before/after held/named stats; openJob invokes this for addon, supervisor and Git and final current repeats it. Runtime verifyInputs already groups eight reads; no blanket parallelization recommendation is supported. No product/source edits, test/build/probe execution, fixture-body reads or live process inspections were performed for this assessment.

Bindings: `source-binding.json` SHA256 `b9da72f640106383e0897895a1cddf3891d19ace3e1687a4a8bf77e3eef23586`; `summary.json` SHA256 `d9aa0197382a55bf0df8bb00cf2991df6445a70d49a46b782ab7c0c44a4ecd3d`; complete metadata-only numeric/call-path archive SHA256 `3f7abecce1e5bc56459dcf066d5244ccfa3cf9cf1adb1a15ec059cce4e6e7608`. The archive retains all paths/node totals, but data: URLs are represented by SHA256 and byte length rather than duplicating code bodies. Original eight profiles are unchanged and individually hashed in summary.json. Recovery log SHA256 `aa32c55043f8fa84f03b795a137b7ec5127f3a7f5651f3e8c7bb9cece8b26083`; terminal receipt SHA256 `8553df9da69ef2144702e530808182283bd2ef38bf330f39d16a36bf3337e73b`. Analyzer/source scripts are retained alongside this report.
