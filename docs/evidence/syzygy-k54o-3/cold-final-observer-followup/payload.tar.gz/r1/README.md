# Cold-final preparation observer review

Test-only single-file subject. No runtime authority, budgets, product guards, assertions, stop criteria or fixture order change. Original imported port calls are observed only within the existing genuine cold-helper invocation. Existing mocks are unwrapped and restored with their call counters intact; concurrent invocations use AsyncLocalStorage and share port installation only until all original promises settle. The original values/promises and rejection/throw objects are returned unchanged.

Metadata retains rolling 32 preparations and 32 steps per preparation plus first preparation/step refusals independently. It contains only closed phase/predicate names, ordinal, timing, remaining deadline and boolean outcomes. No path/body/error value enters a diagnostic. Only after an original null result, actual returned product/history metadata is projected against the current private comparison order; this is explicitly a post-return projection, not an observed private guard. Successful preparations perform no extra identity hashing. Ephemeral metadata references are dropped when the original invocation settles.

The existing forwarding case adds call count/argument/promise/error identity checks, outside-call exclusion, late-refusal retention, failure-only comparison projection, and concurrent-scope checks. No new case is introduced. Eligible audit diagnostics now receive the same actual audit path as interrupted recovery; previous not-created was produced from an undefined test locator.

Review exact frozen source/patch and preserve prior native guards. Focused three observer cases and typecheck are pending at freeze; no native run is claimed.
