# Independent review — cold-final preparation observer R2
Verdict: REVISE
Source SHA-256: 273f2c5412a182f1b85800ffa23b5e183a8d86b18914cc7d02fd90751492f1b0
Patch SHA-256: 0073d0f36858e8ccec2af544c0e3870f54f729ad842b30f0b7c0022bb780b833

Base commit: 5b2e3fe678468921285fa36dd843d790e251daec
Subject: packages/polaris-dossier/src/url-run-composed.test.ts, frozen in this packet.
Review basis: exact frozen source and patch, base implementation, repository AGENTS.md, test-rigor skill, and the packet's focused check output. No source, index, or commit mutation was performed. No additional test run was performed.

1. Preserve the original pre-existing spy and its counters when installing and restoring the observer (source lines 462–468; forwarding assertion line 2064). [Observed] The watch helper extracts previous.getMockImplementation() and delegates directly to that implementation after vi.spyOn. When Vitest supplies a distinct outer spy, original calls bypass the previous spy itself, so its call counter and recorded argument/result history are not preserved. The restoration branch also reinstalls the extracted implementation on the outer spy instead of restoring the previous spy. This violates the stated preservation requirement and test-rigor expectations 1 and 3. [Observed] focused/focused.log reports the matching regression: expected isClaimedStoppedUrlRun to be called 80 times, got 0; the three selected cases yielded two passed and one failed, with four native cases skipped out of seven total. [Inferred] Distinguish the same-spy case, which requires avoiding recursion, from the distinct-spy case, which must forward through and restore the original spy. Keep the existing forwarding assertions as the regression check.

[Observed] Source and patch hashes match metadata.json. The supplied focused result names this exact source digest. Net new test cases declared by the packet: 0.

[Unknown] Native completion. The native cases were skipped, and this review does not establish native success, authority availability, or completion. The counter-preservation defect is sufficient for REVISE; this report makes no acceptance claim for the remaining observer behavior.
