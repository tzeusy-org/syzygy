REVISE

Independent source review of the frozen R3 cold-final preparation observer packet.

Subject binding

- Base commit: 5b2e3fe678468921285fa36dd843d790e251daec; base tree: e84bfa56f8596f3123643d1854b627f711b79f5c.
- Source: packages/polaris-dossier/src/url-run-composed.test.ts, SHA-256 8119338cfd3d7577060e6987ec71527ee71c0d3d3f7b75db32025529fbe20395.
- Patch: observer.patch, SHA-256 8293c5295c2b41ef88d3ad79d3193c6312d1e30c0902d673febb60fc0eb3784b.
- [Observed] Scripted hashes match metadata. Applying the patch to the named base source in a temporary directory produces the frozen source exactly.

Blocking findings

1. [Observed] The claim wrapper loses its type-predicate signature. At frozen source line 472, the wrapper inferred as `(value: unknown, claim: unknown) => boolean` does not satisfy the original `(value: unknown, claim: unknown) => claim is UrlRecoveryClaim`. The packet's current typecheck/typecheck.log reports TS2322 for this line. Preserve the original predicate signature while forwarding its original boolean result; this exact packet does not pass its required typecheck.

2. [Observed] The stored-authority wrapper does not preserve its universally generic return signature. At frozen source line 479, the supplied wrapper is inferred as returning unknown rather than `T | null` for every caller-selected T. The packet's current typecheck/typecheck.log reports TS2322 for this line. Preserve the generic callable type through watch/measure or give this wrapper an explicitly checked signature without changing its original runtime result.

Source review observations

- [Inferred] Across the eight watched exported ports and the two measured stored-authority callbacks, each wrapper delegates once at the original call site. The observer introduces timing/metadata work and promise-settlement observers, but does not itself perform another authority sample or product/file read. Direct argument objects, returned objects, promises, rejection objects and synchronous thrown objects are forwarded unchanged. Stored authority deliberately receives forwarding callback wrappers; their calls delegate once to the original callbacks.
- [Inferred] The distinct-versus-reused spy branch addresses the earlier counter failure: a distinct wrapper delegates through the previous mock, while a reused mock delegates through its saved implementation, avoiding self-recursion. Restoration reinstates the saved implementation for reused mocks and restores the wrapped property for distinct spies. The actual native pre-existing lease and snapshot observers remain in the delegation chain.
- [Inferred] One AsyncLocalStorage frame per run keeps concurrent preparation entries separate; shared installation remains until the active count reaches zero. The extended existing case releases the second preparation before the first and asserts their differing claim outcomes in their respective entries.
- [Observed] The source retains rolling 32-entry and 32-step tails plus independent first-refusal records. The summary projects closed phase/predicate labels, counts, times, remaining deadline and boolean outcomes; captured product/history objects are deleted on settlement. The new forwarding assertions use private sentinel paths, body and error text and check their exclusion from the summary.
- [Inferred] The identity comparisons are a failure-only post-null projection of returned metadata, not an observation of the private guard that returned null. The `after-original-null` basis makes that limitation visible. It must be reported as Inferred, and cannot establish which private predicate actually failed. Its canonical digest limits match the current product identity comparison implementation. Successful preparations do not run this projection.
- [Inferred] Setting resumedDesignAudit for every successfully created resumed audit fixes the eligible scenario's diagnostic locator; it uses the actual audit parent/name path already used for interrupted recovery.
- [Observed] The patch changes this single test file, extends an existing forwarding case, and preserves the six test-declaration tokens in both base and frozen source; the four-scenario loop still expands the collected population to seven cases. Inspection of the complete patch found observer wiring, summaries and the audit diagnostic locator change, with existing runtime guards, assertion criteria, timeouts, deadlines and budgets retained.

Verification and limits

- [Observed] focused/result.json binds its result to the reviewed base/source and its focused.log digest matches the actual log. The retained run reports one test file passed, 3 tests passed and 4 skipped out of 7. The typecheck log contains the two errors above.
- [Observed] This review read the full patch, observer implementation, extended forwarding case, original cold helper, original stored-authority function, the relevant existing observer chains and audit-locator integration. It ran hash/base/patch consistency checks only; it did not edit repository source, index or commits, and did not run heavy tests or mutation checks.
- [Inferred] No additional blocking behavioral issue was identified within this reviewed scope. This is a source review judgment, not full conformance evidence.
- [Unknown] Actual native completion, native performance and observer overhead under the native workload remain unverified; four native cases were skipped. The focused tests and this review do not establish those outcomes.
