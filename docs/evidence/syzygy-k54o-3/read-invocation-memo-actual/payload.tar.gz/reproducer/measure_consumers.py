#!/usr/bin/env python3
"""Time exactly the four existing socket-fixture consumers once; no selftest."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.dont_write_bytecode = True
source_path = args.repo / 'scripts/check_spec_reconciliation.py'
commit = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=args.repo,
                        capture_output=True, text=True, check=True).stdout.strip()
source = source_path.read_bytes()
sys.path.insert(0, str(args.repo / 'scripts'))
spec = importlib.util.spec_from_file_location('reconciliation_measurement', source_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = {'sourceCommit': commit, 'sourcePath': 'scripts/check_spec_reconciliation.py',
          'sourceSha256': hashlib.sha256(source).hexdigest(),
          'measurementScriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'fixture': 'signoff-entry-socket', 'expectedConsumers': 4,
          'consumers': [], 'status': 'running',
          'scope': 'One scratch fixture; each existing consumer exactly once in original order. '
          'No clean-baseline run, additions, full selftest or benchmark sweep. Reverse cache '
          'scope starts cold, so these numbers do not reproduce all hosted selftest conditions.'}
def retain():
    args.output.write_text(json.dumps(report, indent=2) + '\n')
retain()
with tempfile.TemporaryDirectory(prefix='census-consumers-', dir=args.output.parent) as tmp:
    base, tree = Path(tmp) / 'base', Path(tmp) / 'signoff-entry-socket'
    module.scratch(args.repo, base)
    module._propose_candidate(base)
    module.shutil.copytree(base, tree)
    entry, setup, _kind, expected_class = module.ENTRY_KIND_CASES['signoff-entry-socket']
    path = tree / module.DECISIONS / entry
    setup(path, tree)
    methods = [('run', module.run), ('census', module.census),
               ('check_outcomes', lambda t: module.check_outcomes(t, module.Report())),
               ('check_census', lambda t: module.check_census(t, module.Report()))]
    with module._reverse_cache_scope():
        for label, method in methods:
            observed, calls = [], []
            def invoke(root):
                calls.append(1)
                try:
                    return method(root)
                except BaseException as error:
                    observed.append({'type': type(error).__name__,
                                     'filenameMatches': getattr(error, 'filename', None) is not None
                                     and Path(error.filename) == path})
                    raise
            started = time.perf_counter()
            with contextlib.redirect_stdout(io.StringIO()):
                failures = module._library_error(label, invoke, tree, path, expected_class)
            item = {'consumer': label, 'elapsedSeconds': time.perf_counter() - started,
                    'invocations': len(calls), 'expectedExceptionClass': expected_class.__name__,
                    'observed': observed, 'existingAssertionFailures': failures}
            report['consumers'].append(item)
            retain()
            print(json.dumps(item), flush=True)
            assert len(calls) == 1 and failures == [] and len(observed) == 1
report['status'] = 'complete'
report['executedConsumers'] = len(report['consumers'])
assert report['executedConsumers'] == 4
retain()
print('MEASUREMENT COMPLETE: four existing consumers, one invocation each', flush=True)
