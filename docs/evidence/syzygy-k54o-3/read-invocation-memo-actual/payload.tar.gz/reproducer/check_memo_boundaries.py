#!/usr/bin/env python3
"""Extract only memo helpers; no project imports or real checker execution."""
import ast
import contextlib
import copy
import functools
import hashlib
import json
from pathlib import Path
import sys
import types

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'check_spec_reconciliation.py'
source = SOURCE.read_text()

def environment(text):
    tree = ast.parse(text)
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name in {'_read_memo_scope', '_per_run', 'reference_signed'}]
    assert len(selected) == 3
    ns = dict(contextlib=contextlib, copy=copy, functools=functools, Path=Path,
              _RUN_MEMO=None, _SIGNED_MEMO=None, _FILES_OVERRIDE=None)
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<isolated-helpers>', 'exec'), ns)
    return ns

def tests(text):
    results = []
    prior_module = sys.modules.get('d10_supersession')
    def check(name, action):
        ns = environment(text)
        calls = []
        def d10_state(root):
            calls.append(str(root))
            return {'findings': []}
        module = types.ModuleType('d10_supersession')
        module.state = d10_state
        sys.modules['d10_supersession'] = module
        action(ns, module, d10_state, calls)
        results.append(name)
    def counting(ns):
        calls = []
        def binding(root, *args, **kwargs):
            calls.append(root)
            return {'findings': [len(calls)]}
        return ns['_per_run'](binding), calls
    def outside(n,*_):
        fn,c=counting(n); fn(Path('/a'));fn(Path('/a'));assert len(c)==2
    check('outside-scope-uncached',outside)
    def hit(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope'](): fn(Path('/a'));fn(Path('/a'));assert len(c)==1
    check('same-root-cached',hit)
    def deep(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope']():
            value=fn(Path('/a'));value['findings'].append('mutated');assert fn(Path('/a'))=={'findings':[1]}
    check('deepcopy-caller-mutation-isolated',deep)
    def roots(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope'](): fn(Path('/a'));fn(Path('/b'));assert len(c)==2
    check('different-root-separated',roots)
    def resolved(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope'](): fn(Path('/a/x/..'));fn(Path('/a'));assert len(c)==1
    check('resolved-root-shared',resolved)
    def functions(n,*_):
        def first(root):return 'first'
        def second(root):return 'second'
        a,b=n['_per_run'](first),n['_per_run'](second)
        with n['_read_memo_scope'](): assert a(Path('/a'))=='first' and b(Path('/a'))=='second'
    check('function-key-separated',functions)
    def kwargs(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope'](): fn(Path('/a'),flag=True);fn(Path('/a'),flag=True);assert len(c)==2
    check('keyword-calls-bypass',kwargs)
    def extra(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope'](): fn(Path('/a'),1);fn(Path('/a'),1);assert len(c)==2
    check('extra-positional-bypass',extra)
    def override(n,*_):
        fn,c=counting(n)
        with n['_read_memo_scope']():
            fn(Path('/a'));n['_FILES_OVERRIDE']=('fixture',{})
            fn(Path('/a'));fn(Path('/a'));assert len(c)==3
            n['_FILES_OVERRIDE']=None;assert fn(Path('/a'))=={'findings':[1]}
    check('files-override-bypasses-existing-cache',override)
    def nested(n,m,original,c):
        with n['_read_memo_scope']():
            mem=n['_RUN_MEMO'];signed=n['_SIGNED_MEMO'];state=m.state
            with n['_read_memo_scope'](): assert n['_RUN_MEMO'] is mem and n['_SIGNED_MEMO'] is signed and m.state is state
            assert n['_RUN_MEMO'] is mem and m.state is state
    check('nested-scope-reuses-and-retains-owner',nested)
    def restore(n,m,original,c):
        previous={};n['_SIGNED_MEMO']=previous
        with n['_read_memo_scope'](): assert n['_RUN_MEMO'] is not None and m.state is not original
        assert n['_RUN_MEMO'] is None and n['_SIGNED_MEMO'] is previous and m.state is original
    check('normal-return-restores-original-state',restore)
    def exception(n,m,original,c):
        error=RuntimeError('original')
        try:
            with n['_read_memo_scope'](): raise error
        except RuntimeError as got:assert got is error
        else:raise AssertionError('exception swallowed')
        assert n['_RUN_MEMO'] is None and n['_SIGNED_MEMO'] is None and m.state is original
    check('body-exception-propagates-and-restores',exception)
    def setup(n,m,original,c):
        error=RuntimeError('setup')
        def fail(fn):raise error
        n['_per_run']=fail
        try:
            with n['_read_memo_scope']():raise AssertionError('entered')
        except RuntimeError as got:assert got is error
        else:raise AssertionError('setup exception swallowed')
        assert n['_RUN_MEMO'] is None and n['_SIGNED_MEMO'] is None and m.state is original
    check('setup-exception-propagates-and-restores',setup)
    def fresh(n,*_):
        current=['before'];calls=[]
        def binding(root):calls.append(root);return current[0]
        fn=n['_per_run'](binding)
        with n['_read_memo_scope']():assert fn(Path('/a'))=='before'
        current[0]='after'
        with n['_read_memo_scope']():assert fn(Path('/a'))=='after'
        assert len(calls)==2
    check('fixture-mutation-between-invocations-seen',fresh)
    def failed(n,*_):
        calls=[];error=OSError('original')
        def binding(root):calls.append(root);raise error
        fn=n['_per_run'](binding)
        with n['_read_memo_scope']():
            for _ in range(2):
                try:fn(Path('/a'))
                except OSError as got:assert got is error
                else:raise AssertionError('exception swallowed')
        assert len(calls)==2
    check('binding-exception-not-cached',failed)
    def d10(n,m,original,c):
        with n['_read_memo_scope']():
            first=m.state(Path('/a'));first['findings'].append('mutated')
            assert m.state(Path('/a'))=={'findings':[]} and len(c)==1
        assert m.state is original
    check('d10-memo-deepcopy-and-restoration',d10)
    if prior_module is None:sys.modules.pop('d10_supersession',None)
    else:sys.modules['d10_supersession']=prior_module
    return results

names=tests(source)
mutants=[('nested-owner-guard', '    if _RUN_MEMO is not None:\n        yield\n        return\n', ''),
         ('override-bypass', ' or _FILES_OVERRIDE is not None', ''),
         ('discard-on-return', '        _SIGNED_MEMO, _RUN_MEMO = previous_signed, previous_run', '        pass  # mutant retains stale memos')]
mutant_results=[]
for name,old,new in mutants:
    assert source.count(old)==1
    try:tests(source.replace(old,new))
    except AssertionError:
        mutant_results.append(dict(name=name,old=old,new=new,result='killed'))
    else:raise AssertionError('survived '+name)
report=dict(candidateSourceSha256=hashlib.sha256(source.encode()).hexdigest(),harnessSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Only extracted _read_memo_scope, _per_run and reference_signed definitions. Synthetic roots/modules; no project imports, fixtures or subprocesses.',passed=len(names),expected=16,cases=names,mutants=mutant_results)
(HERE/'isolated-boundary-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
