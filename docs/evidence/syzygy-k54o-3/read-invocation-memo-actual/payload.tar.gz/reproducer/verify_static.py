#!/usr/bin/env python3
import ast
import difflib
import hashlib
import json
from pathlib import Path
P=Path(__file__).resolve().parent
old=(P/'original-check_spec_reconciliation.py').read_text()
new=(P/'check_spec_reconciliation.py').read_text()
oldtree,newtree=ast.parse(old),ast.parse(new)
a={n.name:n for n in oldtree.body if isinstance(n,ast.FunctionDef)}
b={n.name:n for n in newtree.body if isinstance(n,ast.FunctionDef)}
for name,node in a.items():
    if name=='run':continue
    before=ast.parse(ast.unparse(node)).body[0]
    after=ast.parse(ast.unparse(b[name])).body[0]
    if name in ('check_outcomes','census','check_census'):
        assert ast.unparse(after.decorator_list[-1])=='_read_memo_scope()'
        after.decorator_list.pop()
    assert ast.dump(before)==ast.dump(after),name
assert set(b)-set(a)=={'_read_memo_scope'}
assert ast.dump(ast.Module(body=[a['run'].body[1],*a['run'].body[7].body,a['run'].body[-1]],type_ignores=[]))==ast.dump(ast.Module(body=b['run'].body,type_ignores=[]))
assert [ast.unparse(d) for d in b['run'].decorator_list]==['_reverse_cache_scope()','_read_memo_scope()']
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/scripts/check_spec_reconciliation.py',tofile='b/scripts/check_spec_reconciliation.py'))
assert patch==(P/'census-memo.patch').read_text()
measurement=json.loads((P/'original-consumer-measurement.json').read_text())
raw=[json.loads(line) for line in (P/'original-consumer-measurement.log').read_text().splitlines() if line.startswith('{"consumer":')]
assert measurement['status']=='complete'
assert measurement['consumers']==raw
assert [r['consumer'] for r in raw]==['run','census','check_outcomes','check_census']
assert all(r['invocations']==1 and not r['existingAssertionFailures'] and r['observed']==[{'type':'OSError','filenameMatches':True}] for r in raw)
assert measurement['sourceSha256']==hashlib.sha256(old.encode()).hexdigest()
print(json.dumps({'unchangedOldFunctionsExcludingRun':len(a)-1,'runCheckOrderPreserved':True,'consumerPopulationJSONAndRawLog':len(raw),'invocationsPerConsumer':1,'candidateSha256':hashlib.sha256(new.encode()).hexdigest()}))
