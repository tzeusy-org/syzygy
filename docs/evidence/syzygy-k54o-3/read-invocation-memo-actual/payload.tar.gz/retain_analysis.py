#!/usr/bin/env python3
"""Retain actual logs and compare complete printed populations, without execution."""
import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

HERE=Path(__file__).resolve().parent
OUT=HERE/'retained'
OUT.mkdir(exist_ok=True)
BASE=Path('/home/orca/.tmp/f3-native-admission-fixes/census-memo-a303')
HOSTED=Path('/home/orca/.tmp/f3-native-admission-fixes/hosted-a303bc56e/reconciliation.log')
REPO=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
ACTUAL='2c6ff308aaa5d34d2b590ef06bd43ec87fb40948'
OLD='a303bc56e86f65e252aa13663827d46bdcc104f2'
SHA='65ab0c346b962ebe62bac592271181161d877aaaba5fe13e9e09f38c55f6ef51'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def archive(name,data):
    (OUT/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
    return {'file':name+'.gz','rawSha256':sha(data),'rawBytes':len(data),'gzipMtime':0}

# Retain the previously used parser as a dependency, rather than importing checker code.
parser_path=HERE/'printed_population_parser.py'
spec=importlib.util.spec_from_file_location('printed_population_parser',parser_path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
raw=(HERE/'canonical-selftest.log').read_bytes();oldraw=HOSTED.read_bytes()
actual,profiles,interleaved,lines=module.parse_log(raw)
old,oldprofiles,oldinterleaved,oldlines=module.parse_log(oldraw)
assert len(actual)==len(old)==679
assert len({w['id'] for w in actual})==len({w['id'] for w in old})==679
key=lambda rows:[(w['id'],w['expected'],w['outcome']) for w in rows]
assert key(actual)==key(old)
counts=collections.Counter(w['outcome'] for w in actual)
assert counts=={'killed':566,'held':113}
terminal=[line for line in lines if line.startswith('SELFTEST PASS:')]
assert len(terminal)==1
match=re.search(r'; (\d+) of (\d+) mutants killed .*; (\d+) of (\d+) controls held \(commit ([0-9a-f]+)\)',terminal[0])
assert match and list(map(int,match.groups()[:4]))==[566,566,113,113] and ACTUAL.startswith(match[5])
subject=json.loads((HERE/'subject.json').read_text());result=json.loads((HERE/'results.json').read_text())
assert subject['subject']==result['subject']==ACTUAL and result['terminal']
assert git('rev-parse',ACTUAL+'^{tree}').decode().strip()==subject['tree']
assert subject['sourceSha256']==SHA
selftest=next(r for r in result['results'] if r['phase']=='canonical-selftest')
assert selftest['exit']==0 and selftest['logSha256']==sha(raw)
command=next(args for phase,args in subject['commands'] if phase=='canonical-selftest')
assert command==['python3','-B','scripts/check_spec_reconciliation.py','--selftest']
source=git('show',ACTUAL+':scripts/check_spec_reconciliation.py');assert sha(source)==SHA
assert source==(BASE/'check_spec_reconciliation.py').read_bytes()
assert sha(git('show',OLD+':scripts/check_spec_reconciliation.py'))=='b0886d00ab1d17251a9bc0b0fc7cfa0485125a1d0b9768c0fab38fe90eb0dd67'
consumer=json.loads((HERE/'candidate-consumer-measurement.json').read_text());original=json.loads((BASE/'original-consumer-measurement.json').read_text())
for data,commit,source_sha in ((consumer,ACTUAL,SHA),(original,OLD,'b0886d00ab1d17251a9bc0b0fc7cfa0485125a1d0b9768c0fab38fe90eb0dd67')):
    assert data['status']=='complete' and data['sourceCommit']==commit and data['sourceSha256']==source_sha
    assert [r['consumer'] for r in data['consumers']]==['run','census','check_outcomes','check_census']
    assert data['executedConsumers']==data['expectedConsumers']==4
    assert all(r['invocations']==1 and not r['existingAssertionFailures'] and r['observed']==[{'type':'OSError','filenameMatches':True}] for r in data['consumers'])
synthetic=json.loads((BASE/'isolated-boundary-results.json').read_text())
assert synthetic['candidateSourceSha256']==SHA and synthetic['passed']==synthetic['expected']==len(synthetic['cases'])==16
assert len(synthetic['mutants'])==3 and all(m['result']=='killed' for m in synthetic['mutants'])
assert synthetic['harnessSha256']==sha((BASE/'check_memo_boundaries.py').read_bytes())
by={p['phase']:p for p in profiles};oldby={p['phase']:p for p in oldprofiles}
assert len(by)==len(profiles)==len(oldprofiles)==len(oldby)==57
selected={
 'subject':ACTUAL,'subjectTree':subject['tree'],'sourceSha256':SHA,'predecessor':OLD,
 'actualResult':selftest,'actualTerminal':terminal[0],
 'witnessCount':len(actual),'independentTokenParserCount':len(actual),'distinctIds':len({w['id'] for w in actual}),
 'terminalDenominator':{'mutantsKilled':566,'mutantsTotal':566,'controlsHeld':113,'controlsTotal':113,'sum':679},
 'outcomes':dict(counts),'orderedPrintedIdentityExpectationOutcomeEqualToHostedA303':True,
 'printedFailureDetailDifferences':sum(a['failedPrinted']!=b['failedPrinted'] for a,b in zip(actual,old)),
 'profileCount':len(profiles),'profiles':profiles,'hostedA303Profiles':oldprofiles,
 'actualInterleavedProfileFragments':interleaved,'hostedInterleavedProfileFragments':oldinterleaved,
 'selectedPhaseMs':{name:{'actualLocal':by[name]['elapsedMs'],'hostedA303':oldby[name]['elapsedMs']} for name in ('total','prefix-mutants','_entry_kind_cases')},
 'consumerMeasurements':[{'consumer':a['consumer'],'originalLocalSeconds':b['elapsedSeconds'],'candidateLocalSeconds':a['elapsedSeconds']} for a,b in zip(consumer['consumers'],original['consumers'])],
 'syntheticEvidence':{'cases':16,'exactMutantsKilled':3,'executionPreCommit':True,'actualCommittedSourceBytesIdentical':True},
 'limits':[
 'No --witnesses argument was passed. Complete printed identities, expectation labels and outcomes agree; original structured path/old/new fields were not emitted. Full old/new structured tuple parity is not claimed; final structured witness run remains needed.',
 'Local 304.2525486946106-second pass and hosted predecessor 616-second profile are different environments, not a controlled serial-versus-parallel speedup experiment. Hosted acceptance of the candidate, both seven-minute clocks, and complete final battery remain unproven by this packet.',
 'Synthetic 16-case/3-mutant evidence executed before actual subject commit, against exactly the same source bytes; this retention analysis did not rerun the checker or the synthetic checks.',
 'Printed failed-detail text is diagnostic and can differ by paths, ordering or versions; ordered identity/expectation/outcome population is the comparison claimed.',
 'Worker phase times overlap and must not be summed as wall time.']}
archives=[archive('canonical-selftest.log',raw),archive('hosted-a303-reconciliation.log',oldraw),archive('actual-printed-witnesses.json',(json.dumps(actual,indent=2)+'\n').encode()),archive('hosted-a303-printed-witnesses.json',(json.dumps(old,indent=2)+'\n').encode()),archive('committed-check_spec_reconciliation.py',source)]
(OUT/'selected-report.json').write_text(json.dumps(selected,indent=2)+'\n')
for name in ('subject.json','results.json','candidate-consumer-measurement.json'):
    (OUT/name).write_bytes((HERE/name).read_bytes())
if (HERE/'consumer-measurement.log').exists():archives.append(archive('consumer-measurement.log',(HERE/'consumer-measurement.log').read_bytes()))
# Preserve the exact rerunnable original benchmark and boundary/mutation packet.
repro=OUT/'reproducer';repro.mkdir(exist_ok=True)
for path in sorted(BASE.iterdir()):
    if path.is_file():(repro/path.name).write_bytes(path.read_bytes())
(OUT/'printed_population_parser.py').write_bytes(parser_path.read_bytes())
(OUT/'retain_analysis.py').write_bytes(Path(__file__).read_bytes())
(OUT/'README.md').write_text('''# Actual invocation-local memo retention

[Observed] Subject 2c6ff308aaa5d34d2b590ef06bd43ec87fb40948, source SHA-256 65ab0c346b962ebe62bac592271181161d877aaaba5fe13e9e09f38c55f6ef51. Parent-supplied result records terminal exit 0 in 304.2525486946106 seconds for the unchanged canonical --selftest command. Raw log hashes, commit/tree/source binding and both parsers were checked by retain_analysis.py without checker execution.

[Observed] The terminal reports 566/566 mutants and 113/113 controls. Profile JSON fragments were removed with JSONDecoder.raw_decode before row parsing, including concatenated fragments; independent token/delimiter parsing agrees with the regex parser on all 679 distinct IDs. Ordered printed identity, expectation and outcome triples equal the actual hosted a303 population. Full parsed populations and raw logs are retained as deterministic gzip.

[Observed] The original four-consumer measurement, script, raw output, exact candidate, patch, isolated 16-case boundary harness and three exact killed mutants are retained under reproducer. These checks predate the actual subject commit but source bytes exactly match it. No rerun occurred during retention.

[Unknown] This run omitted --witnesses, so structured path/old/new tuple parity is not established. A final structured witness run is still required. This local result does not prove hosted timing acceptance or a matched-environment speedup. See selected-report.json for actual profile values and provenance limitations. Primary source/index were not edited by this retention task.
''')
files={str(p.relative_to(OUT)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p != OUT/'manifest.json'}
manifest={'subject':ACTUAL,'tree':subject['tree'],'sourceSha256':SHA,'archives':archives,'files':files}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'directory':str(OUT),'manifestSha256':sha((OUT/'manifest.json').read_bytes()),'selected':{k:v for k,v in selected.items() if k in ('subject','witnessCount','independentTokenParserCount','outcomes','printedFailureDetailDifferences','selectedPhaseMs','consumerMeasurements','actualInterleavedProfileFragments','hostedInterleavedProfileFragments')}},indent=2))
