# Actual invocation-local memo retention

[Observed] Subject 2c6ff308aaa5d34d2b590ef06bd43ec87fb40948, source SHA-256 65ab0c346b962ebe62bac592271181161d877aaaba5fe13e9e09f38c55f6ef51. Parent-supplied result records terminal exit 0 in 304.2525486946106 seconds for the unchanged canonical --selftest command. Raw log hashes, commit/tree/source binding and both parsers were checked by retain_analysis.py without checker execution.

[Observed] The terminal reports 566/566 mutants and 113/113 controls. Profile JSON fragments were removed with JSONDecoder.raw_decode before row parsing, including concatenated fragments; independent token/delimiter parsing agrees with the regex parser on all 679 distinct IDs. Ordered printed identity, expectation and outcome triples equal the actual hosted a303 population. Full parsed populations and raw logs are retained as deterministic gzip.

[Observed] The original four-consumer measurement, script, raw output, exact candidate, patch, isolated 16-case boundary harness and three exact killed mutants are retained under reproducer. These checks predate the actual subject commit but source bytes exactly match it. No rerun occurred during retention.

[Unknown] This run omitted --witnesses, so structured path/old/new tuple parity is not established. A final structured witness run is still required. This local result does not prove hosted timing acceptance or a matched-environment speedup. See selected-report.json for actual profile values and provenance limitations. Primary source/index were not edited by this retention task.
