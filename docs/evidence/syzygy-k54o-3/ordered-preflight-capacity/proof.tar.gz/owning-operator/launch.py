from owning_verification import cli

if __name__ == "__main__":
    raise SystemExit(cli())
