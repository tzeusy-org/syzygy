"""Exact helper controls: private bytes/Python children plus read-only actual preflight; no product run."""
import ast, ctypes, datetime, hashlib, json, os, pathlib, re, signal, stat, subprocess, sys, tempfile, time

packet=pathlib.Path(__file__).resolve().parent
source_text=(packet/'owning_verification.py').read_text();tree=ast.parse(source_text)
root=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
config=json.loads((packet/'bindings.json').read_text());controls=[]
functions=[node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name!='cli']
scope=dict(globals());scope.update(ROOT=root,_deadline=time.monotonic()+120,__file__=str(packet/'owning_verification.py'),FILES={
    'unit':['packages/polaris-dossier/src/url-design-product.test.ts'],
    'integration':['packages/polaris-dossier/src/url-machine-peer.test.ts','packages/polaris-dossier/src/session-machine-transport.test.ts'],
})
exec(compile(ast.Module(body=functions,type_ignores=[]),'<exact owning helper definitions>','exec'),scope)
def passed(name):controls.append({'control':name,'passed':True})
def refuses(name,action):
    try:action()
    except RuntimeError as error:controls.append({'control':name,'passed':True,'error':str(error)})
    else:raise AssertionError(name+' unexpectedly admitted')

selected_file,other_file=scope['FILES']['integration']
case={'file':selected_file,'fullName':'own selected predicate','title':'selected predicate','ancestorTitles':['own']}
selected={key:case[key]for key in ['fullName','title','ancestorTitles']}
other={'fullName':'own other predicate','title':'other predicate','ancestorTitles':['own']}
def report(failed=False):
    return {'testResults':[
        {'name':str(root/selected_file),'message':'','assertionResults':[dict(selected,status='failed'if failed else 'passed',failureMessages=['AssertionError: expected own predicate\n at '+selected_file+':1:2']if failed else [])]},
        {'name':str(root/other_file),'message':'','assertionResults':[dict(other,status='pending'if failed else 'passed',failureMessages=[])]},
    ],'numTotalTests':2,'numPassedTests':0 if failed else 2,'numFailedTests':1 if failed else 0,'numPendingTests':1 if failed else 0,'success':not failed}
parse=scope['report_result'];baseline=parse(report(),'integration',0);assert baseline['accepted'];passed('unfiltered owning file population and all passed assertions admitted')
mutant={'case':case,'failureKind':'AssertionError','failureIncludes':['expected own predicate'],'logIncludes':['own predicate console cause']}
log='own predicate console cause';kwargs=dict(baseline=baseline['inventory'],mutant=mutant,log=log)
assert parse(report(True),'integration',1,**kwargs)['accepted'];passed('exact selected assertion stack and console cause kill admitted')
for diagnostic in ['Unhandled Errors','Unhandled Error','Unhandled Rejection','Uncaught Exception','Vitest caught 1 unhandled error during the test run.','\x1b[31mUnhandled\x1b[0m Errors']:
    refuses('intended kill plus unhandled console refused: '+repr(diagnostic),lambda diagnostic=diagnostic:parse(report(True),'integration',1,**dict(kwargs,log=log+'\n'+diagnostic)))
contradiction=report(True);contradiction.update(numPassedTests=1,numFailedTests=0)
refuses('assertion and aggregate contradiction refused',lambda:parse(contradiction,'integration',1,**kwargs))
missing=report();missing['testResults'].pop()
refuses('missing owning file refused',lambda:parse(missing,'integration',0))
setup=report(True);setup['testResults'][0]['message']='compiler/setup failure'
refuses('compiler/setup file error cannot establish kill',lambda:parse(setup,'integration',1,**kwargs))
generic=report(True);generic['testResults'][0]['assertionResults'][0]['failureMessages']=['Error: generic native/setup refusal\n at '+selected_file+':1:2']
refuses('generic nonzero failure cannot establish kill',lambda:parse(generic,'integration',1,**kwargs))
refuses('missing expected console cause refused',lambda:parse(report(True),'integration',1,**dict(kwargs,log='unrelated console')))
wrong_case=dict(mutant,case=dict(case,fullName='another selected predicate'))
refuses('wrong selected assertion identity refused',lambda:parse(report(True),'integration',1,**dict(kwargs,mutant=wrong_case)))
assert not parse(report(),'integration',1)['accepted'];passed('nonzero baseline with otherwise passing assertions remains unaccepted')

with tempfile.TemporaryDirectory(prefix='f3own-guard-',dir='/home/orca/.tmp')as temporary:
    private=pathlib.Path(temporary);scope['ROOT']=private
    relative='packages/polaris-dossier/src/owned.ts';target=private/relative;target.parent.mkdir(parents=True);target.write_bytes(b'original fixture\n');target.chmod(0o640)
    sample=target.stat();values={relative:{'body':target.read_bytes(),'mode':0o640,'uid':sample.st_uid,'gid':sample.st_gid,'backup':'inert backup','produced':None}}
    definition={'edits':[{'path':relative,'old':'original','new':'mutated'}]}
    scope['apply_mutant'](definition,values);assert target.read_bytes()==b'mutated fixture\n'
    target.chmod(0o600);scope['restore_sources'](values)
    assert target.read_bytes()==b'original fixture\n'and stat.S_IMODE(target.stat().st_mode)==0o640;passed('known exact mutation restores original bytes and mode')
    scope['apply_mutant'](definition,values);target.write_bytes(b'unrelated fixture edit\n')
    refuses('unknown source edit is retained instead of overwritten',lambda:scope['restore_sources'](values))
    assert target.read_bytes()==b'unrelated fixture edit\n'
    original=signal.pthread_sigmask(signal.SIG_BLOCK,set())
    call=next(node for node in ast.walk(tree)if isinstance(node,ast.Call)and isinstance(node.func,ast.Attribute)and isinstance(node.func.value,ast.Name)and node.func.value.id=='subprocess'and node.func.attr=='Popen')
    try:
        for extra in [set(),{signal.SIGINT}]:
            intended=original|extra;signal.pthread_sigmask(signal.SIG_SETMASK,intended)
            with(private/'child.log').open('wb')as stream:
                child=eval(compile(ast.Expression(body=call),'<exact owning Popen>','eval'),dict(subprocess=subprocess,command=[sys.executable,'-c','import json,signal;print(json.dumps(sorted(int(x)for x in signal.pthread_sigmask(signal.SIG_BLOCK,set()))))'],ROOT=private,environment=dict(os.environ),log=stream))
                assert child.wait(timeout=5)==0
            assert json.loads((private/'child.log').read_text())==sorted(int(sig)for sig in intended)
            passed('exact product launch preserves inherited mask '+repr(sorted(int(sig)for sig in intended)))
    finally:signal.pthread_sigmask(signal.SIG_SETMASK,original)
    scope['_deadline']=time.monotonic()+.1
    try:scope['metadata']([sys.executable,'-c','import time;time.sleep(5)'])
    except subprocess.TimeoutExpired:passed('metadata command has finite cooperative timeout')
    else:raise AssertionError('metadata timeout absent')
    scope['_deadline']=time.monotonic()-1
    refuses('expired phase refuses verification',lambda:scope['verify']([{'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}]))
    scope['_deadline']=time.monotonic()+5;owned={'forcedOwnedChildren':[{'pid':0,'signal':15}]}
    scope['drain'](owned);assert owned['noOwnedChildren']and owned['forcedOwnedChildren'];passed('final drain preserves earlier forced cleanup evidence')

scope.update(ROOT=root,_deadline=time.monotonic()+120)
scope['validate_config'](config,config['subject']);scope['source'](config)
cache=scope['tools'](config);scope['retained_runtime'](config)
passed('actual frozen source whole local/global tools and retained runtime read-only preflight')
scope['drain']({});passed('inert children joined')
print(json.dumps({'scope':'inert exact helpers and read-only actual metadata only; no operator CLI/product/native/build/typecheck/test','operatorSha256':hashlib.sha256(source_text.encode()).hexdigest(),'subject':config['subject'],'controls':controls,'passed':len(controls),'failed':0,'resultCache':cache},indent=2))
