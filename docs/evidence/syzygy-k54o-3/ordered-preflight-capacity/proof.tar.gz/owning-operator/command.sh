#!/bin/sh
set -eu
SYZYGY_POC_BROWSER=/home/orca/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/owning-verification-3bd8be9-R1/launch.py --subject 3bd8be92ad39d4d1cec8ee3e9ac3ad9b5fc8b6b3 --bindings /home/orca/.tmp/f3-native-admission-fixes/owning-verification-3bd8be9-R1/bindings.json --output /home/orca/.tmp/f3-native-admission-fixes/owning-verification-3bd8be9-1
