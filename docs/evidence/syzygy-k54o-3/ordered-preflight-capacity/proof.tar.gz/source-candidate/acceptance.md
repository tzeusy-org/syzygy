# Ordered product capacity recovery acceptance

[Observed] Source subject be93b69eea7fa965293e71aa780f9c69070b02ba, production bytes unchanged from failed original f51ba4 retry. Actual first retained preflight32 lease samples are85060ms then84986ms;85s mediation has not started. A-171 supplies same-delivery genuine replacement; A-240 retains30s preparation/55s effect/85s aggregate and145s product horizon. REQ-polaris-generation-035 requires finite expiring capacity, refresh against actual charged work, and original deadline/ordinary caps.

[Inferred] Accepted correction: operation-local factory/pair, at most two prepare-to-fresh-current passes before protected store admission, at most one genuine replacement or pending-replacement join in that preflight sequence. Existing effect-current refresh behavior remains unchanged; this is not a claim of a new global one-refresh limit across all later callbacks. No earlier pinned horizon, authority verdict cache, cap/deadline increase, or omitted check.

| Trigger | Required observable result |
| --- | --- |
| Ample current lease | First preparation/current succeeds; no reproduction; effect once. |
|85060ms falls to84986ms before first final guard | No effect at the failed guard; one genuine same-delivery replacement and complete proof, then fresh now+85000 guard; effect only if it passes. |
| First preparation already renewed, then loses capacity | Refuse rather than obtain another preflight replacement/join. |
| Initial prepare false or throws | Immediate refusal; no second preparation or protected effect. |
| Second final current fails | Refuse after two passes; no retry loop or effect. |
| Processing, policy, peer, run, claim or transport authority withdrawn | Refuse; no recovered grant or effect. |
| Product retired, Unknown, changed, failed proof/replacement, or insufficient new lifetime | Existing fail-closed result remains; no retry converts it to current. |
| Original transport/caller/run bound expires during re-preparation | Same original absolute bound refuses; no deadline reset. |
| Separate or concurrent mediations | Each obtains one own pair/allowance; retries reuse their own pair. No shared last-prepared state or borrowed allowance. |
| After admission | Existing fresh authority/release checks, tighter bounds and effect-current refresh behavior remain unchanged. |

Regression evidence must use literal boundary clocks and actual owning mediation in addition to product/transport seams. Existing semantic assertions stay. Review states exact test declaration delta; mutants name exact old/new fragments and expected assertion, with source restoration checked. A passing scoped test is separate from original genuine recovery and full acceptance. No product run has occurred for this proposed correction.
