# Ordered preflight moving-horizon candidate R1

[Observed] This outside-only packet binds clean source be93b69eea7fa965293e71aa780f9c69070b02ba. The primary checkout was read, not changed. No build, typecheck, test, native command, fixture or recovery run was executed. This is an unreviewed candidate, not acceptance evidence.

[Observed] The failed original ordinary recovery had a retained first preflight refusal at inference32: accepted preparation sampled85060ms remaining; its subsequent current check sampled84986ms. The mediation’s85s protected-store timer had not started. The structured record is ordinary-recovery-f51ba4-diagnosis-1/failure-record.json (SHA dc192b39708cffca47b605bcd523a307dbd83fb12be5f634529f18f29621c8a4). The independently read diagnosis and original failure remain immutable.

## Governing scope

[Observed] A-171 permits “one shared same-delivery reproduction before the upcoming bounded machine effect” when the exact current product passes its full proof and lacks sufficient lease. Its following clauses preserve the original receipt, complete replacement proof, fresh lease and unchanged store effect/release checks; changed, retired and Unknown products refuse. The owning checkUrlOrderedProductCurrent comment assigns same-delivery verification and shared pending capacity to the refresh port. It does not define a global lifetime counter over all later expiry checks.

[Observed] A-240 specifies preparation30000ms, effect55000ms, aggregate85000ms and ordered product145000ms, retaining tighter caller/run/record bounds. REQ-polaris-generation-035 states: “Reserve finite expiring capacity for the remaining supported path and refresh against actual charged work at each admitted step without extending the recorded original deadline or lowering the ordinary role caps.” Source references and exact bytes are bound in governing-bindings.json. acceptance.md is the root’s exact supplied acceptance matrix.

## Candidate behavior

[Inferred] The candidate closes this orchestration gap by giving each mediation one forOperation() pair. The peer runs preparation then a fresh current check. Only successful preparation followed by false current may enter one additional preparation-to-current pass. Initial false or thrown preparation refuses immediately. The peer checks its original deadline after preparation and before and after re-preparation. No store admission or effect occurs until the final current guard passes.

[Inferred] The ordered producer creates a pair-local renewal allowance. It is consumed immediately before requesting an actual replacement or joining the existing pending replacement; ample fast paths leave it unused. The same pair survives both preflight passes. A pair whose first preparation already renewed cannot renew again in this preflight sequence. Separate/concurrent pairs own separate allowances, including when joining one shared pending renewal. The existing effect-current expiry refresh behavior is unchanged: this introduces no whole-mediation global renewal counter.

[Observed] The transport wraps the selected pair and retains its existing absolute connection deadline. All socket, stream and clock guards remain. The existing relay shallow-copy freeze preserves the new forOperation field. No compatibility interface, new module, timer, registry, AsyncLocalStorage scope, cap, native C change or cached authority verdict is introduced. Moving effectHorizon remains min(original run deadline, fresh now + nativeMediationMilliseconds).

## Files and test scope

[Observed] Seven changed files: three production TypeScript modules (peer, transport, ordered-attempt) and four existing test files (product, peer, transport, composed). Full originals/candidates and a directly applicable candidate.patch are included. Native C and the native-policy owning test are separately bound unchanged. All known preflight reference files are enumerated in reference-sweep.json.

[Observed] Two new physical test declarations: product factory allowance behavior and native peer pre-effect refusal. Existing cases are extended for native ordinary/ordered-peer selection and transport disconnect/original-deadline cases. The independent static census is81→83 declarations across the four files. [Inferred] Literal parameter populations imply +7 expanded cases; actual runner counts remain unmeasured. Product loops cover nine scenarios within its one new case. Two declarations are justified because the old product tests did not own a per-operation allowance and the old native lifecycle case did not enter ordered preflight; an adapter mock alone cannot establish real peer/store behavior.

[Observed] The peer fixture compiles a genuine ordinary launcher and a nominal ordered peer profile from one matching design binding. The synthetic MCP script/ordinary launcher remain unchanged, while actual peer capture, protected lifecycle publication and store mediation select the nominal ordered profile. No profile brand is forged and no launch check is weakened. This proves the real ordered peer/store branch, not full ordered launch admission. The original genuine seven-case integration file remains the latter proof; its trace adapter alone is migrated and its assertions, limits and seven-case selection population are unchanged.

[Inferred] Tests target ample capacity; literal85060→84986 loss; first preparation already renewed; second current still false; initial prepare false/throw; withdrawn processing/peer authority; retired/changed products; separate/concurrent/joining pairs; ordinary-profile rejection; original transport/run expiry; final protected lifecycle revocation. Existing Unknown/failed proof/rejected replacement checks remain. No assertion is replaced with a pass surrogate.

## Verification and remaining evidence

[Observed] Source-only checks: clean exact subject; each original equals its Git blob and primary bytes; seven-file population equality; independent scripted/SHA256SUMS digest checks; two independent declaration censuses; unique old fragments for six proposed production mutants; git apply --check against the outside original copies; whitespace diff check. No product parser or test was run. Exact source populations and observations are retained in JSON.

[Inferred] mutant-proposals.json supplies six exact old/new fragments, expected selected source-derived full names and assertion-message signatures: lost-gap, blind-retry, reset-pair, second-renewal, suppress-fresh-current and extend-transport-deadline. They are proposals, not killed-mutant evidence. Selection identity and actual failure signatures must be checked by the reviewed owning operator, with original bytes restored before subsequent work.

[Unknown] Type correctness, focused test results, mutant detection, actual runtime build closure, original ordinary recovery and full acceptance await independent review and authorized execution. The correction may refuse if a replacement remains too short or any authority/deadline is lost. It does not guarantee completion under the unchanged resource caps. Existing composed trace fields still describe their latest sampled preparation/current call; they are not a complete multi-pass timing ledger.
