# Actual ordinary3bd8be failure assessment

[Observed] Subject3bd8be92ad39d4d1cec8ee3e9ac3ad9b5fc8b6b3. Original ordinary case failed529661.431306ms, before its600000ms bound; the protocol completed with1failed/6selection-skipped/7, complete=true and accepted=false. Outer cleanup has no forced children/errors and reports no owned children, source/tools/runtime unchanged. This diagnosis changes no product source and executes no product/native/fixture/recovery command.

[Observed] The earliest retained failure in the failing causal branch is **broker invocation4, dossier_step, host-action rejected** at observer-relative461373.404ms. The later verdict-staged append’s final attempt-current machine-effect refusal is downstream. The initiating private exception/predicate is **Unknown**. The record supports neither an initiating policy/lease-gap failure nor a sole30-second wall-time attribution.

## What advanced past the predecessor

[Observed] The record declares36 inference mediations, retaining12 (ordinals1–4 and29–36;24 omitted); all12 retained mediations accepted. Seven retained preparation/final-current pairs accepted. There is no firstRefusedInference, firstRefusedCurrent or firstRefusedHostCurrent property in the emitted inference object; their source latches are separate from bounded trace retention (url-run-composed.test.ts1367,1708,1873). This supports “no refused inference latched in this snapshot,” without asserting completed coverage of the24 omitted traces.

[Observed] The old f51 first refusal sampled85060→84986ms before native admission. This run’s retained inference32 instead has112020→111944ms and accepts. Inference34 has86611→86529ms and accepts. Inference35’s preparation samples81065/80839ms and lasts7733.857ms; its final current samples137966ms and mediation accepts. [Inferred] Source checkUrlOrderedProductCurrent and the renewed lease support successful replacement/join during preparation35. They do not identify a second preparation pass: tracePreflight assigns step[key] on every invocation and overwrites the previous pass (composed test1689–1700). Exact two-pass multiplicity remains Unknown; the earlier gap is not the observed initiating refusal here.

[Observed] The actual production port is operation-local, selects one pair and retains it for the bounded retry (peer474–511; ordered-attempt104–121,216–220; transport185–194). Existing effect-current renewal behavior remains unchanged. This diagnosis claims neither complete genuine recovery nor that the new second pass executed.

## Failure chronology and clocks

[Observed] The observer begins at absolute monotonic66263.136888ms. Most resumeDiagnostic stamps subtract that origin; base-audit callbacks and firstRuntimeFailure.atMs already use absolute monotonic time. first-refusal.json retains both forms. Rounded observer stamps cannot resolve sub-millisecond ordering between independently observed callbacks.

| Event | Observer-relative ms | Absolute monotonic ms |
| --- | ---: | ---: |
| Broker4 invocation starts |428584.924|494848.060888|
| Broker4 host action starts |430717.131|496980.267888|
| verdict-staged append starts |457161.008|523424.144888|
| Host action rejects |461373.404|527636.540888|
| Nested attempt-current machine-effect refuses |461445.671|527708.807888|
| verdict-staged append rejects |461446.242|527709.378888|
| Broker mediation refuses |461457.641|527720.777888|
| Broker fault recorded |461457.860|527720.996888|
| Runtime transport-unavailable |461519.062289|527782.199177|
| Launcher final confirm refuses |461519.133|527782.269888|
| Role inspection-failed terminal |461535.983|527799.119888|
| Fixture failure cleanup starts |469029.655656|535292.792544|

[Observed] The failing append’s fifth attempt-current call first accepts runtime authority, then machine effect at461318.046→461371.892ms. Its next sample wait461372.689→461445.656 spans the host-action rejection. Immediately afterward, its second machine-effect check refuses. [Inferred] This is consistent with the operation rejecting while an awaited descendant remains active: transport203 revokes the async effect scope in finally after effect rejection; later descendant checks must refuse. The audit guard refusal does not prove it initiated the host failure72.267ms earlier.

[Observed] The broker then poisons host health. url-run-sessions306–322 checks host health and records transport-unavailable when it becomes false. The final launcher sample1144 accepts process/storage/verify, then refuses confirm in about51.702ms overall, within its5000ms inspection bound. It is a downstream authority refusal, not a process/storage timeout. Cleanup starts7656.251656ms after the host-action rejection and cannot explain that earlier rejection.

## Remaining initiating candidates

[Observed] The per-operation envelope is CPU64000000µs and wall30000ms (ordered-attempt350). openOperation183–208 checks direct wall/CPU and ledger guards; waitOperation210–216 independently races the operation against its original absolute expiry. issueReply opens its tool at485, nests audit work while staging the genuine verdict, then appends verdict-staged at515. All original bounds remain.

[Observed] Host-action spans30656.273ms. Broker entry→first-refused-stage snapshots differ by84401185µs of cumulative work CPU. These are **not isolated tool duration/CPU measurements**: tool admission is later than host-action entry; entry/refusal snapshots use the ledger’s last sampled cumulative values and workSnapshot samples no clocks (composed test1562–1565, session546). Nested parent/audit checks are inclusive comparisons against baselines, not evidence of additive double charging. Exact tool CPU/wall baselines are unretained.

[Observed] The first-refused-stage work snapshot says stopped/reason=retired. Work-budget.stop preserves an already-stopped reason (work-budget251–254), but openOperation.check can throw on its own wall/CPU predicate BEFORE calling ledger.current. The operation timer also calls controller stop, which retires the work ledger; serialize catches other private errors and also retires it (session154–178,197–216). Therefore retired does not distinguish timer, direct operation CPU/wall check, or another private exception.

[Unknown] Which of those predicates initiated refusal. Both timing and broader cumulative CPU make operation-envelope exhaustion plausible, but neither identifies the exact first cause. No cap increase, accounting rewrite or product optimization is justified by these snapshots alone.

[Observed] The verdict-staged append spans4285.234ms:4212.396ms overlaps the live host-action interval and72.838ms follows its rejection. Its first four attempt-current calls accept; its fifth refuses after the host action has already rejected. These nested timings overlap; do not add them as an exclusive partition or charge the entire append to the live host operation. A retained audit kind is historical metadata, not proof that an acknowledged final verdict or terminal eligibility completed.

## Evidence coverage and next decision

[Observed] All eight raw execution files were independently hashed; all seven terminal-listed raw files match both recorded bytes/digests. The root-derived failure record equals the first selected Error JSON in vitest.json. assessment-bindings.json binds those files plus15 exact committed source files using hashlib and independent sha256sum. The full derived JSON was walked:234 array denominators and a non-deduplicated outcome census are retained. Cloned first/latest summaries are not independent events.

[Observed] Other recorded populations:8 connections/open/accept/capture/authorize;1144 verification accepts,1143 confirmation accepts/1 refusal;4 broker invocations, only first-stage summary and latest/full first-refusal4 retained (2/3 not retained);16 relay-current and16 host-current traces accepted; product operations32 retained/339 omitted with per-species totals retained; base-audit callbacks32/5256 and32/1976, with separate first-refusal latches. Initial7 bootstrap phases and4 role preparations accept. Resumed policy/claim withdrawal refusals are intentional negative controls. The retained store-refusal population has0 entries/0 omitted. The84 relay observations are21 each of allowed/send-attempt/send-outcome/response-admitted; they do not prove final tool reply/terminal completion. No first-reproduction-refusal field is retained; that is an evidence limitation, not a universal success claim.

[Inferred] Minimal next decision: review a failure matrix for the existing final-tool operation envelope before any further source candidate or recovery run. If a diagnostic is authorized, retain only the **first initiating operation rejection** at the owning direct check/timer/catch boundary, with operation kind, original expiry, exact admission wall/CPU baselines, measured current values and reason before generic retirement; distinguish parent/nested inclusive scope. Existing records already establish the downstream cascade. Do not repeat a broad profiler or alter600/30/64m/85s limits, fresh guards or authority checks merely to obtain another generic transport failure. No code is drafted here.
