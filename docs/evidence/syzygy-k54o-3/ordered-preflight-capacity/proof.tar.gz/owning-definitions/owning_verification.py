"""DEFINITIONS ONLY: no top-level invocation; needs final frozen candidate bindings and review."""
import argparse, ctypes, datetime, hashlib, json, os, pathlib, re, signal, stat, subprocess, tempfile, time
_deadline = None
ROOT=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
NODE='/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM='/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
FILES={
    'unit': ['packages/polaris-dossier/src/url-design-product.test.ts'],
    'integration': ['packages/polaris-dossier/src/url-machine-peer.test.ts', 'packages/polaris-dossier/src/session-machine-transport.test.ts'],
}
BLOCKED=['NODE_OPTIONS','VITEST_MAX_THREADS','VITEST_MIN_THREADS','VITEST_MAX_FORKS','VITEST_MIN_FORKS','SYZYGY_COMPOSED_RETAIN','SYZYGY_F3_NATIVE_EVIDENCE_FILE']

def require(ok, message):
    if not ok: raise RuntimeError(message)

def remaining():
    value = _deadline-time.monotonic() if _deadline is not None else 0
    require(value>0,'operator phase deadline expired')
    return value

def metadata(command,**kwargs):
    return subprocess.check_output(command,timeout=min(remaining(),30),**kwargs)

def read_bytes(path):
    chunks=[]
    with path.open('rb')as stream:
        while True:
            remaining();chunk=stream.read(1_048_576)
            if not chunk:break
            chunks.append(chunk)
    remaining();return b''.join(chunks)

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb')as stream:
        while True:
            remaining();chunk=stream.read(1_048_576)
            if not chunk:break
            digest.update(chunk)
    remaining();return digest.hexdigest()

def independent_hashes(rows):
    for offset in range(0,len(rows),256):
        batch=rows[offset:offset+256]
        output=metadata(['/usr/bin/sha256sum','--zero','--',*[row['path']for row in batch]])
        entries=output.split(b'\0');require(entries[-1]==b''and len(entries)-1==len(batch),'independent hash population mismatch')
        for entry,row in zip(entries[:-1],batch):
            digest,name=entry.split(b'  ',1)
            require(name.decode()==row['path']and digest.decode()==row['sha256'],'independent hash drift: '+row['path'])

def children():
    text = pathlib.Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text()
    return [int(pid) for pid in text.split()]

def drain(record):
    """Reap only our children. Signal a still-owned child only through its pidfd."""
    reaped = record.setdefault('ownedDescendantsReaped', [])
    forced = record.setdefault('forcedOwnedChildren', [])
    record.update(noOwnedChildren=False, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
    began = time.monotonic()
    while True:
        while True:
            try: pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                record.update(noOwnedChildren=True, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
                return
            if not pid: break
            reaped.append({'pid': pid, 'status': status})
        elapsed = time.monotonic() - began
        if elapsed > 20 or (_deadline is not None and time.monotonic()>=_deadline): raise RuntimeError('owned drain deadline expired; private TMP retained')
        if elapsed > 10:
            for pid in children():
                try:
                    fd = os.pidfd_open(pid)
                    try:
                        # A direct owned child cannot recycle its PID before our waitpid.
                        if pid in children():
                            sig = signal.SIGTERM if elapsed < 15 else signal.SIGKILL
                            signal.pidfd_send_signal(fd, sig)
                            forced.append({'pid': pid, 'signal': int(sig)})
                    finally: os.close(fd)
                except ProcessLookupError: pass
        time.sleep(.05)

def stop_leader(child):
    # Only kill the new session while its original leader remains unreaped.
    if child is not None and child.returncode is None:
        try: os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try: child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            child.wait(timeout=5)

def git(*args):
    return metadata(['/usr/bin/git',*args],cwd=ROOT).decode().strip()

def source(config):
    require(git('rev-parse','HEAD')==config['subject'] and git('rev-parse','HEAD^{tree}')==config['tree'],'subject/tree drift')
    require(not git('status','--porcelain','--untracked-files=all'),'ordinary observer requires clean committed source')

def verify(rows):
    unique={}
    for row in rows:
        remaining();previous=unique.setdefault(row['path'],row)
        require((previous['bytes'],previous['sha256'])==(row['bytes'],row['sha256']),'conflicting binding')
    for row in unique.values():
        remaining();path=pathlib.Path(row['path'])
        require(path.stat().st_size==row['bytes']and sha(path)==row['sha256'],'binding drift: '+str(path))
    independent_hashes(list(unique.values()))

def installed_tree(config,*,global_npm=False):
    base=pathlib.Path(config['globalNpmRoot'])if global_npm else ROOT/'node_modules';sample=base.lstat();require(stat.S_ISDIR(sample.st_mode),'installed root is not an ordinary directory')
    rows=[{'path':'.','kind':'directory','mode':stat.S_IMODE(sample.st_mode),'uid':sample.st_uid,'gid':sample.st_gid}];files=[];cache=None;pending=[base]
    while pending:
        directory=pending.pop();remaining()
        with os.scandir(directory)as scan: entries=sorted(scan,key=lambda item:item.name)
        for entry in entries:
            remaining();path=pathlib.Path(entry.path);sample=entry.stat(follow_symlinks=False)
            relative=str(path.relative_to(base));row={'path':relative,'mode':stat.S_IMODE(sample.st_mode),'uid':sample.st_uid,'gid':sample.st_gid}
            if stat.S_ISLNK(sample.st_mode):
                row.update(kind='symlink',target=os.readlink(path),resolved=str(path.resolve(strict=True)))
            elif stat.S_ISDIR(sample.st_mode):row['kind']='directory';pending.append(path)
            elif stat.S_ISREG(sample.st_mode):
                row['kind']='file'
                if not global_npm and relative==config['mutableResultCachePath']:
                    row['mutableResultCache']=True;cache={'path':str(path),'bytes':sample.st_size,'sha256':sha(path),'uid':sample.st_uid,'mode':stat.S_IMODE(sample.st_mode)}
                else:
                    row.update(bytes=sample.st_size,sha256=sha(path));files.append(dict(row,path=str(path)))
            else:raise RuntimeError('unexpected installed special file: '+relative)
            rows.append(row)
    rows.sort(key=lambda row:row['path'])
    require(rows==config['globalNpmTree'if global_npm else 'installedTree'],'complete '+('global npm 'if global_npm else '')+'installed file/directory/symlink population drift')
    require(global_npm or cache is not None,'known result cache missing or changed type')
    independent_hashes(files)
    return cache

def tools(config):
    installed_tree(config,global_npm=True)
    cache=installed_tree(config)
    verify(config['sourceAndTools']+config['nativeToolsAndHeaders']+[config['browser']]+config['workspacePackages'])
    verify([dict(row,path=str(ROOT/row['path']))for row in config['runtimeInputs']])
    return cache

def interrupted(sig,frame):
    raise InterruptedError('operator signal '+str(sig))

def retained_runtime(config):
    """Attest retained bytes, never describe them as newly built from this subject."""
    rows=config['retainedRuntime']
    require(rows and len({row['path']for row in rows})==len(rows),'exact retained-runtime population required')
    require(all(pathlib.Path(row['path']).is_absolute()and pathlib.Path(row['path']).is_relative_to(ROOT)for row in rows),'retained runtime must be inside bound repository')
    verify(rows)
    return rows

def repo_file(relative):
    path=pathlib.PurePosixPath(relative)
    require(not path.is_absolute()and '..'not in path.parts and str(path)==relative,'unsafe repository path')
    result=ROOT/relative
    require(result.resolve(strict=True)==result and stat.S_ISREG(result.lstat().st_mode),'target must be a regular non-symlink source file')
    return result

def report_result(report,project,exit_code,*,baseline=None,mutant=None,log=''):
    results=report['testResults'];by_file={}
    for result in results:
        path=pathlib.Path(result['name'])
        relative=str(path.relative_to(ROOT))if path.is_absolute()else str(path)
        require(relative not in by_file,'duplicate report file')
        require(not result.get('message'),'file-level compiler/setup failure')
        assertions=result['assertionResults'];require(assertions,'empty owning file report')
        identities=[(a['fullName'],a['title'],tuple(a['ancestorTitles']))for a in assertions]
        require(len(identities)==len(set(identities)),'duplicate assertion identity')
        by_file[relative]=assertions
    require(set(by_file)==set(FILES[project]),'exact owning report file population required')
    require(not report.get('numRuntimeErrorTestSuites',0)and not report.get('unhandledErrors',[]),'runtime/setup errors cannot establish assertion outcome')
    assertions=[a for group in by_file.values()for a in group]
    counts={status:sum(a['status']==status for a in assertions)for status in ['passed','failed','pending','skipped']}
    require(sum(counts.values())==len(assertions),'unknown assertion status')
    require(report['numTotalTests']==len(assertions)and report['numPassedTests']==counts['passed']and report['numFailedTests']==counts['failed']and report['numPendingTests']==counts['pending']+counts['skipped'],'aggregate/status contradiction')
    require(type(report['success'])is bool,'unknown report success')
    inventory={name:[{key:a[key]for key in ['fullName','title','ancestorTitles']}for a in group]for name,group in by_file.items()}
    if baseline is not None:
        require(inventory==baseline,'mutant assertion inventory differs from baseline')
    if mutant is None:
        accepted=exit_code==0 and report['success']and counts['passed']==len(assertions)
    else:
        case=mutant['case'];selected=[a for name,group in by_file.items()for a in group if name==case['file']and all(a[key]==case[key]for key in ['fullName','title','ancestorTitles'])]
        require(len(selected)==1,'intended mutant assertion not uniquely identified')
        selected=selected[0]
        require(selected['status']=='failed'and counts['failed']==1 and counts['passed']==0 and counts['pending']+counts['skipped']==len(assertions)-1,'mutant must fail intended assertion and selection-skip every other case')
        failures=selected['failureMessages'];require(isinstance(failures,list)and failures and all(isinstance(item,str)for item in failures),'missing intended assertion failure stack')
        failure='\n'.join(failures)
        require(re.search(re.escape(case['file'])+r':\d+(?::\d+)?',failure),'intended assertion stack lacks owning source location')
        require(mutant['failureIncludes']and all(part in failure for part in mutant['failureIncludes']),'intended assertion signature absent')
        require(mutant['logIncludes']and all(part in log for part in mutant['logIncludes']),'expected console cause absent')
        if mutant['failureKind']=='AssertionError':
            require('AssertionError' in failure,'non-assertion failure cannot count as kill')
        else:
            require(mutant['failureKind']=='VITEST_REJECTS'and 'Error' in failure and mutant['allowedErrorSignature']and mutant['allowedErrorSignature']in failure,'unbound non-AssertionError failure')
        accepted=exit_code==1 and report['success']is False
    return {'populationValid':True,'accepted':bool(accepted),'counts':counts,'assertionCount':len(assertions),'fileCounts':{name:len(group)for name,group in by_file.items()},'inventory':inventory,'assertionsByFile':by_file}


def snapshots(config,out):
    values={};backup=out/'source-backups';backup.mkdir()
    for relative in sorted({edit['path']for item in config['mutants']for edit in item['edits']}):
        path=repo_file(relative);sample=path.stat();body=read_bytes(path)
        require(metadata(['/usr/bin/git','cat-file','blob','HEAD:'+relative],cwd=ROOT)==body,'mutant target differs from committed source')
        destination=backup/(str(len(values))+'.bin');destination.write_bytes(body);destination.chmod(0o600)
        values[relative]={'body':body,'mode':stat.S_IMODE(sample.st_mode),'uid':sample.st_uid,'gid':sample.st_gid,'backup':str(destination),'produced':None}
    for item in config['mutants']:
        for edit in item['edits']:
            require(values[edit['path']]['body'].count(edit['old'].encode('utf-8'))==1,'mutant old fragment must occur exactly once in committed source')
    mapping=[dict(path=relative,bytes=len(value['body']),sha256=hashlib.sha256(value['body']).hexdigest(),**{key:value[key]for key in ['mode','uid','gid','backup']})for relative,value in values.items()]
    (out/'source-backups.json').write_text(json.dumps(mapping,indent=2)+'\n')
    return values

def validate_config(config,subject):
    require(config['subject']==subject and re.fullmatch('[0-9a-f]{40}',subject)and re.fullmatch('[0-9a-f]{40}',config['tree']),'exact committed subject/tree required')
    require(sha(pathlib.Path(__file__))==config['operatorSha256'],'definitions runner differs from frozen binding')
    mutants=config['mutants'];require(1<=len(mutants)<=16,'bounded nonempty mutant population required')
    ids=[item['id']for item in mutants]
    require(len(set(ids))==len(ids)and all(re.fullmatch('[a-z0-9][a-z0-9-]{0,63}',name)for name in ids),'unique safe mutant ids required')
    for item in mutants:
        require(item['project']in FILES and 0<item['seconds']<=300,'bounded ordinary mutant project required')
        require(item['case']['file']in FILES[item['project']],'mutant case outside owning project files')
        require(1<=len(item['edits'])<=4 and len({edit['path']for edit in item['edits']})==len(item['edits']),'bounded unique mutant edits required')
        for edit in item['edits']:
            require(edit['path'].startswith('packages/polaris-dossier/src/')and edit['path'].endswith('.ts')and '.test'not in edit['path'],'mutants may edit production TypeScript only')
            require(isinstance(edit['old'],str)and isinstance(edit['new'],str)and 0<len(edit['old'])<=16384 and len(edit['new'])<=16384 and edit['old']!=edit['new'],'bounded distinct literal mutation fragments required')
        for key in ['failureIncludes','logIncludes']:
            require(isinstance(item[key],list)and item[key]and all(isinstance(part,str)and part for part in item[key]),'explicit nonempty failure/log signature required')
        require(item['failureKind']in ['AssertionError','VITEST_REJECTS'],'narrow mutation failure kind required')
        if item['failureKind']=='VITEST_REJECTS':
            require(isinstance(item['allowedErrorSignature'],str)and len(item['allowedErrorSignature'])>=24,'narrow explicit VITEST_REJECTS Error signature required')

def replace_owned(path,body,mode):
    temporary=None
    try:
        original=path.stat()
        fd,name=tempfile.mkstemp(prefix='.f3-mut-',dir=path.parent);temporary=pathlib.Path(name)
        with os.fdopen(fd,'wb')as stream:
            os.fchown(stream.fileno(),original.st_uid,original.st_gid);stream.write(body)
        temporary.chmod(mode);os.replace(temporary,path);temporary=None
    finally:
        if temporary is not None:temporary.unlink()

def apply_mutant(item,values):
    for edit in item['edits']:
        value=values[edit['path']];path=repo_file(edit['path'])
        require(read_bytes(path)==value['body']and stat.S_IMODE(path.stat().st_mode)==value['mode'],'refuse mutation on drifted source')
        body=value['body'].replace(edit['old'].encode('utf-8'),edit['new'].encode('utf-8'),1)
        value['produced']=body
        replace_owned(path,body,value['mode'])

def restore_sources(values):
    errors=[]
    for relative,value in values.items():
        try:
            path=repo_file(relative);sample=path.stat();body=read_bytes(path)
            require((sample.st_uid,sample.st_gid)==(value['uid'],value['gid']),'source ownership drift; retained backup only')
            require(body==value['body']or(value['produced']is not None and body==value['produced']),'unknown source edit; refuse overwrite; retained backup only')
            if body!=value['body']or stat.S_IMODE(sample.st_mode)!=value['mode']:
                replace_owned(path,value['body'],value['mode'])
            require(read_bytes(path)==value['body']and stat.S_IMODE(path.stat().st_mode)==value['mode'],'source restoration failed')
            value['produced']=None
        except BaseException as error:errors.append({'path':relative,'type':type(error).__name__,'message':str(error)})
    require(not errors,'source restoration failures: '+json.dumps(errors))

def cli(argv=None):
    """Callable only by an eventual separately reviewed launcher; never invoked here."""
    global _deadline
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['subject','bindings','output']:parser.add_argument('--'+name,required=True)
    args=parser.parse_args(argv);_deadline=time.monotonic()+900
    out=pathlib.Path(args.output);config=None;child=None;scratch=None;identity=None;values={};began=time.monotonic()
    require(out.is_absolute()and out.parent==pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')and not out.exists(),'new owned outside output required')
    out.mkdir();record={'subject':args.subject,'tree':None,'complete':False,'accepted':False,'exitCode':90,'activeBudgetSeconds':900,'cleanupBudgetSeconds':60,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':[],'mutants':[],'cleanupErrors':[],'runtimeClaim':'retained outputs unchanged; no build selected'}
    for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,interrupted)
    def attempt(phase,action):
        try:action()
        except BaseException as error:record['cleanupErrors'].append({'phase':phase,'type':type(error).__name__,'message':str(error)})
    def run(name,command):
        nonlocal child
        row={'name':name,'command':command};record['phases'].append(row);started=time.monotonic()
        with(out/(name+'.log')).open('wb')as log:
            child=subprocess.Popen(command,cwd=ROOT,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=child.pid
            while True:
                try:code=child.wait(timeout=min(45,remaining()));break
                except subprocess.TimeoutExpired:print(json.dumps({'phase':name,'seconds':time.monotonic()-started}),flush=True)
        row.update(exitCode=code,seconds=time.monotonic()-started,logSha256=sha(out/(name+'.log')))
        drain(record);require(not record.get('forcedOwnedChildren'),'forced child cleanup cannot establish phase success')
        (out/'progress.json').write_text(json.dumps(record,indent=2)+'\n');return code
    def suite(name,project,mutant=None,baseline=None):
        command=[NODE,'node_modules/vitest/vitest.mjs','run','--project',project,*FILES[project]]
        if mutant is not None:command.append('--testNamePattern=^'+re.escape(mutant['case']['fullName'])+'$')
        command+=['--reporter=default','--reporter=json','--outputFile='+str(out/(name+'.json'))]
        code=run(name,command);report=json.loads(read_bytes(out/(name+'.json')))
        result=report_result(report,project,code,baseline=baseline,mutant=mutant,log=read_bytes(out/(name+'.log')).decode('utf-8',errors='replace'))
        (out/(name+'-parsed.json')).write_text(json.dumps(result,indent=2)+'\n');return result
    try:
        config_path=pathlib.Path(args.bindings);require(config_path.is_absolute(),'absolute frozen bindings path required')
        config=json.loads(read_bytes(config_path));validate_config(config,args.subject)
        record.update(tree=config['tree'],operatorSha256=sha(pathlib.Path(__file__)),bindingsSha256=sha(config_path))
        (out/'bindings-used.json').write_bytes(read_bytes(config_path))
        environment=dict(os.environ)
        for key in BLOCKED:require(not environment.get(key),'runner override: '+key)
        require(environment.get('SYZYGY_POC_BROWSER')==config['browser']['path'],'exact bound browser required')
        source(config);record['resultCacheBefore']=tools(config);record['retainedRuntimeBefore']=retained_runtime(config)
        values=snapshots(config,out)
        scratch=pathlib.Path(tempfile.mkdtemp(prefix='f3own-',dir='/home/orca/.tmp'));scratch.chmod(0o700);identity=scratch.stat()
        environment['TMPDIR']=str(scratch);environment['PATH']=str(pathlib.Path(NODE).parent)+':/usr/bin:/bin'
        require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'owned subreaper unavailable')
        record['typecheckExitCode']=run('typecheck',[NODE,NPM,'run','typecheck'])
        baseline={project:suite('baseline-'+project,project)for project in FILES}
        record['baseline']={project:{key:value for key,value in result.items()if key!='assertionsByFile'}for project,result in baseline.items()}
        record['baselineAccepted']=record['typecheckExitCode']==0 and all(result['accepted']for result in baseline.values())
        if record['baselineAccepted']:
            active_deadline=_deadline
            for item in config['mutants']:
                row={'id':item['id'],'definition':item,'accepted':False};record['mutants'].append(row)
                try:
                    source(config);_deadline=min(active_deadline,time.monotonic()+item['seconds']);apply_mutant(item,values)
                    result=suite('mutant-'+item['id'],item['project'],item,baseline[item['project']]['inventory'])
                    row.update(result)
                finally:
                    _deadline=time.monotonic()+60
                    entry_mask=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
                    try:
                        attempt('mutant-'+item['id']+'-leader-stop',lambda:stop_leader(child))
                        attempt('mutant-'+item['id']+'-owned-drain',lambda:drain(record))
                        attempt('mutant-'+item['id']+'-source-restoration',lambda:restore_sources(values))
                    finally:
                        _deadline=active_deadline;signal.pthread_sigmask(signal.SIG_SETMASK,entry_mask)
                require(not record['cleanupErrors'],'mutant cleanup failed')
                source(config)
            record['mutationPopulationComplete']=len(record['mutants'])==len(config['mutants'])
        else:
            record['mutantsNotRun']='baseline not accepted'
        record['executionComplete']=True
        record['accepted']=bool(record['baselineAccepted']and record.get('mutationPopulationComplete')and all(row['accepted']for row in record['mutants']))
        record['exitCode']=0 if record['accepted']else 1
    except BaseException as error:record['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        _deadline=time.monotonic()+60;signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
        attempt('leader-stop',lambda:stop_leader(child));attempt('owned-drain',lambda:drain(record))
        attempt('source-restoration',lambda:restore_sources(values))
        def final_bindings():
            source(config);record['resultCacheAfter']=tools(config);record['sourceToolsUnchanged']=True
            record['retainedRuntimeAfter']=retained_runtime(config);record['retainedRuntimeUnchanged']=record['retainedRuntimeBefore']==record['retainedRuntimeAfter']
            require(record['retainedRuntimeUnchanged'],'retained runtime changed')
        attempt('source-tools-runtime-final',final_bindings)
        def final_scratch():
            if scratch is not None:
                now=scratch.stat();require((now.st_uid,now.st_dev,now.st_ino,stat.S_IMODE(now.st_mode))==(os.getuid(),identity.st_dev,identity.st_ino,0o700),'private TMP identity/mode drift')
                record.update(privateTMP=str(scratch),privateTMPTopLevel=sorted(path.name for path in scratch.iterdir()),privateTMPIdentityUnchanged=True)
        attempt('private-TMP-final',final_scratch);attempt('owned-drain-final',lambda:drain(record))
        record['cleanupPendingSignals']=[int(sig)for sig in signal.sigpending()if sig in[signal.SIGINT,signal.SIGTERM]]
        def raw_hashes():
            record['rawFiles']=[{'path':str(path.relative_to(out)),'bytes':path.stat().st_size,'sha256':sha(path)}for path in sorted(out.rglob('*'))if path.is_file()and path.name!='terminal.json']
            record['rawFilesComplete']=True
        attempt('raw-artifact-hashes',raw_hashes)
        record['complete']=bool(record.get('executionComplete')and not record.get('error')and not record['cleanupErrors']and record.get('rawFilesComplete')and record.get('noOwnedChildren')and not record.get('forcedOwnedChildren')and record.get('sourceToolsUnchanged')and record.get('retainedRuntimeUnchanged')and record.get('privateTMPIdentityUnchanged')and not record['cleanupPendingSignals'])
        if not record['complete']:record['accepted']=False;record['exitCode']=90
        record['elapsedSeconds']=time.monotonic()-began
        (out/'terminal.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps({key:record[key]for key in ['complete','accepted','exitCode','subject','tree']}),flush=True)
    return record['exitCode']

