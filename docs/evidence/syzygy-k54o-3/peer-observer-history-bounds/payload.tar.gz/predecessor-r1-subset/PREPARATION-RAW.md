Source-only preparation receipt.

Subject: 7903e21a26c2f6488563c73fe45b30e84ef4cc14
Actual primary HEAD at freeze: 12d52359459231612a4370ca18e35883f1795f8e
SourceSHA: 6494b2e37a28e99bd6fe529e4050b66e6a54ae29b83a92ebf81b475d48fc86bc
CandidateSHA: 8c706b4588dd0da658c882707ef261bbcb82647606e78a45e4e23ad32fd01fbd

Observed: AST74spies; independent Python74spies/151method-use lines; selected5spy declarations over3APIs with no asserted selectedhistory. Five original callback bodies byte-exact, helper unchanged, reverse equality exact. No product imports or runtime tests. Every pinned committed source compared to current source.

Observed: outside candidate/patch/census/bindings only. No primary edits.

Unknown: runtime effect, retainedbytes, RSS and speed.
