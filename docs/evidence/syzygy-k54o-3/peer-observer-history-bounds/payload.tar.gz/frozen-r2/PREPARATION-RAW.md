Source-only R2 preparation.

Subject: 7903e21a26c2f6488563c73fe45b30e84ef4cc14
Actual primary HEAD: 12d52359459231612a4370ca18e35883f1795f8e
CandidateSHA: de96b193f896b24de8ec1953d1b180086fd7b4cdb30ec4235c4a46d406f14249
R1ManifestSHA: 58646f376838e5f603abb6499dd1505cae6f289024943b6c450792c1686e8834

Observed:74spies;6selected wrappers;6original inner bodies/helper unchanged; reverseexact; removing only screen wrapper exactlyR1candidate. Broader AST170lexicalproperty occurrences includes169mock/matcher+1metadata; independent158lexicallines cover all170ASToccurrences. Added screen alias TSsymbol has3references and no assertedhistory. No product imports or runtimeexecution.

Unknown: actual retainedbytes/RSS/speed.
