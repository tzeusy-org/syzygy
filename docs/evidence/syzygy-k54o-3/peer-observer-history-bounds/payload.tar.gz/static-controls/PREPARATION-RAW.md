Prepared source-only controls.

Subject: f980667dd2dc51a710752e7156c995307a96c0fa
SourceSHA: de96b193f896b24de8ec1953d1b180086fd7b4cdb30ec4235c4a46d406f14249

Observed: committedsource copied outside; parser extraction yields six exact spy bindings, parameters and inner bodies at lines926,953,1533,1637,1726,1747. Six solewrapperremoval old/newfragments and mutantdigests prepared. No checker or control execution. No product/test imports. No primary edits.

Unknown: baseline/control results pending root execution. Scope is static wiring only; no runtime/performance claim.
