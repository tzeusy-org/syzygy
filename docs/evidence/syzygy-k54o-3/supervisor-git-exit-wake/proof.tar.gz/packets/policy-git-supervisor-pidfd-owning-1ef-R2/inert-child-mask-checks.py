import hashlib, json, os, signal, subprocess
from pathlib import Path
p = Path(__file__).resolve().parent
original = signal.pthread_sigmask(signal.SIG_BLOCK, set())
intended = {signal.SIGUSR1}
target = ['/usr/bin/python3', '-c', "import json,os,signal,sys; got=[]; signal.signal(signal.SIGTERM,lambda s,f:got.append(s)); mask=sorted(int(s) for s in signal.pthread_sigmask(signal.SIG_BLOCK,set())); os.kill(os.getpid(),signal.SIGTERM); print(json.dumps({'mask':mask,'termDelivered':got,'argvTail':sys.argv[1:],'environment':os.environ['F3_INERT_MASK_CONTROL']}))", 'literal $() argument', 'two words']
try:
    signal.pthread_sigmask(signal.SIG_SETMASK, intended)
    captured = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT,signal.SIGTERM})
    launched = ['/usr/bin/python3',str(p/'child-exec.py'),json.dumps(sorted(int(s) for s in captured)),json.dumps(target)]
    try:
        child = subprocess.Popen(launched,env=dict(os.environ,F3_INERT_MASK_CONTROL='inert-only'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        registered = child.pid
    finally: signal.pthread_sigmask(signal.SIG_SETMASK,captured)
    stdout,stderr = child.communicate(timeout=10)
    actual = json.loads(stdout)
    assert child.returncode == 0 and not stderr
    assert registered == child.pid
    assert actual == {'mask':[int(signal.SIGUSR1)],'termDelivered':[int(signal.SIGTERM)],'argvTail':target[-2:],'environment':'inert-only'},actual
    assert signal.pthread_sigmask(signal.SIG_BLOCK,set()) == intended
finally: signal.pthread_sigmask(signal.SIG_SETMASK,original)
assert signal.pthread_sigmask(signal.SIG_BLOCK,set()) == original
result={'mode':'INERT_SUBPROCESS_ONLY','shimSha256':hashlib.sha256((p/'child-exec.py').read_bytes()).hexdigest(),'launchedArgv':launched,'actualProductArgv':target,'actual':actual,'exitCode':child.returncode,'parentEntryMaskRestored':True,'leaderRegisteredBeforeUnblock':True,'productNativeOperatorExecution':False}
(p/'inert-child-mask-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['mode','actual','exitCode','parentEntryMaskRestored','productNativeOperatorExecution']}))
