#!/usr/bin/python3
"""Restore the caller's entry mask, then replace this shim with its exact argv."""
import json, os, signal, sys
mask = json.loads(sys.argv[1])
argv = json.loads(sys.argv[2])
signal.pthread_sigmask(signal.SIG_SETMASK, mask)
os.execve(argv[0], argv, os.environ)
