#!/bin/sh
set -eu
exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/policy-git-supervisor-idle-microdiagnostic-1ef234-R2/run-isolated.py --execution-name execution-1
