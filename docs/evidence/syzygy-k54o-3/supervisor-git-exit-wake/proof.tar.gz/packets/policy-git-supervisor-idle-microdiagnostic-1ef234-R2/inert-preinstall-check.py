#!/usr/bin/env python3
"""Exercise the exact operator tool guard on inert temporary byte fixtures only."""
import ast, hashlib, json, tempfile
from pathlib import Path
packet=Path(__file__).resolve().parent
source=(packet/'run-isolated.py').read_text()
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='verify_tools')
with tempfile.TemporaryDirectory(prefix='guard-',dir='/home/orca/.tmp')as temporary:
 home=Path(temporary);root=home/'clone';origin=home/'source';meta=home/'packet';meta.mkdir()
 shim=b'inert known shim';native=b'inert known native';installer=b'inert installer'
 contents={'node_modules/esbuild/bin/esbuild':shim,'node_modules/esbuild/install.js':installer,'node_modules/@esbuild/linux-x64/bin/esbuild':native}
 sha=lambda data:hashlib.sha256(data).hexdigest()
 rows=[]
 for relative,data in contents.items():
  p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  expected=native if relative=='node_modules/esbuild/bin/esbuild'else data
  rows.append({'path':str(origin/relative),'bytes':len(expected),'sha256':sha(expected)})
 (meta/'tool-bindings.json').write_text(json.dumps({'rows':rows,'installedToolRoots':['esbuild','@esbuild/linux-x64'],'installedToolFilesRelative':list(contents)}))
 scope={'json':json,'Path':Path,'PACKET':meta,'PRIMARY':origin,'sha':sha,'MANIFEST':{'esbuildPreparation':{'shimPreimage':{'bytes':len(shim),'sha256':sha(shim)}}}}
 exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact operator verify_tools>','exec'),scope)
 check=scope['verify_tools'];results=[]
 def refuses(name,call):
  try:call()
  except RuntimeError:results.append({'control':name,'refused':True})
  else:raise AssertionError(name+' unexpectedly admitted')
 refuses('strict final guard refuses shim',lambda:check(root))
 check(root,preinstall=True);results.append({'control':'exact known preinstall shim admitted','passed':True})
 target=root/'node_modules/esbuild/bin/esbuild';target.write_bytes(shim+b'changed')
 refuses('different shim refused',lambda:check(root,preinstall=True));target.write_bytes(shim)
 target=root/'node_modules/esbuild/install.js';target.write_bytes(installer+b'changed')
 refuses('different installer refused',lambda:check(root,preinstall=True));target.write_bytes(installer)
 extra=root/'node_modules/esbuild/unexpected';extra.write_bytes(b'extra')
 refuses('extra population refused',lambda:check(root,preinstall=True));extra.unlink()
 (root/'node_modules/esbuild/bin/esbuild').write_bytes(native)
 check(root);results.append({'control':'exact final native image admitted','passed':True})
 assert "FINAL['error'] = {'type':type(error).__name__,'message':str(error)}"in source
 print(json.dumps({'scope':'inert operator guard only; no installer/native/product execution','results':results,'primaryExceptionRetainedInTerminalSource':True},indent=2))
