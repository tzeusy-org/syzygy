// Static parser/text inspection only; no product, fixture or compiler imports.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import ts from '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w/node_modules/typescript/lib/typescript.js';
const base = new URL('./', import.meta.url), rel = 'packages/polaris-dossier/src/';
const read = (side, file) => fs.readFileSync(new URL(`${side}/${rel}${file}`, base), 'utf8');
const walk = node => { const out = []; const visit = n => { out.push(n); ts.forEachChild(n, visit); }; visit(node); return out; };
const tests = side => {
  const text = read(side, 'policy-git-native.test.ts'), ast = ts.createSourceFile('tests.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.equal(ast.parseDiagnostics.length, 0);
  const cases = walk(ast).filter(n => ts.isCallExpression(n) && n.expression.getText(ast) === 'it' && ts.isStringLiteral(n.arguments[0]));
  return { text, cases: new Map(cases.map(n => [n.arguments[0].text, n.getText(ast)])) };
};
const oldTests = tests('original'), newTests = tests('candidate');
const changed = [], unchanged = [];
for (const [name, body] of oldTests.cases) {
  assert(newTests.cases.has(name), name);
  (newTests.cases.get(name) === body ? unchanged : changed).push(name);
}
assert.deepEqual(changed, ['waits and reaps a detached adopted child after direct Git exit and closed pipes']);
const added = [...newTests.cases.keys()].filter(name => !oldTests.cases.has(name));
assert.deepEqual(added, ['refuses unavailable Git pidfds with complete drained usage instead of poisoning host accounting']);
// A second, independent line-subsequence method verifies no original test-source line was removed.
const remaining = newTests.text.split('\n')[Symbol.iterator]();
for (const original of oldTests.text.split('\n')) {
  let next; do { next = remaining.next(); assert(!next.done, `original line missing: ${original}`); } while (next.value !== original);
}
const before = read('original', 'policy-git-supervisor.c'), after = read('candidate', 'policy-git-supervisor.c');
assert.equal(before.slice(0, before.indexOf('int main(')), after.slice(0, after.indexOf('int main(')), 'all C helpers unchanged');
assert(after.includes('git_exitfd = (int)syscall(SYS_pidfd_open, git, 0);'));
assert(after.indexOf('git_exitfd = (int)syscall') > after.indexOf('if (git < 0) goto finish;'));
assert(after.indexOf('git_exitfd = (int)syscall') < after.indexOf('complete = reap(git, &status, &waited);'));
assert(after.includes('if (waited) shut(&git_exitfd);'));
assert(after.includes('poll(watched, 5, 2)'));
assert(after.includes('watched[4].revents & (POLLERR | POLLNVAL)'));
assert(after.includes('cleanup:\n  shut(&git_exitfd);'));
assert(after.includes('finish:\n  shut(&git_exitfd);'));
for (const text of ['now - began >= 1250', 'now - began < 250 ? SIGTERM : SIGKILL', 'struct timespec pause = {0, 2000000}',
  'request.timeout_ms > 10000', 'milliseconds() >= deadline', 'dispatch < 0 || dispatch >= deadline',
  'now < 0 || now >= deadline', 'reads < 4', 'receipt.tree_complete = complete && (git < 0 || waited)']) {
  assert(before.includes(text) && after.includes(text), text);
}
const parserPath = '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w/node_modules/typescript/lib/typescript.js';
const result = { mode: 'STATIC_ONLY', source: { originalTests: oldTests.cases.size, candidateTests: newTests.cases.size,
  netDeclarations: added.length, added, extended: changed, unchangedCases: unchanged.length,
  originalEntireTestSourcePreservedByIndependentLineSubsequence: true,
  allPreMainCHelpersByteUnchanged: true, acquisitionBeforeFirstReap: true, closeOnDirectWaited: true,
  pollSlots: 5, originalPollTimeoutMilliseconds: 2, errorReadinessRefuses: true, commonCloses: ['cleanup', 'finish'],
  originalDeadlineDrainAndOutputBoundFragmentsPreserved: true },
  parser: { path: parserPath, sha256: crypto.createHash('sha256').update(fs.readFileSync(parserPath)).digest('hex') },
  limitations: ['C and embedded C have not been compiled or executed.', 'No typecheck, test, mutation, product or heavy command ran.', 'Static checks do not establish runtime races, leak absence or performance benefit.'] };
fs.writeFileSync(new URL('static-results.json', base), JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify(result.source) + '\n');
