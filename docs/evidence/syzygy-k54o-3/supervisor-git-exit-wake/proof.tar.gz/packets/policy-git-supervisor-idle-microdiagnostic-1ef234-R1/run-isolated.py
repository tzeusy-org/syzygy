#!/usr/bin/env python3
"""Operator-run diagnostic. Creates and mutates only a disposable clone."""
import argparse
import collections
import ctypes
import tempfile
import hashlib
import json
import math
import os
import re
from pathlib import Path
import shutil
import signal
import subprocess
import time

PACKET = Path(__file__).resolve().parent
MANIFEST = json.loads((PACKET / 'manifest.json').read_text())
PRIMARY = Path(MANIFEST['primary'])
FOCUS = MANIFEST['focus']
FOCUS_FULL_NAME = MANIFEST['focusFullName']
FOCUS_PATTERN = '^' + re.escape(FOCUS_FULL_NAME) + '$'
if FOCUS_PATTERN != MANIFEST['focusPattern']:
    raise SystemExit('focus pattern binding mismatch')
parser = argparse.ArgumentParser()
parser.add_argument('--execution-name', required=True, help='New directory name beneath this packet; never reused')
args = parser.parse_args()
if not args.execution_name or Path(args.execution_name).name != args.execution_name:
    raise SystemExit('execution-name must be a single path component')
OUT = PACKET / args.execution_name
OUT.mkdir(exist_ok=False)
CHECKOUT = OUT / 'checkout'
TMP = Path(tempfile.mkdtemp(prefix='md-',dir='/home/orca/.tmp'))
TMP.chmod(0o700)
TMP_IDENTITY = TMP.stat()
ENV = dict(os.environ, TMPDIR=str(TMP))
history = []
CURRENT = None
FINAL = {'complete': False, 'cleanupErrors': []}
NODE = '/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM = '/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
for key in ['NODE_OPTIONS','VITEST_MAX_THREADS','VITEST_MIN_THREADS','VITEST_MAX_FORKS','VITEST_MIN_FORKS','SYZYGY_COMPOSED_RETAIN','SYZYGY_F3_NATIVE_EVIDENCE_FILE']:
    if ENV.get(key): raise SystemExit('forbidden runner override: '+key)
ENV['PATH'] = str(Path(NODE).parent)+':/usr/bin:/bin'
if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0): raise SystemExit('subreaper unavailable')
def interrupted(sig,frame): raise InterruptedError('signal '+str(sig))
for sig in [signal.SIGINT,signal.SIGTERM]: signal.signal(sig,interrupted)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def children():
    text = Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text()
    return [int(pid) for pid in text.split()]

def drain(record):
    """Reap only our children. Signal a still-owned child only through its pidfd."""
    reaped, forced = [], []
    record.update(noOwnedChildren=False, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
    began = time.monotonic()
    while True:
        while True:
            try: pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                record.update(noOwnedChildren=True, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
                return
            if not pid: break
            reaped.append({'pid': pid, 'status': status})
        elapsed = time.monotonic() - began
        if elapsed > 20: raise RuntimeError('owned child drain exceeded 20s; private TMP retained')
        if elapsed > 10:
            for pid in children():
                try:
                    fd = os.pidfd_open(pid)
                    try:
                        # A direct owned child cannot recycle its PID before our waitpid.
                        if pid in children():
                            sig = signal.SIGTERM if elapsed < 15 else signal.SIGKILL
                            signal.pidfd_send_signal(fd, sig)
                            forced.append({'pid': pid, 'signal': int(sig)})
                    finally: os.close(fd)
                except ProcessLookupError: pass
        time.sleep(.05)

def run(name, command, cwd, timeout):
    global CURRENT
    started = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        child = subprocess.Popen(command, cwd=cwd, env=ENV, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        CURRENT = child
        timed_out = False
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            # This group was created by this exact live Popen, never selected by name.
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
        population = {}
        drain(population)
        CURRENT = None
        survivors = children()
        if population['forcedOwnedChildren']: raise RuntimeError('command required forced descendant cleanup')
    history.append({'name': name, 'command': command, 'cwd': str(cwd), 'pid': child.pid,
                    'elapsedSeconds': time.monotonic() - started, 'exitCode': code,
                    'timedOut': timed_out, 'remainingSessionPopulation': survivors})
    (OUT / 'commands.json').write_text(json.dumps(history, indent=2) + '\n')
    if code or timed_out or survivors:
        raise RuntimeError(f'{name} incomplete; inspect retained log and session population; no automatic cleanup')

def verify_primary():
    head = subprocess.check_output(['/usr/bin/git', '-C', str(PRIMARY), 'rev-parse', 'HEAD'], text=True).strip()
    if head != MANIFEST['subject'] or subprocess.check_output(['/usr/bin/git','-C',str(PRIMARY),'rev-parse','HEAD^{tree}'],text=True).strip()!=MANIFEST['subjectTree']:
        raise RuntimeError('primary HEAD moved; regenerate/rebind packet, never transplant silently')
    if subprocess.check_output(['/usr/bin/git', '-C', str(PRIMARY), 'status', '--porcelain']):
        raise RuntimeError('primary is not clean; do not interfere with another run')
    for relative, binding in MANIFEST['sourceBindings'].items():
        if sha((PRIMARY / relative).read_bytes()) != binding['sha256']:
            raise RuntimeError('primary source binding mismatch: ' + relative)

def verify_tools(root):
    bindings=json.loads((PACKET/'tool-bindings.json').read_text())
    for row in bindings['rows']:
        path=Path(row['path'])
        if str(path).startswith(str(PRIMARY)+'/node_modules/'):
            path=root/path.relative_to(PRIMARY)
        if path.stat().st_size!=row['bytes'] or sha(path.read_bytes())!=row['sha256']:
            raise RuntimeError('tool binding drift: '+str(path))
    paths=sorted(str(p.relative_to(root)) for name in bindings['installedToolRoots'] for p in (root/'node_modules'/name).rglob('*') if p.is_file())
    expected=bindings['installedToolFilesRelative']
    if len(expected)!=len(set(expected)) or paths!=sorted(expected): raise RuntimeError('installed tool population drift')

try:
    if sha(Path(__file__).read_bytes()) != MANIFEST['operatorSha256'] or sha((PACKET/'tool-bindings.json').read_bytes()) != MANIFEST['toolBindingsSha256']:
        raise RuntimeError('operator/tool packet binding mismatch')
    verify_primary()
    verify_tools(PRIMARY)
    if sha((PACKET / 'diagnostic.patch').read_bytes()) != MANIFEST['patchSha256']:
        raise RuntimeError('packet patch binding mismatch')
    for relative, binding in MANIFEST['overlayBindings'].items():
        if sha((PACKET / 'overlay' / relative).read_bytes()) != binding['sha256']:
            raise RuntimeError('overlay binding mismatch: ' + relative)
    run('clone', ['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', 'clone', '--template=', '--no-hardlinks',
                  '--no-checkout', str(PRIMARY), str(CHECKOUT)], OUT, 120)
    run('checkout', ['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', 'checkout', '--detach', MANIFEST['subject']], CHECKOUT, 60)
    run('node-version', [NODE, '-e', 'if(process.version!=="v24.6.0")process.exit(1);console.log(process.version)'], CHECKOUT, 10)
    # Workspace links must belong to this clone. No install lifecycle scripts.
    run('install', [NODE, NPM, 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], CHECKOUT, 180)
    verify_tools(CHECKOUT)
    common = [NODE, 'node_modules/vitest/vitest.mjs', 'run', '--project', 'integration',
              'packages/polaris-dossier/src/policy-git-native.test.ts', '-t', FOCUS_PATTERN,
              '--reporter=verbose', '--reporter=json']
    run('original-focused', common + ['--outputFile=' + str(OUT / 'original-vitest.json')], CHECKOUT, 120)
    for relative, binding in MANIFEST['overlayBindings'].items():
        source = CHECKOUT / relative
        if sha(source.read_bytes()) != MANIFEST['sourceBindings'][relative]['sha256']:
            raise RuntimeError('clone source changed before overlay: ' + relative)
        shutil.copyfile(PACKET / 'overlay' / relative, source)
    run('diagnostic-focused', common + ['--outputFile=' + str(OUT / 'diagnostic-vitest.json')], CHECKOUT, 120)
    log = (OUT / 'diagnostic-focused.log').read_text()
    marker = 'POLICY_GIT_DIAGNOSTIC_V1 '
    if log.count(marker) != 1:
        raise RuntimeError('expected exactly one numeric diagnostic marker; retain failure, do not infer zero')
    payload = json.JSONDecoder().raw_decode(log.split(marker, 1)[1])[0]
    rows = [row for case in payload['cases'] for row in case['rows']]
    reports = {}
    for name in ['original', 'diagnostic']:
        report = json.loads((OUT / (name + '-vitest.json')).read_text())
        assertions = [item for result in report['testResults'] for item in result['assertionResults']]
        passed = [item for item in assertions if item['status'] == 'passed']
        if len(assertions) != 18 or len(passed) != 1 or passed[0]['title'] != FOCUS or passed[0]['fullName'] != FOCUS_FULL_NAME or passed[0]['ancestorTitles'] != [] or sum(item['status'] in ['pending','skipped'] for item in assertions)!=17 or report.get('success') is not True:
            raise RuntimeError('focused denominator/result differs; inspect JSON before interpreting timings')
        reports[name] = {'assertionPopulation': len(assertions), 'passed': len(passed),
                         'passedTitle': passed[0]['title'], 'passedFullName': passed[0]['fullName'], 'durationMs': passed[0].get('duration')}
    if len(payload['cases']) != 16 or len(rows) != 22:
        raise RuntimeError('diagnostic job/case population differs; do not summarize partial data')
    expected_jobs = {'baseline': 3, 'HEAD retry': 4, 'early ref drift': 1, 'working drift': 3}
    for case in payload['cases']:
        expected = expected_jobs[case['scenario']] if case['mode'] == 'native' else 0
        if len(case['rows']) != expected:
            raise RuntimeError('case diagnostic population differs')
    required_native = {
        'diagnosticHostIdlePolls', 'diagnosticHostIdlePollUs', 'diagnosticHostMainPolls', 'diagnosticHostMainPollUs',
        'diagnosticQueueUs', 'diagnosticPumpUs', 'diagnosticSupervisorIdlePolls', 'diagnosticSupervisorIdlePollUs',
        'diagnosticSupervisorMainPolls', 'diagnosticSupervisorMainPollUs',
        'diagnosticTransferPollsExcludingFinalReceipt', 'diagnosticTransferPollUsExcludingFinalReceipt',
        'diagnosticDirectGitUnreapedIdlePolls', 'diagnosticDirectGitUnreapedIdlePollUs',
        'diagnosticDirectGitReapedIdlePolls', 'diagnosticDirectGitReapedIdlePollUs',
        'diagnosticArgumentCount', 'diagnosticPreImageMs', 'diagnosticRequestEncodeMs', 'diagnosticPostImageMs',
    }
    for row in rows:
        required = required_native | ({'diagnosticAdmissionCallMs', 'diagnosticAdmissionToCallbackMs'} if row['async'] else {'diagnosticNativeCallMs'})
        if not required.issubset(row):
            raise RuntimeError('missing native diagnostic fields')
        if any(type(value) not in (int, float) or not math.isfinite(value) or value < 0 for key, value in row.items() if key.startswith('diagnostic')):
            raise RuntimeError('unknown/invalid diagnostic stopwatch reading')
    if payload['sourceTestPopulation'] != 18 or payload['plannedNativeJobs'] != 22:
        raise RuntimeError('marker denominator mismatch')
    shapes = collections.Counter(row['commandShape'] for row in rows)
    if dict(shapes) != MANIFEST['plannedDenominator']['commandShapes']:
        raise RuntimeError('unexpected command shape population')
    for row in rows:
        if row['diagnosticArgumentCount'] != (7 if row['command']=='for-each-ref' else 5):
            raise RuntimeError('argument-count drift')
        for key in ['diagnosticDirectGitUnreapedIdlePolls','diagnosticDirectGitReapedIdlePolls','diagnosticSupervisorIdlePolls']:
            if int(row[key]) != row[key]: raise RuntimeError('noninteger poll count')
        if row['diagnosticDirectGitUnreapedIdlePolls']+row['diagnosticDirectGitReapedIdlePolls'] != row['diagnosticSupervisorIdlePolls']:
            raise RuntimeError('idle poll split count mismatch')
        if not math.isclose(row['diagnosticDirectGitUnreapedIdlePollUs']+row['diagnosticDirectGitReapedIdlePollUs'],row['diagnosticSupervisorIdlePollUs'],rel_tol=1e-12,abs_tol=1e-6):
            raise RuntimeError('idle poll split duration mismatch')
    summary = {'jobs':len(rows),'commandShapes':dict(shapes),'asyncJobs':sum(row['async'] is True for row in rows),
      'splitFields':{key:sum(row[key] for row in rows) for key in ['diagnosticDirectGitUnreapedIdlePolls','diagnosticDirectGitUnreapedIdlePollUs','diagnosticDirectGitReapedIdlePolls','diagnosticDirectGitReapedIdlePollUs','diagnosticSupervisorIdlePolls','diagnosticSupervisorIdlePollUs']},
      'limits':'Small focused diagnostic only; no extrapolation to genuine145s native sample weight. Inclusive timings overlap.'}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (OUT / 'metrics.json').write_text(json.dumps(payload, indent=2) + '\n')
    # Restore only the five overlay files in the disposable clone, after exact
    # byte verification; never git-reset a shared checkout or delete artifacts.
    for relative, binding in MANIFEST['overlayBindings'].items():
        source = CHECKOUT / relative
        if sha(source.read_bytes()) != binding['sha256']:
            raise RuntimeError('overlay changed during run; refuse restoration: ' + relative)
        shutil.copyfile(PACKET / 'original' / relative, source)
    clone_status = subprocess.check_output(['/usr/bin/git', '-C', str(CHECKOUT), 'status', '--porcelain'], text=True)
    if clone_status:
        raise RuntimeError('disposable clone not clean after exact restoration; inspect manually')
    verify_primary()
    result = {'status': 'measured, diagnostic only; not native acceptance', 'subject': MANIFEST['subject'],
              'patchSha256': MANIFEST['patchSha256'], 'metricsSha256': sha((OUT / 'metrics.json').read_bytes()),
              'reports': reports, 'nativeRows': len(rows), 'cases': len(payload['cases']),
              'privateTmp': str(TMP), 'overlayRestoredInDisposableClone': True,
              'primaryBindingsRechecked': True, 'commands': history}
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    FINAL['measured'] = True
    print(json.dumps({'status': result['status'], 'result': str(OUT / 'result.json')}))
except BaseException as error:
    (OUT / 'incomplete.json').write_text(json.dumps({'status': 'incomplete', 'error': str(error), 'commands': history}, indent=2) + '\n')
    raise

finally:
    # Defer repeated interrupts until leader stop, owned drain and receipt finish.
    signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
    def attempt(phase,action):
        try: action()
        except BaseException as error: FINAL['cleanupErrors'].append({'phase':phase,'error':str(error)})
    def stop():
        if CURRENT is not None and CURRENT.returncode is None:
            try: os.killpg(CURRENT.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: CURRENT.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try: os.killpg(CURRENT.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                CURRENT.wait(timeout=5)
    attempt('leader-stop',stop)
    attempt('owned-drain',lambda:drain(FINAL))
    def restore():
        if not FINAL.get('noOwnedChildren'): raise RuntimeError('live owned children; preserve diagnostic clone')
        if not CHECKOUT.exists(): return
        for relative,binding in MANIFEST['overlayBindings'].items():
            path=CHECKOUT/relative
            if not path.exists(): continue
            current=sha(path.read_bytes());original=MANIFEST['sourceBindings'][relative]['sha256']
            if current not in [original,binding['sha256']]: raise RuntimeError('unknown clone source; preserve: '+relative)
            if current!=original: shutil.copyfile(PACKET/'original'/relative,path)
        if subprocess.check_output(['/usr/bin/git','status','--porcelain'],cwd=CHECKOUT): raise RuntimeError('clone not exactly restored')
        FINAL['cloneSourceRestored']=True
    attempt('clone-source-restore',restore)
    attempt('primary-final-bindings',verify_primary)
    attempt('tools-final-bindings',lambda:verify_tools(PRIMARY))
    FINAL['primaryBindingsRechecked']=not any(x['phase']=='primary-final-bindings'for x in FINAL['cleanupErrors'])
    def scratch_final():
        now=TMP.stat();FINAL['privateTMPIdentityUnchanged']=(now.st_uid,now.st_dev,now.st_ino)==(os.getuid(),TMP_IDENTITY.st_dev,TMP_IDENTITY.st_ino)
        FINAL['privateTMP']=str(TMP);FINAL['privateTMPTopLevel']=sorted(p.name for p in TMP.iterdir())
    attempt('private-TMP-final',scratch_final)
    FINAL['cleanupPendingSignals']=[int(sig)for sig in signal.sigpending()if sig in [signal.SIGINT,signal.SIGTERM]]
    FINAL['operatorSha256']=sha(Path(__file__).read_bytes());FINAL['manifestSha256']=sha((PACKET/'manifest.json').read_bytes())
    FINAL['rawFiles']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(OUT.iterdir())if p.is_file()and p.name!='terminal.json']
    FINAL['complete']=bool(FINAL.get('measured')and FINAL.get('noOwnedChildren')and not FINAL.get('forcedOwnedChildren')and not FINAL['cleanupErrors']and FINAL.get('cloneSourceRestored')and FINAL['primaryBindingsRechecked']and FINAL.get('privateTMPIdentityUnchanged')and not FINAL['cleanupPendingSignals'])
    (OUT/'terminal.json').write_text(json.dumps(FINAL,indent=2)+'\n')
    if not FINAL['complete']: raise SystemExit(90)
