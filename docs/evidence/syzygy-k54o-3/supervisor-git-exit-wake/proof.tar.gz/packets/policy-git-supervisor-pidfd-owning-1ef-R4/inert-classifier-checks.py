import ast, hashlib, json, re
from pathlib import Path
p=Path(__file__).resolve().parent
source=(p/'run.py').read_text(); tree=ast.parse(source)
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='assertion_failure')
PRIMARY=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w'); TEST='packages/polaris-dossier/src/policy-git-native.test.ts'
scope={'re':re,'PRIMARY':PRIMARY,'TEST':TEST}
exec(compile(ast.Module(body=[function],type_ignores=[]),'<inert-extracted-classifier>','exec'),scope)
check=scope['assertion_failure']
prior=Path('/home/orca/.tmp/f3-native-admission-fixes/policy-git-supervisor-pidfd-owning-1ef-execution-1')
report=json.loads((prior/'mutant-predecessor.json').read_text()); rows=[r for s in report['testResults'] for r in s['assertionResults'] if r['status']=='failed']; assert len(rows)==1
messages=rows[0]['failureMessages']; log=(prior/'mutant-predecessor.log').read_text(); message=messages[0]
fixtures=[('actual-pinned-rejects-assertion',messages,log,True),('ordinary-assertion',['AssertionError: expected value'], '',True),('plain-error',['Error: ordinary failure'],log,False),('missing-messages',[],log,False),('missing-console',messages,'',False),('missing-rejects-stack',[message.replace('_Assertion.__VITEST_REJECTS__','unrelated')],log,False),('wrong-source-line',[message.replace(':305:27',':306:27')],log,False),('wrong-console-message',messages,log.replace('AssertionError: promise resolved','AssertionError: unrelated'),False)]
for token in ['ENOENT','Command failed','fatal error:','error: unused','policy-git-usage-unavailable']:
 fixtures.append(('negative-'+token,[message+'\n'+token],log,False))
results=[]
for name,m,l,expected in fixtures:
 actual=check(m,l); assert actual is expected,(name,actual,expected)
 results.append({'name':name,'expected':expected,'actual':actual})
result={'mode':'INERT_EXTRACTED_CLASSIFIER_ONLY','runnerSha256':hashlib.sha256((p/'run.py').read_bytes()).hexdigest(),'actualReportSha256':hashlib.sha256((prior/'mutant-predecessor.json').read_bytes()).hexdigest(),'actualLogSha256':hashlib.sha256((prior/'mutant-predecessor.log').read_bytes()).hexdigest(),'controls':results,'productNativeRunnerExecution':False}
(p/'inert-classifier-results.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps({'controls':len(results),'passed':len(results),'productNativeRunnerExecution':False}))
