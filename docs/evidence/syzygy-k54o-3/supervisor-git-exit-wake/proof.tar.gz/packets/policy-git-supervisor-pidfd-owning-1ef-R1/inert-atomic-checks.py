"""Only extract source definitions; never import/execute the runner or product."""
import ast, hashlib, json, os, signal, stat, tempfile
from pathlib import Path
HERE = Path(__file__).resolve().parent
source = (HERE / 'run.py').read_text(); parsed = ast.parse(source)
names = {'regular_bytes', 'require', 'atomic_source'}
nodes = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name in names
         or isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in {'sha', 'sha_file'} for target in node.targets)]
assert len(nodes) == 5
scope = dict(Path=Path, os=os, signal=signal, stat=stat, tempfile=tempfile, hashlib=hashlib)
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<extracted-inert-atomic-definitions>', 'exec'), scope)
atomic = scope['atomic_source']; sha = scope['sha']
root = Path(tempfile.mkdtemp(prefix='gp-atomic-inert-', dir='/home/orca/.tmp')); identity = root.stat()
target = root / 'owned-source'; original = b'original owned inert source\n'; candidate = b'replacement owned inert source\n'
target.write_bytes(original); target.chmod(0o6750)
def fds():
    result = {}
    for name in os.listdir('/proc/self/fd'):
        try: result[name] = os.readlink('/proc/self/fd/' + name)
        except FileNotFoundError: pass
    return result
before = fds(); modes = []
for mode in [0o640, 0o6750]:
    target.chmod(mode)
    atomic(target, candidate, {sha(original)})
    assert target.read_bytes() == candidate and stat.S_IMODE(target.stat().st_mode) == mode
    atomic(target, original, {sha(candidate)})
    assert target.read_bytes() == original and stat.S_IMODE(target.stat().st_mode) == mode
    modes.append(oct(mode))
mode = stat.S_IMODE(target.stat().st_mode)
try: atomic(target, candidate, {'0' * 64})
except RuntimeError as error: assert str(error).startswith('source preimage drift:')
else: raise AssertionError('unknown preimage accepted')
assert target.read_bytes() == original and stat.S_IMODE(target.stat().st_mode) == mode
assert sorted(path.name for path in root.iterdir()) == ['owned-source']
assert fds() == before and fds() == before
assert (root.stat().st_uid, root.stat().st_dev, root.stat().st_ino) == (os.getuid(), identity.st_dev, identity.st_ino)
result = {'mode': 'INERT_OWNED_TEMP_ONLY', 'runnerSha256': sha((HERE / 'run.py').read_bytes()),
 'replacementAndRestoration': True, 'fullModesPreserved': modes, 'unknownPreimageRefusedBeforeWrite': True,
 'sourceBytesAndModeUnchangedAfterRefusal': True, 'temporaryResidues': [], 'descriptorCensusUnchangedTwice': True,
 'productNativeOperatorExecution': False}
target.unlink(); root.rmdir(); result['preciseOwnedInertDirectoryRemoved'] = True
(HERE / 'inert-atomic-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
