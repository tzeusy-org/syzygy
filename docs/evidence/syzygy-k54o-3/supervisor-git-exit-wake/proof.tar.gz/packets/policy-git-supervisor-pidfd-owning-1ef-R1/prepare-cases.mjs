// Static declaration census only; imports parser, never product or tests.
import fs from 'node:fs';
import ts from '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w/node_modules/typescript/lib/typescript.js';
const source = '/home/orca/.tmp/f3-native-admission-fixes/policy-git-supervisor-pidfd-1ef-R2/candidate/packages/polaris-dossier/src/policy-git-native.test.ts';
const ast = ts.createSourceFile(source, fs.readFileSync(source, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
if (ast.parseDiagnostics.length) throw Error('parse diagnostics');
const cases = [];
function visit(node, ancestors = []) {
  if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.arguments.length > 0 && ts.isStringLiteral(node.arguments[0])) {
    if (node.expression.text === 'describe') {
      visit(node.arguments[1], [...ancestors, node.arguments[0].text]); return;
    }
    if (node.expression.text === 'it') {
      cases.push({title: node.arguments[0].text, ancestorTitles: ancestors, fullName: [...ancestors, node.arguments[0].text].join(' ')}); return;
    }
  }
  ts.forEachChild(node, child => visit(child, ancestors));
}
visit(ast);
if (cases.length !== 19 || new Set(cases.map(row => row.fullName)).size !== 19) throw Error('population');
fs.writeFileSync(new URL('expected-cases.json', import.meta.url), JSON.stringify({source, cases}, null, 2) + '\n');
process.stdout.write(JSON.stringify({mode: 'STATIC_DECLARATION_CENSUS', cases: cases.length}) + '\n');
