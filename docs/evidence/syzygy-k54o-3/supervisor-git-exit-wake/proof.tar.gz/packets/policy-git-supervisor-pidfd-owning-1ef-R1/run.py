#!/usr/bin/python3
"""Root-run owning check; imports never start product commands."""
import argparse, ctypes, hashlib, json, os, re, signal, stat, subprocess, tempfile, time
from pathlib import Path, PurePosixPath
HERE = Path(__file__).resolve().parent
BASE = Path('/home/orca/.tmp/f3-native-admission-fixes')
PRIMARY = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
NODE = '/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM = '/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
TEST = 'packages/polaris-dossier/src/policy-git-native.test.ts'
C = 'packages/polaris-dossier/src/policy-git-supervisor.c'
RUNTIME = 'packages/polaris-dossier/dist/runtime'
sha = lambda data: hashlib.sha256(data).hexdigest()
sha_file = lambda path: sha(regular_bytes(path))
CURRENT = None
OUT = None
ENV = None
HISTORY = []

def git_at(root, *args):
    return subprocess.check_output(['git','-C',str(root),*args])

def require(ok, reason):
    if not ok: raise RuntimeError(reason)

def checkpoint(out, name, value):
    temporary = out / (name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temporary, out / name)

def snapshot_at(root):
    require(root.resolve(strict=True) == root,'source-root-alias-refused')
    paths = sorted(set(git_at(root, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').split(b'\0')) - {b''})
    rows = []
    for raw in paths:
        name = os.fsdecode(raw); p = root / name
        require(p.parent.resolve(strict=True) == p.parent and root in p.parents,'source-parent-alias-refused:' + name)
        try:
            first = p.lstat()
        except FileNotFoundError:
            rows.append({'path': name, 'state': 'missing'}); continue
        if stat.S_ISLNK(first.st_mode):
            data = os.fsencode(os.readlink(p)); kind = 'symlink'
        elif stat.S_ISREG(first.st_mode):
            data = p.read_bytes(); kind = 'file'
        else:
            raise RuntimeError('unexpected-source-kind:' + name)
        second = p.lstat()
        require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns, first.st_ctime_ns) ==
                (second.st_dev, second.st_ino, second.st_size, second.st_mtime_ns, second.st_ctime_ns), 'source-changed-during-snapshot:' + name)
        rows.append({'path': name, 'state': kind, 'mode': stat.S_IMODE(second.st_mode), 'bytes': len(data), 'sha256': sha(data)})
    return {'head': git_at(root, 'rev-parse', 'HEAD').decode().strip(),
            'status': git_at(root, 'status', '--porcelain=v1', '-z', '--untracked-files=all').decode(),
            'population': len(rows), 'rows': rows,
            'rowsSha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}

def regular_bytes(path):
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode), 'bound-file-not-regular:' + str(path))
    data = path.read_bytes(); second = path.lstat()
    require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns, first.st_ctime_ns) ==
            (second.st_dev, second.st_ino, second.st_size, second.st_mtime_ns, second.st_ctime_ns), 'bound-file-read-drift:' + str(path))
    return data

def file_row(root, name):
    relative = PurePosixPath(name)
    require(isinstance(name, str) and str(relative) == name and relative.parts and not relative.is_absolute()
            and all(part not in ('', '.', '..') for part in relative.parts) and '\\' not in name, 'unsafe-bound-relative-path')
    path = root / name
    require(root.resolve(strict=True) == root and path.parent.resolve(strict=True) == path.parent and root in path.parents, 'bound-file-parent-alias')
    data = regular_bytes(path)
    return {'path': name, 'bytes': len(data), 'sha256': sha(data)}

def ignored_runtime_snapshot(root):
    directory = root / RUNTIME
    if not directory.exists():
        require(not directory.is_symlink(), 'runtime-root-dangling-link')
        return {'state': 'absent'}
    require(directory.resolve(strict=True) == directory and directory.is_dir(), 'runtime-root-alias')
    rows = []
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), 'runtime-link-refused')
        if path.is_dir():
            rows.append({'path': str(path.relative_to(directory)), 'state': 'directory', 'mode': stat.S_IMODE(path.stat().st_mode)})
        else:
            row = file_row(directory, str(path.relative_to(directory))); row.update(state='file', mode=stat.S_IMODE(path.stat().st_mode)); rows.append(row)
    return {'state': 'directory', 'mode': stat.S_IMODE(directory.stat().st_mode), 'rows': rows,
            'rowsSha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}

def children():
    text = Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text()
    return [int(pid) for pid in text.split()]

def drain(record):
    """Reap only our children. Signal a still-owned child only through its pidfd."""
    reaped, forced = [], []
    record.update(noOwnedChildren=False, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
    began = time.monotonic()
    while True:
        while True:
            try: pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                record.update(noOwnedChildren=True, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
                return
            if not pid: break
            reaped.append({'pid': pid, 'status': status})
        elapsed = time.monotonic() - began
        if elapsed > 20: raise RuntimeError('owned child drain exceeded 20s; private TMP retained')
        if elapsed > 10:
            for pid in children():
                try:
                    fd = os.pidfd_open(pid)
                    try:
                        # A direct owned child cannot recycle its PID before our waitpid.
                        if pid in children():
                            sig = signal.SIGTERM if elapsed < 15 else signal.SIGKILL
                            signal.pidfd_send_signal(fd, sig)
                            forced.append({'pid': pid, 'signal': int(sig)})
                    finally: os.close(fd)
                except ProcessLookupError: pass
        time.sleep(.05)

def atomic_source(target, content, expected):
    mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
    temporary = None
    try:
        before = target.stat()
        require(not target.is_symlink() and sha_file(target) in expected, 'source preimage drift: ' + str(target))
        fd, name = tempfile.mkstemp(prefix='.f3-overlay-', dir=target.parent)
        temporary = Path(name); identity = temporary.stat()
        with os.fdopen(fd, 'wb') as stream:
            stream.write(content)
            stream.flush()
            os.fchmod(stream.fileno(), before.st_mode & 0o7777)
        current = target.stat()
        require((current.st_dev, current.st_ino) == (before.st_dev, before.st_ino) and sha_file(target) in expected, 'source changed before atomic replacement')
        os.replace(temporary, target)
    finally:
        try:
            if temporary is not None and temporary.exists():
                current = temporary.stat()
                require((current.st_dev, current.st_ino) == (identity.st_dev, identity.st_ino), 'owned source temporary identity drift')
                temporary.unlink()
        finally: signal.pthread_sigmask(signal.SIG_SETMASK, mask)

def verify_payload():
    manifest = json.loads(regular_bytes(HERE / 'manifest.json'))
    for row in manifest['files']:
        require(file_row(HERE, row['path']) == row, 'operator payload drift: ' + row['path'])
    source_packet = Path(manifest['sourcePacket'])
    raw = regular_bytes(source_packet / 'manifest.json')
    require(sha(raw) == manifest['sourceManifestSha256'], 'reviewed source manifest drift')
    for row in json.loads(raw)['files']:
        require(file_row(source_packet, row['path']) == row, 'reviewed source payload drift: ' + row['path'])
    return manifest

def verify_tools():
    binding = json.loads(regular_bytes(HERE / 'tool-bindings.json'))
    for row in binding['rows']:
        path = Path(row['path'])
        require(path.stat().st_size == row['bytes'] and sha_file(path) == row['sha256'], 'tool binding drift: ' + str(path))
    actual = sorted(str(path.relative_to(PRIMARY)) for name in binding['installedToolRoots']
                    for path in (PRIMARY / 'node_modules' / name).rglob('*') if path.is_file())
    require(actual == sorted(binding['installedToolFilesRelative']), 'installed tool population drift')
    require(Path('/usr/bin/cc').resolve() == Path('/usr/bin/x86_64-linux-gnu-gcc-15'), 'compiler alias drift')

def verify_candidate(config):
    require(PRIMARY.resolve(strict=True) == PRIMARY, 'primary alias')
    require(git_at(PRIMARY, 'rev-parse', 'HEAD').decode().strip() == config['subject'], 'HEAD drift')
    require(git_at(PRIMARY, 'rev-parse', 'HEAD^{tree}').decode().strip() == config['tree'], 'tree drift')
    require(not git_at(PRIMARY, 'diff', '--cached', '--name-only', '-z'), 'index is not frozen')
    require(not git_at(PRIMARY, 'ls-files', '--others', '--exclude-standard', '-z'), 'unexpected untracked source')
    changed = sorted(os.fsdecode(raw) for raw in git_at(PRIMARY, 'diff', 'HEAD', '--name-only', '-z').split(b'\0') if raw)
    require(changed == sorted(row['path'] for row in config['candidateBindings']), 'candidate changed paths drift')
    for row in config['candidateBindings']:
        actual = file_row(PRIMARY, row['path'])
        require(actual == {key: row[key] for key in ['path', 'bytes', 'sha256']}, 'candidate byte drift: ' + row['path'])
        require(stat.S_IMODE((PRIMARY / row['path']).stat().st_mode) == row['mode'], 'candidate mode drift')

def interrupt(sig, frame):
    raise InterruptedError('operator signal ' + str(sig))

def stop_leader():
    if CURRENT is not None and CURRENT.returncode is None:
        try: os.killpg(CURRENT.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try: CURRENT.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if CURRENT.poll() is None:
                try: os.killpg(CURRENT.pid, signal.SIGKILL)
                except ProcessLookupError: pass
            CURRENT.wait(timeout=5)

def run(name, argv, timeout):
    global CURRENT
    phase = {'name': name, 'command': argv, 'cwd': str(PRIMARY), 'exitCode': None, 'timeoutSeconds': timeout}
    HISTORY.append(phase); checkpoint(OUT, 'commands.json', HISTORY)
    began = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
        try: CURRENT = subprocess.Popen(argv, cwd=PRIMARY, env=ENV, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        finally: signal.pthread_sigmask(signal.SIG_SETMASK, mask)
        phase['pid'] = CURRENT.pid
        try: phase['exitCode'] = CURRENT.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            phase['timedOut'] = True
            stop_leader()
            phase['exitCode'] = CURRENT.returncode
        population = {}; drain(population); phase['children'] = population
        phase['elapsedSeconds'] = time.monotonic() - began
        CURRENT = None
    checkpoint(OUT, 'commands.json', HISTORY)
    require(not phase.get('timedOut') and population['noOwnedChildren'] and not population['forcedOwnedChildren'], 'timeout/forced child cleanup: ' + name)
    return phase

def classify(name, phase, expected, selected=None):
    raw = regular_bytes(OUT / (name + '.json')); report = json.loads(raw)
    rows = [row for suite in report.get('testResults', []) for row in suite.get('assertionResults', [])]
    wanted = json.loads(regular_bytes(HERE / 'expected-cases.json'))['cases']
    require(len(report.get('testResults', [])) == 1 and len(rows) == len(wanted) == 19, 'owning file/declaration denominator')
    require(sorted(row['fullName'] for row in rows) == sorted(row['fullName'] for row in wanted), 'owning case identity population')
    require(len({row['fullName'] for row in rows}) == 19, 'duplicate owning cases')
    counts = {status: sum(row['status'] == status for row in rows) for status in ['passed', 'failed', 'pending', 'skipped']}
    checkpoint(OUT, name + '-observed-counts.json', {'name': name, 'expected': expected, 'selected': selected,
      'reportSha256': sha(raw), 'returncode': phase['exitCode'], 'reportedSuccess': report.get('success'), 'counts': counts,
      'failures': [{'fullName': row['fullName'], 'failureMessages': row.get('failureMessages', [])}
                   for row in rows if row['status'] == 'failed'], 'classification': 'NOT_YET_VALIDATED'})
    require(report.get('numTotalTests') == 19 and report.get('numPassedTests') == counts['passed']
            and report.get('numFailedTests') == counts['failed'] and report.get('numPendingTests') == counts['pending'] + counts['skipped'], 'report/result counts disagree')
    if expected == 'baseline':
        require(phase['exitCode'] == 0 and report.get('success') is True and counts['passed'] == 19
                and not counts['failed'] and not counts['pending'] and not counts['skipped'], 'owning baseline failed or partial')
    else:
        target = next(row for row in rows if row['fullName'] == selected)
        require(all(row['status'] in ['pending', 'skipped'] for row in rows if row is not target), 'unselected mutant test ran')
        require(phase['exitCode'] == 1 and report.get('success') is False and target['status'] == 'failed'
                and counts['failed'] == 1 and counts['passed'] == 0 and counts['pending'] + counts['skipped'] == 18, 'mutant not killed by the exact selected case')
        messages = target.get('failureMessages', [])
        require(messages and all(isinstance(message, str) for message in messages), 'missing mutant failure evidence')
        require(any('AssertionError:' in message for message in messages), 'mutant compiler/setup/runtime failure is not assertion kill')
        require(not any(re.search(r'ENOENT|Command failed|fatal error:|error: unused|policy-git-usage-unavailable', message) for message in messages), 'spurious mutant setup/runtime failure')
    result = {'name': name, 'expected': expected, 'reportSha256': sha(raw), 'returncode': phase['exitCode'],
              'counts': counts, 'selected': selected, 'failures': [{'fullName': row['fullName'], 'failureMessages': row.get('failureMessages', [])}
                for row in rows if row['status'] == 'failed']}
    checkpoint(OUT, name + '-assessment.json', result)
    return result

def execute():
    global OUT, ENV
    parser = argparse.ArgumentParser(description='Only root runs this after independent source/operator review.')
    parser.add_argument('--subject', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    config = verify_payload()
    require(args.subject == config['subject'], 'explicit subject mismatch')
    require(args.output.is_absolute() and not args.output.exists() and not args.output.is_symlink(), 'output must be new absolute path')
    require(args.output.parent.resolve(strict=True) == BASE and args.output.parent.stat().st_uid == os.getuid(), 'output parent not canonical owned evidence base')
    for key in ['NODE_OPTIONS', 'NODE_PATH', 'VITEST_MAX_THREADS', 'VITEST_MIN_THREADS', 'VITEST_MAX_FORKS', 'VITEST_MIN_FORKS',
                'SYZYGY_COMPOSED_RETAIN', 'SYZYGY_F3_NATIVE_EVIDENCE_FILE', 'ESBUILD_BINARY_PATH']:
        require(not os.environ.get(key), 'runner override forbidden: ' + key)
    verify_candidate(config); verify_tools()
    OUT = args.output; OUT.mkdir(mode=0o700)
    scratch = Path(tempfile.mkdtemp(prefix='gp-', dir='/home/orca/.tmp')); identity = scratch.stat()
    ENV = dict(os.environ, TMPDIR=str(scratch), PATH=str(Path(NODE).parent) + ':/usr/bin:/bin')
    initial = snapshot_at(PRIMARY); runtime = ignored_runtime_snapshot(PRIMARY)
    checkpoint(OUT, 'source-before.json', initial); checkpoint(OUT, 'runtime-before.json', runtime)
    checkpoint(OUT, 'subject.json', {'subject': config['subject'], 'tree': config['tree'], 'manifestSha256': sha(regular_bytes(HERE / 'manifest.json')),
      'candidateBindings': config['candidateBindings'], 'TMPDIR': str(scratch), 'baselineSourcePopulation': initial['population']})
    record = {'complete': False, 'subject': config['subject'], 'phases': [], 'mutants': [], 'cleanupErrors': []}
    baseline_c = regular_bytes(HERE / 'candidate-supervisor.c'); baseline_sha = sha(baseline_c)
    mutations = json.loads(regular_bytes(HERE / 'mutations.json'))['mutants']
    allowed = {baseline_sha, *(row['sha256'] for row in mutations)}
    handlers = {}; subreaper = False
    try:
        require(not children(), 'operator already owns children')
        require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'subreaper unavailable'); subreaper = True
        for sig in [signal.SIGINT, signal.SIGTERM]: handlers[sig] = signal.signal(sig, interrupt)
        phase = run('typecheck', [NODE, NPM, 'run', 'typecheck'], 180)
        require(phase['exitCode'] == 0, 'typecheck failed; mutants not started')
        require(snapshot_at(PRIMARY) == initial and ignored_runtime_snapshot(PRIMARY) == runtime, 'typecheck source/runtime drift')
        common = [NODE, 'node_modules/vitest/vitest.mjs', 'run', '--project', 'integration', TEST, '--reporter=verbose', '--reporter=json']
        phase = run('owning', common + ['--outputFile=' + str(OUT / 'owning.json')], 180)
        record['phases'].append(classify('owning', phase, 'baseline'))
        require(snapshot_at(PRIMARY) == initial and ignored_runtime_snapshot(PRIMARY) == runtime, 'owning baseline source/runtime drift')
        for mutant in mutations:
            verify_candidate(config)
            target = config['mutantSelections'][mutant['id']]
            data = regular_bytes(HERE / mutant['path']); require(sha(data) == mutant['sha256'], 'mutant byte drift')
            name = 'mutant-' + mutant['id']
            item = dict(mutant, subject=config['subject'], candidateSha256=baseline_sha, selectedFullName=target, result='UNKNOWN')
            record['mutants'].append(item); checkpoint(OUT, 'progress.json', record)
            atomic_source(PRIMARY / C, data, {baseline_sha})
            phase = run(name, common + ['-t', '^' + re.escape(target) + '$', '--outputFile=' + str(OUT / (name + '.json'))], 120)
            item['assessment'] = classify(name, phase, 'mutant', target); item['result'] = 'ASSERTION_KILLED'
            require(not children(), 'owned children prevent source restoration')
            atomic_source(PRIMARY / C, baseline_c, allowed)
            require(snapshot_at(PRIMARY) == initial and ignored_runtime_snapshot(PRIMARY) == runtime, 'post-mutant source/runtime drift')
            checkpoint(OUT, 'progress.json', record)
        record['verificationPassed'] = True
    except BaseException as error:
        record['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
        def attempt(name, action):
            try: action()
            except BaseException as error: record['cleanupErrors'].append({'phase': name, 'type': type(error).__name__, 'message': str(error)})
        attempt('leader-stop', stop_leader)
        if CURRENT is not None and HISTORY: HISTORY[-1]['exitCode'] = CURRENT.returncode
        checkpoint(OUT, 'commands.json', HISTORY)
        if subreaper: attempt('owned-drain', lambda: drain(record))
        def restore():
            require(record.get('noOwnedChildren'), 'live owned children; refuse source restoration')
            current = sha_file(PRIMARY / C); require(current in allowed, 'unknown C source; refuse overwrite')
            if current != baseline_sha: atomic_source(PRIMARY / C, baseline_c, allowed)
            verify_candidate(config)
            after = snapshot_at(PRIMARY); checkpoint(OUT, 'source-after.json', after)
            require(after == initial, 'whole source population/diff not restored')
            record['sourceAndOriginalCandidateDiffRestored'] = True
        attempt('source-restore', restore)
        def runtime_after():
            after = ignored_runtime_snapshot(PRIMARY); checkpoint(OUT, 'runtime-after.json', after)
            require(after == runtime, 'ignored runtime changed'); record['ignoredRuntimeUnchanged'] = True
        attempt('runtime-snapshot', runtime_after); attempt('tools-after', verify_tools)
        def tmp_after():
            now = scratch.stat(); record['privateTMPIdentityUnchanged'] = (now.st_uid, now.st_dev, now.st_ino) == (os.getuid(), identity.st_dev, identity.st_ino)
            record['privateTMP'] = str(scratch); record['privateTMPRemainders'] = sorted(path.name for path in scratch.iterdir())
            require(record['privateTMPIdentityUnchanged'] and set(record['privateTMPRemainders']) <= {'node-compile-cache'},
                    'private TMP identity drift or unrecognized retained fixture remnants')
            cache = scratch / 'node-compile-cache'; rows = []
            if cache.exists() or cache.is_symlink():
                require(cache.is_dir() and not cache.is_symlink(), 'Node compile cache root is not a directory')
                for path in [cache, *sorted(cache.rglob('*'))]:
                    info = path.lstat()
                    require(info.st_uid == os.getuid() and (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)),
                            'Node compile cache ownership/kind drift')
                    row = {'path': str(path.relative_to(scratch)), 'mode': stat.S_IMODE(info.st_mode),
                           'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'file'}
                    if stat.S_ISREG(info.st_mode):
                        require(info.st_nlink == 1, 'Node compile cache linked file')
                        row.update(bytes=info.st_size, sha256=sha_file(path))
                    rows.append(row)
            record['retainedNodeCompileCache'] = rows
        attempt('private-TMP', tmp_after)
        record['pendingCleanupSignals'] = [int(sig) for sig in signal.sigpending() if sig in [signal.SIGINT, signal.SIGTERM]]
        record['commands'] = HISTORY
        record['rawFiles'] = [{'path': str(path.relative_to(OUT)), 'bytes': path.stat().st_size, 'sha256': sha_file(path)}
                              for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'terminal.json']
        record['complete'] = bool(record.get('verificationPassed') and record.get('noOwnedChildren') and not record.get('forcedOwnedChildren')
          and not record['cleanupErrors'] and record.get('sourceAndOriginalCandidateDiffRestored') and record.get('ignoredRuntimeUnchanged') and not record['pendingCleanupSignals'])
        checkpoint(OUT, 'terminal.json', record)
        # Keep cleanup blocked through process exit: a second signal cannot cut restoration/receipt short.
    print(json.dumps({'complete': record['complete'], 'terminal': str(OUT / 'terminal.json')}), flush=True)
    return 0 if record['complete'] else 90

if __name__ == '__main__':
    raise SystemExit(execute())
