#!/bin/sh
set -eu
exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/policy-git-supervisor-pidfd-owning-1ef-R1/run.py --subject 1ef23447df5c69fb1418f5c226bf6abd925e15ff --output /home/orca/.tmp/f3-native-admission-fixes/policy-git-supervisor-pidfd-owning-1ef-execution-1
