# Governance batch split candidate

Outside-only, prepared against `f9f514c5b3fe7fe12096972027ce1efead5d317d`. Candidate: `governance-docs.yml`; exact diff: `candidate.patch`; source/status/runner/metadata hashes: `binding.json`. No primary edits, CI runs or canonical checks were performed.

The workflow retains `governance` through `record_versioned_signoff --selftest`, then adds literal `git tag --list 'doctrine-*'` once as requested. New sibling `governance-continuation` starts with `prepare_three_surface_poc_governedby_reference_recording --check`. The first job holds47 original checks plus the orientation; the second holds87 original checks. The other three groups hold4 checks unchanged. Total:139 canonical commands, comprising138 checks and1 orientation. Two independent source parsers confirm this population; the normalized shell-argument multiset has every command exactly once. The existing checker intentionally calls only Python commands checks, so PROJECT-STATUS's138-check count remains correct.

Both governance jobs retain the original full-history checkout, Python3.11, runner image and15-minute safety timeout. PyYAML6.0.3 stays solely with the contract-index fixture in the first job. The existing Node24 setup and all subsequent pilot checks move intact with the tail. Triggers, permissions, concurrency cancellation, other three groups, command bytes/order within each partition and all fixture/predicate semantics are unchanged. There is no npm install or additional fixture execution.

The required `checks` job keeps `always()` and adds the continuation to needs, result environment and explicit exact-success AND. A missing, failed, skipped, cancelled, timed-out or neutral mandatory result fails this join. Existing gate behavior for the other four results is preserved.

## Actual cost and limitations

[Observed] Metadata for job138823853298 at associated PR head9c878b13f5ea7b819b4817517c675810d4b0f23c records545 seconds of job wall time. Its142 steps sum to543 timestamped seconds; setup/job/checkout/Python use about9 seconds. Existing named run steps sum to535 seconds. No observed command exceeds59 seconds (dossier v1.5 selftest); recorder selftest takes48 seconds and three behavior-act checks take34/34/35 seconds. Serialization is the measured issue, not a single demonstrated over420-second check.

[Observed] The split's first partition accounts for264 measured seconds, including2 seconds of pip installation; its second accounts for271 measured seconds before its unexecuted tail. The prior failure is the1-second review-campaign partition check;27 downstream canonical checks plus Node setup were skipped. Their current duration is Unknown. Whole-second metadata is not a fine-grained profiler. Queue time from push/run creation is Unknown because this packet contains job timestamps only. `measured-split-summary.json` enumerates every unmeasured command.

The current original workflow exactly matches the locally available measured PR-head workflow. However, the retained failure log is a bounded excerpt, not a full checkout log; tested synthetic-merge commit, parent/tree binding and exact executed source are Unknown in this packet. This does not replace rule7 execution provenance or claim a PR/workflow pass. Recorded timings are measurements for that hosted job, not a future guarantee. The420-second job/run budget remains outstanding until an actual complete hosted run after adoption.

## Scoped verification and mutation evidence

`verify_static.py` reads only frozen YAML and canonical source text. It executes the runner's extracted pure battery parser, never its main/commands. Its9 static checks pass. They assert exact prefix/tail/setup inheritance, original other-job structures, top-level policy equality,139-command multiplicities, one pinned pip installation and the exact five-result aggregate. Its13 static source mutants were all rejected, retaining exact old/new fragments in `static-validation.json`: omitted/duplicated/altered commands, removed orientation, shallow checkout, wrong Python/Node version, duplicated pip, omitted dependency/AND/always, hardcoded success and an altered other-group selftest. The static truth table checks30 non-success result cells and all-success acceptance. This is a static checker guard, not executed GitHub Actions or runtime fixture evidence.

The existing owning CG-26 checker and its orientation fixture are topology-agnostic and remain untouched. A scoped search enumerated574 source/test files; matching references and its limits are in `owning-test-inspection.json`. No owning test edit is necessary. No canonical predicate or case population grows.

Fresh review should confirm the frozen diff, exact139-command denominator, no lost or repeated fixture, checkout history on both groups and stable required check name. After applying/adopting, run the canonical project battery in a clean clone under the root's schedule; inspect the full output/denominator. The next hosted run must execute the formerly skipped tail and show each mandatory job and aggregate succeeding within the actual budget. Do not infer hosted timing acceptance from the264/271 partial measurements.

## R2 companion documentation correction

R1 independent review found that CONTRIBUTING.md still placed the governance battery in one job. R2 retains the exact reviewed workflow and static controls and changes that sentence to two jobs. The predecessor and candidate documentation are retained; contributing.patch is the complete companion diff. No historical timing statement or budget is changed. R1 is retired as an adoption-package verdict; its unchanged workflow analysis remains historical. This R2 package requires a fresh review before adoption.
