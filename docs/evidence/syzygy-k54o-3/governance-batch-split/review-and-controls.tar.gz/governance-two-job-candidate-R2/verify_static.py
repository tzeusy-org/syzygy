#!/usr/bin/env python3
"""Parse frozen sources/YAML and static mutants; execute no workflow commands."""
import ast
import collections
import copy
import hashlib
import json
from pathlib import Path
import re
import shlex
import yaml

ROOT = Path(__file__).resolve().parent
OLD = (ROOT / 'original-governance-docs.yml').read_text()
NEW = (ROOT / 'governance-docs.yml').read_text()
STATUS = (ROOT / 'PROJECT-STATUS.md').read_text()
BASELINE = yaml.safe_load(OLD)
GOV = BASELINE['jobs']['governance']
CUT = next(i for i, s in enumerate(GOV['steps'])
           if s.get('name') == 'record_versioned_signoff --selftest') + 1
TAG = {'name': 'doctrine tag orientation', 'run': "git tag --list 'doctrine-*'"}
SIBLING = 'governance-continuation'
OTHERS = ['reconciliation-selftest', 'p115-selftest', 'readability-selftest']
MANDATORY = ['governance', SIBLING, *OTHERS]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalize(command, variables=None):
    if not isinstance(command, str):
        raise ValueError('run is not text')
    variables = variables or {}
    command = re.sub(r'\$([A-Za-z_][A-Za-z0-9_]*)',
                     lambda m: variables.get(m[1], m[0]), command)
    return tuple(shlex.split(command, comments=True))


# Execute only the canonical runner's pure source parser, not its module/main.
runner_ast = ast.parse((ROOT / 'run_status_battery.py').read_text())
battery = next(n for n in runner_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'battery')
namespace = {'re': re, 'Path': Path, 'HEADING': '## How to verify this page',
             'STATUS': Path('PROJECT-STATUS.md'),
             'ASSIGNMENT': re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)=(\S*)$')}
exec(compile(ast.Module(body=[battery], type_ignores=[]), '<canonical-source-parser-only>', 'exec'), namespace)
CANONICAL = collections.Counter(normalize(c, v) for c, v in namespace['battery'](STATUS))
block = STATUS.split('## How to verify this page', 1)[1].split('```sh', 1)[1].split('```', 1)[0]
variables, independent = {}, []
for line in block.splitlines():
    line = line.strip()
    if not line or line.startswith('#'):
        continue
    assignment = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)=(\S*)', line)
    if assignment:
        variables[assignment[1]] = assignment[2]
    else:
        independent.append(normalize(line, variables))
assert CANONICAL == collections.Counter(independent)
assert sum(CANONICAL.values()) == 139 and all(n == 1 for n in CANONICAL.values())
assert sum(n for c, n in CANONICAL.items() if c[0] == 'python3') == 138


def verify(text):
    w = yaml.safe_load(text)
    checks = {}
    def require(name, condition):
        checks[name] = bool(condition)
    require('top-level-policy-unchanged', {k: v for k, v in w.items() if k != 'jobs'}
            == {k: v for k, v in BASELINE.items() if k != 'jobs'})
    require('exact-job-population-and-order', list(w['jobs']) == [*MANDATORY, 'checks'])
    a, b = w['jobs']['governance'], w['jobs'][SIBLING]
    expected_a = {**GOV, 'steps': GOV['steps'][:CUT] + [TAG]}
    expected_b = {'name': 'checks (governance continuation)', 'runs-on': GOV['runs-on'],
                  'timeout-minutes': GOV['timeout-minutes'],
                  'steps': GOV['steps'][:2] + GOV['steps'][CUT:]}
    require('first-group-exact-original-prefix-plus-tag', a == expected_a)
    require('continuation-exact-original-tail-plus-inherited-setup', b == expected_b)
    require('other-three-groups-unchanged', all(w['jobs'][key] == BASELINE['jobs'][key] for key in OTHERS))
    commands = []
    for key in MANDATORY:
        commands += [s['run'] for s in w['jobs'][key]['steps'] if 'run' in s]
    normalized = [normalize(c) for c in commands]
    actual = collections.Counter(c for c in normalized if c and c[0] != 'pip')
    require('canonical-command-multiset-139-of139', actual == CANONICAL)
    require('pinned-test-only-pip-exactly-once-first',
            [c for c in normalized if c and c[0] == 'pip'] == [('pip', 'install', 'PyYAML==6.0.3')]
            and any(s.get('run') == "pip install 'PyYAML==6.0.3'" for s in a['steps'])
            and not any(s.get('run', '').startswith('pip ') for s in b['steps']))
    expected_gate = copy.deepcopy(BASELINE['jobs']['checks'])
    expected_gate['needs'] = MANDATORY
    gate_step = expected_gate['steps'][0]
    gate_step['env']['GOVERNANCE_CONTINUATION'] = '${{ needs.governance-continuation.result }}'
    gate_step['run'] = gate_step['run'].replace('governance=${GOVERNANCE} ',
        'governance=${GOVERNANCE} governance-continuation=${GOVERNANCE_CONTINUATION} ')
    gate_step['run'] = gate_step['run'].replace('test "${GOVERNANCE}" = success',
        'test "${GOVERNANCE}" = success\ntest "${GOVERNANCE_CONTINUATION}" = success')
    require('required-gate-exact-always-AND-five-results', w['jobs']['checks'] == expected_gate)
    require('mandatory-jobs-no-continue-on-error', all('continue-on-error' not in w['jobs'][key] for key in MANDATORY))
    return checks


def main():
    results = verify(NEW)
    if not all(results.values()):
        raise AssertionError({k: v for k, v in results.items() if not v})
    header = NEW.split('  governance-continuation:', 1)[1].split('      - name: prepare_', 1)[0]
    header = '  governance-continuation:' + header
    mutants = [
        ('omit-canonical-check', 'run: python3 scripts/check_governance.py\n', 'run: echo omitted\n'),
        ('duplicate-canonical-check', 'run: python3 scripts/check_governance.py\n',
         'run: python3 scripts/check_governance.py\n\n      - name: duplicate check\n        run: python3 scripts/check_governance.py\n'),
        ('alter-predicate-command', 'run: python3 scripts/check_governance.py\n', 'run: python3 scripts/check_governance.py --selftest\n'),
        ('omit-orientation', "run: git tag --list 'doctrine-*'", 'run: echo orientation omitted'),
        ('shallow-continuation', header, header.replace('fetch-depth: 0', 'fetch-depth: 1')),
        ('wrong-python-continuation', header, header.replace("python-version: '3.11'", "python-version: '3.12'")),
        ('duplicate-pip-in-tail', header, header + "      - name: duplicate pip\n        run: pip install 'PyYAML==6.0.3'\n\n"),
        ('wrong-node-tail', 'node-version: 24', 'node-version: 22'),
        ('missing-continuation-need', 'needs: [governance, governance-continuation,', 'needs: [governance,'),
        ('hardcoded-continuation-success', '${{ needs.governance-continuation.result }}', 'success'),
        ('omitted-continuation-AND', '          test "${GOVERNANCE_CONTINUATION}" = success\n', ''),
        ('omitted-always', '    if: ${{ always() }}\n', ''),
        ('weaken-other-selftest', 'run: python3 scripts/build_three_surface_poc_readability_successor.py --selftest',
         'run: python3 scripts/build_three_surface_poc_readability_successor.py --check'),
    ]
    mutation_results = []
    for identity, old, new in mutants:
        if NEW.count(old) != 1 or old == new:
            raise AssertionError(f'nonunique or inert mutant: {identity}')
        failures = [name for name, passed in verify(NEW.replace(old, new, 1)).items() if not passed]
        if not failures:
            raise AssertionError(f'mutant survived: {identity}')
        mutation_results.append({'id': identity, 'old': old, 'new': new, 'caughtBy': failures})
    gate_vars = ['GOVERNANCE', 'GOVERNANCE_CONTINUATION', 'RECONCILIATION', 'P115', 'READABILITY']
    observed_tests = re.findall(r'^test "\$\{([A-Z0-9_]+)\}" = success$',
        yaml.safe_load(NEW)['jobs']['checks']['steps'][0]['run'], re.M)
    assert observed_tests == gate_vars
    bad_values = ['failure', 'skipped', 'cancelled', 'timed_out', 'neutral', None]
    gate_table = []
    for name in gate_vars:
        for bad in bad_values:
            values = dict.fromkeys(gate_vars, 'success'); values[name] = bad
            accepted = all(values.get(key) == 'success' for key in observed_tests)
            assert not accepted
            gate_table.append({'jobResultVariable': name, 'result': bad, 'accepted': accepted})
    assert all(dict.fromkeys(gate_vars, 'success').get(key) == 'success' for key in observed_tests)
    report = {'kind': 'static-source-YAML-only; no workflow command execution',
              'candidateYamlSha256': digest(NEW.encode()), 'canonicalCommands':139,
              'canonicalChecks':138, 'orientationCommands':1, 'allOriginalStepsPreserved':True,
              'checks':results, 'mutants':mutation_results, 'aggregateStaticTruthTable':gate_table,
              'allSuccessAccepted':True,
              'limits':['YAML parser is PyYAML; GitHub Actions schema/execution not run.',
                        'Truth table models the frozen explicit shell test statements; no shell/CI executed.',
                        'Hosted queue/tail cost and420-second acceptance remain Unknown.']}
    (ROOT/'static-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'checksPassed':len(results),'mutantsCaught':len(mutation_results),
                      'aggregateRefusalCells':len(gate_table),'canonicalCommands':139,
                      'canonicalChecks':138,'executedWorkflowCommands':0},indent=2))


if __name__ == '__main__':
    main()
