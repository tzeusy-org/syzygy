PASS

# Fresh source review: ordered-host inspection diagnostic

[Inferred] PASS for the diagnostic-only source candidate against the supplied acceptance criteria. No source-level revision finding. This verdict does not establish a behavior repair, type correctness, native execution success, or resolution of the historical failure.

[Observed] Review scope: the single-file candidate and patch in /home/orca/.tmp/f3-native-admission-fixes/hosted-a7bef3f82/ordered-host-diagnostic-candidate; the diagnosis, source plan, and their binding manifests in its parent; and the relevant existing observer/outcome implementation in the clean a7be source checkout. Review applied engineering-bar, test-rigor, and heart-and-soul security/trust-and-evidence. Only read-only git, source inspection, Python byte comparisons, and hashing were used before writing this raw report. No tests, native programs, builds, provider calls, archive operations, canonical battery, or repository source edits were performed. Typecheck and the owning native cases remain pending in the root execution lane.

## Reviewed byte bindings

[Observed] Baseline checkout /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w reports HEAD a7bef3f82605e104830c72c671ba4266d581705d and an empty git status --short. Its test file equals git show for that exact commit.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Baseline packages/polaris-dossier/src/url-ordered-design-host.test.ts | 42691 | 84c6468c6750e1f1921bf39e3cecade1f20c042c7bd8dc558d091b73852aca27 |
| Candidate url-ordered-design-host.test.ts | 42972 | a35e3b80bcff869dda934700026a8901d7e68abb88e6a9c9b80795ef9971faec |
| candidate.patch | 3071 | ddac2eab7253bd89e395a183aac6d4513a07d0980cabf4001a879f0d54d6344f |
| Candidate bindings.json | 542 | 6eb11870dac3793e086757256b9cccd7d86ddba652b4a19a51600991417cd905 |
| Existing session-launch.ts | 47453 | de5c117778f248a296b5cb26d8d46572e5cd4d2342b1a8f0077a2adc8dddf176 |
| ordered-host-source-PLAN.md | 2125 | efefca6a0ce59338adb3edc3d71ceac0b005a069ade9dd3692537acafc9f0a1a |
| ordered-host-diagnosis-RAW.md | 7625 | 226e64c4b52b9c9a5644aaaefe8ada76a4f25c24d84abff961b792d18cba501b |
| ordered-host-diagnosis-bindings.json | 2251 | 0186b0ff62bfe438249bbcb17abb564e15d6d2c9b018e37b90e98706e1acea50 |

[Observed] Recomputed the SHA256 and byte count for all seven source entries and all four retained-input entries in ordered-host-diagnosis-bindings.json: each matches its manifest. Candidate/base/patch SHA256 values also match candidate bindings.json. Independently generating a unified diff from baseline and candidate reproduces candidate.patch byte-for-byte. The patch has exactly one target path and four hunks: import, observer attachment/null guard, result snapshot, and diagnostic expansion.

## Scope and assertion preservation

[Observed] Candidate lines 495-496 attach the existing observeUrlSessionInspectionForTest immediately after preparation and before host binding or launch. Line 526 reads it once after the launch outcome settles and the existing monitor is disabled. Lines 530-531 add the snapshot and the existing full launch outcome to exchangeDiagnostic.

[Observed] A complete literal-line sweep found 58 lines containing expect( in each file. Their joined original bytes are equal; SHA256 02e1b81c5465ac11e3d0a5954bcb1b651d25cff261374abe0437bcb3f804ef6f. The two additional expect.poll lines are unchanged as well. A direct byte comparison and independent digest comparison establish that the entire native describe block is identical: 3933 bytes, SHA256 7ef277a12521ae922ea8db766b4c2ddb3446dc87e406cc6084904680004be952. It retains the positive case, send revocation, and the stage/proof-expiry parameterized cases (four executions). Inspection of the exact four-hunk diff independently confirms no assertion, limit, callback, mock implementation, deadline, test declaration, or production source change. Net test-case delta is zero.

## Observer content, polarity, and lifecycle

[Observed] Existing session-launch.ts:116-122 requires a genuine unconsumed preparation and permits only one observer. Registration reads limits and installs a trace; it does not invoke current, verify, confirm, filesystem inspection, or launch. The returned reader only structuredClone's the retained trace. It supplies no launch/effect capability. The candidate's explicit null rejection is fixture setup failure, never a success fallback.

[Observed] Existing trace types at session-launch.ts:89-112 retain numeric timing/count metadata, fixed phase/outcome/cause enums, and an optional fixed storage operation/cause/errno tuple. The persistent trace has only latest and firstRefusal samples, each with the fixed five-phase keyspace; it does not accumulate a sample array. beginInspectionTrace:125-158 assigns firstRefusal on failure and does not convert refusal to acceptance. Raw error identities remain only inside the existing per-sample matching closure; they are not members of the cloned trace. Storage annotation at :358-379 and :502-503 passes the closed tuple rather than error messages, filenames, bodies, credentials, or raw IO.

[Observed] Launch consumes and deletes both preparation-map and observer-map entries at session-launch.ts:586-589, retaining the selected trace locally for that launch. The getter closure still reaches that same trace after consumption. No replacement-preparation path is invoked by nativeExchange. After result construction, the returned inspection value is a clone rather than a live authority object. The finished launch outcome at :761-764 is explicitly assembled and frozen: outcome/termination/exit fields, counts, sampled resource values, and stdout/stderr byte counts plus hashes. It contains no stdout/stderr bodies, command arguments, paths, source text, or credential headers.

[Inferred] Reading the terminal snapshot is suitable for the target inspection-failed diagnostic: the existing authority refusal writes its refusal before stop(:736-737), and the rejection handler records its rejection before stop(:741-744). A snapshot taken during another kind of shutdown can legitimately contain an unsettled phase; the candidate does not claim that every asynchronous operation has settled. This limitation is not a reason to add waits or authority work to this diagnostic.

[Inferred] Enabling the existing observer adds bounded bookkeeping and cloning cost, so this review makes no timing-neutrality claim. Its existing observed process/storage branches preserve rejection polarity and use the same canonical resource deadlines; the candidate introduces no extra authority callback or mock behavior. Canonical cadence/resource/aggregate values remain 200/2000/5000ms.

## Evidence limits

[Unknown] The exact historical inspection predicate remains Unknown. Approximately two seconds of whole-case duration does not establish exhaustion of the two-second inspection resource deadline. This candidate retains information for a future diagnosis; a passing run alone would not explain the historical failure. The reviewed plan correctly keeps a causal repair conditional on capturing the failing predicate.

[Unknown] Typecheck and the four owning native cases have not been executed for these candidate bytes by this reviewer. The canonical battery remains the root lane's sole heavy gate. This PASS is a fresh source-only review bound to the artifact digests above; editing those artifacts retires it.
