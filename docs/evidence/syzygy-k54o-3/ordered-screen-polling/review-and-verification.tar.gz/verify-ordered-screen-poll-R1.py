import datetime,hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
candidate=Path('/home/orca/.tmp/f3-native-admission-fixes/ordered-screen-poll-candidate')
out=Path('/home/orca/.tmp/f3-native-admission-fixes/ordered-screen-poll-focused-R1')
assert not out.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(candidate/'bindings.json')=='82bd8bbede08ea49baaf158659c60eaf31b72f8f8308f8cd58fb2cfe0fcd822a'
b=json.loads((candidate/'bindings.json').read_text())
for f in b['files']:assert h(candidate/f['path'])==f['sha256']
for f in b['changedFiles']:
 p=root/f['path'];assert p.exists()==f['baseline']['exists']
 if p.exists():assert h(p)==f['baseline']['sha256']
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
for f in b['changedFiles']:(root/f['path']).write_bytes((candidate/'candidate'/f['path']).read_bytes())
out.mkdir()
scratch=Path(tempfile.mkdtemp(prefix='p-',dir='/home/orca/.tmp'));scratch.chmod(0o700)
env={**os.environ,'TMPDIR':str(scratch),'VITEST_MAX_THREADS':'1','VITEST_MIN_THREADS':'1','VITEST_MAX_FORKS':'1','VITEST_MIN_FORKS':'1'}
vitest=['node','node_modules/vitest/vitest.mjs','run'];folder='packages/polaris-dossier/src/'
commands=[('typecheck',['npm','run','typecheck','--','--pretty','false']),('poll-unit',vitest+['--project','unit',folder+'url-ordered-design-screen-poll.test.ts']),('screen-integration',vitest+['--project','integration',folder+'url-ordered-design-screen.test.ts']),('inspection-integration',vitest+['--project','integration',folder+'session-launch.test.ts','--testNamePattern=keeps the 200ms cadence|keeps ordered inspection authority and resource deadlines distinct|joins independent inspection authority with the live census'])]
results={'baseCommit':base,'candidateBindingSha256':h(candidate/'bindings.json'),'scope':'frozen five-file overlay in clean-base clone; no native/fullgate claim','tmpdir':str(scratch),'commands':[]}
for name,command in commands:
 if name!='typecheck':command+=['--reporter=default','--reporter=json','--outputFile='+str(out/(name+'.json'))]
 began=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:done=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'exit':done.returncode,'elapsedSeconds':time.monotonic()-began,'logSha256':h(out/(name+'.log'))}
 if name!='typecheck' and (out/(name+'.json')).exists():
  report=json.loads((out/(name+'.json')).read_text());row['population']={k:report.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','numPassedTestSuites']}
  assert report.get('numTotalTests',0)>0
 results['commands'].append(row);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if done.returncode:raise SystemExit(done.returncode)
