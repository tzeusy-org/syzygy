PASS

Independent combined design, source, and test review R1 of the frozen outside-only ordered-screen-poll candidate. This verdict permits proceeding to the proposed verification; it is not a passing runtime test, an adoption, or evidence of recovered native execution.

Subject and binding

[Observed] Reviewed packet: /home/orca/.tmp/f3-native-admission-fixes/ordered-screen-poll-candidate. Baseline subject f9f514c5b3fe7fe12096972027ce1efead5d317d; baseline tree 2815715549fce908e365b84b3ff19151a32f2c31. bindings.json SHA-256: 82bd8bbede08ea49baaf158659c60eaf31b72f8f8308f8cd58fb2cfe0fcd822a. candidate.patch SHA-256: b021099f67cd2d2cc80727805260c45616791b789c1505191ad131d3c1f54dcc. DESIGN.md SHA-256: 02eed7021de4377dd4e271bcf280fbd15706a01e3076089bbc696daea25b9466. TEST-PLAN.md SHA-256: 711d045fd7aa32db2ed504730f919656b849a3542797e88131a4a518d5a17686. Any changed subject bytes retire this review.

[Observed] Independently recomputed the bytes and SHA-256 of the 23 entries in bindings.json with Python, then checked the same 23 digests with sha256sum --check --strict, reading its individual OK results. Compared the four existing baseline source files with git show at the subject using both byte comparison and cmp; confirmed the new unit file is absent at that subject. Strict in-memory unified-patch application verifies each original hunk and count, and verifies scheduling.patch followed by diagnostics.patch yields the same five-file result as candidate.patch. Intermediate and final bytes match the retained scheduling-stage and candidate files. No patch was applied to a checkout.

Review references and scope

[Observed] Read repository AGENTS.md, the heart-and-soul, engineering-bar and test-rigor skills, SEC-5 and VIS-4, the frozen governing excerpts, DESIGN.md, TEST-PLAN.md, full patch, full screen implementation and screen integration tests, and the relevant launcher sampling and composed-observer source context. Checked the baseline tier routing: a file outside the explicit integration/e2e/live lists defaults to unit; the existing ordered-screen and composed files are integration. Read the retained diagnosis metrics as supporting evidence, without treating the diagnosis as established causality.

[Inferred] The proposed change stays within ordinary agent adoption under VIS-4: “Agents decide everything else,” including screening and classification policy within SEC-5. SEC-5 says “Anything that matches the declared secret-detection policy, or cannot be classified, is excluded”; the patch changes neither detector/classifier code nor the content acceptance predicate. Adoption and required checks remain the implementation owner's work. The review did not authorize a release, exposure change, observed-code execution outside a sandbox, or a weakened classification rule.

Scheduling, guards and cleanup

[Observed] url-ordered-design-screen.ts:83–95 schedules the first check after 20 ms and the next timeout only after current() returns. close sets closed and clears the pending timeout; the post-current closed check covers reentrant closure. A thrown current sets closed before invoking stop and returns without scheduling another poll. The integration retains the original current closure rather than replacing it with a cached grant or weaker predicate.

[Inferred] The new cadence provides the specified minimum interval after completion of the synchronous check. It does not guarantee 20 ms revocation latency or prove that a real census completes within its unchanged bound. The removal of repeated interval callbacks after the first thrown current does not weaken the refusal path: stop marks failed and sends the existing process-group SIGKILL, the independent wall timer remains, close cancels polling, and a failed child cannot produce an accepted result. Repeated authority checks after that irrevocable failure are unnecessary for the requested security property.

[Observed] The full candidate and patch retain initial validation, image-read guards, full checks around held-image hashing, held/named image identity tests, charging before spawn, the full post-charge check, deadline clipping, sandbox argv, CPU/address/output limits and child kill logic. Splitting the final child-status conditional from the original held/current/deadline conditional preserves its short-circuit order and success requirements. Output parsing, canonical encoding, identity validation and fail-closed catch remain. Descriptor closure stays in finally. The launcher changes only its sample shape and initialization; its 2000 ms census and 5000 ms ordered aggregate join remain unchanged.

Passive diagnostics

[Observed] The final callback is invoked from finally after the existing held-descriptor close attempts. The constructed frozen snapshot has exactly the declared ten scalar/enum fields; no body, path, raw output/error, PID, private worker refusal text, history, or new authority lookup is added. Poll clocks and aggregate updates are conditional on the optional observer. The first recorded stop trigger is retained, with a generic execution-refused fallback. A clean wrapper execution carrying a content refusal is represented as execution accepted/content refused.

[Inferred] The snapshot is bounded under the existing child/run bounds and the new minimum polling cadence. childSpawned only establishes the trusted supervisor's spawn event, as DESIGN.md explicitly states. The observer is trusted synchronous instrumentation; catching exceptions preserves the selected result, but cannot guarantee a caller's later deadline remains current after an arbitrarily slow callback. The design correctly discloses that limit.

[Observed] The composed observer leaves result.ok && result.observation.outcome.result.ok unchanged, records one fixed-size final snapshot on the bounded inference-step record, and forwards the prior observer once with exceptions caught. Existing inference retention caps remain. session-launch.ts initializes startedMonotonicMs from the already captured sampleBegan through beginInspectionTrace; it adds no clock or authority read. The source and design distinguish absolute monotonic starts from the composed relative observedMs clock.

Tests and verification note

[Observed] Net suite growth is four hermetic unit cases: slow successful polling, a thrown authority check, closure before the first callback, and reentrant closure during the callback. The new file imports the source helper without executing the module's process runner. The existing screen integration cases gain assertions for a frozen allow-listed accepted snapshot, accepted execution with secret-content refusal, pre-child authority refusal, throwing observer isolation, and live authority stop with retained charging. They retain the prior result/security assertions and add no sandbox invocation. The pre-existing nearest integration tests do not exercise the deterministic timer-boundary cases.

[Inferred] Those four cases earn their cost: they distinguish continued scheduling from withdrawal, cancellation from a merely suppressed callback, and reentrant cleanup from unconditional rescheduling. The integrations test observable execution/content distinctions and result isolation, rather than rechecking a copied implementation formula.

[Inferred; nonblocking verification note] In url-ordered-design-screen-poll.test.ts:14, vi.getTimerCount() === 0 during current is a structural assertion. Replacing the helper with the original interval can fail there before reaching the end-to-start gap and census assertions. This is consistent with the explicit design invariant of no outstanding poll while a check runs, so it is not a correctness finding. However, mutation evidence must name this actual failing predicate. Do not report that mutant alone as observed proof that the 20 ms gap assertion detects the predecessor. If gap-specific mutation evidence is desired, separately break the reschedule delay or isolate that behavioral predicate, and retain its exact failure. The existing starts [20, 240], end 220, intervening callback, and difference-of-20 assertions still directly specify the intended temporal behavior.

Limits and conclusion

[Unknown] Typecheck, unit/integration/mutation results, native interrupted recovery, final capture, native performance and exact original failure causality. No tests, builds, typecheck, worker/helper execution, native runs, provider/network calls, or heavy commands were run in this review. Read-only hashing, parsing, git-object comparisons, source inspection and writing this external raw report were the only actions.

[Inferred] No blocking design/source/test finding was identified in the reviewed change. The retained metrics establish the actual 2 s census refusal, while screen spawn/poll participation and earliest causal ordering remain Unknown. Proceed with the proposed isolated verification and original native scenario, preserving those Unknowns unless new evidence resolves them.
