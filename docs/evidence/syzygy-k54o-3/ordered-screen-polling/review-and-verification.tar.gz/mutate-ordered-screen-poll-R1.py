import hashlib,json,os,re,subprocess,tempfile,time
from pathlib import Path
root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
base=Path('/home/orca/.tmp/f3-native-admission-fixes/ordered-screen-poll-focused-R1')
out=Path('/home/orca/.tmp/f3-native-admission-fixes/ordered-screen-poll-mutants-R1');out.mkdir(exist_ok=False)
source=root/'packages/polaris-dossier/src/url-ordered-design-screen.ts';original=source.read_text();sha=lambda b:hashlib.sha256(b).hexdigest()
helper=original[original.index('export function startOrderedDesignScreenCurrentPolling'):original.index('/** Invoke only after')]
interval='''export function startOrderedDesignScreenCurrentPolling(current: () => void, stop: () => void): () => void {
  const timer = setInterval(() => { try { current(); } catch { stop(); } }, 20);
  return () => clearInterval(timer);
}

'''
observer='''    try { options.observeProgress?.(Object.freeze({ stage, startedMonotonicMs: started, childSpawned, childClosed,
      pollCount, pollTotalMs, pollMaximumMs, stopReason, execution, content })); }
    catch { /* Observation grants no authority and cannot replace the result. */ }'''
observe_throws='''    options.observeProgress?.(Object.freeze({ stage, startedMonotonicMs: started, childSpawned, childClosed,
      pollCount, pollTotalMs, pollMaximumMs, stopReason, execution, content }));'''
content='''    if (isRecord(observation.outcome.result)) content = observation.outcome.result.ok === true ? 'accepted'
      : observation.outcome.result.ok === false ? 'refused' : 'Unknown';'''
mutants=[('breathing-gap-too-short','if (!closed) timer = setTimeout(poll, 20);','if (!closed) timer = setTimeout(poll, 19);','poll-unit','leaves twenty milliseconds','A nineteen-millisecond gap must fail the stated twenty-millisecond cadence while retaining no pending timer during a running check.'),('original-interval',helper,interval,'poll-unit','leaves twenty milliseconds','Structural no-outstanding-poll assertion may reject before gap; do not claim native causality.'),('close-no-cancel','return () => { closed = true; clearTimeout(timer); };','return () => {};','poll-unit','cleans up a child closing before-check','Cancellation prevents callbacks after close.'),('reschedule-after-withdrawal','catch { closed = true; stop(); return; }','catch { stop(); }','poll-unit','stops on a thrown fresh authority','No polling after a refused full check.'),('observer-errors-escape',observer,observe_throws,'screen-integration','reissues the exact profile','Observer exception must not replace the original successful result.'),('content-collapsed',content,"    if (isRecord(observation.outcome.result)) content = 'accepted';",'screen-integration','keeps private no-path secret','Execution and content refusal are independent diagnostic facts.')]
scratch=Path(tempfile.mkdtemp(prefix='p-',dir='/home/orca/.tmp'));scratch.chmod(0o700);env={**os.environ,'TMPDIR':str(scratch),'VITEST_MAX_FORKS':'1','VITEST_MIN_FORKS':'1'}
result={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceSha256':sha(original.encode()),'scope':'intentional isolated source mutants against exact reviewed overlay, not native/fullproof','mutants':[]}
try:
 for name,old,new,group,needle,predicate in mutants:
  assert source.read_text()==original and original.count(old)==1,(name,original.count(old))
  report=json.loads((base/(group+'.json')).read_text());cases=[t for suite in report['testResults'] for t in suite['assertionResults'] if needle in t['fullName']];assert len(cases)==1 and cases[0]['status']=='passed',(name,[t['fullName'] for t in cases])
  file='url-ordered-design-screen-poll.test.ts' if group=='poll-unit' else 'url-ordered-design-screen.test.ts';project='unit' if group=='poll-unit' else 'integration';mutation=original.replace(old,new);source.write_text(mutation)
  command=['node','node_modules/vitest/vitest.mjs','run','--project',project,'packages/polaris-dossier/src/'+file,'--testNamePattern=^'+re.escape(cases[0]['fullName'])+'$','--reporter=default','--reporter=json','--outputFile='+str(out/(name+'.json'))]
  start=time.monotonic()
  try:
   with (out/(name+'.log')).open('wb') as log:done=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  finally:source.write_text(original)
  r=json.loads((out/(name+'.json')).read_text());failed=[t for suite in r['testResults'] for t in suite['assertionResults'] if t['status']=='failed'];assert done.returncode!=0 and len(failed)==1 and failed[0]['fullName']==cases[0]['fullName'],(name,done.returncode,r.get('numPassedTests'),r.get('numFailedTests'))
  row={'id':name,'old':old,'new':new,'predicate':predicate,'fullName':cases[0]['fullName'],'sourceSha256':sha(mutation.encode()),'exit':done.returncode,'elapsedSeconds':time.monotonic()-start,'command':command,'population':{k:r.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']},'failures':failed[0].get('failureMessages'),'logSha256':sha((out/(name+'.log')).read_bytes())};result['mutants'].append(row);(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['id','exit','elapsedSeconds','population']}),flush=True)
finally:
 source.write_text(original)
 assert sha(source.read_bytes())==result['sourceSha256']
