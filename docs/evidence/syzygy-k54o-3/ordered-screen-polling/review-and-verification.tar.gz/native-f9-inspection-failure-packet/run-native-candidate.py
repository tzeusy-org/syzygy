"""Run one original genuine recovery case in a clean exact-commit clone.

Retain native cut/observation versions and actual execution-record bytes while
the original tests run. This harness supplies no product calls or test filters.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import tempfile

root = Path(sys.argv[1]).resolve()
subject = sys.argv[2]
out = Path(sys.argv[3]).resolve()
scenario = sys.argv[4]
assert scenario in ('stop-resume', 'eligible-stop-resume')
assert re.fullmatch(r"[0-9a-f]{40}", subject)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip() == subject
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=root)
out.mkdir(exist_ok=False)
(out / "retained").mkdir()
private_tmp = Path(tempfile.mkdtemp(prefix="f3-", dir="/home/orca/.tmp"))
# /home/orca/.tmp inherits the shared group's setgid bit. Protected-store
# fixtures require exact private modes; clear inheritance on this owned scratch
# directory before any fixture is created. Never apply this to project paths.
private_tmp.chmod(0o700)
assert (private_tmp.stat().st_mode & 0o7777) == 0o700
# Inventory is the longest fixed role: /syz-url-XXXXXX/inventory/b/b.sock.
# Keep enough room for the exact existing 103-byte launch admission ceiling.
assert len(str(private_tmp).encode()) + len("/syz-url-XXXXXX/inventory/b/b.sock") <= 103
(out / "tmpdir.json").write_text(json.dumps({"path": str(private_tmp), "mode": "0700", "bytes": len(str(private_tmp).encode())}, indent=2) + "\n")
env = os.environ.copy()
env.update(TMPDIR=str(private_tmp), VITEST_MAX_THREADS="1", VITEST_MIN_THREADS="1",
           VITEST_MAX_FORKS="1", VITEST_MIN_FORKS="1",
           SYZYGY_COMPOSED_RETAIN=str(out / "native-cut.json"),
           SYZYGY_F3_NATIVE_EVIDENCE_FILE=str(out / "native-observation.json"))
started = time.time()
manifest = {"subject": subject, "tree": subprocess.check_output(
    ["git", "rev-parse", "HEAD^{tree}"], cwd=root, text=True).strip(),
    "clone": str(root), "tmpdir": str(private_tmp), "command": ["node", "node_modules/vitest/vitest.mjs", "run", "--project", "integration",
                "packages/polaris-dossier/src/url-run-composed.test.ts",
                "--testNamePattern=runs the genuine production pipeline to " + scenario + "$"],
    "scenario": scenario,
    "startedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "retention": "original native-cut and observation versions plus actual record.json bytes; no product probes"}
(out / "subject.json").write_text(json.dumps(manifest, indent=2) + "\n")
seen = set()
run_paths = set()
captures = []
workers = set()
maximum = 0
peak_rss_kib = 0


def retain(name, data, origin):
    digest = hashlib.sha256(data).hexdigest()
    key = (name, digest)
    if key in seen:
        return
    seen.add(key)
    target = f"{name}-{digest}.json"
    (out / "retained" / target).write_bytes(data)
    captures.append({"at": time.time(), "kind": name, "file": target,
                     "sha256": digest, "bytes": len(data), "origin": str(origin)})
    (out / "capture-index.json").write_text(json.dumps(captures, indent=2) + "\n")


def capture():
    for name in ("native-cut.json", "native-cut.json.failure.json", "native-observation.json"):
        path = out / name
        try:
            data = path.read_bytes()
            value = json.loads(data)
        except (OSError, ValueError):
            continue
        run = value.get("run")
        if isinstance(run, str) and Path(run).is_absolute():
            run_paths.add(Path(run))
        retain(name.removesuffix(".json"), data, path)
    for run in run_paths:
        path = run / "record.json"
        try:
            data = path.read_bytes()
            record = json.loads(data)
        except (OSError, ValueError):
            continue
        if record.get("format") == "polaris-dossier-execution-record/2":
            retain("execution-record", data, path)


def census():
    global maximum, peak_rss_kib
    current = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            if os.readlink(entry / "cwd") != str(root):
                continue
            title = (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            if re.match(r"node \(vitest [0-9]+\)", title):
                current.append(int(entry.name))
                for row in (entry / "status").read_text().splitlines():
                    if row.startswith("VmRSS:"):
                        peak_rss_kib = max(peak_rss_kib, int(row.split()[1]))
        except OSError:
            continue
    maximum = max(maximum, len(current))
    workers.update(current)


with (out / "check-all.log").open("wb") as log:
    process = subprocess.Popen(manifest["command"], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    (out / "pid").write_text(str(process.pid) + "\n")
    print(json.dumps({"state": "running", "subject": subject, "pid": process.pid, "artifacts": str(out)}), flush=True)
    while process.poll() is None:
        capture()
        census()
        time.sleep(0.5)
    capture()
    census()
result = {**manifest, "exit": process.returncode, "elapsedSeconds": time.time() - started,
          "finishedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "maxNumberedVitestWorkers": maximum, "workerPids": sorted(workers),
          "workerCensusMethod": "proc cwd and numbered process title every500ms; internal threads not counted",
          "captureCount": len(captures), "numberedVitestPeakRssKiB": peak_rss_kib, "logSha256": hashlib.sha256((out / "check-all.log").read_bytes()).hexdigest()}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"state": "terminal", "exit": process.returncode, "elapsedSeconds": result["elapsedSeconds"]}), flush=True)
sys.exit(process.returncode)
