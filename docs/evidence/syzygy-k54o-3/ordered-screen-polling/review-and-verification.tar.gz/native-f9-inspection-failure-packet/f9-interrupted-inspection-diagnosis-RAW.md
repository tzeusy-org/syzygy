# Exact-head f9 interrupted recovery: independent retained-evidence diagnosis

[Observed] Subject f9f514c5b3fe7fe12096972027ce1efead5d317d, tree2815715549fce908e365b84b3ff19151a32f2c31. Exact retained subject.json selects the clone; its HEAD and inspected source files match that commit byte-for-byte. Worktree porcelain was empty before/after. Bindings and computed metrics accompany this report. No new test, probe, helper, capture, build, source edit, provider or network call was performed. Parent separately owns native process/bridge log analysis.

[Observed] The genuine interrupted scenario exited1 after374.710185s with one numbered Vitest worker and peak RSS544484KiB. Resumed render8643.622692ms/admission accepted; producerRefusal=false. The failure is now beyond the previously failing prepared MCP reply: broker invoke, mediation, host action, release, release-check and final-budget all accepted. Actual host action25669.132ms; prepared append13332.821ms. No store refusal entries were recorded (entries0, omitted0). This does not prove no possible unreported authority refusal; store diagnostics specifically name selected deadline guards.

## Exact rejecting predicate and the retained denominator

[Observed] Resumed inferenceCount10 means10 mediation records, with9 accepted and1 refused: ordinal10. It does not mean10 accepted mediations. Ordinal10's product preparation accepted in22107.551ms, including genuine reproduction17271.402ms and checked delivery read1935.437ms. Prepared-product current137.217ms accepted; the request's full controller current2225.788ms and product assertion672.966ms accepted. The relay request then refused after7730.204ms; its screening wrapper refused after4087.042ms. The mediation refused after36703.413ms.

[Observed] Design launcher sample358 is the first retained actual low-level refusal: phase=storage, cause=bounded-timeout, elapsed2203.984027ms. Its process phase began at0.049473ms and storage phase at0.091963ms, neither with a settled stamp. The independently retained authority observer reached only357 samples; each of those357 verified and confirmed successfully. Latest/last confirmed ordinal357 ended at284722.506 diagnostic milliseconds. No verify or confirm refusal is retained. Sample358 did not reach authority verification. The launcher reports selected aggregate inspection5000ms, but source explicitly clips its process/storage census to min(selected inspection, ordinary inspection2000ms)=2000ms. The resource timeout is not exhaustion of the5000ms ordered authority-join envelope. It is also not a stored filesystem errno/type/entry-count rejection: no storageFailure detail is attached.

[Observed source] The resource timer's rejection is tagged with the current outer census phase. That phase remains storage until storage() finishes, while the process walk runs concurrently. Consequently this exact observation establishes that the complete shared census failed to settle in its two-second bound while storage was still the publication phase. It does not identify the slow pending descriptor operation, prove a storage syscall itself blocked for2203ms, prove process completion, or distinguish I/O latency, scheduling pressure, slow progress, retries or an unobserved earlier subordinate cause. A timer callback can run late; observed2203.984ms is not an authorized limit increase.

## What the wrapper outcomes do and do not prove

[Observed source] The test labels screening-worker accepted only when result.ok AND result.observation.outcome.result.ok. A refused label therefore conflates execution/authority/worker failure with a successfully executed content predicate refusing the request. The retained record includes neither underlying result.ok/reason/charge nor the content refusal enum. The4087ms wrapper interval supplies no evidence of exhausting the worker's20000ms cap. It cannot prove the worker had even spawned: image verification and input encoding are inside the same observed call.

[Observed source] The inference effect observer uses an unconditional () => true acceptance predicate. Its accepted label means the callback resolved; it is not proof of request admission, send success or a successful enclosing native mediation. Source requires a further native boundary after await effect(). A launcher stop can invalidate that boundary even if the callback returned an ordinary refusal value. The21 retained audit rows end with machine-peer:inference-forward after ordered:prepared; there is no later attempt-allowed/send-attempt row in this retained audit population. Do not infer a second provider request from the effect wrapper.

[Observed] Broker population1 invocation, first peer invocation1, all retained broker stages accepted. MCP ingress population2 reads: one data and one end, no refused/rejected read. Three native connections accepted capture/authorization: initial inference, MCP shim, then a fresh inference bridge. This places the current refusal after a genuinely delivered prepared result and accepted replacement-product work, rather than in the prior MCP store envelope.

[Observed] firstRuntimeFailure and firstReproductionRefusal are absent JSON members, not explicit null records. Their omitted observer values do not establish absence of an underlying failure. Source can set role-ended directly during stopping without calling onFailure. Likewise the authority observer's firstSampleRefusal is absent because the failed resource census did not invoke its verify/confirm callbacks.

## Cleanup consequence and causal order limits

[Observed source] The census catch records the inspection rejection and calls stop('inspection-failed'). That sets the role outcome and sends SIGTERM to the process group, then schedules bounded SIGKILL/cleanup. isUrlSessionProcess becomes false when launch reason leaves exited; fresh native/processing guards then refuse. The terminal inspection-failed/SIGTERM tuple is a cleanup consequence of the launcher path, not evidence that the native Design process spontaneously chose SIGTERM. Later role-ended is the supervisor's classification of its uncompleted terminal; it does not name the triggering census operation.

[Observed] Terminal notification is at287713.157,2990.651ms after ordinal357's confirmation, while screening wrapper settled287627.419 and native mediation287747.114. [Unknown] Precise wall-clock ordering between the sample358 timeout and the screening predicate/runtime refusal: launcher samples store elapsed phase times but no absolute sample start, so those clocks cannot be aligned exactly from this record. Logical source propagation supports census failure invalidating native/processing authority; it does not exclude an independent screening failure close to the same time. The first positively identified low-level rejecting predicate is the inner resource Promise.race timeout, not an inferred store or screen limit.

## Smallest causal next design to assess

[Inferred hypothesis, not a verified fix] runOrderedDesignScreen uses a20ms setInterval whose callback synchronously invokes the full current() guard. That guard calls requireProcessingCurrent→processingCurrent→fresh native effect boundary plus machine.current. In the immediately preceding retained full current trace, the two relevant synchronous pairs cost190.760ms (machine-effect128.621+machine-authority62.139) and182.922ms (123.047+59.875), before other callback bookkeeping. These costs exceed the requested20ms poll interval. Repeated due full checks can pressure event-loop progress while descriptor-relative storage/process walks are awaiting callbacks. Source also hashes trusted held images under the same screen wrapper. [Unknown] Whether this particular screen call reached the child/poll phase, its poll count/durations, and which census await was pending. The trace lacks those discriminators; this remains a specific, falsifiable scheduling hypothesis, not causal proof.

A small guard-preserving candidate, conditional on confirming the child/poll path, would schedule the next20ms poll only after the prior fresh synchronous check returns, leaving an actual interval for census I/O progress. Retain the same full current predicate at every poll and every existing effect/result boundary; keep worker CPU/wall, original operation/run, census2000 and ordered aggregate5000 limits. Do not cache authority, skip samples, widen the census ceiling, or treat a queued success as a grant. A proportional regression must hold a census I/O completion pending while one current poll consumes longer than20ms, prove that completion can settle between polls, and independently prove withdrawal still kills/refuses the child and final use. This is a proposal for independent design review, not permission to claim the actual failure repaired.

The smallest additional original-path discriminator would retain bounded numeric absolute sample start, active census operation/counts, screen execution-vs-content status, and whether/when child polling began. It need not retain paths, bodies, raw exceptions or subprocess diagnostics. Parent's separately retained native logs may already establish the same facts, so inspect them before authorizing a new run. [Unknown] Actual interrupted recovery, final capture and performance after any further change.

## Exact source excerpts

session-launch.ts:17 (exact subject)
```typescript
export const URL_LAUNCH_LIMITS = Object.freeze({ milliseconds: 1_800_000, setupMilliseconds: 20_000, cleanupMilliseconds: 2500,
  cpuSeconds: 600, addressBytes: 68_719_476_736, fileBytes: 2_097_152, storageBytes: 16_777_216,
  entries: 16_384, processes: 64, outputBytes: 8_388_608, descriptors: 256, sampleMilliseconds: 200, inspectionMilliseconds: 2_000 });
// Ordered Design joins fresh asynchronous parent/claim verification and the
// final synchronous authority check. Its resource census retains the ordinary
// two-second bound; only the complete authority join gets this finite envelope.
export const URL_ORDERED_INSPECTION_MILLISECONDS = 5_000;
```

session-launch.ts:30 (exact subject)
```typescript
async function bounded<T>(operation: () => T | Promise<T>, milliseconds: number, observeTimeout?: (error: Error) => void): Promise<T> {
  const deadline = performance.now() + Math.max(1, milliseconds);
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_resolve, reject) => {
    const expire = (): void => {
      // A timer callback can arrive early when its clock rounds the delay.
      const remaining = deadline - performance.now();
      if (remaining <= 0) {
        const error = refused();
        observeTimeout?.(error);
        reject(error);
      } else timer = setTimeout(expire, Math.ceil(remaining));
    };
    expire();
  });
  try { return await Promise.race([Promise.resolve().then(operation), timeout]); }
  finally { clearTimeout(timer); }
}

```

session-launch.ts:646 (exact subject)
```typescript
    const sampleBegan = performance.now();
    const observation = trace === undefined ? undefined : beginInspectionTrace(trace, sampleBegan);
    let phase: InspectionPhase = 'storage', processRejection: unknown;
    const resourceMilliseconds = Math.min(limits.inspectionMilliseconds, URL_LAUNCH_LIMITS.inspectionMilliseconds);
    const checkSample = (source = phase): void => {
      const inactive = !sampleActive || exited || finishedCapture || reason !== 'exited';
      const milliseconds = source === 'storage' || source === 'process' ? resourceMilliseconds : limits.inspectionMilliseconds;
      if (inactive || performance.now() - sampleBegan >= milliseconds) {
        const error = refused();
        observation?.note(error, source, inactive ? 'sample-inactive' : 'sample-deadline');
        throw error;
      }
    };
```

session-launch.ts:678 (exact subject)
```typescript
        // The walks share a deadline. Keep storage's earlier refusal and
        // publication order even if the process walk completes first.
        let processCount: Promise<number | null> | undefined;
        if (child.pid !== undefined) {
          if (observation === undefined) processCount = descendants(child.pid, limits.processes, checkSample).catch(() => null);
          else {
            observation.begin('process');
            processCount = descendants(child.pid, limits.processes, () => checkSample('process')).then(count => {
              observation.settle('process', 'accepted');
              return count;
            }, error => {
              processRejection = error;
              observation.settle('process', 'rejected');
              return null;
            });
          }
        }
        observation?.begin('storage');
        let storageBytes: number;
        try { storageBytes = await storage([view.inputs.homeDirectory, view.inputs.workDirectory], limits, checkSample, observation?.storageFailure); }
        catch (error) { observation?.settle('storage', 'rejected'); throw error; }
        observation?.settle('storage', 'accepted');
        checkSample();
        sampledStorageBytes = storageBytes;
        if (sampledStorageBytes > limits.storageBytes) {
          observation?.refuse('storage', 'resource-limit'); stop('storage-limit'); return;
        }
        if (processCount !== undefined) {
          phase = 'process';
          const count = await processCount;
          checkSample();
          if (count === null) {
            const error = refused();
            observation?.inherit(error, processRejection);
            throw error;
          }
          peakProcesses = Math.max(peakProcesses ?? 0, count);
          if (count > limits.processes) {
            observation?.refuse('process', 'resource-limit'); stop('process-limit'); return;
          }
        }
      }, resourceMilliseconds, observation === undefined ? undefined : error => {
```

session-launch.ts:739 (exact subject)
```typescript
    }, limits.inspectionMilliseconds, observation === undefined ? undefined : error => {
      observation.note(error, phase, 'bounded-timeout');
    }).catch(error => {
      if (exited || finishedCapture) return;
      observation?.reject(error, phase);
      stop('inspection-failed');
    })
      .finally(() => { sampleActive = false; pendingSample = undefined; });
  }, limits.sampleMilliseconds);
```

session-launch.ts:622 (exact subject)
```typescript
  const signal = (name: NodeJS.Signals): void => { try { if (child.pid !== undefined) process.kill(-child.pid, name); } catch { /* Independent verification below. */ } };
  const stop = (why: UrlSessionLaunchOutcome['outcome']): void => {
    if (finishedCapture || reason !== 'exited') return;
    // Exit may already be known while the child's streams and process group
    // are still closing. A cleanup request must preserve that terminal result.
    if (why !== 'stopped' || !exited) reason = why;
    if (endTimer !== undefined) return;
    signal('SIGTERM');
    killTimer = setTimeout(() => signal('SIGKILL'), Math.min(250, limits.cleanupMilliseconds));
    endTimer = setTimeout(wake, limits.cleanupMilliseconds);
  };
```

url-ordered-design-screen.ts:137 (exact subject)
```typescript
      const timer = setTimeout(stop, enforcedWallMilliseconds);
      // Revocation and shared budget exhaustion must stop a running child too.
      const poll = setInterval(() => { try { current(); } catch { stop(); } }, 20);
      child.once('error', stop);
      child.stdin!.once('error', stop);
      child.stdout!.once('error', stop);
      child.stderr!.once('error', stop);
      child.stdout!.on('data', (chunk: Buffer) => {
        outputBytes += chunk.length;
```

url-run-composed.test.ts:1515 (exact subject)
```typescript
      inferencePhase('kernel-peer', () => kernelPeer(...args), result => result !== null));
    const screen = orderedScreen.runOrderedDesignScreen;
    vi.spyOn(orderedScreen, 'runOrderedDesignScreen').mockImplementation(input => decisionScope.getStore() === true
      ? relayPhase('screening-worker', () => screen(input), result => result.ok && result.observation.outcome.result.ok)
      : screen(input));
```

url-run-composed.test.ts:1629 (exact subject)
```typescript
      const invoke = () => mediatePeer(peer, operation, current => {
        const stamp = step.effect = { startedMs: clock() };
        return timed(stamp, () => effect(current), () => true);
      }, observedPreflight);
      return timed(step.mediate, () => inferenceScope.run(step, invoke), result => {
        if (!result.ok) firstRefusedInference ??= step;
        return result.ok;
      });
    }
    if (firstBrokerInvocation.getStore() !== true) return mediatePeer(peer, operation, effect, preflight);
    return brokerPhase('mediate-peer', () => mediatePeer(peer, operation, current =>
      brokerPhase('host-action', () => effect(current), () => true), preflight), result => result.ok);
```

url-run-ordered-attempt.ts:132 (exact subject)
```typescript
  const processingCurrent = (): boolean => !closed && sessionMachineEffectCurrent() !== false
    && delivery !== null && render !== null && input.budget.current() && input.machine.current()
    && input.now() < input.deadline;
  const assertProcessingCurrent = (): void => { if (!processingCurrent()) throw refused(); };
  const assertCurrent = (): void => {
    assertProcessingCurrent();
    assertUrlDesignDeliveryViewCurrent(delivery!);
```

url-ordered-design-session.ts:228 (exact subject)
```typescript
      if (input.operation === 'request' && !('planInput' in input)) throw refused();
      const result = await runOrderedDesignScreen({ program: screening.program, input, deadlineEpochMilliseconds: boundary.expires,
        current: () => { try { requireProcessingCurrent(); boundary.check(); return true; } catch { return false; } },
        imageReadCurrent: () => { try { requireAuthority(); boundary.check(); return true; } catch { return false; } },
        chargeCpuMicroseconds: value => { work.chargeScreenCpuMicroseconds(value); workBudget?.current(); boundary.check(); } });
      workBudget?.current();
      boundary.check();
      if (!result.ok) throw refused();
      return result.observation;
    }
```

url-run-sessions.ts:413 (exact subject)
```typescript
  const rememberTerminal = (role: ViewRole, child: UrlSessionProcess, canExit: () => boolean): void => {
    const capture = captures.get(role)!;
    capture.pid = child.pid; capture.startedAt = options.now();
    capture.outcome = 'Unknown'; capture.finishedAt = 'Unknown';
    const unexpectedTerminal = (): void => {
      if (stopping) failure ??= 'role-ended';
      else fail('role-ended');
    };
    const design = role === 'design' && completedDesign?.child === child ? completedDesign : null;
    terminals.push(child.finished.then(async outcome => {
      capture.outcome = outcome; capture.finishedAt = options.now();
      const permitted = canExit();
      const completed = design !== null && permitted && isCompletedUrlDesignExit(outcome);
      if (!urlSessionStoppedCleanly(outcome) || (!stopping && (!permitted
        || design !== null && completedDesign === design && !completed))) unexpectedTerminal();
      try { await audit.append({ kind: 'launch-terminal', role, scope: audit.scope(role), payload: outcome }); }
      catch { if (stopping) failure ??= 'audit-unavailable'; else fail('audit-unavailable'); }
    }, unexpectedTerminal));
  };
  const probe = createServer(socket => socket.destroy()); probe.on('error', () => {});
```
