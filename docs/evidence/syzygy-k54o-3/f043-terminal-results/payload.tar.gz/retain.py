from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess

OUT = Path(__file__).resolve().parent
HOST = Path('/home/orca/.tmp/f3-native-admission-fixes/hosted-f043a10aa')
NATIVE = Path('/home/orca/.tmp/f3-native-eligible-f043a10aa')
REPO = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
SUBJECT = 'f043a10aab6bf3baee0b1acd24c72b78d3654ded'
CORRECTION = '6ab6014d7c1eb698586130ef61aad56baf0b4902'
entries = []

def digest(data): return hashlib.sha256(data).hexdigest()
def write(relative, data):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return target

def retain(source, relative, compressed=False):
    assert source.is_file() and not source.is_symlink(), source
    data = source.read_bytes()
    saved = gzip.compress(data, compresslevel=9, mtime=0) if compressed else data
    if compressed:
        assert saved == gzip.compress(data, compresslevel=9, mtime=0)
        assert gzip.decompress(saved) == data
    write(relative, saved)
    entries.append({'original': str(source), 'retained': relative, 'originalBytes': len(data),
                    'originalSha256': digest(data), 'retainedBytes': len(saved), 'retainedSha256': digest(saved),
                    'encoding': 'gzip;mtime=0;no-filename' if compressed else 'identity',
                    'originalFileModifiedAtUtc': datetime.datetime.fromtimestamp(source.stat().st_mtime, datetime.timezone.utc).isoformat()})

def json_write(relative, value):
    return write(relative, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

# Explicit selections only. Never walk original stores, caches, state or credentials.
for name in ['core3-raw.log', 'stop-resume-raw.log', 'eligible-raw.log', 'reconciliation-raw.log']:
    retain(HOST/name, 'hosted/'+name+'.gz', True)
for name in ['snapshot-current-summary.json', 'snapshot-20261124T200841Z.json', 'unit-summary.json',
             'failure-summary.json', 'stop-resume-failure.json', 'stop-resume-runtime-diagnostic.json',
             'interrupted-diagnosis.json', 'interrupted-diagnosis-partial.json', 'eligible-failure.json', 'eligible-runtime-diagnostic.json',
             'reconciliation-phases.json']:
    retain(HOST/name, 'hosted/'+name)
for name in ['diagnosis.json', 'failure-excerpt.json', 'source-line-evidence.json', 'private-reader-advice-mismatch.json']:
    retain(HOST/'core3-diagnosis'/name, 'hosted/core3-diagnosis/'+name)
for name in ['profile-and-failure-attribution.json', 'ledger-boundary-proof.json']:
    retain(HOST/'reconciliation-diagnosis'/name, 'hosted/reconciliation-diagnosis/'+name)
retain(HOST/'artifact-observer-review/r5/focused.log', 'causal-artifact/r5-before.log.gz', True)
for name in ['focused-result.json', 'observer.patch']:
    retain(HOST/'artifact-observer-review/r5'/name, 'causal-artifact/r5-'+name)
for name in ['result.json', 'focused.log']:
    retain(HOST/'artifact-fix-review/r1/causal-single-change'/name,
           'causal-artifact/single-runtime-change-'+name+('.gz' if name.endswith('.log') else ''), name.endswith('.log'))
retain(HOST/'artifact-fix-review/r1/verified-results.json', 'causal-artifact/verified-results.json')
retain(HOST/'artifact-fix-review/r1/fix.patch', 'causal-artifact/fix.patch')
for name in ['commit', 'tree', 'exit', 'worker-summary.json', 'worker-samples.jsonl', 'capture-index.json',
             'eligible-source-operation-diagnosis.json']:
    retain(NATIVE/name, 'local-eligible/'+name)
retain(NATIVE/'native-recovery.log', 'local-eligible/native-recovery.log.gz', True)
index = json.loads((NATIVE/'capture-index.json').read_text())
for row in index:
    source = NATIVE/'retained'/row['file']
    assert digest(source.read_bytes()) == row['sha256']
    assert source.read_bytes() == (NATIVE/row['input']).read_bytes()
    retain(source, 'local-eligible/retained/'+row['file'])
assert (NATIVE/'commit').read_text().strip() == SUBJECT
assert (NATIVE/'exit').read_text().strip() == '1'

def git_bytes(*args): return subprocess.check_output(['git', *args], cwd=REPO)
tree = git_bytes('rev-parse', SUBJECT+'^{tree}').decode().strip()
assert tree == (NATIVE/'tree').read_text().strip()
source_names = ['url-run-artifacts.ts','url-run-artifacts.test.ts','reader-advice.ts','draft-schema.ts',
                'url-check-product-shape.ts','url-dossier-result.ts','url-origin-ledger.ts','url-source-reader.ts',
                'url-run-origins.ts','url-recovery.ts','url-stopped-run.ts','policy-snapshot.ts','polaris.ts',
                'url-run-composed.test.ts','url-product-read-limits.ts','url-run-sessions.ts','session-machine-transport.ts',
                'url-machine-peer.ts','url-run-ordered-attempt.ts','url-session-audit.ts']
source_bindings=[]
for name in source_names:
    relative='packages/polaris-dossier/src/'+name
    data=git_bytes('show', SUBJECT+':'+relative)
    target='subject-source/'+relative
    write(target, data)
    source_bindings.append({'commit':SUBJECT,'path':relative,'retained':target,'sha256':digest(data),
                            'gitBlob':git_bytes('rev-parse',SUBJECT+':'+relative).decode().strip()})
json_write('source-bindings.json', {'subjectCommit':SUBJECT,'subjectTree':tree,'sources':source_bindings,
          'followupCorrectionCommit':CORRECTION,'followupCorrectionTree':git_bytes('rev-parse',CORRECTION+'^{tree}').decode().strip()})
snapshot=json.loads((HOST/'snapshot-20261124T200841Z.json').read_text())
assert snapshot['subjectCommit']==SUBJECT
runs=[]; jobs=[]
for run in snapshot['runs']:
    assert run['head_sha']==SUBJECT and run['status']=='completed'
    rows=[]
    for job in run['jobs']:
        assert job['status']=='completed'
        row={k:job[k] for k in ['id','name','status','conclusion','started_at','completed_at','elapsedSeconds','waitFromRunCreationSeconds']}
        row['failedSteps']=[{'name':step['name'],'started_at':step.get('started_at'),'completed_at':step.get('completed_at'),'conclusion':step.get('conclusion')} for step in job['steps'] if step.get('conclusion')=='failure']
        rows.append(row); jobs.append(row)
    runs.append({**{k:run[k] for k in ['id','head_sha','status','conclusion','created_at','run_started_at','updated_at','elapsedFromRunCreationSeconds']},'jobCount':len(rows),'jobs':rows})
summary={'subjectCommit':SUBJECT,'capturedAt':snapshot['capturedAt'],'workflowRunCount':len(runs),'jobCount':len(jobs),
         'jobConclusions':dict(collections.Counter(j['conclusion'] for j in jobs)),'runs':runs,
         'scope':'Every job in the retained two-run terminal snapshot, including aggregate jobs; no acceptance claim.'}
assert len(jobs)==sum(len(r['jobs']) for r in snapshot['runs'])
json_write('hosted/terminal-all-jobs.json',summary)
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
def terminal_lines(source):
    return [line for line in ansi.sub('',source.read_text()).splitlines()
            if len(line)<700 and re.search(r'Test Files\s+|Tests\s+\d|Duration\s+|Process completed with exit code',line)]
native_diag=json.loads((NATIVE/'eligible-source-operation-diagnosis.json').read_text())
terminal={'subjectCommit':SUBJECT,'subjectTree':tree,'exit':1,'scenario':'eligible-stop-resume',
          'terminalLines':terminal_lines(NATIVE/'native-recovery.log'),
          'testCounts':{'failed':1,'skipped':6,'total':7},'invocationDurationSeconds':838.14,
          'captureTimes':[{'input':r['input'],'capturedAtUtc':datetime.datetime.fromtimestamp(r['at'],datetime.timezone.utc).isoformat(),'sha256':r['sha256']} for r in index],
          'failureInputTreeSha256':native_diag['failureInputTreeSha256'],
          'classification':native_diag['classification'],
          'observedSourceReadMilliseconds':native_diag['observed']['readElapsedMs'],
          'observedSourceReadOutcome':native_diag['observed']['sourceRead']['outcome'],
          'observedLedgerRestoreOutcome':native_diag['observed']['ledgerRestore']['outcome'],
          'guardAttribution':'Inferred original post-read operation deadline from observed accepted 5597.984665ms read and unconditional private 5000ms source guard; no observed checkTime callback throw.',
          'limitations':['No completed resumed record observed; this is a failed attempt, not acceptance.',
                         'Activation/runner allowances are distinct from original product expiry.',
                         'No new replay or project checks were run to create this packet.']}
json_write('local-eligible/terminal-summary.json',terminal)
json_write('hosted/retained-log-terminal-lines.json',{name:terminal_lines(HOST/name) for name in ['core3-raw.log','stop-resume-raw.log','eligible-raw.log','reconciliation-raw.log']})
json_write('original-selection.json',{'scope':'explicit selected files only','files':entries,'selectedOriginalFileCount':len(entries)})
readme = """# Failed f043 predecessor evidence

[Observed] Subject f043a10aab6bf3baee0b1acd24c72b78d3654ded, tree 0dcc9f487fbb57658b4ddd23981e3270373e1750. This packet retains failed predecessor attempts. It makes no acceptance claim.

[Observed] The terminal hosted snapshot captured 2026-11-24T20:08:41.319396+00:00 contains two failed workflow runs and 15 completed jobs (9 success, 6 failure, including aggregate jobs). hosted/terminal-all-jobs.json contains every retained job's actual start/completion timestamps and computed elapsed time. The raw terminal snapshot is preserved. Four available failed-job logs are retained with deterministic gzip; successful-job logs were not newly fetched.

[Observed] Local eligible recovery exited 1: 1 failed, 6 skipped, 7 total; invocation 838.14s. Exact content-addressed stopped cut and failure JSON are retained and verified equal to the original top-level copies. Commit/tree/exit, capture index, worker census, and the source-operation diagnosis are included. The observed first source read accepted after 5597.984665ms; ledger restoration then rejected. [Inferred] The original private 5000ms post-read guard caused that refusal. The observed callback did not throw, so no private thrown guard is claimed as directly observed.

[Observed] The artifact report returned by the actual helper contained readerAdvice.worthKnowing; the older strict bridge rejected it before a product read. Identical diagnostic test bytes failed on f043 and passed when only the strict optional-field validator was corrected. causal-artifact/ binds both replay subjects and retains the closed-metadata R5 log. [Inferred] This deterministic reproduced defect explains the hosted core-3 failure; the hosted raw failure itself erased the private predicate. Follow-up correction 6ab6014d7c1eb698586130ef61aad56baf0b4902 is a distinct subject. Its focused checks do not accept the failed native attempts.

[Unknown] The source read's underlying scheduling/I/O cost, and any unobserved later recovery behavior, remain unknown. Hosted stop-resume and eligible failures are retained separately; both the prior partial interrupted diagnosis and final read-only diagnosis are preserved with filesystem modification timestamps in original-selection.json; their causal leaves are not collapsed into the local source-read signature. Activation/runner timing is not later product expiry.

source-bindings.json binds exact predecessor source bytes and Git object identities. original-selection.json maps every selected original to retained bytes and hashes. manifest.json hashes the complete packet population except itself and SHA256SUMS; SHA256SUMS includes the manifest. retain.py documents explicit safe selections and deterministic compression. No cache, store, state directory, credential file, or native run directory was copied. Raw originals remain unchanged. Recheck with sha256sum -c SHA256SUMS from this directory.
"""
write('README.md',readme.encode())
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in ['manifest.json','SHA256SUMS'])
manifest={'subjectCommit':SUBJECT,'subjectTree':tree,'scope':'failed predecessor evidence only; no acceptance claim',
          'fileCount':len(files),'files':[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in files]}
json_write('manifest.json',manifest)
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
write('SHA256SUMS',''.join(digest(p.read_bytes())+'  '+str(p.relative_to(OUT))+'\n' for p in files).encode())
print(json.dumps({'packet':str(OUT),'selectedOriginalFiles':len(entries),'manifestPopulation':manifest['fileCount'],
                  'manifestSha256':digest((OUT/'manifest.json').read_bytes()),'sha256sumsSha256':digest((OUT/'SHA256SUMS').read_bytes()),
                  'jobCount':len(jobs),'jobConclusions':summary['jobConclusions']}))
