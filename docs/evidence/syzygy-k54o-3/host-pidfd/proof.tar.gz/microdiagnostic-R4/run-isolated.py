#!/usr/bin/env python3
"""Operator-run diagnostic. Creates and mutates only a disposable clone."""
import argparse
import hashlib
import json
import math
import os
import re
from pathlib import Path
import shutil
import signal
import subprocess
import time

PACKET = Path(__file__).resolve().parent
MANIFEST = json.loads((PACKET / 'manifest.json').read_text())
PRIMARY = Path(MANIFEST['primary'])
FOCUS = MANIFEST['focus']
FOCUS_FULL_NAME = MANIFEST['focusFullName']
FOCUS_PATTERN = '^' + re.escape(FOCUS_FULL_NAME) + '$'
if FOCUS_PATTERN != MANIFEST['focusPattern']:
    raise SystemExit('focus pattern binding mismatch')
parser = argparse.ArgumentParser()
parser.add_argument('--execution-name', required=True, help='New directory name beneath this packet; never reused')
args = parser.parse_args()
if not args.execution_name or Path(args.execution_name).name != args.execution_name:
    raise SystemExit('execution-name must be a single path component')
OUT = PACKET / args.execution_name
OUT.mkdir(exist_ok=False)
CHECKOUT = OUT / 'checkout'
TMP = OUT / 'tmp'
TMP.mkdir(mode=0o700)
ENV = dict(os.environ, TMPDIR=str(TMP))
history = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot_session(session):
    rows = []
    for item in Path('/proc').iterdir():
        if not item.name.isdigit():
            continue
        try:
            text = (item / 'stat').read_text()
            fields = text[text.rfind(')') + 2:].split()
            if int(fields[3]) == session:
                rows.append({'pid': int(item.name), 'ppid': int(fields[1]), 'processGroup': int(fields[2]),
                             'session': int(fields[3]), 'startTicks': int(fields[19]), 'state': fields[0]})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return sorted(rows, key=lambda row: row['pid'])

def run(name, command, cwd, timeout):
    started = time.monotonic()
    with (OUT / (name + '.log')).open('wb') as log:
        child = subprocess.Popen(command, cwd=cwd, env=ENV, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            # This group was created by this exact live Popen, never selected by name.
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
        survivors = snapshot_session(child.pid)
    history.append({'name': name, 'command': command, 'cwd': str(cwd), 'pid': child.pid,
                    'elapsedSeconds': time.monotonic() - started, 'exitCode': code,
                    'timedOut': timed_out, 'remainingSessionPopulation': survivors})
    (OUT / 'commands.json').write_text(json.dumps(history, indent=2) + '\n')
    if code or timed_out or survivors:
        raise RuntimeError(f'{name} incomplete; inspect retained log and session population; no automatic cleanup')

def verify_primary():
    head = subprocess.check_output(['git', '-C', str(PRIMARY), 'rev-parse', 'HEAD'], text=True).strip()
    if head != MANIFEST['subject']:
        raise RuntimeError('primary HEAD moved; regenerate/rebind packet, never transplant silently')
    if subprocess.check_output(['git', '-C', str(PRIMARY), 'status', '--porcelain']):
        raise RuntimeError('primary is not clean; do not interfere with another run')
    for relative, binding in MANIFEST['sourceBindings'].items():
        if sha((PRIMARY / relative).read_bytes()) != binding['sha256']:
            raise RuntimeError('primary source binding mismatch: ' + relative)

try:
    verify_primary()
    if sha((PACKET / 'diagnostic.patch').read_bytes()) != MANIFEST['patchSha256']:
        raise RuntimeError('packet patch binding mismatch')
    for relative, binding in MANIFEST['overlayBindings'].items():
        if sha((PACKET / 'overlay' / relative).read_bytes()) != binding['sha256']:
            raise RuntimeError('overlay binding mismatch: ' + relative)
    run('clone', ['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--template=', '--no-hardlinks',
                  '--no-checkout', str(PRIMARY), str(CHECKOUT)], OUT, 120)
    run('checkout', ['git', '-c', 'core.hooksPath=/dev/null', 'checkout', '--detach', MANIFEST['subject']], CHECKOUT, 60)
    run('node-version', ['node', '-e', 'if(process.version!=="v24.6.0")process.exit(1);console.log(process.version)'], CHECKOUT, 10)
    # Workspace links must belong to this clone. No install lifecycle scripts.
    run('install', ['npm', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], CHECKOUT, 180)
    common = ['node', 'node_modules/vitest/vitest.mjs', 'run', '--project', 'integration',
              'packages/polaris-dossier/src/policy-git-native.test.ts', '-t', FOCUS_PATTERN,
              '--reporter=verbose', '--reporter=json']
    run('original-focused', common + ['--outputFile=' + str(OUT / 'original-vitest.json')], CHECKOUT, 120)
    for relative, binding in MANIFEST['overlayBindings'].items():
        source = CHECKOUT / relative
        if sha(source.read_bytes()) != MANIFEST['sourceBindings'][relative]['sha256']:
            raise RuntimeError('clone source changed before overlay: ' + relative)
        shutil.copyfile(PACKET / 'overlay' / relative, source)
    run('diagnostic-focused', common + ['--outputFile=' + str(OUT / 'diagnostic-vitest.json')], CHECKOUT, 120)
    log = (OUT / 'diagnostic-focused.log').read_text()
    marker = 'POLICY_GIT_DIAGNOSTIC_V1 '
    if log.count(marker) != 1:
        raise RuntimeError('expected exactly one numeric diagnostic marker; retain failure, do not infer zero')
    payload = json.JSONDecoder().raw_decode(log.split(marker, 1)[1])[0]
    rows = [row for case in payload['cases'] for row in case['rows']]
    reports = {}
    for name in ['original', 'diagnostic']:
        report = json.loads((OUT / (name + '-vitest.json')).read_text())
        assertions = [item for result in report['testResults'] for item in result['assertionResults']]
        passed = [item for item in assertions if item['status'] == 'passed']
        if len(assertions) != 17 or len(passed) != 1 or passed[0]['title'] != FOCUS or passed[0]['fullName'] != FOCUS_FULL_NAME:
            raise RuntimeError('focused denominator/result differs; inspect JSON before interpreting timings')
        reports[name] = {'assertionPopulation': len(assertions), 'passed': len(passed),
                         'passedTitle': passed[0]['title'], 'passedFullName': passed[0]['fullName'], 'durationMs': passed[0].get('duration')}
    if len(payload['cases']) != 16 or len(rows) != 22:
        raise RuntimeError('diagnostic job/case population differs; do not summarize partial data')
    expected_jobs = {'baseline': 3, 'HEAD retry': 4, 'early ref drift': 1, 'working drift': 3}
    for case in payload['cases']:
        expected = expected_jobs[case['scenario']] if case['mode'] == 'native' else 0
        if len(case['rows']) != expected:
            raise RuntimeError('case diagnostic population differs')
    required_native = {
        'diagnosticHostIdlePolls', 'diagnosticHostIdlePollUs', 'diagnosticHostMainPolls', 'diagnosticHostMainPollUs',
        'diagnosticQueueUs', 'diagnosticPumpUs', 'diagnosticSupervisorIdlePolls', 'diagnosticSupervisorIdlePollUs',
        'diagnosticSupervisorMainPolls', 'diagnosticSupervisorMainPollUs',
        'diagnosticTransferPollsExcludingFinalReceipt', 'diagnosticTransferPollUsExcludingFinalReceipt',
        'diagnosticPreImageMs', 'diagnosticRequestEncodeMs', 'diagnosticPostImageMs',
    }
    for row in rows:
        required = required_native | ({'diagnosticAdmissionCallMs', 'diagnosticAdmissionToCallbackMs'} if row['async'] else {'diagnosticNativeCallMs'})
        if not required.issubset(row):
            raise RuntimeError('missing native diagnostic fields')
        if any(type(value) not in (int, float) or not math.isfinite(value) or value < 0 for key, value in row.items() if key.startswith('diagnostic')):
            raise RuntimeError('unknown/invalid diagnostic stopwatch reading')
    (OUT / 'metrics.json').write_text(json.dumps(payload, indent=2) + '\n')
    # Restore only the five overlay files in the disposable clone, after exact
    # byte verification; never git-reset a shared checkout or delete artifacts.
    for relative, binding in MANIFEST['overlayBindings'].items():
        source = CHECKOUT / relative
        if sha(source.read_bytes()) != binding['sha256']:
            raise RuntimeError('overlay changed during run; refuse restoration: ' + relative)
        shutil.copyfile(PACKET / 'original' / relative, source)
    clone_status = subprocess.check_output(['git', '-C', str(CHECKOUT), 'status', '--porcelain'], text=True)
    if clone_status:
        raise RuntimeError('disposable clone not clean after exact restoration; inspect manually')
    verify_primary()
    result = {'status': 'measured, diagnostic only; not native acceptance', 'subject': MANIFEST['subject'],
              'patchSha256': MANIFEST['patchSha256'], 'metricsSha256': sha((OUT / 'metrics.json').read_bytes()),
              'reports': reports, 'nativeRows': len(rows), 'cases': len(payload['cases']),
              'privateTmp': str(TMP), 'overlayRestoredInDisposableClone': True,
              'primaryBindingsRechecked': True, 'commands': history}
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'result': str(OUT / 'result.json')}))
except BaseException as error:
    (OUT / 'incomplete.json').write_text(json.dumps({'status': 'incomplete', 'error': str(error), 'commands': history}, indent=2) + '\n')
    raise
