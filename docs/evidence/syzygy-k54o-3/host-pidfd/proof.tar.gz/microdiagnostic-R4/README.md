# Policy Git microdiagnostic R3 — clean 70fc55 source binding; not executed

[Observed] R3 binds clean subject `70fc55ebc708937ff1900070c32e63670cd3860f`, tree `090dad5e8c56b21eda2627412ebeaf225712c078`, in `/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w`. The diagnostic overlay and operator are byte-identical to R2; R2 remains unchanged across its 19 files. `manifest.json` records SHA-256 and byte counts for eight original source files and five overlay files. No product execution, native compilation, test execution, primary edit, or new measured result was produced while preparing R3.

[Observed] `subject-change-receipt.json` binds the exact four paths changed since `0f629938f7fafa14746d28b2144664415dc78acb` to the frozen question-kind bridge R2 manifest. Both `git diff` and an independent comparison across the 12,535-entry union of tracked trees yield those four paths. Their committed and current bytes match the four reviewed candidates. The eight probe-source files are identical at both commits, in the working tree, and in this packet's originals. The retained raw source review says `PASS`; its original SHA-256 is `96c205c9a050b703c2f17a8d15341b5151d65f5ebd276fd9db27096acba686d7`. Retained runtime records describe the candidate overlays on the predecessor commit; they are not new test runs at 70fc55. This packet adds no dirty-worktree exception or authority gate change. The root's independent binding review and operator execution decision remain external to this source-only preparation.

[Observed] `focus-binding.json` retains the exact assertion from an existing actual test result: `ancestorTitles` is empty and `fullName` equals the title because this case is top-level. It does not belong to the preceding `describe`. Installed runner source separately confirms no parent suite for top-level cases. The old exact title was therefore already the correct full-name literal. R2 binds that literal explicitly, applies `re.escape`, and checks the actual reported `fullName` as well as `title`. Its regex matches exactly one assertion in the historical 17-assertion file population. Historical result durations are not new R2 measurements.

[Inferred] The smallest useful discriminator is one existing real-policy phase test. It exercises the actual three-command baseline probe and its HEAD retry, early ref refusal, and working-file refusal in synchronous and asynchronous forms. Its native branch has 22 Git jobs: twice `(baseline 3 + HEAD retry 4 + early ref drift 1 + working drift 3)`. Its original-executor counterpart has another 22. The selected test is one of 17 declarations in the file; the driver checks that denominator in both actual Vitest JSON reports. There are 16 scenario/mode cases, eight native. Setup Git commands and native compilation are additional operations, excluded from the 44 probe-job denominator.

## Operator command

```sh
python3 /home/orca/.tmp/f3-native-admission-fixes/policy-git-microdiagnostic-70fc55-R3/run-isolated.py --execution-name execution-1
```

The driver refuses an existing output directory, a moved or dirty primary, and any mismatched bound byte. It creates a disposable independent clone inside the packet, runs `npm ci --ignore-scripts --no-audit --no-fund` there with private home-backed `TMPDIR`, then runs the unmodified focused test once and the diagnostic focused test once. It requires Node `v24.6.0`. No primary files or primary `node_modules` are changed. Installation may require registry access; a failed install remains a failed preparation, never a diagnostic result.

The actual focused CLI, run inside that clone, is:

```sh
node node_modules/vitest/vitest.mjs run --project integration packages/polaris-dossier/src/policy-git-native.test.ts -t '<manifest focusPattern: anchored, regex-escaped observed fullName>' --reporter=verbose --reporter=json --outputFile=<execution-directory>/diagnostic-vitest.json
```

The driver passes the exact `focusPattern` value directly as one argv item; the placeholder above describes that value and is not a command to copy. The repository's worker and file-parallelism configuration is used without overrides. The original control uses the same CLI with `original-vitest.json`. Each focused invocation has a 120 second outer timeout; repository test and hook timeouts remain unchanged. Compilation is the existing `beforeAll`, with its existing compiler flags and bounds. This packet is not a 600 second end-to-end run and does not establish end-to-end acceptance.

## Added measurements

| Metric | Population and interpretation |
|---|---|
| `diagnosticPreImageMs` | Each job's three `hold()` calls: fresh path/metadata checks and complete image reads/comparisons; includes the first digest authentication when not yet captured. Scope construction's initial addon checks are excluded. |
| `diagnosticRequestEncodeMs` | Request validation and serialization, after the image holds. |
| `diagnosticNativeCallMs` | Synchronous native call, including decode, setup, supervisor/Git execution, pumping, receipt creation, and return. |
| `diagnosticAdmissionCallMs` | Asynchronous native admission only. |
| `diagnosticAdmissionToCallbackMs` | Async admission through JS completion callback entry. Includes queueing and event-loop delay; not native-only wall time. |
| `diagnosticPostImageMs` | The unchanged three-image completion check. Descriptor close and outer CPU accounting occur afterwards and are excluded. |
| `diagnosticQueueUs` | Native admission to pump entry; contains decode tail and async queueing, not only queue wait. |
| `diagnosticPumpUs` | Native pump entry through pump cleanup. Nested inside native-call or admission-to-callback time. |
| `diagnosticHostMainPolls/Us` | Addon main-loop polls; includes normal I/O readiness and idle reap waiting. |
| `diagnosticHostIdlePolls/Us` | Addon polls after all request/response/receipt descriptors close, while its own spawned supervisor remains unreaped. All three polled descriptors are negative; existing timeout stays 2 ms. |
| `diagnosticSupervisorMainPolls/Us` | Supervisor main-loop polls. Nested inside addon native time. |
| `diagnosticSupervisorIdlePolls/Us` | Supervisor polls with no Git stdin/stdout/stderr descriptor while reap is incomplete; normally only host-control fd4 remains. This includes owned descendant drain waiting, not necessarily direct Git exit alone. Existing timeout stays 2 ms. |
| `diagnosticTransferPollsExcludingFinalReceipt/UsExcludingFinalReceipt` | Supervisor readiness polls during request decode and stdout delivery. The final receipt transfer cannot report its own timing through itself and is explicitly excluded. Cancellation's separate zero-time poll is excluded. |

All `Ms` values are milliseconds; `Us` values are microseconds. Negative C durations mean an added stopwatch failed and are rejected by the result extractor, never read as zero. Image SHA-256 identities accompany each row. No args beyond command names, request bytes, response bytes, environment contents, policy bodies, or raw image bytes are emitted by the diagnostic marker.

The three synchronous JS phases are disjoint but omit closing/accounting overhead. C poll and pump measurements are nested, including host/supervisor overlap: do not sum them as an exclusive partition. Count and time are descriptive; an idle poll does not prove the child was already exited at its beginning. Added stopwatch calls, a larger diagnostic receipt, and changed instrumented image sizes perturb execution. The original focused run is a control for large perturbations, not a calibrated subtraction. One sample per scenario is a discriminator, not a performance distribution.

## Checks retained and restoration

The overlay adds diagnostic state and timing only. It retains ref-before/ref-after calls, HEAD samples/retry, complete image rereads, final working-file checks, environment validation, stdout/stderr limits, fixed command shapes, absolute admission deadline, control cancellation, per-turn drain bound, wait/reap ownership, and CPU accounting. All existing test assertions remain. No cache, no check removal, no pidfd implementation, and no polling-timeout change is included.

The driver records each command's exact argv, exit status, wall time, and remaining population in the command's own new session. It does not enumerate command lines or environments. It checks that the session population is empty after each command. On timeout it signals only the group created for that still-live owned Popen, waits, and retains failure artifacts. Unexpected remaining processes fail the run and require inspection; no name-based killing or silent cleanup follows. These checks cover the selected no-detach case's process sessions and do not claim a host-wide child census.

On successful extraction, the driver restores only the exact five overlay files in the disposable clone, after verifying their overlay digests, then records clone status. It rechecks the primary commit, clean state, and eight source digests. On failure it leaves the disposable clone and logs for review, writes `incomplete.json`, and never tries to repair or reset the primary. Do not copy this overlay into the active primary. Remove the disposable execution directory later only after its recorded process population is empty and its artifacts have been retained.

Successful completion writes `metrics.json`, both Vitest JSON reports, command logs, `commands.json`, and `result.json`. Missing/partial populations fail extraction. No expected numeric outcome is supplied.

## Decision after measurement

[Inferred] If host idle polling accounts for material native time, a later scoped design could evaluate an owned-supervisor exit notification such as pidfd, while retaining `wait4`, complete receipts, CPU charge, and original deadlines. That is not this overlay. The supervisor's direct-Git/descendant case remains separate. If image phases dominate, the packet supplies that evidence without weakening any image check. If neither dominates, these timings constrain the next question; they do not justify speculative transport changes.
