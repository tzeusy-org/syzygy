# Host supervisor exit wakeup candidate — prepared, not executed

[Observed] This packet targets clean commit `70fc55ebc708937ff1900070c32e63670cd3860f`, tree `090dad5e8c56b21eda2627412ebeaf225712c078`. It changes one production file, `policy-git.c`, and its existing integration test file. Primary files were not edited. Compilation, typecheck, tests, mutation checks, and candidate performance remain Unknown. Fresh review must bind this packet before the root applies it; adoption is pending.

[Observed] At preparation's final source check, the primary had advanced to clean `df31849a43770e2a0c4c4802030b21b434a285b8`. The eight bound probe-source files still matched their 70fc55 commit blobs and this packet's originals. The candidate remains anchored to 70fc55 as requested; it does not claim the primary HEAD stayed there.

## Reason and scope

[Observed] The admitted R4 diagnostic recorded 22 addon idle polls totalling 45.219 ms across 22 native jobs, nested inside 180.934 ms of addon pump time. The supervisor independently recorded 20 idle polls totalling 41.124 ms. These intervals overlap; they are not an exclusive partition and must not be added. Image preparation and completion checks took 40.742 ms and 33.118 ms respectively. Both original and instrumented arms passed the selected 1/17 case; their test durations were 639.270 ms and 872.936 ms. The latter includes diagnostic overhead. `measurement-binding.json` records exact source artifacts and digests.

[Inferred] The addon can wake when its own supervisor exits instead of depending only on the next 2 ms timeout when request/response/receipt pipes have closed. This candidate adds that wakeup and preserves the timeout. It makes no performance guarantee: syscall cost, scheduling, remaining supervisor work, image checks, and instrumentation still matter.

## Behavior and descriptor ownership

After a successful `posix_spawn`, the addon acquires `pidfd_open(child, 0)` before its first `wait4`. That child is the same owned supervisor already awaited by this pump. The descriptor is added as the fourth `poll` input. Readability wakes the loop; the next existing `wait4(WNOHANG)` still obtains the exit status and complete helper-tree CPU charge. The pidfd is not read, waited on, or used to signal a process.

The existing 2 ms poll timeout, absolute admission and drain deadlines, control-channel shutdown, stdout/stderr caps, per-turn read bound, receipt validation, and supervisor descendant draining remain. The supervisor, protocol, image checks, policy/ref/HEAD checks, and CPU accounting code are unchanged.

If the syscall is unavailable, denied, or otherwise fails, the call is marked failed and follows the existing control-close/drain/reap path. It cannot return a successful usage receipt or reusable healthy scope. A missing `SYS_pidfd_open` definition takes the same failure branch. This intentionally requires usable pidfds for successful native policy calls; it does not silently continue without them.

`POLLERR` and `POLLNVAL` on the pidfd also mark the call failed. The descriptor closes through the existing idempotent `shut` helper immediately after positive `wait4`, or at final cleanup if not already closed. Closing after the positive reap avoids repeatedly polling a permanently readable descriptor while remaining pipe bytes drain. No new PID-based signalling is introduced.

The Linux man-pages documentation states that pidfds are close-on-exec and pollable for exit. It also identifies the unreaped-child conditions needed to prevent PID reuse. This candidate relies on the pump's existing ownership of that child and its existing `wait4` discipline; it does not add a second reaper. [pidfd_open(2)](https://man7.org/linux/man-pages/man2/pidfd_open.2.html)

## Test delta and proposed verification

Net test delta: one integration case added, one existing case extended; file declarations increase from 17 to 18. The nearest existing cases already cover busy stderr, detached adopted descendants after direct Git exit and closed pipes, preparation expiry, queued expiry, synchronous joining, CPU accounting, image drift, and the actual policy phase trace. Those cases and their assertions are preserved.

The added case follows the existing test-only link-wrapper and bundled-worker pattern. A separate normal-addon process first proves the request succeeds in sync and async modes. A second process loads an addon linked with `--wrap=syscall`; its wrapper recognizes the actual `SYS_pidfd_open` request, records the owned supervisor PID, and returns `ENOSYS`. The case checks refusal, unavailable CPU accounting, blocked scope reuse, failed scope close, exactly two intercepted supervisor acquisitions, and the absence of those supervisors after settlement. The positive transport case additionally checks that host pidfd descriptors do not remain after successful synchronous or asynchronous calls. No production switch or seccomp harness is added.

After independent review and root application at a stable checkpoint, proposed owning checks are:

```sh
npm run typecheck
node node_modules/vitest/vitest.mjs run --project integration packages/polaris-dossier/src/policy-git-native.test.ts
```

Use a private home-backed `TMPDIR`. Expect the actual report to enumerate 18 cases; read the report rather than trusting its exit code. Existing compilation and test bounds remain. These commands have not been run for this candidate.

Proposed mutation predicates, not performed results:

1. Keep the new tests but restore the predecessor production file: the unavailable-pidfd case must fail, proving the wrapper is tied to the new external operation rather than an unrelated refusal.
2. Omit the `exitfd < 0` failure assignment: the unavailable-pidfd case must fail when the scope incorrectly succeeds.
3. Omit both pidfd `shut` calls: the existing transport case's added descriptor check must fail.

The wakeup itself should be assessed by a newly bound focused diagnostic, without a brittle timing assertion in the permanent suite. An idle-poll count can remain nonzero with a pidfd; elapsed idle waiting is the useful comparison. No supervisor optimization is included in this candidate.
