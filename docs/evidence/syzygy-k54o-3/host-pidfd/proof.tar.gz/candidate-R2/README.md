# Host pidfd R2 — fixture compiler correction only

[Observed] The R1 owning record reports typecheck PASS, 17 native cases passed, and the new eighteenth case failed while compiling its test-only wrapper. My fixture discarded `write`'s return value; the compiler correctly rejected that under the existing `-Werror=unused-result` policy. `R1-owning-failure-terminal.json` retains the exact failure record without modification.

[Observed] R2 changes only that wrapper statement. It stores the actual `ssize_t` return and exits the dedicated fixture worker with status 80 if the witness write is incomplete. Compiler flags, test declarations, assertions, and production behavior are unchanged. The production C file is byte-identical to R1, SHA-256 `47ca11e2648d14e9114edd2e6932e783057261a7a4c8c847d1a981895152ff19`.

The packet binds committed originals at `df31849a43770e2a0c4c4802030b21b434a285b8`. Preparation verified the current primary contains the exact two-file R1 candidate; its intentional dirty state was preserved. No primary edit, compile, typecheck, test, or product execution occurred during this preparation. R1's packet and failure receipt remain unchanged.

`candidate.patch` is the complete two-file candidate relative to the committed originals. `fixture-correction.patch` is the single test-file correction relative to the already-applied R1 candidate. The latter is the appropriate incremental patch after verifying the primary still matches R1. Net declarations remain 18; no test was added or removed in R2.

[Unknown] R2 compilation and runtime results remain unestablished. After fresh source review and root application, the next owning run should select the repaired case only, using private home-backed `TMPDIR`:

```sh
node node_modules/vitest/vitest.mjs run --project integration packages/polaris-dossier/src/policy-git-native.test.ts -t 'refuses unavailable supervisor pidfds, drains owned children and keeps CPU usage unknown$'
```

Read the actual report and require one selected pass out of 18 declarations, with 17 selection skips. The prior 17 successful cases do not need repeating solely for this fixture compiler repair. The planned mutation checks remain subsequent work, not results of this packet.
