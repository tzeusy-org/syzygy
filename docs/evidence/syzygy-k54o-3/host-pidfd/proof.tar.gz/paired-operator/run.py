#!/usr/bin/env python3
"""Root-reviewed, exclusive eight-sample paired run; no clone or build."""
import argparse, hashlib, json, math, os, re, shutil, signal, statistics, subprocess, tempfile, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
NODE='/home/orca/.nvm/versions/node/v24.6.0/bin/node'
C='packages/polaris-dossier/src/policy-git.c'
TEST='packages/polaris-dossier/src/policy-git-native.test.ts'
FOCUS='keeps the actual policy phase trace, HEAD retry, ref short circuit and working-file checks'
def require(ok,message):
    if not ok: raise RuntimeError(message)
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def interrupted(sig,frame): raise InterruptedError('signal '+str(sig))
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--subject',required=True); parser.add_argument('--output',required=True)
    args=parser.parse_args(); out=Path(args.output).absolute()
    m=json.loads((HERE/'manifest.json').read_text())
    images={a:(HERE/n).read_bytes() for a,n in [('A','old.c'),('B','candidate.c')]}
    require(re.fullmatch('[a-f0-9]{40}',args.subject),'explicit 40-hex subject required')
    require(git('rev-parse','HEAD').decode().strip()==args.subject==m['subject'],'subject mismatch')
    require(out.parent==HERE.parent and not out.exists(),'new outside output required')
    for a,b in images.items(): require(sha(b)==m['arms'][a]['sha256'],'C packet binding mismatch')
    saved=(ROOT/C).read_bytes(); test=(ROOT/TEST).read_bytes()
    require(saved==images['B'] and sha(test)==m['testSha256'],'exact R2 C/test required')
    status=git('status','--porcelain=v1','-z','--untracked-files=all'); diff=git('diff','HEAD','--binary')
    require(not status and not diff and not git('diff','--cached','--name-only','-z'),'expected clean committed R2 subject')
    require(not git('ls-files','--others','--exclude-standard','-z'),'untracked files present')
    env=os.environ.copy()
    for n in ['NODE_OPTIONS','VITEST_MAX_THREADS','VITEST_MIN_THREADS','VITEST_MAX_FORKS','VITEST_MIN_FORKS','SYZYGY_COMPOSED_RETAIN','SYZYGY_F3_NATIVE_EVIDENCE_FILE']:
        require(not env.get(n),'runner override: '+n)
    require(subprocess.check_output([NODE,'--version'],text=True).strip()=='v24.6.0','node drift')
    out.mkdir(); scratch=Path(tempfile.mkdtemp(prefix='pp-',dir='/home/orca/.tmp')); scratch.chmod(0o700)
    identity=scratch.stat(); env['TMPDIR']=str(scratch)
    result={'subject':args.subject,'manifestSha256':sha((HERE/'manifest.json').read_bytes()),'schedule':'ABBABAAB','samples':[],'complete':False,'scratch':str(scratch)}
    for sig in [signal.SIGINT,signal.SIGTERM]: signal.signal(sig,interrupted)
    try:
        for i,a in enumerate('ABBABAAB',1):
            require((ROOT/C).read_bytes() in images.values() and (ROOT/TEST).read_bytes()==test,'source drift')
            (ROOT/C).write_bytes(images[a]); sample=out/('%02d-%s'%(i,a)); sample.mkdir()
            cmd=[NODE,'node_modules/vitest/vitest.mjs','run','--project','integration',TEST,'-t','^'+re.escape(FOCUS)+'$','--reporter=default','--reporter=json','--outputFile='+str(sample/'vitest.json')]
            row={'index':i,'arm':a,'productionCSha256':sha(images[a]),'command':cmd}; result['samples'].append(row)
            start=time.monotonic()
            with (sample/'command.log').open('wb') as log:
                child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                row['pid']=child.pid
                try: row['exit']=child.wait(timeout=120)
                finally:
                    if child.poll() is None: os.killpg(child.pid,signal.SIGKILL); child.wait(timeout=10)
                    row['commandWallMs']=(time.monotonic()-start)*1000
            report=json.loads((sample/'vitest.json').read_text())
            cases=[c for f in report['testResults'] for c in f['assertionResults']]
            passed=[c for c in cases if c['status']=='passed']; skipped=[c for c in cases if c['status'] in ['pending','skipped']]
            row.update(population=len(cases),passed=len(passed),selectionSkipped=len(skipped))
            require(row['exit']==0 and report.get('success') is True and len(cases)==18 and len(passed)==1 and len(skipped)==17,'expected 1 PASS + 17 selection skips / 18')
            require(passed[0]['fullName']==FOCUS and passed[0]['title']==FOCUS and passed[0]['ancestorTitles']==[],'focus identity mismatch')
            duration=passed[0]['duration']; require(type(duration) in [int,float] and math.isfinite(duration) and duration>=0,'numeric duration required')
            row['caseDurationMs']=duration
            row['rawSha256']={n:sha((sample/n).read_bytes()) for n in ['vitest.json','command.log']}
            (out/'result.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(row),flush=True)
        result['pairs']=[]
        for i in range(0,8,2):
            pair={r['arm']:r for r in result['samples'][i:i+2]}
            result['pairs'].append({k:{'A':pair['A'][k],'B':pair['B'][k],'BminusA':pair['B'][k]-pair['A'][k]} for k in ['caseDurationMs','commandWallMs']})
        result['medians']={k:{a:statistics.median(r[k] for r in result['samples'] if r['arm']==a) for a in 'AB'} for k in ['caseDurationMs','commandWallMs']}
        result['complete']=True
    finally:
        require((ROOT/C).read_bytes() in images.values(),'unexpected C bytes; refusing overwrite')
        (ROOT/C).write_bytes(saved)
        result['restoredExactTwoFiles']=(ROOT/C).read_bytes()==saved and (ROOT/TEST).read_bytes()==test
        result['subjectAndDiffRestored']=git('rev-parse','HEAD').decode().strip()==args.subject and git('status','--porcelain=v1','-z','--untracked-files=all')==status and git('diff','HEAD','--binary')==diff
        now=scratch.stat(); require((now.st_uid,now.st_dev,now.st_ino)==(os.getuid(),identity.st_dev,identity.st_ino),'scratch identity drift')
        shutil.rmtree(scratch); result['privateScratchRemoved']=True
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        require(result['restoredExactTwoFiles'] and result['subjectAndDiffRestored'],'final restoration mismatch')
    print(json.dumps({'complete':result['complete'],'medians':result['medians'],'output':str(out)}),flush=True)
if __name__=='__main__': main()
