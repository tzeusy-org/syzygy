import datetime, hashlib, json, os, pathlib, signal, subprocess, tempfile, time

ROOT = pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
PACK = BASE / 'policy-git-host-pidfd-df318-R2'
OUT = BASE / 'host-pidfd-owning-df318-R2'
OUT.mkdir(exist_ok=False)
MAN = json.loads((PACK / 'manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha((PACK / 'manifest.json').read_bytes()) == '7d7eb98388f77dad8facbb865dff72740509205d82da7cb505fc8d5df3a1f1a9'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == MAN['subject']
for rel, row in MAN['candidate'].items():
    assert sha((ROOT / rel).read_bytes()) == row['sha256'], rel
SAVED = {rel:(ROOT / rel).read_bytes() for rel in MAN['candidate']}
C = 'packages/polaris-dossier/src/policy-git.c'
TEST = 'packages/polaris-dossier/src/policy-git-native.test.ts'
FAIL = 'refuses unavailable supervisor pidfds, drains owned children and keeps CPU usage unknown$'
LEAK = 'preserves complete large stdin and independently permits each output stream at maxBuffer$'
TMP = pathlib.Path(tempfile.mkdtemp(prefix='f3p2-',dir='/home/orca/.tmp'))
ENV = dict(os.environ, TMPDIR=str(TMP))
record = {'subject':MAN['subject'], 'candidateManifestSHA256':sha((PACK/'manifest.json').read_bytes()), 'TMPDIR':str(TMP), 'phases':[]}
def run(name, selector, expected):
    report=OUT/(name+'.json')
    cmd=['node','node_modules/vitest/vitest.mjs','run','--project','integration',TEST,'-t',selector,'--reporter=default','--reporter=json','--outputFile='+str(report)]
    phase={'name':name,'command':cmd,'expected':expected,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    record['phases'].append(phase)
    began=time.monotonic()
    with (OUT/(name+'.log')).open('wb') as log:
        proc=subprocess.Popen(cmd,cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=proc.wait(timeout=90)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL); proc.wait(); raise
    phase.update(exitCode=code,seconds=time.monotonic()-began)
    data=json.loads(report.read_text())
    phase['counts']={k:data[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
    phase['failures']=[{'name':a['fullName'],'messages':a['failureMessages']} for f in data['testResults'] for a in f['assertionResults'] if a['status']=='failed']
    assert data['numTotalTests']==18 and data['numPendingTests']==17, phase
    assert code==(0 if expected=='pass' else 1), phase
    assert data['numPassedTests']==(1 if expected=='pass' else 0), phase
    assert data['numFailedTests']==(0 if expected=='pass' else 1), phase
    print(json.dumps({'name':name,'exitCode':code,'counts':phase['counts']}),flush=True)
    (OUT/'progress.json').write_text(json.dumps(record,indent=2)+'\n')
try:
    run('repaired-failure-case',FAIL,'pass')
    (ROOT/C).write_bytes((PACK/'original'/C).read_bytes())
    run('mutant-predecessor',FAIL,'fail')
    (ROOT/C).write_bytes(SAVED[C])
    text=SAVED[C].decode(); old='  if (exitfd < 0) job->failed = 1;'
    assert text.count(old)==1
    (ROOT/C).write_text(text.replace(old,'  /* mutation: ignore unavailable pidfd */'))
    run('mutant-ignore-pidfd-failure',FAIL,'fail')
    (ROOT/C).write_bytes(SAVED[C])
    assert text.count('shut(&exitfd);')==2
    (ROOT/C).write_text(text.replace('shut(&exitfd);','/* mutation: leak pidfd */'))
    run('mutant-leak-pidfd',LEAK,'fail')
finally:
    for rel,data in SAVED.items(): (ROOT/rel).write_bytes(data)
    record['exactCandidateRestored']=all((ROOT/r).read_bytes()==d for r,d in SAVED.items())
    record['scratchRemainders']=sorted(p.name for p in TMP.iterdir())
    (OUT/'terminal.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['exactCandidateRestored']
