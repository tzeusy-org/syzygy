The native policy-Git transport also requires Linux `pidfd_open` support at
runtime. It opens a pidfd for its owned supervisor to wake the host poll when
that process exits; `wait4` remains the source of exit status and CPU usage.
If the pidfd cannot be opened, the operation fails closed, drains and reaps
its owned supervisor, and leaves CPU usage unavailable. The pidfd is closed
after reaping and on cleanup.
