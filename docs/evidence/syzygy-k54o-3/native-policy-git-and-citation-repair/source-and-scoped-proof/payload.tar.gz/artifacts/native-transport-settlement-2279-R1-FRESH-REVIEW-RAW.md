REVISE

Fresh source review: private native policy-Git transport and settlement, R1

Subject: frozen packet /home/orca/.tmp/f3-native-admission-fixes/native-transport-review-2279-R1/manifest.json
Manifest SHA256: 9bf9ab0c17d4b3a7f9201e005dcd41ef11aff34edf100e7ff0974f5eb336db75
Subject base: 2279ffc2211ec987f313ff6aa005259c6dbeb817

[Observed] Python hashlib verification matched the manifest digest and each of its ten listed file digests. A second sha256sum sweep over the manifest and the same ten files produced the same values. Reviewed candidate paths below are relative to candidate/packages/polaris-dossier/src/ inside that packet. This review is bound only to those frozen bytes.

Scope and governing references

[Observed] Read the supplied canonical SEC-3, SEC-5 and VIS-4 clauses. SEC-3 states: "Syzygy itself never runs observed-project code." SEC-5 states: "Unclassifiable content is excluded too: classification fails closed." VIS-4 reserves weakening secret detection and running observed code outside a sandbox to the owner. Applied the engineering-bar and test-rigor skills named in the assignment.

This is a source review of the C addon, isolated supervisor, private protocol, TS transport/scope, fixture and native/meter tests. No candidate code, build, test, observed code, network or provider call was executed. Read-only file/hash inspection and writing this raw review are the only operations used. Runtime behavior remains unverified by this review. Caller deadline/Stop post-query integration is excluded. The accepted possibility that a synchronous CPU query blocks until native Git lifetime/drain is not a finding. This verdict gives no overall recovery, performance or final runtime-integration approval.

F1 — P2: Image descriptor cleanup precedes settlement ownership release

Anchors: policy-git-native.ts:147–150, policy-git-native.ts:28–41, policy-git.ts:95–102, policy-git.ts:111–112.

[Observed] The adapter exposes settleSync() that always re-runs job.current(). Its completion promise closes the held image descriptors in an inner finally before the scope's outer completion callback accounts the receipt and removes the charge from unsettled. current() treats fstat/read errors on those closed descriptors as false.

[Inferred] There is a completion-microtask interval after that close and before the outer meter callback in which cpuClock() can still encounter an uncharged unsettled record. A CPU query there, for example from promise/async instrumentation, gets the valid native usage then rechecks closed descriptors, throws policy-git-image-drift and permanently poisons the scope. Native work is complete and identity verification already succeeded, so this is a false Unknown/failure caused by descriptor lifetime, not real image drift.

Required correction: retain the held descriptors through the point where the scope has accounted the receipt and removed the unsettled record, or retain a shared terminal identity-verification outcome that settlement can safely consume after exact-once cleanup. Cover the completion/settlement interleaving and both completion failure and success cleanup without adding a test-only native export. The existing pre-callback and post-await CPU tests do not cover the intermediate cleanup window. Violates engineering-bar explicit ownership/failure-path expectations and test-rigor 2–3.

F2 — P2: A continuously readable pipe can bypass the native lifetime/control checks

Anchors: policy-git-supervisor.c:124–146 and policy-git-supervisor.c:193–203.

[Observed] drain() loops on successful reads until EOF, EAGAIN or maxBuffer, with no deadline or cancellation check and no fixed work quantum. The loop that checks milliseconds() and cancelled() cannot resume until drain() returns. maxBuffer is a caller-supplied natural bound, not a small fixed transport ceiling.

[Inferred] A sufficiently sustained output producer can keep a pipe nonempty and hold the supervisor inside drain() past the invocation deadline; stderr is especially direct because its bytes are discarded rather than retained. Closing host control after the host-side deadline also cannot interrupt that successful-read loop. Thus the native fixed-lifetime/drain contract is not enforced for this path. This finding concerns the native supervisor's own lifetime, independently of the excluded caller deadline/Stop integration.

Required correction: bound each drain pass or check deadline/control between bounded read chunks, propagate timeout/cancellation to the existing owned-tree cleanup, and add a continuous-output fixture case with a cap high enough that timeout rather than overflow must end it. Cover both stdout and stderr without relying on the current finite 1025-byte overflow fixture. Violates engineering-bar durable failure-path handling and test-rigor 3.

Other scoped observations

[Observed] Request bytes and descriptors are copied before libuv queueing (policy-git.c:57–69). The native admission deadline is recorded before queueing, and an already-expired queued job produces a proven no-child receipt (policy-git.c:61–64, 113–121). The per-job condition variable is signalled by execute() independently of JS completion (policy-git.c:219–236). The scope joins unsettled work before sampling host CPU and deduplicates later matching completion charges (policy-git.ts:57–69, 106–117).

[Observed] The supervisor is the subreaper, not Node; signal_children() uses its own child list and waitpid ownership before signalling, avoiding a process-name census or signalling a reaped PID (policy-git-supervisor.c:89–109, 158–160). The host's wait4 joins the supervisor epilogue (policy-git.c:150–172). Unknown/incomplete receipts poison the scope (policy-git.c:183–188; policy-git.ts:57–66).

[Observed] The supplied tests include independent literal argv/environment/stdin expectations with changed-field negative controls; nested waited-child CPU, detached adopted-child drain, queue-expiry, input copying, failure/overflow, missing-receipt and image-digest cases. They do not exercise the two failure paths above. The retained fixture's detached case is one fork plus setsid, while its nested CPU case waits both generations; these support those specific populations and do not constitute an executed double-fork result. Neither test suite was run in this source-only review.

Final scoped verdict: REVISE.
