REVISE

Fresh source review of the frozen native transport and settlement package.

[Observed] Subject base: `2279ffc2211ec987f313ff6aa005259c6dbeb817`. Manifest: `/home/orca/.tmp/f3-native-admission-fixes/native-transport-review-2279-R2/manifest.json`, SHA256 `013cf3c5a27fe82a9f510cad43bce81fd64fc2374d0d55067d2afd82a1fe1828`. All 10 manifest entries were independently hashed during this review and matched their recorded SHA256 values. The population was eight review files and two governing files.

[Observed] This review read the supplied engineering-bar and test-rigor skills, the frozen eight source/test files, and relevant SEC-3, SEC-5 and VIS-4 text. It ran no product code, build, test, mutation, network request or provider call. Source-reading and SHA256 computation were the only verification performed. The report itself is the only written artifact.

Governing frame: SEC-3 states, “Syzygy itself never runs observed-project code.” SEC-5 states, “Unclassifiable content is excluded too: classification fails closed.” VIS-4 reserves weakening secret detection and running observed code outside a sandbox to the owner. Neither finding asks to broaden an executable, environment, argument, screening or observed-code boundary.

Findings

1. P2 — Recheck the native lifetime at dispatch, after request preparation.

[Observed] `candidate/packages/polaris-dossier/src/policy-git-supervisor.c:171` checks the absolute deadline before reading arguments, environment and stdin. Lines 172–179 then decode/copy the request, allocate stdin and create pipes; line 181 forks Git without another deadline or cancellation check. `transfer()` checks at the beginning of nonempty transfers, but returns immediately for a zero-byte input and has no final check after its last read (`:34–50`). A cancellation arriving after the last transfer is likewise not checked at dispatch. The addon also checks queued expiry at `policy-git.c:118` before its pipe/file-action preparation and calls `posix_spawn()` at `:148` without another deadline check.

[Inferred] A valid request can cross its admission deadline during preparation or a scheduler pause and still start Git afterward. The later supervision-loop timeout rejects the operation, but does not satisfy the explicit criterion that expired work never dispatches. This finding concerns native dispatch only; it does not concern the separately reviewed caller post-join checks or the accepted blocking CPU-clock tradeoff.

Required change: sample the monotonic deadline and relevant control state at the final native dispatch gates, after preparation and before starting the supervisor/Git child. Expiry before Git starts must retain a truthful complete no-Git receipt; do not introduce a new request size/count cap. Extend the nearest queued-expiry regression (`policy-git-native.test.ts:140–170`) with a case that expires during preparation before dispatch and independently confirms that the fixture executable did not start. The existing test covers expiry while waiting for the libuv worker, not this later interval. Engineering-bar: behavior verified and failure paths covered; test-rigor 2–3.

2. P2 — Attempt every held-image cleanup after request-construction failure.

[Observed] `candidate/packages/polaris-dossier/src/policy-git-native.ts:134–137` opens all three held images before serializing the request. Serialization can throw, for example on an invalid command, timeout, environment or `maxBuffer`. The catch at `:143` calls each `image.close()` in a plain loop. If the first close throws, the catch exits immediately and never attempts the remaining held-image closes. By contrast, the normal job close at `:138–142` deliberately catches each close error and continues. Each individual hold marks itself closed before invoking `closeSync()` (`:46–49`), so retrying it is neither needed nor appropriate.

[Inferred] A construction failure combined with one close error leaks the remaining image descriptors, violating the requested exact-once failure cleanup. Poisoning the outer scope does not close those skipped handles, because construction never returned their owner.

Required change: use the same best-effort, attempt-each-image cleanup discipline in the construction catch, preserving an appropriate error and never retrying an already attempted descriptor. Add a focused failure-path regression that makes request construction fail after all three holds and makes the first close throw; independently assert that each held descriptor was attempted exactly once, later descriptors were released, and admission is poisoned. The existing cleanup tests (`policy-git.test.ts:44–68`, `policy-git-native.test.ts:94–113`) cover completed calls rather than this constructor catch. Engineering-bar: durable fixes and failure paths covered; test-rigor 2–3.

[Observed] Source paths examined for the other requested criteria include request/descriptor copying in `policy-git.c:46–71`, per-job wrapper/work references and native condition-variable settlement in `:215–273`, helper wait4 collection and receipt validation in `:153–191`, isolated subreaper/reap/descendant signaling in `policy-git-supervisor.c:80–121,161–164,196–235`, four-read drain bounds in both C files, outer exact-once charge and host-sample ordering in `policy-git.ts:58–73,93–124`, and async image ownership through outer settlement in `policy-git-native.ts:153–162`. These observations are source evidence, not execution evidence.

[Unknown] Runtime/build/admission correctness, the caller post-join deadline/Stop behavior, overall recovery and performance, and suite execution are outside this review. The snapshot contains no predecessor test population, so net test-count growth cannot be established here. A new source review is required for changed bytes; this verdict binds only the manifest identified above.
