REVISE

Source manifest: /home/orca/.tmp/f3-native-admission-fixes/native-runtime-build-review-2279-R1/manifest.json
Source manifest SHA256: fdf16fac3e8f24c2aa97255b127854a05f9db0607443ebdf686f9fa9777d8209
Subject baseline: 2279ffc2211ec987f313ff6aa005259c6dbeb817

[Observed] The manifest digest matches the requested digest. The complete 13-file frozen population matches its manifest hashes, verified independently with Python hashlib and sha256sum. Review covers only candidate/scripts/compile_dossier_policy_git.mjs, candidate/scripts/build_dossier_runtime.mjs, candidate/packages/polaris-dossier/src/url-runtime.ts, and candidate/packages/polaris-dossier/src/url-run-machine.test.ts against the supplied baselines (the compiler helper is new). Other frozen files were read only for type/context. Engineering-bar and test-rigor were applied from the repository's canonical .codex/skills/th-engineering/subskills paths; SEC-2, SEC-3 and SEC-5 supplied the minimal security context.

Blocking findings

1. P2 — External header provenance is first captured after consumption.
   Source: candidate/scripts/compile_dossier_policy_git.mjs:65-73, 87-89.
   [Observed] The final preprocessing command runs at line 65; only afterward does the helper enumerate its dependency file and hash external headers at lines 66-73. The final identity sweep compares against those post-preprocessing hashes.
   [Inferred] A header replaced while preprocessing is underway, before its first identity read, can leave the frozen .i containing predecessor bytes while nativeBuild.headers records successor bytes. If that successor remains installed, the end sweep accepts it. The frozen preprocessed digest honestly identifies compilation input, but the recorded header identities do not establish which header bytes produced it. This violates the requested honest, stable build provenance and engineering-bar's explicitness/verification expectations.
   Required correction: discover the dependency closure, capture the relevant header identities before the final preprocessing pass, and compare both closure and identities afterward (or preprocess from a captured closure). Keep the compile-from-frozen-.i and post-compilation .i checks. Add a focused control for a header change during final preprocessing and for dependency-closure change.

2. P2 — Native/source drift controls exercise size rejection, leaving digest refusal unprotected.
   Source: candidate/packages/polaris-dossier/src/url-run-machine.test.ts:129-136; candidate/packages/polaris-dossier/src/url-runtime.ts:88-95, 132-136, 226-227, 232-234.
   [Observed] Each new addon, supervisor and protocol-source drift control appends bytes. readStable rejects a file larger than its recorded byte count before hashing; therefore these controls reach the size guard rather than distinguishing digest verification. The manifest controls at test lines 109-116 change the Git path but never supply an incorrect valid-form digest for the genuine system Git path.
   [Inferred] Removing the native output/source digest comparisons would leave the added byte-append controls passing; removing the system Git digest comparison would leave the added path control passing. This violates test-rigor 2-4: plausible regressions in the new admission boundary are not pinned by the intended controls.
   Required correction: mutate addon, supervisor and protocol bytes while preserving each file's length; independently mutate the system Git digest to a different valid 64-character hex value while retaining its genuine path and byte count. Assert refusal for each and retain the restored positive admission check. Do not raise caps, waits or timeouts.

Other scoped observations

[Observed] Native addon flags (-fPIC, -shared, -pthread) are present in both preprocessing and .i compilation; the preprocessor receives the optimization/language profile and NAPI definition before compilation. The helper compiles captured first-party source copies, and the build includes its script plus the native sources and protocol header in captured inputs.

[Observed] The runtime requires the closed v2 manifest/output order, recognizes the native source paths explicitly, hashes the actual /usr/bin/git realpath, and stores the selected addon/supervisor/Git identities only in the genuine-runtime WeakMap. A spread-cloned runtime is tested to receive no policy selection. The selected program is frozen, and context source shows the native adapter reopens and rehashes held images.

[Inferred] These four scoped changes introduce no observed-project code execution, provider call, or secret-screening relaxation. This conclusion concerns the reviewed admission/build changes only; it does not approve the separately changing native concurrency or transport implementation.

Verification and limits

[Observed] This was a fresh source-only review. No product code was executed, no build or test was run, no product/candidate file was edited, and no network/provider call was made. The test delta is two added tests plus expanded shared fixture preparation; existing waits/timeouts/caps are unchanged in the diff.

[Unknown] Test outcomes, native performance, final recovery behavior, and concurrency/transport correctness remain unverified by this review. PASS for source correctness is withheld pending the two corrections above. Any later byte change needs a new digest-bound review; this record applies only to the manifest digest named above.
