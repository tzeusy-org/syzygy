# R4 terminal verification

[Observed] Subject source-binding.json SHA-256 5deaeb7eaf077380510d83d7b5c66a62c200a7094f94245e4aa66d1a4d3e010e; 28 bound source files. Python hashlib and independent sha256sum each checked the complete28-file population after commands; no drift.

[Observed] Corrected lifecycle file passed3/3 cases, zero failed/pending, explicit rc0, 4.373s. All three reached intended null/rejected claim or missing post-verification disclosure branch and checked retained scope closure/no resumed launch. Shared typecheck explicit rc0,19.754s, empty log. Owned focused child waited; both private scratch directories removed. Typecheck scratch contained only node-compile-cache at terminal.

[Observed] The unchanged R3 native15 and scope5 passed in the preserved earlier23-case run (20pass/3fixture-setup-fail). Exactly one fixture literal changed afterwards; no product/native source changed. No new single23/23 run is claimed. Full earlier failed attempt and its frozen28-file subject remain in corrections-checkpoint-3. Previous 84/84 caller-clock run remains bound to its own checkpoint2; unchanged files carry that limited evidence.

[Unknown] Rule-6 mutation adequacy, fresh source-review verdicts, updated real production build/runtime admission and genuine stopped recovery/performance remain outstanding. No full recovery or performance claim.
