# R4 fixture-only correction

[Observed] Prior R3 focused attempt retained unchanged in corrections-checkpoint-3: explicit rc1, 20/23 passed; native15 and scope5 passed, three new lifecycle controls failed at writeUrlSupervisorState before recovery predicates. The synthetic tmuxSession violated the existing polaris-[a-z0-9]{1,64} grammar. Only the literal polaris-own-recovery becomes polaris-ownrecovery. All production C/TS and remaining tests are byte-identical to R3. This snapshot binds the complete successor28-file population.

[Unknown] Corrected lifecycle controls and shared typecheck have not run yet. Previous native15/scope5 results bind their unchanged bytes, not the corrected lifecycle fixture.
