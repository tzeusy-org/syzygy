# Fresh bounded source review — CPU initial-spent handoff R1

Verdict: PASS

[Inferred] No actionable blocking findings in the frozen two-file delta. This verdict covers the CPU-budget helper and its owning tests only. It does not establish integrated native performance, complete native effects, caller correctness, a full test gate, or merge readiness.

## Review binding

[Observed] Reviewed on 2026-11-25 in fresh context against the stated acceptance criteria: retain two-argument/default behavior and existing hold/reserve/charge semantics; carry known pre-pool usage once without double charging or recovering spent capacity; reject invalid and over-limit usage before effects; preserve ceilings.

- Base: `2279ffc2211ec987f313ff6aa005259c6dbeb817`.
- Packet: `/home/orca/.tmp/f3-native-admission-fixes/cpu-initial-spent-source-2279-R1/`.
- Manifest SHA-256: `e8eb35422d30ccd6f51648a157be6954a5201c73ca2c3b978e1077551ca6a61a`.
- Frozen patch SHA-256: `a66420f81946e7bd591c1cfca17e230510c463ba8e9e46896c1fdb5813b6c6da`.
- `packages/polaris-dossier/src/url-run-cpu-budget.ts`: 3,626 bytes; SHA-256 `d524f77253ae294cf833030b3b9eea5d4bf0c713fe56b6f881425a42f4ae14b0`.
- `packages/polaris-dossier/src/url-run-cpu-budget.test.ts`: 6,187 bytes; SHA-256 `a1b6c76ed247beca51ce64e28f232cfea230f1d8625dc78a3c00dd6d4c45152b`.

[Observed] Independently recomputed the manifest, patch, and source hashes and byte counts. Both frozen files matched their exact worktree counterparts. An exact-path `git diff --no-ext-diff --binary <base> -- <two paths>` matched the frozen patch byte-for-byte. The owning evidence's original source matched the base commit, and its candidate and test snapshots matched the packet. Other worktree changes were not reviewed. Any change to these reviewed bytes requires a new review.

## Source assessment

[Observed] Lines 11–16 validate `initialSpent` as a safe integer in `[0, limit]` before invoking the supplied clock, then initialize `spent` once and retain `previous = cpuClock()`. The default remains zero. The hold, continuation reservation, charging, release, and sampling bodies are unchanged apart from the clock parameter rename.

[Inferred] This preserves the original accounting equations: initial usage consumes `limit - spent` immediately; later clock deltas add only subsequent work and reduce an active hold. Releasing a hold changes reserved capacity, not spent usage. Continuation reservations still use the remaining original limit. The parameter rename and comment distinguish measured policy-child CPU from other native jobs' full-capacity charges without adding an execution path or raising a ceiling. Correct selection of clock populations by callers remains outside this helper review.

## Test and evidence assessment

[Observed] The test delta is four additions, taking this owning file from six tests to ten. The additions cover carried usage and future host/child deltas, repeated sampling without double charging, hold protection from a competing charge, exact exhaustion after release, legacy/default and explicit-zero behavior, full initial usage, and invalid/over-limit refusal before the clock is read. Existing tests continue to cover continuation reservation, release, rollback, and charge semantics. Expectations use literal values and a deterministic injected clock boundary.

[Inferred] The four additions earn their growth under test-rigor 10: the previous six tests had no nonzero initial-usage input to protect these new behaviors. The tests are behavior-oriented and proportionate to this small accounting change.

[Observed] Read the retained Vitest JSON assertion results, not only exit statuses, and recomputed the referenced log hashes:

- `/home/orca/.tmp/f3-native-admission-fixes/cpu-initial-spent-owning-2279-execution-1/results.json`, SHA-256 `8a5769658b0e6870bc3e6e9ddc0b25a849c29ae6adc66538b558176be6b35406`: predecessor plus candidate tests records 4 failed / 6 passed / 10 total; candidate records 10 passed / 10 total, with no pending tests. The four predecessor failures are the four added tests.
- `/home/orca/.tmp/f3-native-admission-fixes/cpu-initial-spent-rule6-2279-execution-1/results.json`, SHA-256 `2fe2288f50bbf3af691e81e6c5cd714bfd9586edabe7dc0f264f032282e31634`: five named mutations cover dropping initial usage, removing the safe-integer guard, allowing negative usage, allowing over-limit usage, and losing the current clock baseline. Each records one executed assertion failure and nine selection-skipped tests out of ten, with the intended owning test named. The record retains the base, subject hashes, old/new fragments, commands, and restoration declaration. These are assertion failures, not collection failures.

[Observed] No tests, builds, mutation runs, or source edits were performed by this reviewer. The review used the frozen source, frozen diff, and retained execution artifacts. The restoration booleans are record facts; the two reviewed current source files independently matched the frozen candidate bytes at review time.

## Governing review bar and limits

[Observed] Applied the engineering-bar and test-rigor skills; Syzygy CC-BAR-1/2, CC-TEST-1/2/5/7; and the trust-and-evidence distinction between observed artifact contents and an inferred review judgment. Relevant acceptance is anchored to source and retained artifacts above. The helper change touches resource-accounting refusal behavior; this review finds no weakening in the frozen delta. Normative adoption and broader integration are outside the supplied two-file review scope.

[Unknown] Integrated native callsite handoff, sandbox behavior, full suite results, and final adoption status are not established by this review.
