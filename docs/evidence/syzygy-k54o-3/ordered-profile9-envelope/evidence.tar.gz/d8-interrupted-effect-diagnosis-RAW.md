# Exact-head d8 interrupted recovery diagnosis

[Observed] Exact subject d8e1bf97b94989d767d47a0c1abc76ab9db48749, tree e8d1a52d4cc30be438aacc730b263cbeb0088672. Original genuine interrupted case exited1 after417.35469985s; one numbered Vitest worker; peak557836KiB. Resumed render8086.098ms/admission accepted. Companion bindings identify exact original artifact/source bytes; companion metrics compute intervals and denominators. Work was read-only; no test, build, helper, probe, native/provider/network execution or primary edit.

## Actual rejection and ordering

[Observed] The first retained store rejection is check-deadline/operation-limit, operationPhase=effect, phaseElapsed30021.577260ms against30000, totalElapsed35579.041993ms against60000, original run remaining6814045ms. It is not timer-fired, preparation expiry, absolute60000 expiry, original-run expiry, broker expiry or screening refusal. Derived from the diagnostic's own atMs/elapsed values: operation began360251.008434; effect began365808.473167; private preparation5557.464733ms; effect deadline395808.473167, all monotonic ms.

The owning native action is inference-forward ordinal12: the SECOND Messages request's attempt-allowed audit, after its request screening/admission and header mediation had accepted. Its peer preparation and peer audit accepted, then the trusted effect callback rejected after29876.739ms. The effect phase starts before the initial peer boundary and transport wrapper, so its clock is not identical to the observer's callback interval. The audit wrapper rejected after29726.898ms. Inside it the ordered request-admitted append accepted after15707.588ms. That append has12 audit-authority callbacks totaling5491.336ms and5 attempt-authority callbacks totaling10106.798ms; each set is serial/nonoverlapping. Those17 callbacks together occupy15598.134ms of the15707.588ms append. Filesystem stage sums are stat0.979/read0.865/write0.181/sync103.453ms; concurrent stat/read durations must not be summed as exclusive time. Five nested complete attempt-current calls accepted. The rest of the audit wrapper is12022.880ms after subtracting that ordered append and the later1996.430ms base append; this residual includes mandatory full current checks and other work and is not independently attributed to one function by retained timing.

[Observed] Base audit instance2 append7 is relay/design/attempt-allowed. It starts393834.023189 and rejects395830.453594, only1996.430ms into its own30000ms append cap; the enclosing effect30 is tighter and expires first. Current callback511 and its machine-effect callbacks512/513 accepted; current514 and515/516 accepted. Current517 begins394933.634495, calls accepted machine-effect518 (394933.649955->395091.236562), awaits options.current(), then invokes machine-effect519 (395737.263851->395830.144667), which returns false. The last accepted native callback ended at effect29282.763395ms,717.236605ms before its deadline. Callback519 began71.209316ms before that deadline but spent92.880816ms in its fresh boundary path; the store's own check detects expiry21.577260ms beyond the cap. A check that starts before expiry is not a grant through its completion or later use.

[Observed source] The base audit current callback explicitly brackets await options.current() with sessionMachineEffectCurrent() in url-run-sessions.ts:323-324. There is an await between518 and519, so sharing their authority result would be unlawful. commit() maps511 to the outer io precheck,514 to the check immediately before writeRow, and517 to the post-write check before file.sync. Consequently this base audit row was physically appended but its post-write fresh authority check refused before sync, directory sync, publication and success acknowledgement. The observed audit read's25-row count and final relay:attempt-allowed bytes must not be mistaken for an acknowledged/durably authenticated append. No second request send-attempt is retained. Source session-relay.ts orders awaited attempt-allowed audit before subsequent currentness/header/native-forward steps; this failure precedes that second provider forward.

The callback's false result poisons the base audit; its append rejects, the ordered host reports audit-unavailable, ordinal12 native mediation refuses, and ordinal13's later refusal is consequential. The resumed role terminal is stopped/SIGTERM. SIGTERM is cleanup after this path, not evidence of a spontaneous Design process exit. firstRuntimeFailure and firstReproductionRefusal are omitted JSON members; do not call them explicit null observations.

## New screen evidence and cross-run correspondence

[Observed] Three final screen snapshots are retained on inference ordinals1,7,10 (zero-based retained-array positions0,5,8). They correspond in source order to initial Messages request, first provider response, and post-prepared SECOND Messages request. All report execution=accepted, content=accepted, output stage, childSpawned/childClosed=true, stopReason=none. Poll counts1/1/11; cumulative full poll duration151.593/196.254/2391.145ms, maxima151.593/196.254/253.176ms. childSpawned confirms only prlimit's spawn event; accepted parsed output supplies stronger execution evidence. These observations prove the three named screen calls accepted in this run, not native recovery or a general census/performance fix.

[Observed cross-run labels] c52 reached initial request -> attempt-allowed -> send-attempt -> send-outcome -> response -> response-admitted -> headers; its first MCP prepared reply's enclosing store operation30 then refused (host action25424.579ms, prepared append13814.857ms). f9's phase-split run accepted that MCP prepared reply, then ordinal10's post-prepared second-request screening wrapper refused4087.042ms; low-level launcher sample358 had process/storage census bounded-timeout2203.984ms under2000. d8 likewise accepted the MCP prepared reply (host action26841.497ms, prepared append14493.729ms), then accepted ordinal10's named post-prepared second-request screening/admission (screen5520.226ms), accepted ordinal11's header mediation, and rejected ordinal12 attempt-allowed audit at its real effect30 bound. This is matching protocol/source-order stage labels across runs, not an assertion of identical request bodies/model output or exclusive causal repair. f9 lacked screen spawn/poll/result discriminators, so the new successful screen cannot establish why f9 failed.

## Census, closure and retained populations

[Observed] d8 launcher samples405; independent authority observer started405, verified405, verify-refused/rejected0, confirmed404, confirm-refused/rejected0. No firstRefusal is present in launcherInspection or design roleInspections, and no firstSampleRefusal is present. The latest sample405 starts monotonic395735.056086; process/storage settle accepted at+201.956/+227.479ms, verify accepted at+371.488ms; no confirm completion is retained. Terminal stopped occurs while this last verification is in flight, and the independently retained verify stamp settles after terminal notification. The resource deadline itself did not reject in the retained first-refusal fields. Earlier samples' full phase timings are not retained; these counters and bounded summaries cannot prove every possible transient cause absent. In particular, absence of a census refusal in one run is not proof that polling repaired the old one.

Populations: one store refusal entry, omitted0;2 audit instances/2 retained; audit2 callbacks519 started/32 retained,8 appends/8 retained. FirstCallbackRefusal preserves519 despite ring retention; append8 launch-terminal rejects immediately with0 callbacks after poisoning.13 inference records started/12 retained: missing ordinal5 due observer eviction, retained10 accepted and2 refused (12/13); do not report all13 outcomes as inspected. Three screen snapshots retained. Three native connections accepted capture/authorization (inference, MCP, fresh inference). MCP ingress2 reads: data1/end1, refused0/rejected0. Resumed failures[] is empty; terminal failure field says audit-unavailable. These are bounded observer populations, not blanket absence claims about every internal action.

## Scope for a further design

[Inferred] This evidence supports a whole-effect composition audit, because multiple mandatory private/durable operations run serially inside one30s effect. It does not support another isolated cap increase or cached authority. Any candidate must account for the complete ordered observe/append/current/base-audit path, preserve independent child and original parent/run/record bounds, and explicitly adopt any changed numeric semantics. No implementation candidate is part of this diagnosis.

Source proves518/519 cannot share a sample (await), ordered writer calls separated by descriptor I/O/durable effects cannot share across those effects, and the current()/processingCurrent()/assertCurrent() chain has intervening awaits and protected-delivery reads. Truly adjacent synchronous derivations require a narrower ownership/callsite proof before optimization; high callback counts alone do not prove redundancy. Proposed budget alternatives, exact profile/horizon/planner consequences and the distinction between native capture/effect and store-effect30 belong to the next source-only design audit.

[Unknown] Actual interrupted recovery, final capture, hosted performance, exclusive original cause of f9 census refusal, and success of any future budget/optimization design.

## Exact owning source excerpts

url-machine-store.ts:491 at exact subject
```typescript
        const monotonic = performance.now(), operationElapsedMs = monotonic - began;
        if (operationElapsedMs >= operationMilliseconds) {
          reportRefusal({ phase: 'check-deadline', reason: 'operation-limit', operationElapsedMs,
            runRemainingMs: deadline - now }); throw refused();
        }
        if (orderedPhases !== undefined) {
          const phaseMilliseconds = effectBegan === undefined ? orderedPhases.preparation : orderedPhases.effect;
          const phaseElapsedMs = monotonic - (effectBegan ?? began);
          if (phaseElapsedMs >= phaseMilliseconds) {
            reportRefusal({ phase: 'check-deadline', reason: 'operation-limit', operationElapsedMs,
              runRemainingMs: deadline - now, operationPhase: effectBegan === undefined ? 'preparation' : 'effect',
              phaseMilliseconds, phaseElapsedMs }); throw refused();
          }
        }
        return now;
      };
      const check = (): number => {
        checkDeadline();
        live();
        return checkDeadline();
```

url-machine-peer.ts:495 at exact subject
```typescript
      // Native reattestation can start a fresh inspection. Settle that sample
      // before the synchronous effect guards, within the same held lease.
      await current(state, true);
      const effectiveUntil = Math.min(context.deadline, Date.parse(record.expiresAt), Date.parse(active.expiresAt));
      const boundary = (): boolean => {
        try {
          if (check(state) >= effectiveUntil) return false;
          const now = lease.sampleCurrent === undefined ? lease.current() ? lease.now() : null : lease.sampleCurrent();
          return now !== null && now < effectiveUntil;
        } catch { return false; }
      };
      // All private preparation, including the fresh audit and reattestation,
      // has settled. Only this trusted continuation can start the effect phase.
      if (isOrderedDesignSessionProfile(options.profile) && lease.beginEffect?.() !== true) throw refused();
      if (!boundary()) throw refused();
      const value = await effect(boundary);
      if (!boundary()) throw refused();
```

session-machine-transport.ts:61 at exact subject
```typescript
export function sessionMachineEffectCurrent(): boolean | undefined {
  const selected = effects.getStore();
  return selected === undefined ? undefined : selected.active && selected.boundary();
}
/** Protected producers call this again immediately before an awaited write. */
```

url-run-sessions.ts:319 at exact subject
```typescript
  const audit = await createUrlSessionAudit({ parent: options.auditParent, name: options.auditName, binding,
    originPolicySha256: options.originPolicySha256, project: 'project:syzygy', pin: record.subject.pinnedRevision.commit,
    principal: options.principal, profiles: plans.map(plan => plan.profile), declaredClasses: options.declaredClasses,
    screen: options.screen, deadline: options.deadline, firstDesignRound: resume?.verified.nextDesignRound ?? 1,
    current: async () => sessionMachineEffectCurrent() !== false
      && await options.current() === true && sessionMachineEffectCurrent() !== false });
```

url-ordered-design-session.ts:379 at exact subject
```typescript
    await serialize(async () => {
      await requireCurrent();
      if (event.route !== 'messages' || event.received === null || event.admission === null) throw refused();
      const scope: Scope = { requestId: event.requestId, route: event.route, received: byteIdentity(event.received), forwarded: byteIdentity(event.admission) };
      if (event.event === 'attempt-allowed') {
        if (pending !== null || response !== null) throw refused();
        if (initial) {
          const checked = request;
          request = null;
          if (admittedInitial || checked === null || !equal(checked.received, scope.received) || !equal(checked.forwarded, scope.forwarded)
            || event.consumedToolResults.length !== 0 || !budget.reserve('design', event.admission)) throw refused();
          admittedInitial = true;
          initialBudgetPending = true;
          pending = { scope, admission: null, wrapper: null, step: 'send-attempt' };
          return;
        }
        const checked = request;
        request = null;
        const exactResult = event.consumedToolResults[0], latest = receipts.at(-1);
        if (checked === null || !equal(checked.received, scope.received) || !equal(checked.forwarded, scope.forwarded)
          || checked.resultWrappers.length !== receipts.length || event.consumedToolResults.length !== 1
          || !exactResult || !latest || exactResult.toolUseId !== latest.call.id || !equal(byteIdentity(exactResult), latest.reply)
          || budgetReservation?.reserve(event.admission) !== true)
          throw refused();
        const results = checked.resultWrappers.map(({ toolUseId, wrapper }, index) => {
          const receipt = receipts[index]!;
          if (toolUseId !== receipt.call.id) throw refused();
          return { receipt: receipt.receipt, wrapper };
        });
        const admission = await append('request-admitted', { ...scope, results, logical: checked.logical, transcriptSha256: checked.transcriptSha256 });
        pending = { scope, admission, wrapper: results.at(-1)!.wrapper, step: 'send-attempt' };
        await requireCurrent();
```

url-session-audit.ts:513 at exact subject
```typescript
    const checkCurrent = async (deadline: number): Promise<void> => {
      guard(deadline); if (await wait(track('callback', current), deadline) !== true) poison(); guard(deadline);
    };
    const io = async <T>(deadline: number, fn: () => Promise<T>, cleanup = false): Promise<T> => {
      // Closing verifies the historical physical prefix only; it grants no new
      // act and must still release descriptors after the run becomes stale.
      if (!cleanup) await checkCurrent(deadline);
      const result = await wait(track('filesystem', fn), deadline);
      if (!cleanup) { guard(deadline); await checkCurrent(deadline); }
      else if (poisoned || performance.now() >= deadline) poison();
      return result;
```

url-session-audit.ts:833 at exact subject
```typescript
      try {
        const tail = await io(deadline, async () => {
          await inspectIdentities(deadline);
          await checkEffectCurrent(deadline);
          const full = await writeRow(role, row.bytes, deadline, checkBoundary);
          await checkEffectCurrent(deadline);
          await segments.get(role)!.file.sync();
          await checkEffectCurrent(deadline);
          await directory.sync();
          await checkEffectCurrent(deadline);
          await inspectIdentities(deadline, { ...full, role });
          if (checkEffectCurrent !== checkCurrent) await checkEffectCurrent(deadline);
          return full;
        });
        publishRow(role, row, tail, deadline, checkBoundary);
```

session-relay.ts:317 at exact subject
```typescript
        if (await effect(boundary => boundary() ? admittedHeaders() : null) === null) { await auditRefusal(403); return; }
        // This await is the actual choke point ordering, not an after-send log.
        await audit(event('attempt-allowed', 'allowed', null));
        if (terminal) return;
        if (!(await ports.current()) || terminal) { await auditRefusal(409); return; }
        // Credential expiry and current policy are checked after the audit,
        // without another await between header preparation and native send.
        const sending = await effect(boundary => {
          const forwardingHeaders = admittedHeaders();
          if (forwardingHeaders === null) return null;
          if (!boundary()) throw new Error('session-machine-transport-unavailable');
          return { exchange: forward({ route, headers: forwardingHeaders, body: forwardingBody, signal: controller.signal, limits }) };
```
