import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

root = Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
out = Path('/home/orca/.tmp/f3-native-admission-fixes/guard-profile9-execution')
out.mkdir(exist_ok=False)
tmp = Path(tempfile.mkdtemp(prefix='f3-', dir='/home/orca/.tmp'))
tmp.chmod(0o700)
env = os.environ.copy()
env.update(TMPDIR=str(tmp), VITEST_MAX_THREADS='1', VITEST_MIN_THREADS='1', VITEST_MAX_FORKS='1', VITEST_MIN_FORKS='1')
results = []
def run(name, argv):
    began = time.monotonic()
    with (out / (name+'.log')).open('w') as log:
        p = subprocess.run(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = {'name':name,'argv':argv,'exit':p.returncode,'elapsedSeconds':time.monotonic()-began}
    report = out / (name+'.json')
    if report.exists():
        r=json.loads(report.read_text())
        row['tests']={k:r.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
        row['failed']=[{'name':a['fullName'],'messages':a.get('failureMessages',[])} for f in r.get('testResults',[]) for a in f.get('assertionResults',[]) if a.get('status')=='failed']
    results.append(row)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k!='failed'}),flush=True)
    return row
def vitest(name, project, paths, pattern=None):
    args=['node','node_modules/vitest/vitest.mjs','run','--project',project,*paths]
    if pattern: args.append('--testNamePattern='+pattern)
    return run(name,[*args,'--reporter=json','--outputFile='+str(out/(name+'.json'))])

base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert base=='d8e1bf97b94989d767d47a0c1abc76ab9db48749'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
guard='apps/three-surface-poc/src/sync-child-process-guard.test.ts'
packet=Path('/home/orca/.tmp/f3-native-admission-fixes/machine-peer-guard-pin-candidate')
assert (root/guard).read_bytes()==(packet/'original-guard.ts').read_bytes()
shutil.copyfile(packet/'candidate-guard.ts',root/guard)
try:
    passed=vitest('guard-positive','integration',[guard])
    assert passed['exit']==0 and passed['tests']['numTotalTests']==11 and passed['tests']['numPassedTests']==11
    shutil.copyfile(packet/'original-guard.ts',root/guard)
    negative=vitest('guard-old-pin-mutant','integration',[guard],'^suite child processes and the vitest worker RPC runs only short local tools synchronously in a suite test file or any module it imports$')
    assert negative['exit']!=0 and negative['tests']['numFailedTests']==1 and negative['tests']['numPassedTests']==0
finally:
    shutil.copyfile(packet/'candidate-guard.ts',root/guard)

profile=Path('/home/orca/.tmp/f3-native-admission-fixes/ordered-profile9-envelope-candidate')
binding=json.loads((profile/'binding.json').read_text())
for file in binding['files']:
    path=file['path']
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==file['originalSha256']
    assert hashlib.sha256((profile/'candidate'/path).read_bytes()).hexdigest()==file['candidateSha256']
    shutil.copyfile(profile/'candidate'/path,root/path)
assert run('typecheck',['npm','run','typecheck'])['exit']==0
assert vitest('profile-unit','unit',['packages/polaris-dossier/src/url-ordered-design-work-budget.test.ts'])['exit']==0
assert vitest('profile-integration','integration',['packages/polaris-dossier/src/url-machine-store.test.ts','packages/polaris-dossier/src/session-launch.test.ts','packages/polaris-dossier/src/url-run-artifacts.test.ts','packages/polaris-dossier/src/url-machine-peer.test.ts'])['exit']==0
print('SCOPED VERIFICATION COMPLETE; not full canonical or native acceptance',flush=True)
