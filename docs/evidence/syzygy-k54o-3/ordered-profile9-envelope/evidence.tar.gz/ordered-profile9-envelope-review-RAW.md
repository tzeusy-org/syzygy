# Independent source review — ordered profile9 envelope

Verdict: PASS

[Inferred] PASS is limited to the frozen source candidate and its proposed verification plan. It permits proceeding to the authorized application and execution checks; it is not a claim that tests pass, native recovery completes, generated pins match, or the seven-minute acceptance is met.

## Subject and binding

- Base checkout: /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w
- [Observed] Base HEAD: d8e1bf97b94989d767d47a0c1abc76ab9db48749; git status --porcelain emitted no entries during this review.
- Frozen packet: /home/orca/.tmp/f3-native-admission-fixes/ordered-profile9-envelope-candidate/
- [Observed] MANIFEST.json SHA-256: 372be4d3578555ce654d6721204362704243bc45a4b8e4ec7647037ecf3ee3d9
- [Observed] candidate.patch SHA-256: 1ba33573fc986daf6e25ae0d28d203b25eda9637ad3cf3db0ead10112fe9e84a
- [Observed] DESIGN.md SHA-256: 5507fecfc836f8c7a4738b25774634601757afe7f7f86bf8de00a7b8d03f6f3c
- [Observed] mutation-plan.json SHA-256: 494803b8427057e5d03e322324900c7af0130e339712d827bc99d457ff005e12
- [Observed] Python hashlib checked the 22 manifest-listed files against their byte lengths and digests, with no mismatch. sha256sum separately corroborated the manifest and patch hashes. The seven original source files match the base checkout bytes. Python difflib reconstruction of their seven original/candidate pairs equals candidate.patch byte-for-byte. The 23 explicitly listed unchanged-dependencies.json source/compiler/lock hashes match the checkout. This is the declared dependency population, not a complete transitive build closure.

## Governing references and acceptance

Used the heart-and-soul, engineering-bar and test-rigor skills, SEC-1/SEC-2/SEC-3/SEC-5, trust-and-evidence.md, CC-BAR-1/2, CC-TEST-1/2/5, and CC-REV-1/2. This fresh review received the frozen artifact, its DESIGN/test plan and acceptance criteria; it did not inspect other reviewers' conclusions.

REQ-polaris-generation-035, dossier-url-declared-source-run/proposed/polaris-generation/spec.md:291 requires capacity reservation “without extending the recorded original deadline or lowering the ordinary role caps.” Its line293 requires refusal rather than restarting or escaping live transfer bounds. REQ-polaris-generation-048 at789 requires finite registry/audit I/O/output/lock/operation limits under the original deadline, and at795 requires bounded lifecycle operation execution and refusal on inconsistent authority. These references govern the review, not the candidate DESIGN's own claims.

Acceptance is a coherent selected preparation30/effect55/aggregate85/product145 envelope within the existing broker85; preservation of stricter independent audit/screen/capture30, census2, connection300 and original caller/run/record bounds; refusal of retained profile7/8; behavioral tests and a bounded follow-up verification plan. Effect55 is an agent policy allocation. It does not assert that every serial child maximum fits: two serial audit30 operations can still refuse under effect55 or a tighter parent.

## Review observations

1. [Observed] The production diff touches session-profile.ts, url-product-read-limits.ts and url-machine-store.ts. The limit module independently fixes preparation at30,000, fixes aggregate at85,000, derives effect as55,000, and derives only ordered startup/replacement product leases as render60,000 +85,000 =145,000. Ordinary render60,000 and other product5,000 remain literal existing entries. session-profile.ts:11 advances the ordered ID to9, with immutable canonical transcript identity compiled from these values at37–39. The ordinary profile fixture retains its exact literal ID/byte/digest assertion in session-launch.test.ts:674–677.

2. [Observed] url-machine-store.ts:848–855 updates both closed ordered-phase ceilings and retains positivity and aggregate equality. Entry still requires a first-party issued native profile; the durable audit profile digest, role and run checks at858–861 remain. An older credential cannot be silently upgraded by requesting profile9. No compatibility branch is introduced.

3. [Observed] Store aggregate time starts once; checkDeadline at482–505 checks original run, aggregate, then phase. beginEffect at622–635 checks preparation/live authority before starting effect and refuses a repeated transition. armTimer at605–619 uses the minimum of remaining aggregate, run and phase time. Those control-flow bodies are unchanged by this patch; changing the ceiling expressions introduces no clock reset. Admission30, queue256, contention1, ordinary5/native20 remain outside the ordered changed ceilings.

4. [Observed] The lexical consumer sweep over696 non-dist .ts/.mjs source files under packages/ and scripts/ returned34 matching lines, corroborated independently by Python and rg. The production references are in seven files: session-profile, url-product-read-limits, url-machine-store, url-machine-peer, url-run-ordered-attempt, url-ordered-design-session and url-ordered-design-work-budget. Tracing those references found preparation passed to the separately closed capture30 check (peer24–30); aggregate passed to product coverage/preflight horizon (attempt188–197), to the existing planner check against broker85 (work-budget118–119), and into the ordered profile consumed by store. The selected allocation does not widen capture or broker. Generated dist inputs are outside this source census and must be rebuilt/reverified.

5. [Observed] session-machine-transport.ts:99–110 anchors the connection deadline before capture, caps caller-selected connection at300,000 and clips capture to that original connection; at184–195 its effect boundary combines transport currentness and native-lease currentness. url-machine-peer.ts:477–515 preserves preparation ordering and effectiveUntil=min(context deadline, record expiry, active-instance expiry). url-operation-products.ts:48 and url-design-product.ts:191 preserve immutable caller/continuation clipping. The new product145 maximum therefore grants no fresh original run/record lifetime.

6. [Observed] Independent tighter checks remain in source: broker85; relay/bridge300; URL_SESSION_AUDIT_LIMITS.milliseconds30,000 and queued enqueue deadline; ordered request/response/tool/audit/terminal work envelopes30,000 with existing CPU/read/detector counts; screen worker minimum of selected bound and operation remaining; launch process/storage resource census2,000 and other inspection5,000. The candidate does not modify those sources. These parents can refuse before the selected store envelope completes.

7. [Observed] url-runtime.ts:23–31 includes the three changed production source files in its verified inputs; its registry SHA at191–192 binds inputs and product-read limits. url-recovery.ts:120 and url-role-plan.ts:226–239 retain runtime registry and recompiled-profile mismatch refusal. [Inferred] This is a deliberate profile/runtime identity break requiring a fresh matching runtime/run. It must not be repaired by relabeling historical profile8 records or changing support digests by hand. The unchanged standalone support compiler inputs support, but do not prove, byte identity after rebuilding.

8. [Observed] The seven-file patch modifies existing test declarations rather than adding declarations. Store tests use literal elapsed values to prove success after the old30s effect allowance (29s preparation +45s effect), failure at preparation30, failure at effect55.001 before aggregate85, aggregate-first failure at85, exact effect55 refusal, duplicate transition/withdrawal/run-deadline refusal, and independently selected suspended phase timers30/55. Retained credential inputs now include both7 and8 shapes with canonical digest recalculation and assert callback non-entry. Product tests exercise public read capabilities at caller70 and maximum145, expiration/retirement, and refusal of145.001. Profile tests pin literal30/55/85 alongside the broker relationship. Planner tests assert85 equality,86 refusal and reservation unchanged by the optional mediation parameter. Those are observable behaviors with literal or independently compared expectations, rather than expected values imported from the changed constants.

9. [Inferred] The mutation plan is appropriate to the predicates: prep decoupling, phase/aggregate deadline, timer minimum, durable profile binding, caller clipping, broker upper bound and one-use effect transition. Its expected failure metadata distinguishes phase from aggregate refusal. No mutation results are claimed: the plan marks them NOT RUN and requires isolated execution retaining exact old/new bytes and assertion output.

## Findings and execution limits

[Inferred] No source defect requiring revision was identified within this frozen seven-file patch and the traced envelope acceptance criteria. The proposed55s allowance is finite and compatible with the existing85s broker allocation; it is not an empirical duration estimate or an additive worst-case guarantee.

[Unknown] Tests/typecheck, mutation kills, generated artifact/pin equality, actual profile8-to9 recovery refusal, both genuine native recovery cases, first refusals, record2 publication, unchanged closed-already bytes, hosted gates and420s timing. No project tests, build, compiler, native case or heavy command ran in this review. These remain required execution evidence before completion under CC-BAR-2 and CC-TEST-2. The source-only PASS does not change the prior native failure's status.

Review output created outside the repository. Primary source, git/index, Beads and remote state were not mutated.
