# d8 whole ordered-effect budget/design audit

[Observed source] Exact d8e1bf97b94989d767d47a0c1abc76ab9db48749, tree e8d1a52d4cc30be438aacc730b263cbeb0088672. This is source-only design analysis following the separately frozen d8-interrupted-effect-diagnosis-RAW.md. No implementation, tests, typecheck/build, probe, provider/network/native execution or primary edit. The proposed numeric policy below is not an adopted or verified repair. Exact source/governing/artifact bindings accompany this report.

## Complete ordinal12 action and nested ceilings

[Observed] The failing native operation is inference-forward for the post-prepared SECOND request's attempt-allowed audit. session-relay audit() opens one context.mediate around the whole asynchronous ports.audit callback. The protected callback is serial:

1. Initial peer boundary, then ordered-host audit callback's await current().
2. controller.observe(event), whose serialize wrapper performs await requireCurrent().
3. For attempt-allowed after the first result, validate/reserve the complete admitted request, then append ordered request-admitted under an ordered audit operation envelope.
4. await requireCurrent() after that durable ordered append.
5. input.audit(event), which in this attempt appends the base relay attempt-allowed row. Usage would be a separate preceding base append when present, though this exact attempt-allowed has no usage.
6. Return through the effect callback, fresh post-effect peer boundary, store's fresh post-operation checks and final acknowledgement. No second provider forward can occur before the awaited audit and later independent ports.current/header/native-forward checks succeed.

The caps are nested, not additive grants:

| Owner | d8 selected bound | Origin and clipping |
| --- | --- | --- |
| Original run, record/active instance and live claims | original immutable deadlines/currentness | Every relevant fresh native/store/current boundary; no renewal |
| Relay/transport |300000ms | Connection/HTTP origins independently retained; encompasses multiple mediated actions |
| Ordered store mediation | preparation30000 + effect30000 = absolute60000ms | Absolute begins before lock/private preparation; one-use trusted beginEffect; original caller/run clips |
| This store effect |30000ms | Begins before first actual peer boundary and callback, contains every action above |
| Full parent/native reattestation in peer preparation | parent join5000ms; capture selected30000ms | Occurs before effect; independent native helper/kernel limits remain finite |
| Ordered controller request/response/tool/audit/terminal operations | each30000ms,64000000 CPU microseconds,500000000 audit-read bytes plus detector bounds | openOperation, measured checks/timer; auditOperation covers writer append, not whole host.observe |
| Ordered request-admitted writer | encloses store.current, durable append and post-durable current | Writer's original attempt deadline; ordered audit30 bounds the whole append |
| Base URL audit append |30000ms per enqueued row | Starts at enqueue; clipped by original input/attempt deadline; queue waits included; fresh current around IO/effects |
| Ordered screening child |20000ms,8 CPU seconds,2147483648 address bytes | Not part of ordinal12; its request screen accepted in ordinal10 |
| Ordered launch census | process/storage2000ms, full authority join5000ms | Independent sampling/stop; unchanged |
| MCP broker |85000ms | Does not own this inference audit; it is the existing fixed supported per-turn broker policy used by the work planner |

[Observed] d8's operation spent5557.465ms in preparation and30021.577ms in effect. The callback29.877s includes the ordered append15.708s; its17 serial audit/attempt authority callbacks consumed15.598s. Base append7 was only1.996s into its own30s cap when the enclosing effect expired after its physical write and before sync/publication. Another12.023s of the audit wrapper lies outside those two append intervals, including host/controller full current work. The independent child30 limits do not imply a complete parent effect30 fits. The current effect began before the wrapper timestamp, so inferring a spare123ms from callback29.877 would be false.

## (a) Duplicate synchronous work: no safe local removal established

[Observed source] Current callback518 and519 have await options.current() between them (url-run-sessions.ts:323-324). They are the required before/after samples and cannot share. Each ordered checkAttemptCurrent wraps an awaited attemptCurrent with awaited base checkCurrent before and after (url-session-audit.ts:1027-1032). Commit separates those samples with prefix IO, write, sync, directory sync and another prefix scan. No cached pass may cross these operations. Physical append/sync/publication boundaries must retain their fresh checks, including the post-write sample that correctly refused d8.

The superficially adjacent processingCurrent() at url-run-ordered-attempt.ts:155 and assertCurrent()->assertProcessingCurrent() in checkUrlOrderedProductCurrent are not a proven pure scalar duplication. Between them the helper calls urlDesignProductLeaseState(), which invokes lifetime.authorityCurrent/backendState/entry.checkLease callbacks and can irreversibly terminate the product. On expired products it invokes the refresh path, which can reproduce and await. Deleting the earlier check without proving those callback effects and retirement semantics changes more than one private derivation. Likewise the peer boundary's check(state) and lease.sampleCurrent cover different process/channel and protected store/parent authorities, with expensive external filesystem observations between clock samples. They are not interchangeable results.

[Inferred] A future focused optimization could compose genuinely identical derivations within one trusted boundary and retain a final clock sample, but this audit established no such replacement with a complete withdrawal/error/order proof. Callback counts and long durations are not proof of redundancy. Do not mix speculative guard removal with the numeric repair.

## (b) Explicit aggregate allocation from existing85: defensible scope

[Proposed agent policy, not current fact] Select the existing broker policy85000ms as the shared ordered mediation capacity reference. Preserve preparation/capture30000ms independently. Derive effect as85000-30000=55000ms; total as30000+55000=85000ms. Derive ordered product startup/replacement from existing render60000+mediation85000=145000ms, clipped to original run as before. Prospective product coverage becomes min(originalRunDeadline, now+85000); it is not an entitlement to exceed tighter transport/broker/record/instance/caller lifetime. The store's one-use transition and absolute origin remain unchanged; do not rebase timers to a new now or let preparation/effect borrow capacity.

This is a meaningful change to the prior A-236 actual-effect30000 semantic decision. Name it plainly as a larger finite aggregate effect allowance for mandatory host preparation/audit/current work, not a restored latent allowance or an optimization. No standalone native-effect30 timer exists underneath the transcript field: nativeEffectMilliseconds is consumed by url-machine-store's ordered effect cap. Capture uses nativePreparationMilliseconds and hard-clips<=30000, independently. Native kernel/program helper caps, detector CPU/bytes/policy, sandbox and ordinary profile/store caps need no change.

The55 is an allocation constrained by the existing85 policy, not a conservative sum guaranteeing every nested maximum. Two serial child audit30 maxima alone total60 before full current work. For this exact audit, the runtime's aggregate55 may still refuse when child work approaches those maxima. REQ035 permits stricter parent/role/broker limits and ceilings that do not promise every legitimate packet fits. The honest supported contract is finite aggregate capacity with every child's limit additionally enforced, and truthful early planning/refusal, not guaranteed55 completion independent of original parents. If reviewers require a guarantee that every child may consume its individual maximum and still complete, REVISE this proposal: neither55 nor an unexplained85 total proves that stronger contract; a separate complete bounded-current decomposition/admission design would be necessary. This limitation must remain in the adoption/test evidence.

For the observed path this proposal removes the accidental30s aggregate that serial mandatory work demonstrably exceeded. [Unknown] Whether the original native case completes under55 and whether later parts/verdict/ack have another tighter bottleneck. Preserve the whole path assertions and expose first refusal rather than repeating numerical adjustments blindly.

## Coherent minimal source impact if root chooses this policy

Use one leaf numeric policy home to prevent85 drift and cycles. A small url-session-resource-limits.ts could own the existing broker85000 literal, independent preparation30000 literal, derive ordered effect by subtraction and total by addition. Do not import session-broker.ts into session-profile.ts or product-limit policy: broker -> transport -> peer -> profile already creates a path and would introduce a cycle. No new runtime subsystem is needed; the leaf contains constants only.

Production files that would change:

- New leaf constants; session-broker.ts reads the shared existing85 without changing its actual cap.
- url-product-read-limits.ts uses the shared derived mediation85 to derive145. Crucially, remove the current preparation=effect alias; otherwise changing effect would accidentally raise capture/preparation to55.
- session-profile.ts imports the new constants and issues ordered-design-9 with explicit nativePreparation30000/effect55000/mediation85000. Full canonical transcript/profile digest changes. Existing ordinary profile bytes and public supported request/response field shape stay as before.
- url-machine-store.ts validates ordered preparation/effect against the exact selected policy (including positive safe integer and sum consistency) rather than its current independent effect<=30000 literal. Generic/ordinary limits and caller/run/record clipping remain; no every-leaf-call-must-have85 admission requirement. Existing trusted beginEffect, effect-start/absolute clocks/timers and diagnostics are reused without reset or removed checks.
- url-run-ordered-attempt.ts and url-ordered-design-work-budget.ts read the shared broker85 in their existing enforcement/cap validation. All operation child30 envelopes remain unchanged. Product horizon already reads transcript.nativeMediation and therefore needs no unrelated control-flow rewrite.

url-machine-peer.ts already selects capture from preparation and enforces<=30; it should remain unchanged except meaningful assertions if needed. url-ordered-design-session.ts already passes transcript.nativeMediation into reservation and enforces original child envelopes. It should remain unchanged unless a focused test exposes an actual inconsistency.

Planning already validates mediation<=broker and counts broker once. With equal85 it must accept equality and reject85001/tampered profiles, without double counting the85 leaf. Current full four-result prospective wall calculation is4*(relay300000+broker85000)+(request4+response4+tool4+audit24+terminal1)*30000=2650000ms before its strict original deadline comparison; this arithmetic does not change because the existing broker bucket already counts85. Reservation still occurs before first prepared release and uses actual charged work thereafter. The broker can still refuse because its connection/invocation includes ingress/preflight/reproduction and has a different origin from transport;85 total mediation does not reserve a fresh85 entitlement inside an already-used broker. This remains an explicit tighter-parent limitation, not permission to reset the connection.

Profile/program coherence: profile9 must be newly issued and pinned everywhere. Retained profile8/7 credentials must refuse rather than silently upgrade. The screen worker reissues the profile and binds its digest, so changing profile source also changes compiled trusted worker bytes/runtime input tree; generate/install through existing pinned runtime tooling in the later authorized verification clone. No support script literal hash change is justified by this numeric-only source change. Update exact profile-ID/digest assertions and stale-profile refusal fixtures, keeping legacy7 coverage and adding8 rather than replacing one unexamined predecessor with another. Bind review to final source and fresh runtime/program bytes before a native run; no prior static capture proves profile9 behavior.

## Proportional proof required before adoption

Extend existing phase boundary tests: late preparation plus effect greater than30 but below55 accepts while total<85; preparation exactly30 refuses; effect exactly55 refuses; absolute exactly85 refuses; original shorter caller/run deadline refuses; duplicate/reentrant beginEffect still rejects; withdrawal before/after await/effect still rejects with the original guard/error/return ordering. Explicitly retain ordinary30/generic limits, independent capture30, child audit30 and broker85. Product tests require145 and original clipping/irreversible expiry; planner tests require mediation85 equality accepted and no double-count, over-parent refusal and original deadline reservation. Profile tests require9/current digest and strict8+7 refusal. Fresh source review must inspect all checks/awaits and changed constant consumers. Rule6 mutants should target wrong55/85/145 derivation, accidental prep55, refreshed outer timer, stale8 admission and omitted parent clipping. Then run the original genuine interrupted case before any full/final/hosted readiness claim.

## Authority and owner class

[Observed governing clauses] REQ-polaris-generation-035 requires conservative full-path CPU/wall/native/broker/remaining-run calculation and finite expiring reservation, while preserving stricter existing role/broker/request limits and original deadlines. REQ-polaris-generation-048 requires finite registry/audit/lock/operation limits and fresh authoritative record/projection/attested instance/policy/scope verification on each mediated act. These clauses contain no universal30000 effect ceiling; A-236 is the explicit agent decision that selected30/30/60. A later agent adoption must explicitly supersede that numeric selection and report retained fail-closed limits and Unknown recovery.

[Inferred owner-class classification] A finite ordered aggregate-resource allocation, profile identity, product horizon and honest planning change is outside VIS-4/D10's four owner-only classes if all screening/secret detection, SEC-5 fail-closed behavior, sandboxing, ownership and network exposure remain unchanged. Therefore root may adopt after review/proportional verification with an append-only agent row and revert command; no invented owner blocker is warranted. The current adoption record's numeric30 claim must not remain presented as the active successor policy without a new row naming the semantic difference. This report itself adopts nothing.

[Unknown] Native recovery, profile9 test/runtime results, final capture, hosted performance and later-phase completion. This bounded design is reviewable; it is not proof that another cap alone completes F3.

## Exact source excerpts

url-product-read-limits.ts:1
```typescript
export const URL_ORDERED_NATIVE_EFFECT_MILLISECONDS = 30_000;
// Preparation retains the existing ordered capture allowance. The two serial
// phases share one absolute envelope; neither can borrow the other's capacity.
export const URL_ORDERED_NATIVE_PREPARATION_MILLISECONDS = URL_ORDERED_NATIVE_EFFECT_MILLISECONDS;
export const URL_ORDERED_NATIVE_MEDIATION_MILLISECONDS = URL_ORDERED_NATIVE_PREPARATION_MILLISECONDS
  + URL_ORDERED_NATIVE_EFFECT_MILLISECONDS;
```

url-product-read-limits.ts:16
```typescript
/** The runtime binds these limits before issuing an immutable read deadline.
 * Ordered Design startup and replacement include time for the following
 * native setup or effect under the same lease. */
export const URL_PRODUCT_READ_MILLISECONDS = Object.freeze({
  ...productReadMilliseconds,
  'ordered-design-startup': productReadMilliseconds.render + URL_ORDERED_NATIVE_MEDIATION_MILLISECONDS,
  'ordered-design-replacement': productReadMilliseconds.render + URL_ORDERED_NATIVE_MEDIATION_MILLISECONDS,
});
```

url-machine-store.ts:843
```typescript
      const synchronousOrdinaryRead = ordinaryEffect && currentAsync === undefined && publication === undefined && !terminalRead;
      const operationMilliseconds = orderedEffect
        ? effectProfile.transcript.nativeMediationMilliseconds : ordinaryEffect ? ORDINARY_NATIVE_EFFECT_MILLISECONDS
          : terminalRead && currentAsync !== undefined ? ASYNC_TERMINAL_READ_MILLISECONDS
            : publication?.operationMilliseconds ?? URL_MACHINE_STORE_LIMITS.operationMilliseconds;
      const orderedPhases = orderedEffect ? { preparation: effectProfile.transcript.nativePreparationMilliseconds,
        effect: effectProfile.transcript.nativeEffectMilliseconds } : undefined;
      if (orderedPhases !== undefined && (!positive(orderedPhases.preparation) || orderedPhases.preparation > 30_000
        || !positive(orderedPhases.effect) || orderedPhases.effect > 30_000
        || operationMilliseconds !== orderedPhases.preparation + orderedPhases.effect)) return false;
      if (!positive(operationMilliseconds) || operationMilliseconds > (orderedPhases === undefined ? 30_000
        : orderedPhases.preparation + orderedPhases.effect)) return false;
```

url-run-ordered-attempt.ts:327
```typescript
    const envelope = { cpuMicroseconds: 64_000_000, wallMilliseconds: 30_000, auditReadBytes: 500_000_000,
      inputCodeUnits: 8_388_608, secretCodeUnits: 103_000_000, secretCalls: 524_361, activeCodeUnits: 16_777_216, activeCalls: 32 };
    const enforcement: OrderedDesignWorkEnforcement = { runtimeSha256: input.runtime.inputTreeSha256, workerSha256: program.worker.sha256,
      operations: { request: envelope, response: envelope, tool: envelope, audit: envelope, terminal: envelope },
      relayMilliseconds: 300_000, brokerMilliseconds: 85_000 };
    writer = input.audit.beginOrderedDesignAudit(plan, current, bytes => {
      input.work.observeProtectedRead(bytes); controller!.chargeAuditRead(bytes);
    });
```

url-ordered-design-work-budget.ts:116
```typescript
      || !positive(enforcement.relayMilliseconds) || enforcement.relayMilliseconds > 300_000
      || !positive(enforcement.brokerMilliseconds) || enforcement.brokerMilliseconds > 85_000) return null;
    if (input.nativeMediationMilliseconds !== undefined && (!positive(input.nativeMediationMilliseconds)
      || input.nativeMediationMilliseconds > enforcement.brokerMilliseconds)) return null;
    const cpu = calculateOrderedDesignCpuRequirement(enforcement);
    if (cpu === null) return null;
    let wall = 4 * (enforcement.relayMilliseconds + enforcement.brokerMilliseconds), auditReadBytes = 0;
    for (const operation of OPERATIONS) {
      const envelope = enforcement.operations[operation];
      if (!positive(envelope.cpuMicroseconds) || !positive(envelope.wallMilliseconds)
        || !positive(envelope.inputCodeUnits) || envelope.inputCodeUnits > RESPONSE_BYTES
        || ![envelope.auditReadBytes, envelope.secretCodeUnits, envelope.secretCalls, envelope.activeCodeUnits, envelope.activeCalls].every(nonnegative)) return null;
      wall += COUNTS[operation] * envelope.wallMilliseconds;
      auditReadBytes += COUNTS[operation] * envelope.auditReadBytes;
    }
    if (![wall, cpu, auditReadBytes, now + wall].every(Number.isSafeInteger)
      || now + wall >= deadline || cpu > remainingRunCpuMicroseconds) return null;
```

url-session-audit.ts:1026
```typescript
      const attemptDeadline = Date.parse(binding.deadline);
      const checkAttemptCurrent = async (deadline: number): Promise<void> => {
        if (!(Date.now() < attemptDeadline)) throw refused();
        await checkCurrent(deadline);
        const allowed = await wait(track('callback', attemptCurrent), deadline);
        await checkCurrent(deadline);
        if (allowed !== true || !(Date.now() < attemptDeadline)) throw refused();
      };
      const held: Array<{ record: OrderedDesignStoredRecord; read: (charge?: boolean) => Uint8Array }> = [];
      const writer = createOrderedDesignAuditWriter({ profile: orderedDesignProfile, plan, principal: input.principal }, {
        current: async () => { await checkAttemptCurrent(performance.now() + limits.milliseconds); return true; },
        append: async record => {
          const event = await enqueue({ kind: 'design-ordered', role: 'design', scope, payload: record },
            'design-ordered', checkAttemptCurrent, attemptDeadline);
```

url-ordered-design-host.ts:129
```typescript
      audit: async event => {
        try {
          if (!(await current())) throw refused();
          await selectedController().observe(event);
          await input.audit(event);
          if (event.event === 'response-admitted') issuedCall = event.response?.tool ?? null;
          if (['attempt-refused', 'transport-failed', 'response-refused'].includes(event.event)) poison();
        } catch { poison(); throw refused(); }
      },
    }, undefined, input.relayMachine);
```

url-design-product.ts:110
```typescript
export function urlDesignProductLeaseState(capability: ValidatedUrlDesignProduct):
  { readonly state: ProductCheck; readonly deadline: number } | { readonly state: 'Unknown' } {
  const lifetime = lifetimes.get(capability);
  if (!lifetime) return { state: 'Unknown' };
  const { deadline, signal } = lifetime;
  const entry = validated.get(capability);
  const current = (): boolean => lifetime.termination !== 'retired' && lifetime.authorityCurrent()
    && !signal.aborted && (entry === undefined || entry.signalCurrent());
  try {
    if (current()) {
      const backend = lifetime.backendState();
      // The deadline can pass after the first backend sample. The local lease
      // check can confirm that cause while a refusal elsewhere retires it.
      const checked = backend === 'open' ? entry?.checkLease() : backend;
      if (checked === 'open' && validated.get(capability) === entry) return { state: 'open', deadline };
      if (checked === 'expired' && current()) return { state: terminateProduct(capability, 'expired'), deadline };
    }
  } catch { /* A failed lease predicate retires the original capability. */ }
  return { state: terminateProduct(capability, 'retired'), deadline };
```

A-236 exact adopted selection:

| A-236 | 2026-11-25 | `b2221bf94400bb87ee43bcc1f9422ff7dfb22499` | Agent adoption: ordered profile8 separates preparation30000ms and actual effect30000ms under one absolute60000ms mediation total with a trusted one-use transition. Reserve mediation60000 in the120000ms ordered product horizon; retain tighter broker85000, caller/run/record limits and every fresh authority/release guard. Old ordered7 credentials remain refused, no migration. | Actual interrupted c52 refused its combined30000ms store envelope after preparation and an otherwise accepted25424ms host action. Fresh combined review PASS; typecheck,21 unit,156 store/peer and6 targeted lease/launch cases pass;13 cases added and4 intended mutants detected. [Evidence](../../../docs/evidence/syzygy-k54o-3/ordered-mediation-phases/README.md). Current-main genuine, full, rendering and hosted verification remain Unknown. | `git revert b2221bf94400bb87ee43bcc1f9422ff7dfb22499` | — |

Exact defined-clause quotations at the bound specification source:

REQ-polaris-generation-035:
> The host SHALL calculate conservative byte/node/depth and transform/detector input, CPU/wall, native result, broker/wrapper, received/prepared request/response, history/turn and remaining-run bounds for that whole planned path.

REQ-polaris-generation-035:
> Reserve finite expiring capacity for the remaining supported path and refresh against actual charged work at each admitted step without extending the recorded original deadline or lowering the ordinary role caps.

REQ-polaris-generation-048:
> Every subsequent mediated act, including an existing open connection and resume, SHALL recheck the current authoritative record, exact projection binding, independently attested instance/process lifetime, finite expiry, current policy and operation scope.

REQ-polaris-generation-048:
> Before use, record positive bounds: at most16 named clients per run,64 historical instances per client,65,536 bytes/4,096 nodes/depth16 per credential record and finite registry/audit I/O/output/lock/operation wall limits under the original deadline.

