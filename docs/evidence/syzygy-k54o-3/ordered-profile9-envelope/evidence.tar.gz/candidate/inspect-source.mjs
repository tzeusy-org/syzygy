import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import ts from '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w/node_modules/typescript/lib/typescript.js';

// Source parsing only: never imports or evaluates any project/candidate module.
const root = path.dirname(new URL(import.meta.url).pathname);
const binding = JSON.parse(fs.readFileSync(path.join(root, 'binding.json'), 'utf8'));
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const printer = ts.createPrinter({ removeComments: true });
const inspect = (side, name) => {
  const text = fs.readFileSync(path.join(root, side, name), 'utf8');
  const source = ts.createSourceFile(name, text, ts.ScriptTarget.Latest, true);
  const calls = [];
  const visit = node => {
    if (ts.isCallExpression(node) && /^it(?:\.each\([^]*\))?$/.test(node.expression.getText(source))) calls.push(node.expression.getText(source));
    ts.forEachChild(node, visit);
  };
  visit(source);
  return { text, source, testDeclarations: calls.length, diagnostics: source.parseDiagnostics.map(d => d.messageText) };
};
const records = binding.files.map(file => {
  const old = inspect('original', file.path), selected = inspect('candidate', file.path);
  if (hash(old.text) !== file.originalSha256 || hash(selected.text) !== file.candidateSha256) throw new Error('source binding mismatch');
  if (selected.diagnostics.length || old.diagnostics.length) throw new Error('parse diagnostic');
  if (old.testDeclarations !== selected.testDeclarations) throw new Error('test declaration growth');
  return { path: file.path, parsed: true, testDeclarationsBefore: old.testDeclarations,
    testDeclarationsAfter: selected.testDeclarations };
});
const name = 'packages/polaris-dossier/src/url-machine-store.ts';
const old = inspect('original', name), selected = inspect('candidate', name);
const reverted = selected.text
  .replace("import { URL_ORDERED_NATIVE_PREPARATION_MILLISECONDS, URL_ORDERED_NATIVE_EFFECT_MILLISECONDS } from './url-product-read-limits.js';\n", '')
  .replace('orderedPhases.preparation > URL_ORDERED_NATIVE_PREPARATION_MILLISECONDS', 'orderedPhases.preparation > 30_000')
  .replace('orderedPhases.effect > URL_ORDERED_NATIVE_EFFECT_MILLISECONDS', 'orderedPhases.effect > 30_000');
const normalized = ts.createSourceFile(name, reverted, ts.ScriptTarget.Latest, true);
if (printer.printFile(old.source) !== printer.printFile(normalized)) throw new Error('store changed beyond selected ceiling expressions/import');
const limits = inspect('candidate', 'packages/polaris-dossier/src/url-product-read-limits.ts');
const values = new Map();
const evaluate = node => {
  if (ts.isNumericLiteral(node)) return Number(node.text);
  if (ts.isIdentifier(node) && values.has(node.text)) return values.get(node.text);
  if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.MinusToken) return evaluate(node.left) - evaluate(node.right);
  throw new Error('unsupported source constant');
};
for (const statement of limits.source.statements) {
  if (!ts.isVariableStatement(statement)) continue;
  for (const declaration of statement.declarationList.declarations) {
    if (ts.isIdentifier(declaration.name) && declaration.name.text.startsWith('URL_ORDERED_NATIVE_')) values.set(declaration.name.text, evaluate(declaration.initializer));
  }
}
const preparation = values.get('URL_ORDERED_NATIVE_PREPARATION_MILLISECONDS');
const effect = values.get('URL_ORDERED_NATIVE_EFFECT_MILLISECONDS');
const mediation = values.get('URL_ORDERED_NATIVE_MEDIATION_MILLISECONDS');
if (preparation !== 30000 || effect !== 55000 || mediation !== 85000 || preparation + effect !== mediation) throw new Error('envelope mismatch');
process.stdout.write(JSON.stringify({ mode: 'static source parsing only; no project execution', baseCommit: binding.baseCommit,
  records, storeAstUnchangedAfterExactCeilingReversal: true,
  sourceConstants: { preparation, effect, mediation, derivedProductHorizon: 60000 + mediation },
  execution: { tests: 'NOT RUN', build: 'NOT RUN', supportCompilation: 'NOT RUN', native: 'NOT RUN' } }, null, 2) + '\n');
