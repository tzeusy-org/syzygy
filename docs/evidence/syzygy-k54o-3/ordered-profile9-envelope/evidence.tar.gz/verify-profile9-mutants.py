import hashlib,json,os,re,subprocess,tempfile,time
from pathlib import Path
root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
packet=Path('/home/orca/.tmp/f3-native-admission-fixes/ordered-profile9-envelope-candidate')
baseline=Path('/home/orca/.tmp/f3-native-admission-fixes/guard-profile9-execution')
out=Path('/home/orca/.tmp/f3-native-admission-fixes/profile9-mutant-execution');out.mkdir(exist_ok=False)
plan=json.loads((packet/'mutation-plan.json').read_text())
files={'profile-integration.json','profile-unit.json'}
tests=[(f['name'],a['fullName']) for name in files for f in json.loads((baseline/name).read_text())['testResults'] for a in f.get('assertionResults',[]) if a.get('status')=='passed']
targets={
 'prep-decoupling':('session-launch.test.ts','compiles the independently named design profile'),
 'store-effect-phase':('url-machine-store.test.ts','for \'effect-limit\''),
 'store-total':('url-machine-store.test.ts','for \'outer-limit\''),
 'phase-timer':('url-machine-store.test.ts','suspended'),
 'profile-binding':('url-machine-store.test.ts','retained ordered-design-7/8 credentials'),
 'product-clipping':('url-run-artifacts.test.ts','ordered'),
 'planner-parent':('url-ordered-design-work-budget.test.ts','reserves the broker once'),
 'native-transition':('url-machine-store.test.ts','for \'duplicate-transition\''),
}
for key,(suffix,fragment) in targets.items():
 selected=[name for path,name in tests if path.endswith(suffix) and fragment in name]
 if not selected: raise RuntimeError('empty intended baseline selection '+key+': '+repr([name for path,name in tests if path.endswith(suffix)]))
 targets[key]=(suffix,selected)
tmp=Path(tempfile.mkdtemp(prefix='f3-',dir='/home/orca/.tmp'));tmp.chmod(0o700)
env=os.environ.copy();env.update(TMPDIR=str(tmp),VITEST_MAX_THREADS='1',VITEST_MIN_THREADS='1',VITEST_MAX_FORKS='1',VITEST_MIN_FORKS='1')
results=[]
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert base==plan['baseCommit']
for mutant in plan['mutants']:
 file=root/mutant['path'];original=file.read_bytes();text=original.decode()
 assert hashlib.sha256(original).hexdigest()==mutant['sourceSha256']
 assert text.count(mutant['old'])==1,(mutant['id'],text.count(mutant['old']))
 suffix,selected=targets[mutant['id']]
 source=next(path for path,name in tests if path.endswith(suffix))
 project='unit' if suffix=='url-ordered-design-work-budget.test.ts' else 'integration'
 report=out/(mutant['id']+'.json')
 argv=['node','node_modules/vitest/vitest.mjs','run','--project',project,source,'--testNamePattern=^(?:'+'|'.join(re.escape(name) for name in selected)+')$','--reporter=json','--outputFile='+str(report)]
 began=time.monotonic()
 try:
  file.write_text(text.replace(mutant['old'],mutant['new'],1))
  with (out/(mutant['id']+'.log')).open('w') as log: p=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  r=json.loads(report.read_text())
  failed=[a['fullName'] for f in r['testResults'] for a in f.get('assertionResults',[]) if a.get('status')=='failed']
  row={**mutant,'baseCommit':base,'argv':argv,'selectedBaselinePassed':selected,'exit':p.returncode,'elapsedSeconds':time.monotonic()-began,'failed':failed,'numFailedTests':r['numFailedTests'],'numPassedTests':r['numPassedTests'],'numPendingTests':r['numPendingTests'],'execution':'KILLED' if p.returncode!=0 and failed and set(failed).issubset(selected) else 'INVALID_OR_SURVIVED'}
  results.append(row);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['id','exit','elapsedSeconds','failed','execution']}),flush=True)
  assert row['execution']=='KILLED'
 finally:
  file.write_bytes(original)
  assert hashlib.sha256(file.read_bytes()).hexdigest()==mutant['sourceSha256']
print('Eight intentional faults detected; source bytes restored',flush=True)
