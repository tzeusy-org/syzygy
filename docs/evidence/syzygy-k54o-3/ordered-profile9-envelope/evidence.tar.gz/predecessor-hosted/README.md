# Exact d8 terminal hosted evidence

[Observed] PR head `d8e1bf97b94989d767d47a0c1abc76ab9db48749`; executed checkout `254ca1562f4083cd62c71e00680330d20923f9da`. Retained GitHub Git-commit API objects establish that merge parents include this PR head and main cb5d7fcec5876592dfcf393839cab0c5ea05f14d, and both commits have tree `e8d1a52d4cc30be438aacc730b263cbeb0088672`. Local Git independently confirms the head tree. This proves full tracked-tree equality, including implementation; it does not make the execution commit equal to the PR head. No Git fetch or primary mutation was needed.

[Observed] Node run45519587831 FAILED:10/10 expected jobs observed,7 success and3 failure (two component jobs plus aggregate). Core2 failed the synchronous-child guard at machine-peer.ts208 prlimit; output46files=45pass/1fail,1846tests=1842pass/3skip/1fail. Interrupted stop-resume failed its600000ms test timeout; output1file failed,7tests=1fail/6skip. Its whole job670s, runner duration604.36s. The raw hosted timeout does not independently identify a private predicate or prove the local417s first-refusal diagnosis applies to this hosted run.

[Observed] Governance run45519587805 PASSED:6/6 expected jobs observed and successful. Slowest readability369s; reconciliation254s; P115299s; governance180s; continuation305s; aggregate3s. Full per-step timestamps/conclusions are retained in raw job metadata and selected-report.json.

[Observed] Five actual integration receipts are retained, individually bound to the tested merge: core1/core3/complete/delivery-stop/eligible-stop-resume. ZIP hashes match GitHub's advertised artifact digests5/5; decoded receipt SHA/lane identities were independently checked. Mandatory core2 and stop-resume receipts are missing. No7-receipt success claim is made.

[Observed] Two clock views remain separate. Maximum job: Node670s (breach), governance369s. Run-start to final job: Node880s (breach), governance376s. Initial job start lag is2–3s; Node integration jobs start after unit completion and are not unexplained queue time. [Unknown] Actual push-to-green, because no push timestamp/pre-run scheduler evidence was collected. The candidate is FAILED; no whole420s acceptance claim.

The16-job denominator is checked both against API total_count/unique IDs and independently expanded exact-subject YAML job populations (Node10, governance6). The five-receipt denominator is checked against artifact API count/unique lane population and exact seven-lane YAML selection.

| Job ID | Job | Conclusion | Seconds |
|---|---|---|---:|
| 138887772221 | node (unit) | success | 198 |
| 138889225525 | node (e2e) | success | 154 |
| 138889225530 | node (integration, complete) | success | 149 |
| 138889225564 | node (integration, core-1) | success | 101 |
| 138889225595 | node (integration, core-2) | failure | 141 |
| 138889225606 | node (integration, delivery-stop) | success | 124 |
| 138889225656 | node (integration, stop-resume) | failure | 670 |
| 138889225694 | node (integration, core-3) | success | 342 |
| 138889225748 | node (integration, eligible-stop-resume) | success | 210 |
| 138894131342 | node | failure | 5 |
| 138887772889 | checks (P115 recording selftest) | success | 299 |
| 138887773085 | checks (reconciliation selftest) | success | 254 |
| 138887773111 | checks (governance) | success | 180 |
| 138887773165 | checks (governance continuation) | success | 305 |
| 138887773231 | checks (readability selftest) | success | 369 |
| 138890469446 | checks | success | 3 |

Provenance: raw JSON is retained gh API response output. The two failed logs and one governance-group log were fetched with gh api --allow-escape-sequences to binary output files, with no full log printed. Their labels mean CLI-emitted response-body bytes; HTTP headers/compression provenance was not captured. Connector-decoded progress files are separate historical inputs and are not mislabeled original HTTP bytes here. The three retained checkout log proofs and five receipt payloads name the exact tested merge. Unfetched individual job logs are not independently represented as checkout observations.

project-retained.py reprojects only retained files; it does not execute project code or fetch remote state. No tests/build/native/provider calls or primary source/index/tracker/lifecycle changes occurred. Results do not cover subsequent A239/A240 changes.
