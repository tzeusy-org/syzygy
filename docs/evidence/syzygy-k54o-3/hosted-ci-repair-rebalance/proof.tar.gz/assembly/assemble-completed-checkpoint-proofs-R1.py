#!/usr/bin/env python3
"""Copy completed evidence and assemble deterministic archives; executes no repository code."""
import collections
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tarfile

BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
SELF = BASE / 'assemble-completed-checkpoint-proofs-R1.py'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe(name):
    p = pathlib.PurePosixPath(name)
    assert not p.is_absolute() and p.parts and '..' not in p.parts and str(p) == name, name
    assert not any(x in {'.git', 'node_modules', '__pycache__', 'tmp', 'TMP'} for x in p.parts), name
    assert p.suffix != '.pyc', name
    return p

def verify_manifest(folder, filename='SHA256SUMS'):
    manifest = folder / filename
    for line in manifest.read_text().splitlines():
        digest, name = line.split(None, 1)
        name = name.lstrip('*')
        safe(name)
        assert sha((folder / name).read_bytes()) == digest, str(manifest) + ':' + name
    done = subprocess.run(['sha256sum', '--check', filename], cwd=folder, capture_output=True, text=True)
    assert done.returncode == 0, str(manifest) + ': ' + done.stderr

class Proof:
    def __init__(self, name):
        self.root = BASE / name
        self.root.mkdir(exist_ok=False)
        self.payload = self.root / 'payload'
        self.payload.mkdir()
        self.sources = []

    def file(self, source, relative):
        source = pathlib.Path(source)
        safe(relative)
        assert source.is_file() and not source.is_symlink(), str(source)
        data = source.read_bytes()
        target = self.payload / relative
        assert not target.exists(), str(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        assert target.read_bytes() == data and source.read_bytes() == data, str(source)
        self.sources.append({'path': relative, 'source': str(source), 'bytes': len(data), 'sha256': sha(data)})

    def tree(self, source, relative):
        source = pathlib.Path(source)
        assert source.is_dir() and not source.is_symlink(), str(source)
        files = sorted(p for p in source.rglob('*') if p.is_file())
        assert not any(p.is_symlink() for p in source.rglob('*')), str(source)
        for p in files:
            self.file(p, relative + '/' + p.relative_to(source).as_posix())
        return len(files)

    def write(self, relative, text):
        safe(relative)
        p = self.payload / relative
        assert not p.exists()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)

    def finish(self, readme, subject):
        self.file(SELF, 'assembly/assemble-completed-checkpoint-proofs-R1.py')
        self.write('README.md', readme)
        source_index = {'subject': subject, 'copiedFileCount': len(self.sources),
                        'copiedBytes': sum(x['bytes'] for x in self.sources), 'files': self.sources}
        self.write('SOURCE-INDEX.json', json.dumps(source_index, indent=2) + '\n')
        files = sorted((p for p in self.payload.rglob('*') if p.is_file()),
                       key=lambda p: p.relative_to(self.payload).as_posix())
        members = [{'path': p.relative_to(self.payload).as_posix(),
                    'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in files]
        expected = {row['path']: row for row in members}
        def archive(path):
            with path.open('wb') as raw:
                with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=9) as gz:
                    with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
                        for p, row in zip(files, members):
                            data = p.read_bytes()
                            info = tarfile.TarInfo(row['path'])
                            info.size = len(data)
                            info.mtime = 0
                            info.uid = info.gid = 0
                            info.uname = info.gname = ''
                            info.mode = 0o644
                            tf.addfile(info, io.BytesIO(data))
        output = self.root / 'proof.tar.gz'
        second = self.root / 'proof-rebuild.tar.gz'
        archive(output)
        archive(second)
        assert output.read_bytes() == second.read_bytes(), 'non-deterministic archive'
        second.unlink()
        seen = []
        with tarfile.open(output, 'r:gz') as tf:
            for item in tf:
                safe(item.name)
                assert item.isfile() and item.name in expected, item.name
                assert item.mode == 0o644 and item.uid == item.gid == item.mtime == 0
                assert item.uname == item.gname == ''
                data = tf.extractfile(item).read()
                row = expected[item.name]
                assert len(data) == row['bytes'] == item.size and sha(data) == row['sha256'], item.name
                seen.append(item.name)
        assert seen == sorted(expected) and len(seen) == len(set(seen))
        index = {'subject': subject, 'archive': 'proof.tar.gz', 'archiveBytes': output.stat().st_size,
                 'archiveSha256': sha(output.read_bytes()), 'memberCount': len(members),
                 'copiedSourceFiles': len(self.sources), 'copiedSourceBytes': sum(x['bytes'] for x in self.sources),
                 'payloadBytes': sum(row['bytes'] for row in members),
                 'deterministicByteRebuildEqual': True, 'memberReadbackHashCount': len(seen),
                 'memberMode': '0644', 'memberMtime': 0, 'uid': 0, 'gid': 0,
                 'members': members}
        index_path = self.root / 'ARCHIVE-INDEX.json'
        index_path.write_text(json.dumps(index, indent=2) + '\n')
        checks = [(p, 'payload/' + p.relative_to(self.payload).as_posix()) for p in files]
        checks += [(output, 'proof.tar.gz'), (index_path, 'ARCHIVE-INDEX.json')]
        (self.root / 'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + name + '\n' for p, name in checks))
        verified = subprocess.run(['sha256sum', '--check', 'SHA256SUMS'], cwd=self.root,
                                  capture_output=True, text=True)
        assert verified.returncode == 0
        assert len(verified.stdout.splitlines()) == len(checks)
        # Recheck every copied source after final assembly; never seal a drifting completed record.
        for row in self.sources:
            data = pathlib.Path(row['source']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['source']
        return {'root': str(self.root), 'archive': str(output), 'memberCount': len(members),
                'copiedFiles': len(self.sources), 'archiveBytes': output.stat().st_size,
                'archiveSha256': index['archiveSha256'], 'indexSha256': sha(index_path.read_bytes()),
                'sealSha256': sha((self.root / 'SHA256SUMS').read_bytes()),
                'independentSha256sumChecks': len(checks),
                'memberReadbackHashCount': len(seen)}

# Source-container seals remain byte-exact and are checked in their original homes.
for name in ['ordinary-recovery-8198e8-R1', 'first-boundary-phase-analysis-preparation',
             'hosted-ci-checkpoint-1cd763-R1', 'hosted-ci-last-pin-supplement-R1',
             'hosted-ci-8198-checkpoint-R1', 'hosted-core-rebalance-8198-R2',
             'ordinary-recovery-8198e8-diagnosis-assessment-1']:
    verify_manifest(BASE / name)
verify_manifest(BASE / 'ordinary-recovery-8198e8-diagnosis-assessment-1', 'ADDENDUM-SHA256SUMS')

terminal_path = BASE / 'ordinary-recovery-8198e8-1/terminal.json'
terminal = json.loads(terminal_path.read_text())
assert terminal['complete'] and not terminal['accepted'] and terminal['exitCode'] == 1
raw_names = [row['path'] for row in terminal['rawFiles']]
assert len(raw_names) == 7 and len(set(raw_names)) == 7
assert set(raw_names) | {'terminal.json'} == {p.name for p in terminal_path.parent.iterdir() if p.is_file()}
for row in terminal['rawFiles']:
    safe(row['path'])
    data = (terminal_path.parent / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']

staging = BASE / 'fourth-tool-phase-proof-staging-R1'
staging_index = json.loads((staging / 'staging-index.json').read_text())
assert len(staging_index['files']) == 33
for row in staging_index['files']:
    safe(row['path'])
    data = (staging / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
assert {p.relative_to(staging).as_posix() for p in staging.rglob('*') if p.is_file()} == {row['path'] for row in staging_index['files']} | {'staging-index.json'}

phase = Proof('fourth-tool-phase-proof-final-R1')
assert phase.tree(staging, 'historical-staging-R1') == 34
assert phase.tree(BASE / 'ordinary-recovery-8198e8-R1', 'original-operator-8198') == 16
phase.file('/home/orca/.tmp/f3-8198-original-operator-review-RAW.md', 'reviews/f3-8198-original-operator-review-RAW.md')
phase.file(BASE / 'ordinary-8198-execution-admission.json', 'ordinary-8198-execution-admission.json')
for name in sorted(raw_names + ['terminal.json']):
    phase.file(terminal_path.parent / name, 'original-execution-8198/' + name)
phase.tree(BASE / 'first-boundary-phase-analysis-preparation', 'phase-analyzer')
phase.tree(BASE / 'ordinary-recovery-8198e8-diagnosis-1', 'completed-root-analysis')
phase.file(BASE / 'root-original-8198-reconciliation.json', 'root-original-8198-reconciliation.json')
phase.file(BASE / 'root-original-8198-runtime-output-readback.json', 'root-original-8198-runtime-output-readback.json')
phase.tree(BASE / 'ordinary-recovery-8198e8-diagnosis-assessment-1', 'independent-assessment')

phase_readme = """# Fourth-tool phase observer and completed local 8198 failure

[Observed] This proof retains the completed source-only R2/R3 observer packets, raw PASS reviews, actual observer commits 50bc595a946a2d0e4e39ab8c28fdb648be8725eb and a362226235409efb184622271b22729cf8754d08, focused execution and the unchanged original operator rebound to actual 8198e8e34e394c8918a86db3dec02dc1ef1fa8f2 / tree 3f31393e0b5966ab9c3d23f80954b9742a427213. Historical-staging-R1 is copied byte-exact: its final pending-result paragraph describes staging time, superseded for this package by the completed result below. Its NOTES and recorded verdicts remain unchanged.

[Observed] Focused observer evidence passes typecheck and its one selected unit case. Three intended mutants fail their target assertions with restoration and joined child cleanup. The third retained-content mutant was not accepted by the original wrapper because Vitest abbreviated the object formatter; root separately accepted its intended failure from the actual AssertionError, body diff and location. The unchanged wrapper/final/raw logs and root reconciliation preserve this limitation. This is not three original-wrapper successes.

[Observed] The actual original local case at 8198 completes/unaccepted with build PASS and selected stop-resume FAIL in 536206.948485 ms, one failure plus six selection skips of seven under the unchanged 600000-ms case and 30000-ms hook limits/ordinary workers. Seven terminal-declared raw files plus terminal are retained exactly (eight files), including all three fresh runtime captures. Root reconciliation records exact source/tools/runtime, 367 build inputs/10 outputs, no forced children, pending cleanup signals or cleanup errors, and no remaining owned children.

[Observed] Six agreeing first-boundary copies identify original fourth tool / turn 3 TIMER, wall limit 30000 ms, observed elapsed 30036.031010 ms. Current/remaining CPU are null/Unknown; the 64000000-microsecond CPU cap is unchanged. The added fixed spans return: reproduction 5787.615 ms, proof 629.655 ms, staging 8027.977 ms. Returned means promise settlement, not acceptance or eligibility. The verdict-staged store append then REJECTS after 4555.849 ms; the timer occurs within it, before its rejection. This differs from the earlier retained 22b accepted store span and is not relabelled.

[Observed] The standalone analyzer code, its exact invocation/result, root reconciliation and completed independent assessment are retained. Read independent-assessment/ADDENDUM.md with ASSESSMENT.md: the later source addendum corrects the original optimization conclusion by tracing the production ledger freshness callback to native checks and identifies the existing bounded inspectMetadata seam as a source-supported candidate. The exact invocation parent count and any time saving remain Unknown; no optimization outcome is claimed here.

[Unknown] Successful local original recovery, runtime repair, CPU exhaustion and full F3 acceptance. Full final gates were not run. Hosted CI is separate evidence in the CI proof; this local failure remains a failure. No new adoption ID is proposed. Primary source, ledger, prior proofs and raw reviews were not edited during assembly. No product, test, fixture, build, native helper or provider was executed. Private TMP, clones, dependencies, backups and observed fixture bodies are excluded.

[Observed] SOURCE-INDEX.json preserves copied-source locators and hashes. The external ARCHIVE-INDEX.json binds every safe normalized member name/size/SHA and the archive SHA. Files use deterministic mtime 0, uid/gid 0 and mode 0644. A second archive is byte-identical; every compressed member is read back and independently SHA-checked.
"""
phase_result = phase.finish(phase_readme, {
    'observerCommits': ['50bc595a946a2d0e4e39ab8c28fdb648be8725eb', 'a362226235409efb184622271b22729cf8754d08'],
    'originalExecutionCommit': terminal['subject'], 'originalExecutionTree': terminal['tree'],
    'originalOutcome': 'complete/unaccepted/FAIL', 'fullFinalGates': 'not run'})

ci = Proof('hosted-ci-repair-rebalance-proof-final-R1')
ci.tree(BASE / 'hosted-ci-checkpoint-1cd763-R1', 'failed-hosted-1cd-source-repair')
ci.tree(BASE / 'hosted-ci-last-pin-supplement-R1', 'last-pin-source-supplement')
ci.file('/home/orca/.tmp/f3-1cd-ci-repair-source-review-RAW.md', 'reviews/f3-1cd-ci-repair-source-review-RAW.md')
ci.file(BASE / 'ci-repair-actual-commit.json', 'actual-commits/ci-repair-actual-commit.json')
ci.file(BASE / 'verify-1cd-ci-repairs.py', 'verification-definitions/verify-1cd-ci-repairs.py')
repair_output = BASE / 'ci-repair-check-8198e8e-1'
repair_allowed = sorted(p for p in repair_output.iterdir()
    if p.is_file() and (p.suffix == '.log' or p.name in {
        'canonical-selection.json', 'progress.json', 'complete.json', 'reconciliation-witnesses.json'}))
for p in repair_allowed:
    ci.file(p, 'ci-repair-execution-8198/' + p.name)
repair_complete = json.loads((repair_output / 'complete.json').read_text())
assert repair_complete['scopedAccepted'] and repair_complete['subject'] == terminal['subject']
for row in repair_complete['steps']:
    p = repair_output / (row['name'] + '.log')
    assert p in repair_allowed
    data = p.read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
witnesses = json.loads((repair_output / 'reconciliation-witnesses.json').read_text())
outcomes = collections.Counter(row['outcome'] for row in witnesses['mutants'])
assert len(witnesses['mutants']) == 806
assert outcomes == {'killed': 646, 'held': 160}, outcomes
ci.tree(BASE / 'hosted-ci-8198-checkpoint-R1', 'completed-hosted-8198')
ci.tree(BASE / 'hosted-core-rebalance-8198-R2', 'rebalance-source-R2')
ci.file('/home/orca/.tmp/f3-hosted-rebalance-R2-source-review-RAW.md', 'reviews/f3-hosted-rebalance-R2-source-review-RAW.md')
ci.file(BASE / 'hosted-rebalance-actual-commit.json', 'actual-commits/hosted-rebalance-actual-commit.json')
ci.file(BASE / 'verify-hosted-rebalance.py', 'verification-definitions/verify-hosted-rebalance.py')
focused = BASE / 'hosted-rebalance-focused-1'
focused_allowed = sorted(p for p in focused.iterdir() if p.is_file() and
    (p.suffix == '.log' or p.name in {'selection.json', 'progress.json', 'complete.json'}))
for p in focused_allowed:
    ci.file(p, 'rebalance-focused-execution/' + p.name)
focused_complete = json.loads((focused / 'complete.json').read_text())
assert focused_complete['scopedAccepted']
for row in focused_complete['steps']:
    p = focused / (row['name'] + '.log')
    assert p in focused_allowed
    data = p.read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']

hosted = BASE / 'hosted-ci-8198-checkpoint-R1'
for label, expected_count in [('node', 10), ('governance', 6)]:
    data = json.loads((hosted / (label + '-jobs.json')).read_text())
    jobs = data['jobs']
    assert data['total_count'] == len(jobs) == expected_count
    assert all(j['conclusion'] == 'success' for j in jobs)
rebalance_receipt = json.loads((BASE / 'hosted-rebalance-actual-commit.json').read_text())
assert focused_complete['head'] == rebalance_receipt['head']
ci_readme = """# Scoped CI repair, completed hosted 8198 PASS and bounded rebalance

[Observed] Historical hosted checkpoint 1cd763 failed in core-2's complete-source native-call guard, reconciliation selftest and review-campaign partition. Its exact failed logs, metadata, source candidate and last-pin supplement remain unchanged. Actual repair 8198e8e34e394c8918a86db3dec02dc1ef1fa8f2 / tree 3f31393e0b5966ab9c3d23f80954b9742a427213 removes only two ledger inter-row blanks, corrects one overescaped campaign regex and refreshes the reviewed whole-source AST pin while retaining its native-call pin and negative controls. Fresh raw source PASS and actual receipt are retained.

[Observed] Focused verification at committed clean clone 8198 is scopedAccepted: full native guard 11 cases, campaign check 1220/1220 paths by two methods and selftest 26 fixtures, governance and reconciliation check, then all 806 witnesses (646 killed, 160 held). Nine step logs plus progress/complete/canonical selection/witnesses are retained, with exact command definitions. The canonical battery population is 140; only five owning commands are selected here. This focused result is not a full final gate.

[Observed] Completed hosted 8198 metadata independently enumerates all 16 jobs: node 10/10 SUCCESS and governance 6/6 SUCCESS, including both aggregates. Two exact winning leaf logs are retained. The genuine hosted stop-resume case passes in 334800 ms: one pass plus six selection skips of seven. This is hosted evidence, distinct from the local 8198 failure preserved in the separate fourth-tool phase proof. No product code changed between 22b and 8198, so differing local/hosted timings are not attributed to a runtime repair.

[Observed] Hosted success does not satisfy the unchanged 420-second slowest-job budget: core-3 is 504 seconds, stop-resume 453, governance reconciliation selftest 472. The metadata/assessment retain these overruns explicitly. Timing compliance and environment-independent runtime acceptance remain Unknown.

[Observed] Actual bounded rebalance commit 8f8c024940b7eabf1324a3180c4355593bc48187 / tree f6f8ddb5f3f5a1e6c54193c70101c4f0e0f58329 follows 8198. Its frozen source R2 and raw fresh PASS retain three files: move the existing whole ordered-host file to core-1; remove integration's unused selector computation but keep explicit full fallback; correct matching CONTRIBUTING prose while preserving the 420-second bar. Unit/e2e selectors, seven lanes, all native prerequisites, four genuine scenarios, three observers and exact success receipts remain complete.

[Observed] Focused rebalance verification is scopedAccepted: control plus 18 rejected routing mutations, discovery 146 files/seven composed cases with core counts 49+48+48, selector 14 cases, and governance 22 OK/17 WARN/0 FAIL out of 39. Four completed logs and selection/progress/complete records are retained with their definition script. No test declaration or coverage was removed. This evidence does not establish resulting hosted timing.

[Unknown] Full final gates, hosted 8f8c budget compliance and successful local original recovery. New adoption IDs are intentionally not guessed; root can record exact actual subjects after inspecting this proof. No source/ledger/primary edit, product execution, fixture execution, build, rerun, provider request or push occurred during packaging. Clone, node_modules, TMP and active outputs are excluded. Historical source packets, raw verdicts and prior proof archives remain byte-exact.

[Observed] SOURCE-INDEX.json binds all copied inputs. The external ARCHIVE-INDEX.json binds every safe normalized member name/size/SHA and archive SHA. Deterministic mtime 0, uid/gid 0 and mode 0644 are used. A second archive is byte-identical, every compressed member is read back, and SHA256SUMS is independently checked.
"""
ci_result = ci.finish(ci_readme, {
    'ciRepairCommit': terminal['subject'], 'ciRepairTree': terminal['tree'],
    'hostedOutcome': '16/16 jobs SUCCESS; three over 420s',
    'rebalanceCommit': rebalance_receipt['head'], 'rebalanceTree': rebalance_receipt['tree'],
    'fullFinalGates': 'not run'})
results = {'phase': phase_result, 'ci': ci_result}
(BASE / 'completed-checkpoint-proofs-R1-receipt.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))

