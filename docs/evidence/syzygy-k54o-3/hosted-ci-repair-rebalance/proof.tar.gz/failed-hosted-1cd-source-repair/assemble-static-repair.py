import pathlib,subprocess,json,difflib,re,hashlib,datetime,collections
root=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
out=pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes/hosted-ci-checkpoint-1cd763-R1')
fix=out/'repair';fix.mkdir(exist_ok=False)
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
targets=['.syzygy/governance/decisions/AGENT-ADOPTIONS.md','docs/review-campaigns/d10-f3-url-supervisor.md']
patch=[];meta={'sourceHead':head,'sourceOnly':True,'files':[]}
for f in targets:
 old=subprocess.check_output(['git','-C',str(root),'show',head+':'+f]).decode()
 if f.endswith('AGENT-ADOPTIONS.md'):
  new=old
  for ident in ['A-324','A-325']:
   a='\n\n| '+ident+' |'; b='\n| '+ident+' |'
   assert new.count(a)==1,(ident,new.count(a))
   new=new.replace(a,b,1)
  assert len(old.splitlines())-len(new.splitlines())==2
 else:
  lines=old.splitlines(keepends=True);assert 'ordered-preflight-gap-be93' in lines[4]
  oldpattern=lines[4];newpattern=oldpattern.replace('RAW\\\\.md','RAW\\.md')
  assert oldpattern!=newpattern
  lines[4]=newpattern;new=''.join(lines)
  expression=re.search(r'`([^`]+)`',newpattern).group(1)
  four=['f3-ordered-gap-owning-operator-initial-RAW.md','f3-ordered-gap-owning-operator-review-RAW.md','f3-ordered-preflight-gap-be93-R1-review-RAW.md','f3-ordinary-3bd8-R1-operator-review-RAW.md']
  assert all(re.fullmatch(expression,'syzygy-k54o-3/'+x) for x in four)
 for kind,data in [('original',old),('resolved',new)]:
  p=fix/kind/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+f,tofile='b/'+f))
 meta['files'].append({'path':f,'originalSha256':hashlib.sha256(old.encode()).hexdigest(),'resolvedSha256':hashlib.sha256(new.encode()).hexdigest()})
(fix/'minimal.patch').write_text(''.join(patch))
(fix/'binding.json').write_text(json.dumps(meta,indent=2)+'\n')
logs={}
for p in out.glob('job-*.log'):
 s=p.read_text(); counts=collections.Counter(re.findall(r'Z (killed|held|SURVIVED)\s+',s))
 logs[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'lines':len(s.splitlines()),'witnessCounts':dict(counts),'selftestFailureCount':len(re.findall(r'Z SELFTEST FAIL:',s))}
(out/'failure-census.json').write_text(json.dumps(logs,indent=2)+'\n')
print(json.dumps({'repairHead':head,'patchSha256':hashlib.sha256((fix/'minimal.patch').read_bytes()).hexdigest(),'logs':logs},indent=2))

