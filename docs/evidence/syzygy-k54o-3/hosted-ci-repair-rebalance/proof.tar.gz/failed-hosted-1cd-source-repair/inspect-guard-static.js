const ts = require('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w/node_modules/typescript');
const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const dir = '/home/orca/.tmp/f3-native-admission-fixes/hosted-ci-checkpoint-1cd763-R1';
const repo = '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w';
const path = 'packages/polaris-dossier/src/url-machine-peer.ts';
const expectedSource = 'a3549f4eba5aaca923d3c9a27b8a689facf24a2e30f929893c8b6d6010ce0ffd';
const expectedCall = 'a91baeff25ce94e5c56a9306b460dd766124f95c695fd8cc626019e67953e87f';
const printer = ts.createPrinter({removeComments:true});
const inspect = (ref) => {
 const text = cp.execFileSync('git',['-C',repo,'show',ref+':'+path],{encoding:'utf8'});
 const source = ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true);
 const hash = (node,hint=ts.EmitHint.Unspecified)=>crypto.createHash('sha256').update(printer.printNode(hint,node,source)).digest('hex');
 const calls=[]; const visit=node=>{
  if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='spawnSync')calls.push({line:source.getLineAndCharacterOfPosition(node.getStart()).line+1,fingerprint:hash(node,ts.EmitHint.Expression)});
  ts.forEachChild(node,visit);
 };visit(source);
 return {ref,sourceByteSha256:crypto.createHash('sha256').update(text).digest('hex'),sourceFingerprint:hash(source),calls};
};
const current=inspect('a362226235409efb184622271b22729cf8754d08');
const prior=inspect('6dcfa2e73c08e8de14271b5807373037786a77f5');
const result={typescriptVersion:ts.version,expectedSource,expectedCall,prior,current,callRetained:current.calls.length===1&&current.calls[0].fingerprint===expectedCall};
if(!result.callRetained)throw Error('native call drift');
fs.writeFileSync(dir+'/guard-static-analysis.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));

