PASS

# Fresh independent source review: hosted core rebalance R2

[Inferred] PASS for the bounded source change and its source controls. No revision finding in the three-file candidate. This verdict does not establish runtime acceptance or hosted budget compliance.

## Review subject and integrity

- Packet: `/home/orca/.tmp/f3-native-admission-fixes/hosted-core-rebalance-8198-R2`
- Actual base commit: `8198e8e34e394c8918a86db3dec02dc1ef1fa8f2`
- Actual base tree: `3f31393e0b5966ab9c3d23f80954b9742a427213`
- Patch SHA-256: `89feb1ccd4f77e5a6539bb7477b54df3bd5d19ebc45b8c411753e093a8cdfb30`
- SHA256SUMS SHA-256: `54b557f4cb984c2b9dbe85b7309d024d558cd5c8c9197613879324b7481e6c8d`
- Packet-index SHA-256: `01f0f73bd6cc3b3c8f412b55b912973164296140ee22e19067edb966c85c26b0`
- Binding SHA-256: `b4fe800cc812e5ff43c80cb023ae6efe541d4775e4cf4271ed5ff19896d42ab2`

[Observed] Python hashlib verified each of the 15 SHA256SUMS entries against actual bytes, and independently checked the 14 packet-index entries and their byte lengths. A second method, sha256sum -c SHA256SUMS, reported OK for the same 15-entry population. The sealed actual-commit receipt equals its outer copy. Git object reads independently confirmed the receipt tree and each of the three original files at the recorded head. Reconstructing a unified diff from the complete original/resolved files reproduced minimal.patch byte for byte.

| File | Original SHA-256 | Resolved SHA-256 |
| --- | --- | --- |
| `scripts/run_integration_lane.mjs` | `abb7ead193281304676f96f5bb3909e589392de37a3617efe96508c8de514380` | `6f656a4b12e3edd4b2f8a2624ce28755610aa6b6d91103ecdfdbf00eb0f45fa0` |
| `.github/workflows/node-ci.yml` | `80454b017ae08a02d4fe28b9711bb978fcbbb23d32440ece647b058fb3bcddb5` | `9476f9be4530652fc8ef1e701e0c747d65ba25d2dd7b7846e9be51cfd33c431b` |
| `CONTRIBUTING.md` | `32b669709b8416134eeea2ba037e11ac08bdde43eb3120176fe0aec3d35f1174` | `56bd4ed5ff6867b7ead147940ce8a43884fc1b9ab141cd56a6ad070407286780` |

## Governing criteria and method

[Observed] Applied ci-discipline and test-rigor from /home/orca/.dotfiles/ai-bootstrap/skills/personal/th-engineering/subskills/, the dispatch acceptance criteria, sealed README.md, complete original/resolved workflow and router, and CONTRIBUTING.md checking/hosted-budget policy. The nearest selector planning test and selector source at the actual Git head were read to determine whether existing tests cover workflow wiring. They cover selection planning rather than the integration workflow wiring predicates added here. No transcript or live execution result supplied the verdict.

[Observed] Reviewed the complete three-file diff and resolved files. Tools performed read-only source inspection, Git object reads, static Python comparisons, and digest verification. No repository module, product, test, build, fixture, native helper, provider, or candidate selftest was executed. The only write is this review artifact.

## Findings

1. [Observed] Scope and coverage are preserved. The router plan at resolved/scripts/run_integration_lane.mjs:21-37 first computes the same sorted partition, then removes the exact ordered-host path from its prior slice and adds it to core-1 only when it was in a later slice. Absent and already-first cases do not insert another file. An independent static reading of the actual-head INTEGRATION_TESTS declaration finds 146 distinct integration paths (also counted as 146 literal source rows), including one composed path and 145 non-composed paths. Recomputed assignments match the sealed oldRoutes/proposedRoutes exactly: 48+48+49 becomes 49+48+48, the sole changed assignment being the ordered-host path from core-3 to core-1. The non-composed multisets compare equal.

2. [Observed] Integration removes only its unused informational selector computation. The original and resolved workflow have byte-identical prefixes through the unit job, and byte-identical e2e-through-aggregate suffixes. The integration diff changes its placement comment and informational selector step. It retains the same PR-only disclosure, static seven-lane matrix, fail-fast: false, native prerequisites and provisioner, lane invocation, artifact receipt retention, and aggregate receipt verification. Merge-group executions still run every lane. The whole local integration command remains pinned by checkedPlan and unchanged.

3. [Inferred] The extended workflow guard protects the changed wiring without introducing an exemption. At resolved/scripts/run_integration_lane.mjs:41-58 it requires exactly the canonical unit/e2e job set and their exact retained PR-selector source form, refuses the selector script in integration, and requires the explicit full-fallback text. Existing restrictions against include/exclude/continue-on-error, a missing fail-fast: false, and noncanonical matrix shape remain. The parser is a restriction on the reviewed canonical source form, not a general semantic YAML validator. The actual complete workflow satisfies that form by inspection; the unchanged invocation, discovered population, per-lane actual selection and commit-bound receipt checks remain separate enforcement. No child-process/source guard, accepted invocation fingerprint or execution exemption is changed by this patch.

4. [Observed] Controls are proportional and retained. The existing nine population mutations and three receipt rejection controls are byte-identical in their contiguous source region. The two original workflow controls remain. Four new assert.throws controls respectively remove the unit selector, remove the e2e selector, remove the integration disclosure, and reintroduce the integration selector. Thus 14 rejected controls become 18. The added assertion within the existing selftest independently pins relocated/already-first/absent outcomes to literal [[true, 1], [true, 1], [false, 0]] expected values. A deletion of the relocation branch would preserve population yet fail its moved-case expectation. The patch changes no Vitest test declaration or test file: net new Vitest cases 0. These are source-level assessments; actual mutant/selftest/discovery outcomes remain pending execution by the implementer.

5. [Observed] Documentation matches this bounded change. CONTRIBUTING.md:157-189 explains full integration fallback, retained unit/e2e selection, placement, whole local integration, and the routing checks. The complete CI time budget section is byte-identical to the original and still states seven minutes (420 seconds), measured by the slowest job. README.md explicitly labels resulting duration/budget compliance Unknown and explains why removing overhead cannot make the cited 484893 ms case / 637-second job fit the budget. No source/runtime deadline, production module, scenario, proof archive or readiness criterion is edited in the three-file patch.

## Verification boundary

[Unknown] Execution of the affected selftest, discovery/lane selection and nearest selector controls on the candidate; these are the implementer's next checks. Resulting hosted duration and genuine performance acceptance are also Unknown. This source-only PASS is not evidence that the original slow scenario meets its deadline or the unchanged 420-second hosted budget. Any later edit to a reviewed byte retires this review binding.
