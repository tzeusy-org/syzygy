import os,json,subprocess,time,hashlib
from pathlib import Path
root=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
out=Path('/home/orca/.tmp/f3-native-admission-fixes/hosted-rebalance-focused-1');out.mkdir()
(out/'tmp').mkdir(mode=0o700)
node='/home/orca/.nvm/versions/node/v24.6.0/bin/node'
env=os.environ.copy();env.update(PATH=str(Path(node).parent)+':/usr/bin:/bin',TMPDIR=str(out/'tmp'))
sel=out/'selection.json';sel.write_text(json.dumps({'mode':'scoped-ci-rebalance','tiers':{'unit':['apps/three-surface-poc/src/ci-selection.test.ts']}})+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
records=[]
steps=[('router-selftest',[node,'scripts/run_integration_lane.mjs','--selftest']),('router-discovery',[node,'scripts/run_integration_lane.mjs','--check']),('selector-control',[node,'scripts/check_unit_tmpdir.mjs','--selection',str(sel)]),('governance',['python3','scripts/check_governance.py'])]
for name,argv in steps:
 start=time.monotonic();log=out/(name+'.log')
 with log.open('wb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 raw=log.read_bytes();record={'name':name,'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-start,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};records.append(record)
 (out/'progress.json').write_text(json.dumps({'head':head,'steps':records},indent=2)+'\n')
 print(json.dumps(record),flush=True)
 assert r.returncode==0,name
 text=raw.decode()
 if name=='router-selftest':assert 'control + 18 rejected mutations' in text
 if name=='router-discovery':assert '146 files; 7 composed cases; core slices 49+48+48; 7 lanes' in text
 if name=='selector-control':
  reports=[json.loads(l.split(':',1)[1]) for l in text.splitlines() if l.startswith('syzygy-tmpdir-report:')]
  assert len(reports)==1 and reports[0]['errors']==[]
  rows=reports[0]['files'];assert len(rows)==1 and rows[0]['path']=='apps/three-surface-poc/src/ci-selection.test.ts'
  assert rows[0]['passed']==14 and rows[0]['failed']==0 and rows[0]['skipped']==0 and rows[0]['todo']==0
  owner=[json.loads(l.split(' ',1)[1]) for l in text.splitlines() if l.startswith('tmpdir-result ')]
  assert len(owner)==1 and owner[0]['cleanup'] and owner[0]['errors']==[] and owner[0]['census']['leftovers']==[] and owner[0]['census']['errors']==[] and owner[0]['denominator']['problems']==[]
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
(out/'complete.json').write_text(json.dumps({'head':head,'steps':records,'scopedAccepted':True},indent=2)+'\n')
