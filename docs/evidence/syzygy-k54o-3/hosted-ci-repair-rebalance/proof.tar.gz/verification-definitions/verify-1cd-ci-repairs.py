#!/usr/bin/python3
"""Run the affected owning checks in a clean clone, reading canonical commands."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import time

SOURCE = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
BASE = Path('/home/orca/.tmp/f3-native-admission-fixes')
NODE = '/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM = '/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'

def main(subject):
    assert len(subject)==40 and all(c in '0123456789abcdef' for c in subject)
    out = BASE / ('ci-repair-check-'+subject[:7]+'-1')
    out.mkdir()
    clone = out / 'clone'
    scratch = out / 'tmp'
    scratch.mkdir(mode=0o700)
    env = os.environ.copy()
    env.update(PATH=str(Path(NODE).parent)+':/usr/bin:/bin', TMPDIR=str(scratch))
    records = []
    def run(name, argv, cwd, extra=None):
        began = time.monotonic()
        with (out/(name+'.log')).open('wb') as log:
            child = subprocess.Popen(argv, cwd=cwd, env={**env, **(extra or {})}, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = child.wait(timeout=900)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                raise
        data = (out/(name+'.log')).read_bytes()
        row = {'name':name,'argv':argv,'cwd':str(cwd),'exit':code,'seconds':time.monotonic()-began,
               'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        records.append(row)
        (out/'progress.json').write_text(json.dumps({'subject':subject,'steps':records},indent=2)+'\n')
        print(name,code,f'{row["seconds"]:.3f}s',flush=True)
        assert code==0,row
    run('clone',['git','clone','--no-hardlinks','--no-checkout',str(SOURCE),str(clone)],BASE)
    run('checkout',['git','checkout','--detach',subject],clone)
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
    run('install',[NODE,NPM,'ci','--no-audit','--no-fund'],clone)
    run('native-call-guard',[NODE,'--input-type=module','-e',
        "import {diagnoseVitest} from './scripts/check_unit_tmpdir.mjs'; const result=await diagnoseVitest({root:process.cwd(),project:'integration',files:['apps/three-surface-poc/src/sync-child-process-guard.test.ts']}); process.exitCode=result.ok?0:1;"],clone)
    spec=importlib.util.spec_from_file_location('current_battery',clone/'scripts/run_status_battery.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows=module.battery((clone/'PROJECT-STATUS.md').read_text())
    targets=[
        ('campaign-check',['python3','scripts/check_docs_review_campaign_partition.py','--check']),
        ('campaign-selftest',['python3','scripts/check_docs_review_campaign_partition.py','--selftest']),
        ('governance',['python3','scripts/check_governance.py']),
        ('reconciliation-check',['python3','scripts/check_spec_reconciliation.py','--check']),
        ('reconciliation-selftest',['python3','scripts/check_spec_reconciliation.py','--selftest']),
    ]
    selected=[]
    for name,expected in targets:
        found=[(command,variables) for command,variables in rows if shlex.split(command,comments=True)==expected]
        assert len(found)==1,(name,len(found))
        command,variables=found[0]
        selected.append({'name':name,'canonicalCommand':command,'variables':variables})
        (out/'canonical-selection.json').write_text(json.dumps({'population':len(rows),'selected':selected},indent=2)+'\n')
        argv=shlex.split(command,comments=True)
        if name=='reconciliation-selftest':
            argv+=['--witnesses',str(out/'reconciliation-witnesses.json')]
        run(name,argv,clone,variables)
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
    tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=clone,text=True).strip()
    (out/'complete.json').write_text(json.dumps({'subject':subject,'tree':tree,'scopedAccepted':True,
        'canonicalPopulation':len(rows),'canonicalSelected':len(selected),'cloneClean':True,'steps':records},indent=2)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--subject',required=True)
    main(parser.parse_args().subject)
