import pathlib,subprocess,shutil,json,difflib,hashlib
base=pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes');r='/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w';head='8198e8e34e394c8918a86db3dec02dc1ef1fa8f2';p=base/'hosted-core-rebalance-8198-R2';p.mkdir(exist_ok=False)
router=(base/'hosted-core-rebalance-8198-R1/resolved/run_integration_lane.mjs').read_text()
ghref='$'+'{{ github.event.pull_request.base.sha }}'
selector="        if: github.event_name == 'pull_request'\n        run: node --disable-warning=MODULE_TYPELESS_PACKAGE_JSON scripts/select_ci_tests.mjs --base \""+ghref+"\" --out \"$RUNNER_TEMP/ci-selection.json\""
fallback='Integration fallback: every mandatory lane runs; this tier does not consume the PR selection.'
anchor="  assert(block, 'integration job missing');\n"
addition=anchor+"  const selectorStep = "+json.dumps(selector)+";\n  const selectedTiers = [...text.matchAll(/^  (unit|e2e):\\n([\\s\\S]*?)(?=^  [\\w-]+:|(?![\\s\\S]))/gm)];\n  exact(selectedTiers.map(match => match[1]), ['unit', 'e2e'], 'selected workflow tiers');\n  for (const [, tier, body] of selectedTiers) assert(body.includes(selectorStep), tier + ': pull-request selector retained');\n  assert(!block.includes('scripts/select_ci_tests.mjs'), 'integration must not recompute an unused selection');\n  assert(block.includes("+json.dumps(fallback)+"), 'integration full fallback disclosed');\n"
assert router.count(anchor)==1;router=router.replace(anchor,addition)
oldfixture=next(l for l in router.splitlines() if l.startswith('  const fixture = '))
newfixture="  const selectorStep = "+json.dumps(selector)+";\n  const fallback = "+json.dumps(fallback)+";\n  const fixture = ['  unit:', selectorStep, '  integration:', '    strategy:', '      fail-fast: false',\n    '      matrix:', '        lane: ' + JSON.stringify(lanes), '    steps:', '      - run: |',\n    '          echo \"' + fallback + '\"', '  e2e:', selectorStep, ''].join('\\n');"
router=router.replace(oldfixture,newfixture)
console=next(l for l in router.splitlines() if 'console.log(' in l and 'rejected mutations' in l)
checks=r"""  assert.throws(() => workflowLanes(fixture.replace('  unit:\n' + selectorStep, '  unit:')), undefined, 'unit selector omitted');
  assert.throws(() => workflowLanes(fixture.replace('  e2e:\n' + selectorStep, '  e2e:')), undefined, 'e2e selector omitted');
  assert.throws(() => workflowLanes(fixture.replace(fallback, '')), undefined, 'integration fallback omitted');
  assert.throws(() => workflowLanes(fixture.replace('    steps:\n', '    steps:\n          node scripts/select_ci_tests.mjs\n')), undefined, 'integration selector recomputed');
"""
router=router.replace(console,checks+console.replace('mutations.length + 5','mutations.length + 9'))
f='.github/workflows/node-ci.yml';workflow=subprocess.check_output(['git','-C',r,'show',head+':'+f],text=True)
start=workflow.index("      # The selector prints the PR's reach");end=workflow.index("      - name: install pinned Claude native fixture",start)
new="""      # The mandatory lane router does not consume a PR selection. Unit and
      # e2e retain their selectors; integration always runs all seven lanes.
      # Disclose that full fallback without recomputing the unused graph.
      - name: disclose full integration fallback (pull requests only)
        if: github.event_name == 'pull_request'
        run: |
          echo "Integration fallback: every mandatory lane runs; this tier does not consume the PR selection."

"""
workflow=workflow[:start]+new+workflow[end:]
files={'scripts/run_integration_lane.mjs':router,f:workflow};patch=[];rows=[]
for name,resolved in files.items():
 original=subprocess.check_output(['git','-C',r,'show',head+':'+name],text=True)
 for kind,data in [('original',original),('resolved',resolved)]:
  target=p/kind/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(data)
 patch.extend(difflib.unified_diff(original.splitlines(True),resolved.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 rows.append({'path':name,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'resolvedSha256':hashlib.sha256(resolved.encode()).hexdigest()})
(p/'minimal.patch').write_text(''.join(patch))
for name in ['ci-repair-actual-commit.json']:shutil.copyfile(base/name,p/name)
shutil.copyfile(base/'hosted-core-rebalance-8198-R1/static-population.json',p/'static-population.json')
(p/'binding.json').write_text(json.dumps({'subject':head,'files':rows,'patchSha256':hashlib.sha256((p/'minimal.patch').read_bytes()).hexdigest(),'newVitestTestCases':0,'newRejectedSelftestMutations':4,'totalRejectedSelftestMutations':18,'executed':False},indent=2)+'\n')
print(json.dumps({'packet':str(p),'patchSha256':hashlib.sha256((p/'minimal.patch').read_bytes()).hexdigest()}))

