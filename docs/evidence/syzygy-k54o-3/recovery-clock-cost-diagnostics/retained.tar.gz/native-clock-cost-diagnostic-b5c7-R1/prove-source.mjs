import ts from '/home/orca/.tmp/f3-native-admission-fixes/native-coverage-merge-execution/w/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { checkObserverWrappers } from './check-wrappers.mjs';
const read = name => readFileSync(new URL(name, import.meta.url), 'utf8');
const sha = value => createHash('sha256').update(value).digest('hex');
const original = read('original.test.ts'), candidate = read('url-run-composed.test.ts'), edits = JSON.parse(read('edits.json'));
function parse(source) {
 const tree = ts.createSourceFile('subject.ts', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
 if (tree.parseDiagnostics.length) throw new Error('parse diagnostics');
 return tree;
}
const before = parse(original), after = parse(candidate);
let restored = candidate;
for (const edit of [...edits].reverse()) {
 if (restored.split(edit.new).length !== 2) throw new Error(`reverse cardinality ${edit.label}`);
 restored = restored.replace(edit.new, edit.old);
}
if (restored !== original) throw new Error('unexplained source delta');
function walk(tree, predicate) {
 const found = []; function visit(node) { if (predicate(node)) found.push(node); ts.forEachChild(node, visit); } visit(tree); return found;
}
const calls = (tree, expression) => walk(tree, n => ts.isCallExpression(n) && expression(n.expression.getText(tree))).map(n => n.getText(tree));
const protectedCalls = ['vi.spyOn', 'expect', 'setTimeout', 'clearTimeout', 'controller.stop'];
const census = {};
for (const callee of protectedCalls) {
 const a = calls(before, s => s === callee), b = calls(after, s => s === callee);
 if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`protected calls changed: ${callee}`);
 census[callee] = a.length;
}
const types = name => {
 const aliases = walk(before, n => ts.isTypeAliasDeclaration(n) && n.name.text === name);
 if (aliases.length !== 1) throw new Error(`type ${name}`);
 return walk(aliases[0], ts.isStringLiteral).map(n => n.text);
};
const currentPhases = types('CurrentPhase'), boundaryPhases = types('InferenceBoundary'), relayPhases = types('RelayPhase');
function astShape(node) { return [node.kind, ts.isIdentifier(node) || ts.isStringLiteral(node) || ts.isNumericLiteral(node) ? node.text : null, node.getChildren().filter(n => n.kind !== ts.SyntaxKind.EndOfFileToken).map(astShape)]; }
if (JSON.stringify(astShape(parse(restored))) !== JSON.stringify(astShape(before))) throw new Error('restored AST differs');
const wrappers = checkObserverWrappers(candidate);
if (!wrappers.accepted || wrappers.population !== 10) throw new Error('ten original observer wrappers must remain');
// Conservative wire envelope: every bounded collection is full; counters reach their
// population cap, and every unbounded numeric field gets a conservative 25-byte
// finite-number JSON spelling (one byte wider than signed Number.MAX_VALUE).
// This overstates mutually exclusive outcomes.
const N = -0.0000010000000000000002;
const stamp = () => ({ startedMs: N, settledMs: N, outcome: 'accepted' });
const phaseSummary = phase => ({ count: 64, pending: 64, refused: 64, rejected: 64, ms: N, maxMs: N });
const stages = (phases, maximum) => ({ count: maximum, retained: maximum, omitted: 0, phases: Object.fromEntries(phases.map(phase => [phase, phaseSummary(phase)])) });
const current = () => ({ ...stamp(), lease: 'retired', leaseRemainingMs: N, stages: stages(currentPhases, 64) });
const cost = () => ({ ordinal: N, inclusiveDurationsMayOverlap: true, productPreparation: current(), preparedProductCurrent: current(), controllerCurrent: current(), boundaries: stages(boundaryPhases, 12), relay: stages(relayPhases, 12) });
const connection = () => ({ ordinal: N, boundMs: N, kind: 'inference-bridge', open: stamp(), accept: stamp(), capture: stamp(), authorize: stamp(), latestSample: { ordinal: N, verify: stamp(), confirm: stamp(), confirmationInput: false } });
const newFields = { observedMs: N, observerBeganMs: N, onTestFinishedEnteredMs: N, cleanupTiming: { afterEachStartedMs: N, failureStopStartedMs: N }, connectionCount: N, transportCounts: { open: N, accept: N, capture: N, authorize: N }, connections: Array.from({ length: 12 }, connection), inference: { latestCosts: Array.from({ length: 2 }, cost) } };
const worstCaseSerializedBytes = Buffer.byteLength(JSON.stringify(newFields));
if (worstCaseSerializedBytes >= 24 * 1024) throw new Error(`new-fields envelope too large: ${worstCaseSerializedBytes}`);
const report = { state: 'Observed source/AST inspection only; no test or product module execution', sourceSha256: sha(original), candidateSha256: sha(candidate), exactEdits: edits.map(e => ({ label: e.label, oldSha256: sha(e.old), newSha256: sha(e.new) })), parseDiagnostics: 0, reverseExactByteIdentity: true, reverseAstIdentity: true, protectedCallCensus: census, observerWrappers: wrappers, phasePopulations: { current: currentPhases.length, boundary: boundaryPhases.length, relay: relayPhases.length }, currentPhases, boundaryPhases, relayPhases, newFieldsWorstCaseSerializedBytes: worstCaseSerializedBytes, ceilingBytes: 24 * 1024, envelope: newFields, limitation: 'Only added fields are bounded here; existing diagnostic fields and total line size are unchanged and not certified below a log limit. Inclusive phase durations may overlap and are not CPU.' };
writeFileSync(new URL('source-proof.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ candidateSha256: report.candidateSha256, edits: edits.length, protectedCallCensus: census, wrappers: wrappers.population, phasePopulations: report.phasePopulations, newFieldsWorstCaseSerializedBytes: worstCaseSerializedBytes }));
