import ts from '/home/orca/.tmp/f3-native-admission-fixes/native-coverage-merge-execution/w/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const packet = new URL('./', import.meta.url), hash = value => createHash('sha256').update(value).digest('hex');
const read = name => readFileSync(new URL(name, packet));
const manifest = JSON.parse(read('manifest.json'));
for (const item of manifest.files) { const value = read(item.path); assert.equal(value.length, item.bytes); assert.equal(hash(value), item.sha256); }
const binding = JSON.parse(read('binding.json'));
assert.equal(hash(readFileSync(binding.typescriptParser.path)), binding.typescriptParser.sha256);
assert.equal(process.argv.length, 3, 'fresh sibling output directory argument required');
const output = resolve(process.argv[2]);
assert.equal(dirname(output), dirname(resolve(packet.pathname)), 'output must be outside repo, a packet sibling');
mkdirSync(output, { recursive: false });
const source = read('url-run-composed.test.ts').toString();
assert.equal(hash(source), binding.candidateSha256);
const tree = ts.createSourceFile('candidate.ts', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
assert.equal(tree.parseDiagnostics.length, 0);
const snapshots = [];
function visit(node) { if (ts.isVariableDeclaration(node) && node.name.getText(tree) === 'nativeSnapshot') snapshots.push(node); ts.forEachChild(node, visit); }
visit(tree); assert.equal(snapshots.length, 1);
const callback = snapshots[0].initializer;
assert.ok(ts.isArrowFunction(callback) && ts.isBlock(callback.body));
const declarations = new Map();
for (const statement of callback.body.statements) if (ts.isVariableStatement(statement)) for (const declaration of statement.declarationList.declarations)
 if (['stages', 'current', 'append'].includes(declaration.name.getText(tree))) declarations.set(declaration.name.getText(tree), declaration);
assert.equal(declarations.size, 3);
const extracted = ['stages', 'current', 'append'].map(name => `const ${declarations.get(name).getText(tree)};`).join('\n');
writeFileSync(`${output}/extracted-projections.ts`, extracted);
function compile(code) {
 const result = ts.transpileModule(code + '\nglobalThis.projections = { stages, current, append };', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None }, reportDiagnostics: true });
 assert.equal(result.diagnostics?.length ?? 0, 0);
 assert.ok(!/\b(?:import|require)\s*\(/.test(result.outputText));
 const context = vm.createContext(Object.create(null));
 new vm.Script(result.outputText, { filename: 'extracted-metadata-projections.js' }).runInContext(context, { timeout: 1000 });
 return { functions: context.projections, javascript: result.outputText };
}
const plain = value => value === undefined ? value : JSON.parse(JSON.stringify(value));
function freeze(value) { if (value && typeof value === 'object') { for (const child of Object.values(value)) freeze(child); Object.freeze(value); } return value; }
const row = (phase, startedMs, settledMs, outcome, extra = {}) => ({ phase, timing: { startedMs, ...(settledMs === undefined ? {} : { settledMs }), ...(outcome === undefined ? {} : { outcome }) }, ...extra });
const checks = {
 cap(f) {
  const input = freeze([...Array.from({ length: 95 }, () => row('audit-authority', 0, 2, 'accepted')), row('read', 3), row('write', 4, 9, 'rejected')]);
  const result = f.stages(input, 96);
  assert.equal(result.count, 97, 'CAP_DENOMINATOR'); assert.equal(result.retained, 96, 'CAP_RETAINED');
  assert.equal(result.omitted, 1, 'CAP_OMITTED'); assert.equal(result.phases.write, undefined, 'CAP_EXCLUDES_TAIL');
  assert.equal(result.phases['audit-authority'].count, 95, 'CAP_PHASE_COUNT');
 },
 pending(f) {
  const result = f.stages(freeze([row('runtime-authority', 0, 5, 'accepted'), row('runtime-authority', 10, 7, 'refused'), row('runtime-authority', 9), row('runtime-authority', 2, 6, 'rejected')]), 64).phases['runtime-authority'];
  assert.equal(result.pending, 1, 'PENDING_COUNT'); assert.equal(result.refused, 1, 'REFUSED_COUNT'); assert.equal(result.rejected, 1, 'REJECTED_COUNT'); assert.equal(result.count, 4, 'PHASE_COUNT');
 },
 sum(f) { const result = f.stages(freeze([row('read', 0, 5, 'accepted'), row('read', 2, 6, 'accepted')]), 96).phases.read;
  assert.equal(result.ms, 9, 'INCLUSIVE_SUM'); assert.equal(result.maxMs, 5, 'INCLUSIVE_MAX'); },
 clamp(f) { const result = f.stages(freeze([row('read', 10, 7, 'refused')]), 96).phases.read;
  assert.equal(result.ms, 0, 'CLAMP_NEGATIVE'); assert.equal(result.maxMs, 0, 'CLAMP_NEGATIVE_MAX'); },
 current(f) {
  const input = freeze({ startedMs: 100, settledMs: 200, outcome: 'accepted', stages: [row('product-lease', 0, 1, 'accepted', { lease: 'open', leaseRemainingMs: 99 }), ...Array.from({ length: 62 }, () => row('budget', 1, 3, 'accepted')), row('product-lease', 4, 5, 'refused', { lease: 'expired', leaseRemainingMs: -7 }), row('product-lease', 6, 7, 'refused', { lease: 'retired', leaseRemainingMs: -99 })] });
  const before = JSON.stringify(input), result = f.current(input);
  assert.equal(result.lease, 'expired', 'LATEST_LEASE'); assert.equal(result.leaseRemainingMs, -7, 'LATEST_LEASE_REMAINING');
  assert.equal(result.startedMs, 100, 'PRESERVE_START'); assert.equal(result.settledMs, 200, 'PRESERVE_SETTLED'); assert.equal(result.outcome, 'accepted', 'PRESERVE_OUTCOME');
  assert.equal(result.stages.count, 65, 'CURRENT_DENOMINATOR'); assert.equal(result.stages.omitted, 1, 'CURRENT_OMISSION'); assert.equal(JSON.stringify(input), before, 'CURRENT_INPUT_UNCHANGED');
 },
 append(f) {
  const input = freeze({ kind: 'response-admitted', timing: { startedMs: 5, settledMs: 35, outcome: 'accepted' }, stages: [row('audit-authority', 1, 5, 'accepted'), row('attempt-authority', 2), row('read', 3, 6, 'rejected')], attemptCurrent: { calls: 40, entries: Array.from({ length: 32 }, (_, ordinal) => ({ startedMs: ordinal, settledMs: ordinal + 1, outcome: 'accepted', stages: [row('runtime-authority', ordinal, ordinal + 1, 'accepted')] })) } });
  const before = JSON.stringify(input), result = f.append(input), attempt = result.attemptCurrent;
  assert.equal(attempt.latest.length, 1, 'ATTEMPT_LATEST_BOUND'); assert.equal(attempt.latest[0].startedMs, 31, 'ATTEMPT_LATEST_IDENTITY');
  assert.equal(attempt.calls, 40, 'ATTEMPT_CALLS'); assert.equal(attempt.retained, 32, 'ATTEMPT_RETAINED'); assert.equal(attempt.omitted, 8, 'ATTEMPT_OMITTED');
  assert.equal(attempt.projected, 1, 'ATTEMPT_PROJECTED'); assert.equal(attempt.projectionOmitted, 31, 'ATTEMPT_PROJECTION_OMITTED');
  assert.deepEqual(plain(result.timing), input.timing, 'APPEND_STAMP'); assert.equal(result.kind, input.kind, 'APPEND_KIND');
  assert.equal(result.inclusiveDurationsMayOverlap, true, 'APPEND_OVERLAP_DISCLOSURE'); assert.equal(result.stages.phases.read.rejected, 1, 'APPEND_STAGE_FAILURE'); assert.equal(JSON.stringify(input), before, 'APPEND_INPUT_UNCHANGED');
 },
 empty(f) { assert.equal(f.current(undefined), undefined); assert.equal(f.append(undefined), undefined); assert.deepEqual(plain(f.stages([], 96)), { count: 0, retained: 0, omitted: 0, phases: {} });
  const value = f.append({ kind: 'prepared', timing: { startedMs: 0 }, stages: [] }); assert.equal(value.attemptCurrent, undefined); }
};
const baseline = compile(extracted);
writeFileSync(`${output}/extracted-projections.js`, baseline.javascript);
for (const check of Object.values(checks)) check(baseline.functions);
const mutants = [
 { id: 'omit-stage-cap', old: 'entries.slice(0, maximum)', replacement: 'entries.slice()', check: 'cap', marker: 'CAP_RETAINED' },
 { id: 'omit-pending-count', old: 'if (timing.settledMs === undefined) summary.pending++;', replacement: '', check: 'pending', marker: 'PENDING_COUNT' },
 { id: 'replace-sum-with-last', old: 'summary.ms += elapsed;', replacement: 'summary.ms = elapsed;', check: 'sum', marker: 'INCLUSIVE_SUM' },
 { id: 'omit-duration-clamp', old: 'Math.max(0, timing.settledMs - timing.startedMs)', replacement: '(timing.settledMs - timing.startedMs)', check: 'clamp', marker: 'CLAMP_NEGATIVE' },
 { id: 'first-lease-instead-of-latest', old: '.filter(stage => stage.lease !== undefined).at(-1)', replacement: '.filter(stage => stage.lease !== undefined).at(0)', check: 'current', marker: 'LATEST_LEASE' },
 { id: 'first-current-instead-of-latest', old: 'value.attemptCurrent.entries.slice(-1)', replacement: 'value.attemptCurrent.entries.slice(0, 1)', check: 'append', marker: 'ATTEMPT_LATEST_IDENTITY' },
 { id: 'omit-current-omissions', old: 'Math.max(0, value.attemptCurrent.calls - value.attemptCurrent.entries.length)', replacement: '0', check: 'append', marker: 'ATTEMPT_OMITTED' }
];
const results = [];
for (const mutant of mutants) {
 assert.equal(extracted.split(mutant.old).length, 2, `sole mutant fragment ${mutant.id}`);
 const code = extracted.replace(mutant.old, mutant.replacement), compiled = compile(code);
 let caught;
 try { checks[mutant.check](compiled.functions); } catch (error) { caught = error; }
 assert.ok(caught instanceof assert.AssertionError, `mutant must fail an assertion: ${mutant.id}`);
 assert.ok(caught.message.includes(mutant.marker), `intended assertion required: ${mutant.id}: ${caught.message}`);
 writeFileSync(`${output}/${mutant.id}.ts`, code);
 results.push({ ...mutant, sourceSha256: hash(code), detectedBy: mutant.marker, error: caught.message });
}
const report = { state: 'Observed outside metadata VM validation; no product/test imports', candidateSha256: binding.candidateSha256, extractedSha256: hash(extracted), baselineChecks: Object.keys(checks), mutantDenominator: mutants.length, rejected: results.length, results };
writeFileSync(`${output}/results.json`, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ baselineChecks: report.baselineChecks.length, rejected: report.rejected, denominator: report.mutantDenominator, output }));
