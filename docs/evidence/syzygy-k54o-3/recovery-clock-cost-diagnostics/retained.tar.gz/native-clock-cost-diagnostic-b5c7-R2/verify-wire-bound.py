import json
from pathlib import Path
packet = Path(__file__).resolve().parent
proof = json.loads((packet / 'source-proof.json').read_text())
slots = 0

def fixed_width(value):
    global slots
    if isinstance(value, float):
        slots += 1
        return '~' * 25
    if isinstance(value, list):
        return [fixed_width(child) for child in value]
    if isinstance(value, dict):
        return {key: fixed_width(child) for key, child in value.items()}
    return value

encoded = json.dumps(fixed_width(proof['envelope']), ensure_ascii=True, separators=(',', ':')).encode()
# Remove the two JSON string quotes around each replacement numeric token.
independent_bytes = len(encoded) - 2 * slots
assert independent_bytes == proof['newFieldsWorstCaseSerializedBytes']
assert independent_bytes < 34 * 1024
print(json.dumps({'independentFixedWidthBytes': independent_bytes, 'numericSlots': slots, 'numericTokenWidth': 25, 'ceilingBytes': 34 * 1024}))
