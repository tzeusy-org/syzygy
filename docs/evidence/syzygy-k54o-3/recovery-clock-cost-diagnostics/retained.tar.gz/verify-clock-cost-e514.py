import subprocess,json,time,tempfile,os,hashlib
from pathlib import Path
root=Path('/home/orca/.tmp/f3-native-admission-fixes/native-coverage-merge-execution/w')
subject='e514a52c2043193ab67a0be1f8f7849aea563994'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==subject
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
out=Path('/home/orca/.tmp/f3-native-admission-fixes/clock-cost-e514-verification');out.mkdir()
tmp=Path(tempfile.mkdtemp(prefix='f3-',dir='/home/orca/.tmp'));tmp.chmod(0o700);assert tmp.stat().st_mode&0o7777==0o700
env=os.environ.copy();env['TMPDIR']=str(tmp)
commands=[('typecheck',['npm','run','typecheck']),('observer-contracts',['node','node_modules/vitest/vitest.mjs','run','--project','integration','--maxWorkers','1','packages/polaris-dossier/src/url-run-composed.test.ts','--testNamePattern=bounded restoration observer','--reporter=json','--outputFile='+str(out/'observer-contracts.vitest.json')]),('governance',['python3','scripts/check_governance.py'])]
results=[]
for name,cmd in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log: code=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 item={'name':name,'command':cmd,'exit':code,'seconds':time.monotonic()-start};results.append(item);(out/'results.json').write_text(json.dumps({'subject':subject,'results':results},indent=2)+'\n');print(json.dumps(item),flush=True)
 if code: raise SystemExit(code)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
