# Fixed b5c7 interrupted-resume success denominator

[Observed] Bound source subject: b5c7bb12e9c1420566dfbf1b74dce0f3563cb3f8. This is a static source census, not execution, timing acceptance or a production optimization. Frozen source bytes and their scripted SHA-256 values are in binding.json; project.py reproduces the mechanical counts without importing project code or running tests.

[Observed] The Design script has four tool responses followed by one terminal response (url-run-composed.test.ts2789–2803): poll; read round-2 part1; read round-2 part2; submit round-2 verdict; end_turn. The initial interrupted attempt stops at confirmed delivery before a provider request; the test asserts design.count()===0 at3026 and sets designRound=2 at3174 before starting resumed Design. The profile resultTurns is exactly ['prepared','part','part','verdict-acknowledgment'] (session-profile.ts43). The transfer preflight explicitly requires partCount===2 (url-ordered-design-bounds.ts86). No successful count-token exchange is included: the ordered host rejects that route at103.

[Observed] Every successful messages request invokes five direct effect() calls and four effect-wrapped audit() calls in session-relay.ts293–388. Their exact source order is:

1. Request screening/admission, with product preflight.
2. Provider-header preparation.
3. attempt-allowed audit, with product preflight.
4. Native send/forwarding-header preparation.
5. send-attempt audit, with product preflight.
6. send-outcome audit, with product preflight.
7. Response screening, with product preflight.
8. response-admitted audit, with product preflight.
9. Final HTTP response write/flush.

[Observed] Each effect() calls the native context.mediate('inference-forward',...) at session-relay.ts210–216. The observer counts that exact operation only when the peer is inference-bridge (url-run-composed.test.ts1630–1634), so MCP broker mediations are separate. The independent enumeration of nine action names matches the source census of five direct effects plus four successful audit events.

| Request | Scripted provider response | Inference ordinals | Ordered records during HTTP exchange | Subsequent tool records |
|---|---|---|---:|---|
|1|poll tool call|1–9|0|prepared (1)|
|2|part1 tool call|10–18|4|part-receipt (1)|
|3|part2 tool call|19–27|4|part-receipt (1)|
|4|verdict submission tool call|28–36|4|delivery-completed, verdict-staged, acknowledgment-receipt (3)|
|5|terminal end_turn|37–45|5, including eligible|none|

[Observed] Thus the fixed success path has5 messages requests,45 inference-forward mediations,4 tool/broker invocations and23 ordered durable records. A second source route confirms the ordered count: the independent verifier consumes prepared, four exchanges, two part receipts, the three verdict/acknowledgment records and eligible, and caps the complete prefix at13+5*partCount=23 (url-ordered-design-audit.ts167/248–292).

[Observed] The retained b5c7 union has18 accepted mediations and19 pending, two provider forwards and two broker invocations, with latest part-receipt accepted. [Inferred] It has completed requests1–2 plus poll/part1 tools. Remaining successful work is27 inference mediations including pending19 through45, two tools (part2 and verdict submission), and17 ordered durable records. Terminal consumption, final producer/render, durable execution-record admission and closed-already byte comparison still follow; they are outside the45 count. Failure/timer/refusal audit, unexpected retries or unsupported SDK traffic can add work or cause refusal;45 is not a cap on every failing run.

[Observed] One successful native mediation has exactly three explicit await current(state) calls (url-machine-peer.ts473,482,497): before optional preflight, inside the machine-store lease before reading the client, and after private peer audit. Each current(state) itself performs three synchronous full peer check(state) calls, one parent-current await and one fresh async kernel-peer capture (328–343). A preflight-enabled mediation additionally calls prepare once and synchronous preflight.current once before entering the store lease (478–479). Boundary callbacks, machine-store synchronous/async authority checks and inner effect callbacks add further checks; their whole-run count is not fixed by the nine-action enumeration.

[Observed] One ordinary base audit append has six checkCurrent invocations: io entry/exit plus four commit checks (url-session-audit.ts516–523/833–845). Each ordered writer append expands further:

- Writer.current before prefix read and after durable append:2 calls (url-ordered-design-writer.ts82–107).
- Each delegates to checkAttemptCurrent, as do five commit boundaries for an ordered record:7 attempt-current callbacks.
- Each checkAttemptCurrent brackets its attempt callback with two base checkCurrent calls (url-session-audit.ts1027–1032), and commit io adds two:16 base audit-current callbacks per ordered record.

[Observed] Consequently23 ordered records alone require161 attempt-current and368 base audit-current callbacks, excluding terminal reader currentness, native mediation's private peer-audit append, the four base relay events and usage append per request, tool checks and store I/O boundaries. For a regular noninitial audit action, the host also checks current before controller.observe, and controller.observe checks current before/after its ordered transition (url-ordered-design-host.ts129–135; url-ordered-design-session.ts379–450). These are nested call-family counts, not disjoint timing buckets or permission to merge checks. The six base checks of a plain append independently match retained append callback traces: six parent-current records plus twelve nested machine-effect records,18 observations total.

[Observed] The first two requests span105.821785s and193.346873s respectively in the same observeDesignRun-relative clock. The second request contains45.884301s mediation15, including23.949603s audit; full audit/current nesting must not be summed again. [Inferred] Repeating the second request's observed193.346873s cost for the three remaining requests would require580.040619s more before tools/closure. This is a conditional arithmetic model, not a lower bound: future action costs can change. It nevertheless demonstrates why this failure is substantial unfinished protocol work, rather than a final boundary overrun.

[Observed] Even with zero startup/tool/closure overhead,420/45 permits only9.333333s average per mediation; real overhead makes that allowance smaller. The ten-minute fixture allowance permits at most13.333333s average before overhead. [Unknown] A valid completion-time bound or mathematical impossibility: runtime limits are ceilings, not measured lower bounds, and remaining verdict staging/reproduction is unmeasured. No waiting-time increase, check removal, caching or implementation change is proposed from this census.
