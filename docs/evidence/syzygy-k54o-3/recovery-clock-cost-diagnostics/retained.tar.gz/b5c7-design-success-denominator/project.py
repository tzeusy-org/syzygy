"""Mechanical source census only. Imports/executes no project module or tests."""
import ast
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
OUT = pathlib.Path(__file__).resolve().parent
SUBJECT = 'b5c7bb12e9c1420566dfbf1b74dce0f3563cb3f8'
PREFIX = 'packages/polaris-dossier/src/'
names = ['url-run-composed.test.ts', 'session-profile.ts', 'session-relay.ts', 'url-machine-peer.ts',
         'url-machine-store.ts', 'url-ordered-design-host.ts', 'url-ordered-design-session.ts',
         'url-ordered-design-writer.ts', 'url-session-audit.ts', 'url-run-ordered-attempt.ts',
         'url-ordered-design-bounds.ts', 'url-ordered-design-audit.ts']
sources = {}
hashes = {}
for name in names:
    data = subprocess.check_output(['git', 'show', SUBJECT + ':' + PREFIX + name], cwd=ROOT)
    sources[name] = data.decode()
    hashes[PREFIX + name] = hashlib.sha256(data).hexdigest()
    (OUT / (name + '.txt')).write_bytes(data)
def region(name, start, end):
    text = sources[name]
    begin = text.index(start)
    return text[begin:text.index(end, begin + len(start))]
fixture = region('url-run-composed.test.ts', "const design = scripted('design',", '\n    const events:')
tool_ids = re.findall(r"tool\('(design_[^']+)'", fixture)
assert tool_ids == ['design_poll', 'design_part_1', 'design_part_2', 'design_submit']
terminal = len(re.findall(r"\{ type: 'text', text: 'SYZYGY_DESIGN_TRANSFER_COMPLETE' \}", fixture))
assert terminal == 1
turns = ast.literal_eval(re.search(r'resultTurns: (\[[^\n]+\])', sources['session-profile.ts'])[1])
assert turns == ['prepared', 'part', 'part', 'verdict-acknowledgment']
assert "partCount !== 2" in sources['url-ordered-design-bounds.ts']
assert 'records.length > 13 + partCount * 5' in sources['url-ordered-design-audit.ts']
request_body = region('session-relay.ts', "incoming.on('end', () => { void (async () => {", '\n      } catch {')
direct_effects = len(re.findall(r'await effect\(', request_body))
audit_events = re.findall(r"await audit\(event\('(attempt-allowed|send-attempt|send-outcome|response-admitted)'", request_body)
assert direct_effects == 5
assert audit_events == ['attempt-allowed', 'send-attempt', 'send-outcome', 'response-admitted']
explicit_current = len(re.findall(r'await ports\.current\(\)', request_body))
assert explicit_current == 4
mediation = region('url-machine-peer.ts', 'export async function mediateUrlMachinePeer', '\nexport function closeUrlMachinePeer')
native_current_calls = len(re.findall(r'await current\(state(?:, true)?\)', mediation))
assert native_current_calls == 3
assert mediation.count('await preflight.prepare()') == 1 and mediation.count('!preflight.current()') == 1
commit = region('url-session-audit.ts', 'const commit = async ', '\n    async function commitRelay')
effect_checks = commit.count('await checkEffectCurrent(deadline)')
assert effect_checks == 5 and commit.count('if (checkEffectCurrent !== checkCurrent)') == 1
attempt = region('url-session-audit.ts', 'const checkAttemptCurrent = async ', '\n      const held:')
base_per_attempt = attempt.count('await checkCurrent(deadline)')
assert base_per_attempt == 2 and attempt.count("track('callback', attemptCurrent)") == 1
io = region('url-session-audit.ts', 'const io = async ', '\n    setupWallDeadline')
io_checks = io.count('await checkCurrent(deadline)')
assert io_checks == 2
writer_append = region('url-ordered-design-writer.ts', "const append: OrderedDesignAuditWriter['append']", '\n  const retire:')
durable = region('url-ordered-design-writer.ts', 'const durable = async ', "\n  const append: OrderedDesignAuditWriter['append']")
writer_current = writer_append.count('await current()') + durable.count('await current()')
assert writer_current == 2
requests = len(tool_ids) + terminal
per_request = direct_effects + len(audit_events)
ordered_records = (requests - 1) * 4 + 1 + turns.count('part') + 3 + 1
ordered_attempt_checks = writer_current + effect_checks
ordered_base_checks = base_per_attempt * ordered_attempt_checks + io_checks
assert ordered_records == 23 and ordered_attempt_checks == 7 and ordered_base_checks == 16
assert ordered_records == 13 + turns.count('part') * 5
per_request_steps = ['request-screening', 'provider-headers', 'attempt-allowed-audit', 'native-send',
                     'send-attempt-audit', 'send-outcome-audit', 'response-screening', 'response-admitted-audit', 'HTTP-response-write']
assert len(per_request_steps) == per_request
bindings = {'subject': SUBJECT, 'sourceSha256': hashes,
            'fixtureTools': tool_ids, 'terminalResponses': terminal, 'profileResultTurns': turns,
            'successfulMessagesRequests': requests, 'directEffectCallsPerRequest': direct_effects,
            'effectWrappedAuditCallsPerRequest': len(audit_events), 'auditEvents': audit_events,
            'inferenceMediationsPerRequest': per_request, 'inferenceMediationsTotal': requests * per_request,
            'explicitRelayCurrentCallsPerRequest': explicit_current,
            'nativeCurrentCallsPerMediation': native_current_calls,
            'preflightEnabledMediationsPerRequest': 6,
            'ordinaryBaseAppendCurrentChecks': io_checks + effect_checks - 1,
            'orderedAppendAttemptCurrentChecks': ordered_attempt_checks,
            'orderedAppendBaseCurrentChecks': ordered_base_checks,
            'orderedDurableRecordsSuccessPath': ordered_records,
            'orderedAppendAttemptCurrentChecksTotal': ordered_records * ordered_attempt_checks,
            'orderedAppendBaseCurrentChecksTotal': ordered_records * ordered_base_checks,
            'requestMap': [{'request': i + 1, 'scriptResponse': item, 'ordinals': [i*per_request+1, (i+1)*per_request],
                            'steps': [{'ordinal': i*per_request+j+1,'action': action} for j,action in enumerate(per_request_steps)]}
                           for i,item in enumerate(tool_ids + ['end_turn'])],
            'observedB5Accepted': 18, 'observedB5Pending': 19, 'remainingMediationsIncludingPending': requests*per_request-18,
            'observedB5CompletedBrokerInvocations': 2, 'remainingToolInvocations': len(tool_ids)-2,
            'scope': 'Successful fixed five-request transcript only. Failure/timer audit, unsupported retries/count-token requests, machine handshake/read, broker mediation, terminal consumption and closure are distinct; no whole-run full-authority census claimed.'}
(OUT / 'binding.json').write_text(json.dumps(bindings, indent=2, sort_keys=True)+'\n')
manifest = {f.name: {'bytes':f.stat().st_size, 'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
            for f in sorted(OUT.iterdir()) if f.is_file() and f.name != 'MANIFEST.json'}
(OUT / 'MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({key:bindings[key] for key in ['subject','successfulMessagesRequests','inferenceMediationsTotal','remainingMediationsIncludingPending','orderedDurableRecordsSuccessPath','orderedAppendAttemptCurrentChecks','orderedAppendBaseCurrentChecks']}))
