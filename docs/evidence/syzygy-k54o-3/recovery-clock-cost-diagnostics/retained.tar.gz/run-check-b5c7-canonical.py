import os,subprocess,time,json,tempfile
from pathlib import Path
root=Path('/home/orca/.tmp/f3-native-admission-fixes/native-coverage-merge-execution/w')
out=Path('/home/orca/.tmp/f3-native-admission-fixes/check-b5c7-canonical')
out.mkdir(exist_ok=False)
subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert subject=='b5c7bb12e9c1420566dfbf1b74dce0f3563cb3f8'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
cpus=sorted(os.sched_getaffinity(0))[:2]
affinity=','.join(map(str,cpus))
parallelism=int(subprocess.check_output(['taskset','-c',affinity,'node','-e','console.log(require("node:os").availableParallelism())'],text=True))
assert parallelism==len(cpus) and parallelism<=2
tmp=Path(tempfile.mkdtemp(prefix='f3-check-',dir='/home/orca/.tmp'))
env=os.environ.copy();env['TMPDIR']=str(tmp)
command=['taskset','-c',affinity,'npm','run','check']
(out/'subject.json').write_text(json.dumps({'subject':subject,'command':command,'availableParallelism':parallelism,'selection':'unfiltered npm run check; unchanged repository worker configuration','tmpdir':str(tmp)},indent=2)+'\n')
start=time.monotonic()
with (out/'check.log').open('wb') as log:
 p=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps({'pid':p.pid,'out':str(out),'subject':subject}),flush=True)
 code=p.wait()
result={'subject':subject,'exit':code,'elapsedSeconds':time.monotonic()-start,'clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=root))}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
raise SystemExit(code)
