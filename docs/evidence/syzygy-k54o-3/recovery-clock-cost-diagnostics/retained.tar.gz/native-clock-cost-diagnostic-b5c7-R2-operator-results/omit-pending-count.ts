const stages = (entries: readonly Phase[], maximum: number) => {
          const retained = entries.slice(0, maximum);
          const phases = new Map<Phase['phase'], { count: number; pending: number;
            refused: number; rejected: number; ms: number; maxMs: number }>();
          for (const { phase, timing } of retained) {
            let summary = phases.get(phase);
            if (summary === undefined) {
              summary = { count: 0, pending: 0, refused: 0, rejected: 0, ms: 0, maxMs: 0 };
              phases.set(phase, summary);
            }
            summary.count++;
            
            if (timing.outcome === 'refused') summary.refused++;
            if (timing.outcome === 'rejected') summary.rejected++;
            if (timing.settledMs !== undefined) {
              const elapsed = Math.max(0, timing.settledMs - timing.startedMs);
              summary.ms += elapsed;
              summary.maxMs = Math.max(summary.maxMs, elapsed);
            }
          }
          return { count: entries.length, retained: retained.length, omitted: entries.length - retained.length,
            phases: Object.fromEntries(phases) };
        };
const current = (value: Step['productPreparation']) => {
          if (value === undefined) return undefined;
          const latestLease = value.stages.slice(0, 64).filter(stage => stage.lease !== undefined).at(-1);
          return { startedMs: value.startedMs, settledMs: value.settledMs, outcome: value.outcome,
            lease: latestLease?.lease, leaseRemainingMs: latestLease?.leaseRemainingMs, stages: stages(value.stages, 64) };
        };
const append = (value: Append) => value === undefined ? undefined
          : { kind: value.kind, timing: { ...value.timing }, inclusiveDurationsMayOverlap: true,
            stages: stages(value.stages, 96),
            attemptCurrent: value.attemptCurrent === undefined ? undefined : {
              calls: value.attemptCurrent.calls, retained: value.attemptCurrent.entries.length,
              omitted: Math.max(0, value.attemptCurrent.calls - value.attemptCurrent.entries.length),
              projected: Math.min(1, value.attemptCurrent.entries.length),
              projectionOmitted: Math.max(0, value.attemptCurrent.entries.length - 1),
              latest: value.attemptCurrent.entries.slice(-1).map(current),
            } };