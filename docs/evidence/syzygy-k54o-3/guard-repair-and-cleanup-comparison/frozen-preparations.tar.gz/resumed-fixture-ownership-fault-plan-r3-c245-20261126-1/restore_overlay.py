#!/usr/bin/env python3
"""Prepared cleanup operator only. Restores a known temporary overlay in a disposable checkout after a terminal descendant-drain receipt."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
from guarded_restore import restore_known_source

HERE = Path(__file__).resolve().parent
PRIMARY = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w').resolve()
PREPARATION = Path('/home/orca/.tmp/f3-native-admission-fixes/resumed-fixture-ownership-preparation-c245-20261126-1')
RELATIVE = 'packages/polaris-dossier/src/url-run-composed.test.ts'
sha = lambda data: hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkout', required=True)
    parser.add_argument('--kind', required=True, choices=['original', 'candidate'])
    parser.add_argument('--terminal', required=True)
    args = parser.parse_args()
    checkout = Path(args.checkout).resolve(strict=True)
    if checkout == PRIMARY or PRIMARY in checkout.parents:
        raise SystemExit('Primary edits are forbidden by this cleanup operator.')
    terminal_path = Path(args.terminal).resolve(strict=True)
    terminal = json.loads(terminal_path.read_text())
    if terminal.get('noOwnedChildren') is not True:
        raise SystemExit('Preserve overlay/root: terminal receipt does not establish descendant drain.')
    if terminal.get('checkout') != str(checkout):
        raise SystemExit('Terminal receipt does not bind this disposable checkout.')
    bindings = json.loads((HERE / 'bindings.json').read_text())
    row = next(row for row in bindings['subjects'] if row['kind'] == args.kind)
    target = checkout / RELATIVE
    if target.resolve(strict=True) != target or checkout not in target.resolve(strict=True).parents:
        raise SystemExit('Source parents must stay inside the disposable checkout without symlink aliases.')
    if target.is_symlink() or not target.is_file():
        raise SystemExit('Target must be a regular source file.')
    current = target.read_bytes()
    original = (PREPARATION / args.kind / RELATIVE).read_bytes()
    if sha(original) != row['originalSha256']:
        raise SystemExit('Frozen restoration source drift.')
    if sha(current) not in [row['originalSha256'], row['overlaySha256']]:
        raise SystemExit('Unrelated source edit preserved; restoration refused.')
    if terminal.get('sourceSnapshotUnchanged') is not True:
        raise SystemExit('Clone freeze drift: retain overlay; restoration forbidden.')
    restored = restore_known_source(checkout,RELATIVE,original,(HERE / (args.kind + '-control.ts')).read_bytes(),
        stat.S_IMODE(target.lstat().st_mode),PRIMARY,terminal.get('sourceParentIdentity'),
        source_unchanged=terminal.get('sourceSnapshotUnchanged'),no_owned_children=terminal.get('noOwnedChildren'))
    if restored != row['originalSha256']:
        raise SystemExit('Restoration digest mismatch.')
    print(json.dumps({'restored': True, 'checkout': str(checkout), 'kind': args.kind, 'sha256': sha(original),
                      'terminalPath': str(terminal_path), 'terminalSha256': sha(terminal_path.read_bytes())}))

if __name__ == '__main__':
    main()
