"""Known-byte restoration through a pinned, checked disposable parent directory."""
import hashlib
import os
from pathlib import Path
import stat

def restore_known_source(checkout, relative, original, overlay, mode, primary, parent_identity, *, source_unchanged, no_owned_children):
    if source_unchanged is not True or no_owned_children is not True:
        raise RuntimeError('restore-requires-unchanged-clone-freeze-and-confirmed-drain')
    checkout = Path(checkout)
    primary = Path(primary).resolve(strict=True)
    target = checkout / relative
    def canonical_guard():
        if checkout.resolve(strict=True) != checkout or target.resolve(strict=True) != target:
            raise RuntimeError('restore-alias-refused')
        if checkout == primary or primary in checkout.parents or primary in target.parents or checkout not in target.parents:
            raise RuntimeError('restore-primary-or-containment-refused')
        if target.is_symlink() or not target.is_file():
            raise RuntimeError('restore-source-not-regular')
    canonical_guard()
    parent_fd = os.open(target.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    source_fd = None
    temporary = None
    try:
        parent = os.fstat(parent_fd)
        identity = {'dev':parent.st_dev,'ino':parent.st_ino,'uid':parent.st_uid}
        if identity != parent_identity or parent.st_uid != os.getuid():
            raise RuntimeError('restore-parent-identity-changed')
        if Path(os.readlink('/proc/self/fd/' + str(parent_fd))) != target.parent:
            raise RuntimeError('restore-open-parent-alias')
        source_fd = os.open(target.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
        source_stat = os.fstat(source_fd)
        if not stat.S_ISREG(source_stat.st_mode) or source_stat.st_uid != os.getuid() or source_stat.st_nlink != 1:
            raise RuntimeError('restore-source-identity-unsafe')
        chunks = []
        while True:
            chunk = os.read(source_fd, 65536)
            if not chunk: break
            chunks.append(chunk)
            if sum(map(len,chunks)) > max(len(original),len(overlay)):
                raise RuntimeError('restore-unrelated-source-size-preserved')
        current = b''.join(chunks)
        if current not in (original,overlay):
            raise RuntimeError('restore-unrelated-source-bytes-preserved')
        if current == original: return hashlib.sha256(original).hexdigest()
        temporary = '.restore-ownership-control-' + os.urandom(16).hex()
        fd = os.open(temporary,os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW,mode,dir_fd=parent_fd)
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),mode); stream.write(original); stream.flush(); os.fsync(stream.fileno())
        canonical_guard()
        named = os.stat(target.name,dir_fd=parent_fd,follow_symlinks=False)
        if (named.st_dev,named.st_ino,named.st_size,named.st_mtime_ns,named.st_ctime_ns) != (source_stat.st_dev,source_stat.st_ino,source_stat.st_size,source_stat.st_mtime_ns,source_stat.st_ctime_ns):
            raise RuntimeError('restore-source-changed-after-read')
        # Both names resolve relative to this held disposable parent descriptor;
        # even a concurrent path alias cannot redirect this write into primary.
        os.rename(temporary,target.name,src_dir_fd=parent_fd,dst_dir_fd=parent_fd)
        temporary = None
        os.fsync(parent_fd)
        canonical_guard()
        if target.read_bytes() != original:
            raise RuntimeError('restore-byte-verification-failed')
        return hashlib.sha256(original).hexdigest()
    finally:
        if temporary is not None:
            try: os.unlink(temporary,dir_fd=parent_fd)
            except FileNotFoundError: pass
        if source_fd is not None: os.close(source_fd)
        os.close(parent_fd)
