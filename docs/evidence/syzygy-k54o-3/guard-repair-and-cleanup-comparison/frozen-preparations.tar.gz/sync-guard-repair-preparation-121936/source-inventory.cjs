// Static syntax/hash inventory only. Does not load/execute any Syzygy module or guard.
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto');
const root='/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w';
const ts=require(path.join(root,'node_modules/typescript'));
const printer=ts.createPrinter({removeComments:true});
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const rels=['apps/three-surface-poc/src/sync-child-process-guard.test.ts','packages/polaris-dossier/src/policy-git-native.test.ts','packages/polaris-dossier/src/url-machine-peer.ts','packages/polaris-dossier/src/session-peer.ts','packages/polaris-dossier/src/acquisition-process.test.ts'];
const result=rels.map(rel=>{
 const text=fs.readFileSync(path.join(root,rel),'utf8'),source=ts.createSourceFile(rel,text,ts.ScriptTarget.Latest,true), calls=[];
 function visit(node){if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&['execFileSync','execSync','spawnSync'].includes(node.expression.text)){
  let owner=node.parent;while(owner&&!(ts.isCallExpression(owner)&&ts.isIdentifier(owner.expression)&&owner.expression.text==='it'))owner=owner.parent;
  calls.push({line:source.getLineAndCharacterOfPosition(node.getStart(source)).line+1,offset:node.getStart(source),fingerprint:hash(printer.printNode(ts.EmitHint.Expression,node,source)),owner:owner?.arguments[0]?.text,printed:printer.printNode(ts.EmitHint.Expression,node,source)});
 }ts.forEachChild(node,visit);}visit(source);
 return{path:rel,rawSha256:hash(text),sourceFingerprint:hash(printer.printNode(ts.EmitHint.Unspecified,source,source)),parseDiagnostics:source.parseDiagnostics.length,itCount:(text.match(/\bit\(/g)||[]).length,calls};
});
fs.writeFileSync(path.join(__dirname,'source-inventory.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.map(({path,rawSha256,sourceFingerprint,parseDiagnostics,itCount,calls})=>({path,rawSha256,sourceFingerprint,parseDiagnostics,itCount,calls:calls.map(({line,fingerprint,owner})=>({line,fingerprint,owner}))})),null,2));
