// Static syntax/hash census of the explicit native-owner list, not an import closure or guard run.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root='/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w',ts=require(path.join(root,'node_modules/typescript'));
const printer=ts.createPrinter({removeComments:true}),hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const guard=fs.readFileSync(path.join(__dirname,'before/apps/three-surface-poc/src/sync-child-process-guard.test.ts'),'utf8');
const table=guard.slice(guard.indexOf('const NATIVE_SITES ='),guard.indexOf('// This exact template'));
const rows=[];for(const m of table.matchAll(/\[(DOSSIER \+ '([^']+)'|PEER_MODULE|MACHINE_PEER_MODULE), new Map\(\[([\s\S]*?)\]\)\]/g)){
 const rel='packages/polaris-dossier/src/'+(m[2]??(m[1]==='PEER_MODULE'?'session-peer.ts':'url-machine-peer.ts'));
 const text=fs.readFileSync(path.join(root,rel),'utf8'),source=ts.createSourceFile(rel,text,ts.ScriptTarget.Latest,true),calls=[];
 function visit(n){if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&['execFileSync','execSync','spawnSync'].includes(n.expression.text))calls.push({line:source.getLineAndCharacterOfPosition(n.getStart(source)).line+1,fingerprint:hash(printer.printNode(ts.EmitHint.Expression,n,source))});ts.forEachChild(n,visit);}visit(source);
 const entries=[...m[3].matchAll(/\['([a-f0-9]{64})', '([^']*)'\]/g)].map(x=>({fingerprint:x[1],matchingCallCount:calls.filter(c=>c.fingerprint===x[1]).length}));
 rows.push({path:rel,rawSha256:hash(text),sourceFingerprint:hash(printer.printNode(ts.EmitHint.Unspecified,source,source)),entries});
}
fs.writeFileSync(path.join(__dirname,'native-binding-inventory.json'),JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify({ownerModules:rows.length,entries:rows.reduce((n,r)=>n+r.entries.length,0),nonUniqueOrMissingExactCalls:rows.flatMap(r=>r.entries.filter(e=>e.matchingCallCount!==1).map(e=>({path:r.path,...e})))},null,2));
