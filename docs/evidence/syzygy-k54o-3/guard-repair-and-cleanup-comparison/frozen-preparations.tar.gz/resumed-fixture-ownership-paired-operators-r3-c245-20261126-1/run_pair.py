#!/usr/bin/env python3
from operator_common import execute
if __name__ == '__main__':
    raise SystemExit(execute())
