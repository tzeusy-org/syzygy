"""Prepared paired diagnostic operator. Imports perform no commands. Root GO required."""
import argparse, ctypes, fcntl, hashlib, json, os, re, shutil, signal, stat, subprocess, tempfile, time
from pathlib import Path
from guarded_restore import restore_known_source
HERE = Path(__file__).resolve().parent
BASE = Path('/home/orca/.tmp/f3-native-admission-fixes')
PRIMARY = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
PREP = BASE / 'resumed-fixture-ownership-preparation-c245-20261126-1'
FAULT = BASE / 'resumed-fixture-ownership-fault-plan-r3-c245-20261126-1'
SUBJECT = 'c10acd305863a653593c23a1e0ad4d22448a2762'
CLONE_HEAD = SUBJECT
ANCESTOR = '77b0df3ac9833bacac8f56e82c7b136d92d9d447'
TEST = 'packages/polaris-dossier/src/url-run-composed.test.ts'
NODE = '/home/orca/.nvm/versions/node/v24.6.0/bin/node'
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
sha = lambda data: hashlib.sha256(data).hexdigest()
def git_at(root, *args):
    return subprocess.check_output(['git','-C',str(root),*args])

EXPECTED = {
    TEST: 'c88fc172ccfcd094e50b7f1e2d1118496745725b8d8e2411bef80b11e8777567',
    'packages/polaris-dossier/src/url-machine-peer.ts': '031ced551de6c59d9227a0de4e584a2c5cf0b9db2e472540aaf1994019e682bd',
    'packages/polaris-dossier/src/url-machine-peer.test.ts': 'bc7bd1fc28709d48e779feec0da35b0b459f4e3486c8a3f2dbfdc5577f113960',
    'packages/polaris-dossier/src/polaris.ts': '8a26c1cab1785cb0e71768cb0fe40b452c5cfe6bbcfb3a66f780f6f78a01110d',
    'packages/polaris-dossier/src/url-run-sessions.ts': '1116c471ca2de89b4daaf7e4f1dc7e40d79f4afc82cf4d02195796a7126700e8',
    'packages/polaris-dossier/src/url-supervisor-state.ts': '1cc0f3b8f8b2df6554d5373ab310398aa6e218369bd7d734a502e067b26e1c50',
    'packages/polaris-dossier/src/url-run-composed.testkit.ts': '748f848bdcf4f8a862266cd8ddfd8db1191ea20d470b0b0334f17b36e1f21fc9',
    'vitest.config.ts': 'a3b641bca9bfba4241a482443c7594e59959e395fffce8ed9c9cfcac6860ce10',
    'vitest.setup.ts': 'ff6204123fefeb3ffd874f7451edaa037a9924e742a401b0cd526d3d3a4f2b85',
}

def require(ok, reason):
    if not ok: raise RuntimeError(reason)

def checkpoint(out, name, value):
    temporary = out / (name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temporary, out / name)

class Interrupted(Exception): pass

def interrupt(sig, frame): raise Interrupted(str(sig))

def drain(child, reaped):
    if child is not None:
        if child.poll() is None:
            try: os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError: pass
            try: child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                if child.poll() is None:
                    try: os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                child.wait(timeout=5)
        else: child.wait()
    deadline = time.monotonic() + 10; sent = {}
    while True:
        try: pid, status_ = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError: return True
        if pid:
            reaped.append({'pid': pid, 'status': status_}); continue
        # These are unreaped children of this operator/subreaper; reserved PIDs
        # are checked with waitpid again before any signal is sent.
        for raw in Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text().split():
            pid = int(raw)
            try: got, status_ = os.waitpid(pid, os.WNOHANG)
            except ChildProcessError: continue
            if got: reaped.append({'pid': got, 'status': status_}); continue
            now = time.monotonic()
            try:
                if pid not in sent: os.kill(pid, signal.SIGTERM); sent[pid] = now
                elif now - sent[pid] >= .25: os.kill(pid, signal.SIGKILL)
            except ProcessLookupError: pass
        require(time.monotonic() < deadline, 'owned-descendant-drain-deadline')
        time.sleep(.01)

def snapshot_at(root):
    require(root.resolve(strict=True) == root,'source-root-alias-refused')
    paths = sorted(set(git_at(root, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').split(b'\0')) - {b''})
    rows = []
    for raw in paths:
        name = os.fsdecode(raw); p = root / name
        require(p.parent.resolve(strict=True) == p.parent and root in p.parents,'source-parent-alias-refused:' + name)
        try:
            first = p.lstat()
        except FileNotFoundError:
            rows.append({'path': name, 'state': 'missing'}); continue
        if stat.S_ISLNK(first.st_mode):
            data = os.fsencode(os.readlink(p)); kind = 'symlink'
        elif stat.S_ISREG(first.st_mode):
            data = p.read_bytes(); kind = 'file'
        else:
            raise RuntimeError('unexpected-source-kind:' + name)
        second = p.lstat()
        require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns, first.st_ctime_ns) ==
                (second.st_dev, second.st_ino, second.st_size, second.st_mtime_ns, second.st_ctime_ns), 'source-changed-during-snapshot:' + name)
        rows.append({'path': name, 'state': kind, 'mode': stat.S_IMODE(second.st_mode), 'bytes': len(data), 'sha256': sha(data)})
    return {'head': git_at(root, 'rev-parse', 'HEAD').decode().strip(),
            'status': git_at(root, 'status', '--porcelain=v1', '-z', '--untracked-files=all').decode(),
            'population': len(rows), 'rows': rows,
            'rowsSha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}

def secure_metadata(file, limit=262144):
    fd = os.open(file, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        first = os.fstat(fd)
        require(stat.S_ISREG(first.st_mode) and first.st_uid == os.getuid() and stat.S_IMODE(first.st_mode) == 0o600 and first.st_nlink == 1 and first.st_size <= limit, 'unsafe-metadata:' + str(file))
        data = os.read(fd, limit + 1)
        require(len(data) <= limit, 'metadata-limit')
        return data
    finally: os.close(fd)

def atomic_metadata(file, value):
    temporary = file.with_suffix(file.suffix + '.tmp')
    data = (json.dumps(value, indent=2) + '\n').encode()
    fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, file)

class Observer:
    """Read only named metadata and lstat directories; never read fixture bodies."""
    EVENTS = {'runtime-acquired','runtime-probe','runtime-stop-settled','cli-settled','body-catch-enter','parent-released','parent-expired','body-catch-probe','body-finally','fixture-close-enter','fixture-close-error','after-each-cleanup-rethrow','fixture-close-return','cleanup-fulfilled','cleanup-rejected','root-delete-enter','root-delete-return'}
    def __init__(self, control, out, arm, nonce):
        self.control, self.out, self.arm, self.nonce = control, out, arm, nonce
        self.identity = None; self.pid = None; self.inodes = {}; self.events = []; self.samples = []; self.capture = None; self.seen_events = 0

    def packet(self, row, state=False):
        require(isinstance(row,dict) and row.get('nonce') == self.nonce and row.get('arm') == self.arm, 'metadata-arm-or-nonce')
        require(isinstance(row.get('pid'),int) and row['pid'] > 0, 'metadata-pid')
        if self.pid is None: self.pid = row['pid']
        require(row['pid'] == self.pid, 'metadata-worker-changed')
        names = ['fixtureRoot','hidden','recoveryRoot']
        require(all(isinstance(row.get(k),str) for k in names), 'missing-fixture-identity')
        identity = {k:row[k] for k in names}
        fixture = Path(identity['fixtureRoot']); recovery = Path(identity['recoveryRoot']); hidden = Path(identity['hidden'])
        require(fixture.parent == Path('/home/orca/.tmp') and re.fullmatch(r'url-composed-[A-Za-z0-9]{6}',fixture.name) is not None, 'fixture-path-prefix')
        require(recovery.parent == Path('/home/orca/.tmp') and re.fullmatch(r'url-composed-host-' + str(self.pid) + r'-[0-9]+',recovery.name) is not None, 'recovery-path-prefix')
        require(hidden.parent == recovery/'acquisitions' and re.fullmatch(r'attempt-[A-Za-z0-9]{6}',hidden.name) is not None, 'hidden-path-prefix')
        require(all(str(Path(value)) == value and '..' not in Path(value).parts for value in identity.values()), 'noncanonical-fixture-path')
        if self.identity is None: self.identity = identity
        require(identity == self.identity, 'different-fixture-identity')
        if not state: require(row.get('event') in self.EVENTS, 'unknown-control-event')
        return row

    def stat_paths(self, phase):
        require(self.identity is not None, 'stat-before-identity')
        observation = {'phase':phase,'observedEpoch':time.time(),'observedMonotonic':time.monotonic(),'paths':{}}
        for name, value in self.identity.items():
            p = Path(value)
            try:
                st = p.lstat()
                require(stat.S_ISDIR(st.st_mode) and not stat.S_ISLNK(st.st_mode) and st.st_uid == os.getuid() and p.resolve(strict=True) == p, 'unsafe-owned-directory:' + value)
                identity = (st.st_dev,st.st_ino,st.st_uid)
                if name in self.inodes: require(self.inodes[name] == identity,'owned-path-replaced:' + value)
                else: self.inodes[name] = identity
                observation['paths'][name] = {'exists':True,'dev':st.st_dev,'ino':st.st_ino,'uid':st.st_uid,'mode':stat.S_IMODE(st.st_mode)}
            except FileNotFoundError: observation['paths'][name] = {'exists':False}
        self.samples.append(observation)
        return observation

    def poll(self):
        raw = secure_metadata(self.control/'events.jsonl')
        lines = raw.splitlines(keepends=True)
        complete = [line for line in lines if line.endswith(b'\n')]
        rows = [self.packet(json.loads(line)) for line in complete]
        require(rows[:len(self.events)] == self.events, 'control-event-history-changed')
        for row in rows[len(self.events):]:
            self.events.append(row)
            if row['event'] in {'runtime-acquired','fixture-close-return','cleanup-fulfilled','cleanup-rejected','root-delete-return'}:
                self.stat_paths('after-' + row['event'])
        try: pending_raw = secure_metadata(self.control/'catch-state.json',16384)
        except FileNotFoundError: return
        pending = self.packet(json.loads(pending_raw),True)
        if pending.get('event') != 'catch-pending' or self.capture is not None: return
        # In the negative arm let the actual early cleanup reach its own
        # settlement (or reported error) during the same bounded body hold.
        # Candidate cleanup must remain pending until we release the body.
        if self.arm == 'original' and not any(row['event'] in {'cleanup-fulfilled','cleanup-rejected'} for row in self.events): return
        require(pending.get('bodySettled') is False and pending.get('cliSettled') is True and pending.get('runtimeSettled') is True, 'catch-not-real-settled-runtime-cli')
        deadline = pending.get('deadlineEpochMs')
        require(isinstance(deadline,(int,float)),'missing-handshake-deadline')
        # No release exists before our stat capture. A later matching source
        # released packet establishes that it did not resume by expiration.
        require(not (self.control/'release.json').exists(),'release-preexists-parent-capture')
        if time.time()*1000 >= deadline - 100: return
        capture = {'arm':self.arm,'nonce':self.nonce,'captureId':os.urandom(24).hex(),'pendingSha256':sha(pending_raw),'pending':pending,'pendingObservedMonotonic':time.monotonic(),'independentLstat':self.stat_paths('catch-blocked-before-parent-release')}
        require(secure_metadata(self.control/'catch-state.json',16384) == pending_raw,'catch-state-changed-during-parent-capture')
        capture['capturedEpoch'] = time.time()
        if capture['capturedEpoch']*1000 >= deadline - 50: return
        atomic_metadata(self.out/'parent-catch-capture.json',capture)
        release = {k:capture[k] for k in ['arm','nonce','captureId']}; release.update(self.identity)
        atomic_metadata(self.control/'release.json',release)
        capture['releaseWrittenEpoch'] = time.time()
        capture['releaseWrittenMonotonic'] = time.monotonic()
        capture['releaseCompletedBeforeEpochDeadline'] = capture['releaseWrittenEpoch']*1000 < deadline
        capture['parentMonotonicElapsedMs'] = (capture['releaseWrittenMonotonic'] - capture['pendingObservedMonotonic'])*1000
        atomic_metadata(self.out/'parent-catch-capture-final.json',capture)
        self.capture = capture

    def finish(self):
        self.poll()
        self.stat_paths('terminal-after-owned-descendant-drain') if self.identity else None
        checkpoint(self.out,'parent-observations.json',{'identity':self.identity,'pid':self.pid,'capture':self.capture,'events':self.events,'lstatSamples':self.samples})
        for name in ['events.jsonl','catch-state.json','release.json']:
            p = self.control/name
            if p.exists(): (self.out/('child-' + name)).write_bytes(secure_metadata(p))

def correlate_error_audit(out, arm, observer, checkout, selected):
    audit = json.loads(secure_metadata(out/'all-errors.json',8_388_608))
    require(audit.get('version') == 1 and audit.get('files') == [str(checkout/TEST)],'wrong-complete-error-audit-file')
    require(audit.get('globalErrors') == [],'unhandled-errors-in-complete-audit')
    records = audit.get('records'); require(isinstance(records,list),'missing-complete-error-records')
    tests = [r for r in records if r.get('taskType') == 'test']
    expected = json.loads((HERE/'expected-cases.json').read_text())['allNames']
    require(len(tests) == 7 and sorted(r.get('fullName') for r in tests) == sorted(expected),'wrong-complete-error-audit-population')
    events = observer.events
    names = ['fixture-close-error','cleanup-rejected','after-each-cleanup-rethrow']
    chain = {name:[(i,r) for i,r in enumerate(events) if r['event'] == name] for name in names}
    allowed = None
    if any(chain.values()):
        require(arm == 'original' and all(len(chain[name]) == 1 for name in names),'incomplete-or-candidate-cleanup-error-chain')
        indices = [chain[name][0][0] for name in names]
        require(indices == sorted(indices),'cleanup-error-phase-order')
        allowed = chain[names[0]][0][1].get('cleanupError')
        require(isinstance(allowed,dict) and allowed.get('errorId') == observer.nonce + '-fixture-close' and allowed.get('phase') == 'fixture-close','wrong-actual-cleanup-error-identity')
        require(allowed.get('truncated') is False and allowed.get('code') in ['ENOENT','ENOTEMPTY'] and allowed.get('syscall') in ['rmdir','scandir','readdir','lstat','stat','unlink','open'],'unclassified-actual-cleanup-error')
        error_path = allowed.get('path')
        require(isinstance(error_path,str) and any(error_path == root or error_path.startswith(root + '/') for root in observer.identity.values()),'cleanup-error-path-not-owned-fixture')
        require(isinstance(allowed.get('stack'),str) and bool(allowed['stack']) and isinstance(allowed.get('message'),str) and bool(allowed['message']),'missing-actual-cleanup-stack-or-message')
        for name in names[1:]:
            packet = chain[name][0][1]
            require(packet.get('phase') == 'fixture-close' and packet.get('cleanupError') == allowed,'cleanup-rejection-or-afterEach-not-the-actual-error')
        forbidden = {'fixture-close-return','cleanup-fulfilled'}
        require(not any(r['event'] in forbidden for r in events),'cleanup-error-after-successful-close')
        finally_indices = [i for i,r in enumerate(events) if r['event'] == 'body-finally']
        require(len(finally_indices) == 1 and chain['after-each-cleanup-rethrow'][0][0] > finally_indices[0],'cleanup-hook-rethrow-before-body-settlement')
    matched = 0; selected_body_errors = []
    for record in records:
        require(record.get('filepath') == str(checkout/TEST),'foreign-file-in-complete-error-audit')
        errors = record.get('errors'); require(isinstance(errors,list),'missing-task-error-list')
        for error in errors:
            marker = error.get('ownershipFaultCleanupErrorId')
            if marker is not None:
                require(allowed is not None and marker == allowed['errorId'],'unmatched-cleanup-error-token')
                require(all(error.get(k) == allowed.get(k) for k in ['name','message','stack','code','path','syscall']),'cleanup-hook-stack-or-operation-does-not-match-actual-rejection')
                matched += 1
            else:
                require(record.get('taskType') == 'test' and record.get('fullName') == selected,'additional-unmatched-hook-suite-or-test-error')
                selected_body_errors.append(error)
    require(len(selected_body_errors) == 1,'expected-exactly-one-original-body-diagnostic-failure')
    if allowed is not None: require(matched >= 1,'actual-cleanup-rejection-not-observable-in-Vitest-errors')
    return {'allowedOriginalCleanupError':allowed,'matchedSerializedOccurrences':matched,'selectedBodyErrorCount':len(selected_body_errors),'allOtherErrorsRejected':True}

def classify(out, arm, rc, observer, checkout):
    d = json.loads((out/'vitest.json').read_text())
    expected = json.loads((HERE/'expected-cases.json').read_text())['allNames']
    selected = 'composed URL run with actual role processes runs the genuine production pipeline to stop-resume'
    files = d.get('testResults',[])
    require(len(files) == 1 and Path(files[0]['name']).resolve() == (checkout/TEST).resolve(),'wrong-control-file-population')
    assertions = files[0].get('assertionResults',[])
    require(len(assertions) == 7 and sorted(a.get('fullName') for a in assertions) == sorted(expected),'wrong-control-seven-name-population')
    require(rc == 1 and d.get('success') is False,'intentional-diagnostic-must-remain-failed')
    require(d.get('numTotalTests') == 7 and d.get('numFailedTests') == 1 and d.get('numPassedTests') == 0 and d.get('numPendingTests') == 6 and d.get('numTodoTests') == 0,'not-one-failure-six-selection-skips')
    for a in assertions:
        require(a.get('status') == ('failed' if a.get('fullName') == selected else 'skipped'),'wrong-selected-failure')
        require(bool(a.get('failureMessages')) if a.get('fullName') == selected else not a.get('failureMessages'),'missing-selected-or-unexpected-skip-failure')
    log = ANSI.sub('',(out/'vitest.log').read_text(errors='replace'))
    forbidden = r'unhandled(?:\s+(?:rejection|exception|errors?))|onFinished[^\n]*(?:error|reject)|(?:error|reject)[^\n]*onFinished|hook timed out|test timed out|SyntaxError|ReferenceError|TypeError|RangeError'
    require(re.search(forbidden,log,re.I) is None,'unrelated-runtime-hook-timeout-or-load-error')
    for key,value in d.items():
        if re.search(r'(?:unhandled|runtimeerror|onfinished|errors?$)',key,re.I): require(not value,'structured-runtime-error')
    error_correlation = correlate_error_audit(out,arm,observer,checkout,selected)
    hook_message = files[0].get('message','')
    if hook_message:
        allowed = error_correlation['allowedOriginalCleanupError']
        require(allowed is not None and hook_message == allowed['message'],'unmatched-file-hook-or-load-error-message')
    if re.search(r'(?:beforeAll|afterAll|beforeEach|afterEach) hook',log,re.I):
        require(error_correlation['allowedOriginalCleanupError'] is not None,'unclassified-hook-error-in-log')
    require(observer.capture is not None,'no-independent-parent-stat-handshake')
    rows = observer.events
    by = {}
    for index,row in enumerate(rows):
        require(row['event'] not in by,'duplicate-control-marker:' + row['event'])
        by[row['event']] = (index,row)
    common = ['runtime-acquired','runtime-probe','runtime-stop-settled','cli-settled','body-catch-enter','parent-released','body-catch-probe','body-finally','fixture-close-enter','root-delete-enter','root-delete-return']
    require(all(k in by for k in common),'missing-control-boundary-marker')
    require('parent-expired' not in by,'late-or-missing-parent-ack-inconclusive')
    capture = observer.capture
    require(by['parent-released'][1].get('captureId') == capture['captureId'] and by['body-catch-probe'][1].get('parentHandshake') == 'released','body-did-not-ack-this-parent-stat')
    require(capture.get('releaseCompletedBeforeEpochDeadline') is True and 0 <= capture.get('parentMonotonicElapsedMs',5000) < 5000,'parent-release-write-completed-late')
    release_packet = by['parent-released'][1]
    require(release_packet.get('maxPauseMs') == 5000 and isinstance(release_packet.get('elapsedMs'),(int,float)) and 0 <= release_packet['elapsedMs'] < 5000,'source-release-acknowledged-after-monotonic-bound')
    order = ['runtime-acquired','runtime-probe','runtime-stop-settled','cli-settled','body-catch-enter','parent-released','body-catch-probe','body-finally']
    require([by[k][0] for k in order] == sorted(by[k][0] for k in order),'wrong-runtime-cli-body-order')
    require(by['fixture-close-enter'][1].get('bodySettled') is (arm == 'candidate'),'wrong-fixture-body-order')
    if arm == 'candidate':
        tail = ['body-finally','fixture-close-enter','fixture-close-return','cleanup-fulfilled','root-delete-enter','root-delete-return']
        require(all(k in by for k in tail) and [by[k][0] for k in tail] == sorted(by[k][0] for k in tail),'candidate-disposal-not-after-actual-body-and-cleanup')
        require('cleanup-rejected' not in by and not hook_message,'candidate-cleanup-failed')
        require(by['body-catch-probe'][1].get('current') is True and by['body-catch-probe'][1].get('fixturePresent') is True,'candidate-fixture-withdrawn-during-body')
        require(all(row['exists'] for row in capture['independentLstat']['paths'].values()),'candidate-independent-capture-not-live')
        require(by['fixture-close-return'][1].get('current') is False and by['fixture-close-return'][1].get('fixturePresent') is False,'candidate-fixture-not-actually-removed')
        final = observer.samples[-1]['paths']
        require(all(not row['exists'] for row in final.values()),'candidate-fixture-or-root-remains-after-cleanup')
    else:
        require(by['fixture-close-enter'][0] < by['body-finally'][0] and by['body-catch-probe'][1].get('current') is False,'original-deletion-race-not-established')
        require(not capture['independentLstat']['paths']['hidden']['exists'] or not capture['independentLstat']['paths']['fixtureRoot']['exists'],'original-independent-file-withdrawal-not-established')
    return {'nativeTestOutcome':'FAILED_INTENTIONAL_DIAGNOSTIC','total':7,'failed':1,'passed':0,'selectionSkipped':6,'orderingAssessment':'observed-original-race' if arm == 'original' else 'observed-candidate-join-before-disposal','errorCorrelation':error_correlation,'genuineAcceptance':False,'actualHookTimeoutTested':False}

def execute():
    parser = argparse.ArgumentParser(description='Prepared serialized paired native diagnostic; root GO required. No native test can PASS this operator.')
    parser.add_argument('--output',required=True)
    parser.add_argument('--subject',default=SUBJECT,help='Explicit frozen primary HEAD descending from 77b0; disposable clones stay pinned c10acd.')
    args = parser.parse_args(); out = Path(args.output).resolve()
    require(out.parent == BASE and out.name.startswith('resumed-fixture-paired-r3-execution-') and not out.exists(),'new-outside-output-required')
    out.mkdir()
    receipt = {'mode':'paired-intentional-diagnostic','primaryHead':args.subject,'cloneHead':CLONE_HEAD,'commands':[],'arms':[],'reaped':[],'errors':[],'complete':False,'genuineAcceptance':False,'actualHookTimeoutTested':False}
    lock = None; child = None; scratch = None; primary_before = None; handlers = {}; env = None
    overlay_rows = None
    def run(label,command,cwd,environment,watchdog,observer=None):
        nonlocal child
        record = {'label':label,'argv':command,'cwd':str(cwd),'operatorWatchdogSeconds':watchdog,'watchdogMeans':'failure-and-owned-descendant-drain-only'}
        receipt['commands'].append(record); began = time.monotonic()
        log_path = out/(label + '.log') if observer is None else observer.out/'vitest.log'
        with log_path.open('xb') as log:
            child = subprocess.Popen(command,cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:
                while child.poll() is None:
                    if observer: observer.poll()
                    if time.monotonic() - began > watchdog:
                        record['timedOut'] = True
                        raise RuntimeError(label + '-operator-watchdog-not-test-success')
                    time.sleep(.02 if observer else .1)
                record['returncode'] = child.wait()
                if observer: observer.poll()
            finally: record['seconds'] = time.monotonic() - began
        require(drain(child,receipt['reaped']),'between-command-descendant-drain'); child = None
        return record['returncode']
    try:
        lock = open(BASE/'resumed-fixture-ownership.operator.lock','a+b'); fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest = json.loads((HERE/'manifest.json').read_text())
        for entry in manifest['payloads']:
            p = Path(entry['path']); data = p.read_bytes()
            require(sha(data) == entry['sha256'] and len(data) == entry['bytes'],'operator-or-overlay-payload-drift:' + str(p))
        receipt['manifestSha256'] = sha((HERE/'manifest.json').read_bytes())
        require(git_at(PRIMARY,'rev-parse','HEAD').decode().strip() == args.subject,'explicit-primary-head-mismatch')
        subprocess.run(['git','-C',str(PRIMARY),'merge-base','--is-ancestor',ANCESTOR,args.subject],check=True)
        require(not git_at(PRIMARY,'diff','--cached','--name-only'),'primary-index-not-clean')
        changed = set(git_at(PRIMARY,'diff','--name-only','-z').split(b'\0')) - {b''}
        require(changed in (set(),{TEST.encode()}),'only-c88-primary-delta-authorized')
        require(not git_at(PRIMARY,'ls-files','--others','--exclude-standard','-z'),'primary-untracked-source')
        require('NODE_OPTIONS' not in os.environ,'inherited-node-options-not-authorized')
        require('SYZYGY_COMPOSED_RETAIN' not in os.environ,'inherited-retention-mode')
        for key in ['SYZYGY_OWNERSHIP_FAULT','SYZYGY_OWNERSHIP_CONTROL_DIR','SYZYGY_OWNERSHIP_CONTROL_NONCE','SYZYGY_OWNERSHIP_CONTROL_ARM','SYZYGY_OWNERSHIP_ERROR_AUDIT']:
            require(key not in os.environ,'inherited-control-environment:' + key)
        for name,expected in EXPECTED.items():
            require(sha((PRIMARY/name).read_bytes()) == expected,'primary-source-binding:' + name)
            require(subprocess.check_output(['sha256sum',str(PRIMARY/name)]).decode().split()[0] == expected,'independent-primary-binding:' + name)
        positive = json.loads((BASE/'resumed-fixture-observer-r2-execution-1/terminal.json').read_text())
        require(sha((BASE/'resumed-fixture-observer-r2-execution-1/terminal.json').read_bytes()) == 'd91ca4836c611d774eba64cfe52e04835d84e237cef8eb6934c313487658c484','exact-positive-TC-observer-receipt')
        require(positive.get('complete') is True and positive.get('typecheckPassed') is True and positive.get('denominator') == {'total':7,'passed':3,'failed':0,'selectionSkipped':4,'todo':0},'positive-c88-TC-observer-prerequisite')
        primary_before = snapshot_at(PRIMARY); checkpoint(out,'primary-before.json',primary_before)
        overlay_rows = json.loads((FAULT/'bindings.json').read_text())['subjects']
        libc = ctypes.CDLL(None,use_errno=True)
        if libc.prctl(36,1,0,0,0): raise OSError(ctypes.get_errno(),'subreaper')
        receipt['subreaper'] = True
        scratch = Path(tempfile.mkdtemp(prefix='resumed-fixture-paired-r3-',dir='/home/orca/.tmp')); os.chmod(scratch,0o700)
        receipt['privateScratch'] = str(scratch)
        require(stat.S_IMODE(scratch.stat().st_mode) == 0o700,'private-scratch-mode')
        env = dict(os.environ); env['PATH'] = str(Path(NODE).parent) + os.pathsep + env.get('PATH','')
        handlers = {sig:signal.signal(sig,interrupt) for sig in (signal.SIGINT,signal.SIGTERM)}
        for kind in ['original','candidate']:
            arm = {'kind':kind,'errors':[],'complete':False}; receipt['arms'].append(arm)
            checkout = scratch/(kind + '-checkout'); arm_out = out/kind; arm_out.mkdir()
            control = scratch/(kind + '-control'); control.mkdir(mode=0o700)
            private_tmp = scratch/(kind + '-tmp'); private_tmp.mkdir(mode=0o700)
            nonce = os.urandom(24).hex(); arm['nonce'] = nonce; arm['checkout'] = str(checkout); arm['controlDirectory'] = str(control)
            fd = os.open(control/'events.jsonl',os.O_CREAT | os.O_EXCL | os.O_WRONLY,0o600); os.close(fd)
            arm_env = dict(env); arm_env.update(TMPDIR=str(private_tmp),TMP=str(private_tmp),TEMP=str(private_tmp))
            clone_before = None; observer = None; target = None; original = None; overlay = None; restore_mode = None
            try:
                require(snapshot_at(PRIMARY) == primary_before,'primary-source-drift-before-arm')
                require(run(kind + '-clone',['git','clone','--no-hardlinks','--no-checkout','--quiet',str(PRIMARY),str(checkout)],BASE,arm_env,120) == 0,'disposable-clone-failed')
                require(run(kind + '-checkout',['git','-C',str(checkout),'checkout','--detach','--quiet',CLONE_HEAD],BASE,arm_env,60) == 0,'fixed-c10-checkout-failed')
                require(git_at(checkout,'rev-parse','HEAD').decode().strip() == CLONE_HEAD,'clone-head-drift')
                row = next(row for row in overlay_rows if row['kind'] == kind)
                original = (PREP/kind/TEST).read_bytes(); overlay = Path(row['overlayPath']).read_bytes()
                require(sha(original) == row['originalSha256'] and sha(overlay) == row['overlaySha256'],'arm-source-or-overlay-drift')
                for name,expected in EXPECTED.items():
                    if name != TEST: require(sha((checkout/name).read_bytes()) == expected,'fixed-clone-dependency-drift:' + name)
                require(sha((checkout/TEST).read_bytes()) == 'bf6c2da5785db51ef61cbbd6fc58ac592fd03fd8031336bb69e5f83a4d1e1e82','c10-original-test-not-frozen-baseline')
                clean_before = snapshot_at(checkout); checkpoint(arm_out,'clone-c10-before.json',clean_before)
                require(run(kind + '-npm-ci',['npm','ci'],checkout,arm_env,600) == 0,'own-clone-npm-ci-failed')
                require(snapshot_at(checkout) == clean_before,'npm-ci-source-drift')
                workspace_links = checkout/'node_modules/@syzygy'
                require(workspace_links.is_dir(),'missing-own-workspace-install')
                for link in workspace_links.iterdir():
                    require(checkout in link.resolve(strict=True).parents,'workspace-package-escaped-disposable-clone:' + link.name)
                target = checkout/TEST; restore_mode = stat.S_IMODE(target.stat().st_mode)
                parent = target.parent.lstat()
                arm['sourceParentIdentity'] = {'dev':parent.st_dev,'ino':parent.st_ino,'uid':parent.st_uid}
                baseline = target.read_bytes()
                # The same pinned-parent guard protects installation and restore.
                restore_known_source(checkout,TEST,overlay,baseline,restore_mode,PRIMARY,arm['sourceParentIdentity'],
                    source_unchanged=snapshot_at(checkout) == clean_before,no_owned_children=True)
                arm['overlayInstallGuarded'] = True
                require(sha(target.read_bytes()) == row['overlaySha256'],'overlay-install-mismatch')
                clone_before = snapshot_at(checkout); checkpoint(arm_out,'clone-overlay-before.json',clone_before)
                arm['overlaySha256'] = row['overlaySha256']; arm['restorationSha256'] = row['originalSha256']
                require(run(kind + '-overlay-typecheck',['npm','run','typecheck'],checkout,arm_env,300) == 0,'overlay-must-positive-typecheck-before-native')
                arm['overlayTypecheckPassed'] = True
                native_env = dict(arm_env); native_env.update(SYZYGY_OWNERSHIP_FAULT='1',SYZYGY_OWNERSHIP_CONTROL_DIR=str(control),SYZYGY_OWNERSHIP_CONTROL_NONCE=nonce,SYZYGY_OWNERSHIP_CONTROL_ARM=kind,SYZYGY_OWNERSHIP_ERROR_AUDIT=str(arm_out/'all-errors.json'))
                observer = Observer(control,arm_out,kind,nonce)
                selected = '^' + re.escape('composed URL run with actual role processes runs the genuine production pipeline to stop-resume') + '$'
                command = [NODE,'node_modules/vitest/vitest.mjs','run','--project','integration',TEST,'--testNamePattern',selected,'--reporter=verbose','--reporter=json','--reporter',str(HERE/'all-errors-reporter.mjs'),'--outputFile',str(arm_out/'vitest.json')]
                # External fail-only guard exceeds the original 600s case + 60s
                # beforeAll + 30s afterEach + 30s afterAll. No test/worker/heap
                # setting is overridden, and a guard expiration is never success.
                rc = run(kind + '-native-diagnostic',command,checkout,native_env,900,observer)
                observer.finish()
                observed_events = {row['event']:index for index,row in enumerate(observer.events)}
                arm['retainedOrderingFacts'] = {
                    'fixtureCloseEnteredBeforeBodyFinally': None if 'fixture-close-enter' not in observed_events or 'body-finally' not in observed_events else observed_events['fixture-close-enter'] < observed_events['body-finally'],
                    'hasBodyFinally': 'body-finally' in observed_events,
                    'hasFixtureCloseEntry': 'fixture-close-enter' in observed_events,
                    'parentCaptureId': None if observer.capture is None else observer.capture['captureId'],
                    'comparisonMayStillBeInconclusive': True,
                }
                arm['diagnostic'] = classify(arm_out,kind,rc,observer,checkout)
                arm['checksPassed'] = True
            except BaseException as failure:
                arm['errors'].append({'phase':'operation','type':type(failure).__name__,'message':str(failure)})
            finally:
                mask = signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
                try:
                    try: arm['noOwnedChildren'] = drain(child,receipt['reaped']); child = None
                    except BaseException as failure: arm['errors'].append({'phase':'drain','type':type(failure).__name__,'message':str(failure)})
                    if observer:
                        try: observer.finish(); arm['ownedFixtureIdentity'] = observer.identity
                        except BaseException as failure: arm['errors'].append({'phase':'observer-final','type':type(failure).__name__,'message':str(failure)})
                    if clone_before is not None:
                        try:
                            after = snapshot_at(checkout); checkpoint(arm_out,'clone-overlay-after.json',after)
                            arm['sourceSnapshotUnchanged'] = after == clone_before
                            require(after == clone_before,'clone-source-or-status-drift')
                        except BaseException as failure: arm['errors'].append({'phase':'clone-freeze','type':type(failure).__name__,'message':str(failure)})
                    if target is not None and original is not None:
                        try:
                            restore_known_source(checkout,TEST,original,overlay,restore_mode,PRIMARY,arm['sourceParentIdentity'],
                                source_unchanged=arm.get('sourceSnapshotUnchanged'),no_owned_children=arm.get('noOwnedChildren'))
                            arm['overlayRestored'] = True
                            checkpoint(arm_out,'clone-restored.json',snapshot_at(checkout))
                        except BaseException as failure: arm['errors'].append({'phase':'restore','type':type(failure).__name__,'message':str(failure)})
                    arm['complete'] = bool(arm.get('checksPassed') and not arm['errors'] and arm.get('noOwnedChildren') and arm.get('sourceSnapshotUnchanged') and arm.get('overlayRestored'))
                    checkpoint(arm_out,'terminal.json',arm)
                finally: signal.pthread_sigmask(signal.SIG_SETMASK,mask)
            require(arm['complete'],'paired-arm-incomplete:' + kind)
            require(snapshot_at(PRIMARY) == primary_before,'primary-source-drift-between-arms')
        receipt['comparisonObserved'] = True
    except BaseException as failure:
        receipt['errors'].append({'phase':'operation','type':type(failure).__name__,'message':str(failure)})
    finally:
        mask = signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
        try:
            try: receipt['noOwnedChildren'] = drain(child,receipt['reaped']); child = None
            except BaseException as failure: receipt['errors'].append({'phase':'final-drain','type':type(failure).__name__,'message':str(failure)})
            if primary_before is not None:
                try:
                    primary_after = snapshot_at(PRIMARY); checkpoint(out,'primary-after.json',primary_after)
                    receipt['primarySourceSnapshotUnchanged'] = primary_after == primary_before
                    require(primary_after == primary_before,'primary-whole-source-or-status-drift')
                except BaseException as failure: receipt['errors'].append({'phase':'primary-freeze','type':type(failure).__name__,'message':str(failure)})
            # Preserve both disposable clones/TMP and any independently indexed
            # external fixture remainders for review. Never delete home fixtures.
            if scratch is not None:
                receipt['privateScratchRetained'] = scratch.exists()
                receipt['retentionReason'] = 'intentional-failure evidence and disposable clones retained for review; no owned directory deletion performed by runner'
            receipt['complete'] = bool(receipt.get('comparisonObserved') and not receipt['errors'] and receipt.get('noOwnedChildren') and receipt.get('primarySourceSnapshotUnchanged') and len(receipt['arms']) == 2 and all(arm.get('complete') for arm in receipt['arms']))
            receipt['artifacts'] = [{'file':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(out.rglob('*')) if p.is_file()]
            checkpoint(out,'terminal.json',receipt)
        finally:
            for sig,old in handlers.items(): signal.signal(sig,old)
            signal.pthread_sigmask(signal.SIG_SETMASK,mask)
            if lock is not None: lock.close()
    print(json.dumps({'complete':receipt['complete'],'nativeTestsPassed':False,'genuineAcceptance':False,'receipt':str(out/'terminal.json'),'sha256':sha((out/'terminal.json').read_bytes()),'errors':receipt['errors']}))
    return 0 if receipt['complete'] else 1
