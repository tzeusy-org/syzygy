// Outside diagnostic metadata only. Installed Vitest's JSON reporter retains
// only the first file error's message, so capture the complete error population.
import { writeFileSync } from 'node:fs';

const errorFields = error => {
  if (error === null || (typeof error !== 'object' && typeof error !== 'function')) {
    return { name:'NonError', message:String(error) };
  }
  const row = {};
  for (const key of ['name','message','stack','code','path','syscall','ownershipFaultCleanupErrorId']) {
    if (typeof error?.[key] === 'string') row[key] = error[key];
  }
  return row;
};
export default class AllErrorsReporter {
  onFinished(files = [], globalErrors = []) {
    const output = process.env.SYZYGY_OWNERSHIP_ERROR_AUDIT;
    if (!output?.startsWith('/home/orca/.tmp/f3-native-admission-fixes/')) throw new Error('missing-bound-error-audit-output');
    const records = [];
    const visit = (task, filepath) => {
      const ancestors = [];
      let suite = task.suite;
      while (suite) { ancestors.push(suite.name); suite = suite.suite; }
      ancestors.reverse();
      records.push({ filepath, taskId:task.id, taskType:task.type, fullName:[...ancestors,task.name].filter(Boolean).join(' '),
        state:task.result?.state, errors:(task.result?.errors ?? []).map(errorFields) });
      for (const child of task.tasks ?? []) visit(child,filepath);
    };
    for (const file of files) visit(file,file.filepath);
    const data = JSON.stringify({ version:1, files:files.map(file => file.filepath), globalErrors:globalErrors.map(errorFields), records },null,2) + '\n';
    if (Buffer.byteLength(data) > 8_388_608) throw new Error('error-audit-metadata-limit');
    writeFileSync(output,data,{flag:'wx',mode:0o600});
  }
}
