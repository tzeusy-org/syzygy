# Completed D10/main proof assembly preparation

[Observed] Preparation only. The assembler has not been imported or invoked. Root may review and invoke it only after `d10-immediate-predecessor-check-f4bb-1` has terminated and its independent reconciliation is complete. No active predecessor output was read during preparation. The first predecessor file read by the invoked script is complete.json; absent/incomplete/unaccepted results refuse assembly before its logs/witnesses are read.

```sh
python3 /home/orca/.tmp/f3-native-admission-fixes/assemble-d10-main-completed-proof-R1.py --root-reconciliation /home/orca/.tmp/f3-native-admission-fixes/ROOT-ACTUAL-RECONCILIATION.json --destination /home/orca/.tmp/f3-native-admission-fixes/d10-main-scoped-proof-final-R1
```

[Observed] The reconciliation argument must be an actual completed JSON file, not the placeholder above, with these explicit assertions:

- candidateSubject:04cc28f2669753340ddbe334f17a1755386017c4
- predecessorSubject:f4bbffea3582817e01cc7dc7eece6aed51472090
- mainCompositionSubject:2dfdd5acc5eecc86b4067f48f16bad28ce25e90a
- sourceDifferenceOnlyReviewedD10File:true
- candidateWrapperFalseDueStale8198Comparison:true
- staleComparisonDifferingWitnessObjects:2
- candidateCompleteSha256:the actual SHA256 of the completed04cc complete.json
- immediatePredecessorCompleteSha256:the actual SHA256 of the completedf4bb complete.json

[Observed] The assembler separately requires actual predecessor scoped acceptance/clean clone/removed scratch, preserves original04cc scopedAccepted=false and AssertionError, checks both actual selftest exits0 and all step-log bytes/hashes, and compares complete witness documents after removing only top-level commit. It asserts806 unique labels,646 killed/160 held, and independent printed-label multiset equality in both logs. It retains four mutation old/new/intended-fixture records and raw logs. Root reconciliation owns the complete source-only difference statement; assembly does not silently assume equivalence from matching counts. Original source packet/review execution/Unknown descriptions are marked historical at the new README's relevant paragraph.

[Observed] Copies only sealed candidate/main packets, raw reviews/receipts, actual commits, completed top-level verification outputs (exact declared census, no clone/TMP), operator definitions, completed original profile and explicit root reconciliation. Source/manifest hashes use hashlib plus independent sha256sum; copies and member readbacks are checked. Destination must be a new direct child of the scratch base. Archive is deterministic with normalized safe relative regular members,mtime0,uid/gid0,mode0644; byte-identical rebuild, source index, archive index and independent final checksum sweep are mandatory.

[Unknown] Runtime benefit, hosted420-second compliance, full final gates and full main-merge acceptance are not established by these scoped results. Local duration differences are not a controlled benchmark. No adoption ID is guessed. No primary/source/ledger/status edit, checker/product/native/test/build/provider execution or publication is permitted by this script.
