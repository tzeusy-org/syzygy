#!/usr/bin/env python3
"""Preparation only: root invokes after predecessor completion and reconciliation."""
import argparse
import collections
import gzip
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
CANDIDATE = '04cc28f2669753340ddbe334f17a1755386017c4'
PREDECESSOR = 'f4bbffea3582817e01cc7dc7eece6aed51472090'
MERGE = '2dfdd5acc5eecc86b4067f48f16bad28ce25e90a'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dual(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    other = subprocess.run(['sha256sum', str(path)], capture_output=True, text=True, check=True).stdout.split()[0]
    assert sha(raw) == other
    return raw

def read(path):
    return json.loads(dual(path))

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def pack(files):
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as handle:
        for name, data in files:
            safe = pathlib.PurePosixPath(name)
            assert not safe.is_absolute() and '..' not in safe.parts and str(safe) == name
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.uid, info.gid, info.mode = len(data), 0, 0, 0, 0o644
            info.uname = info.gname = ''
            handle.addfile(info, io.BytesIO(data))
    out = io.BytesIO()
    with gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0) as handle:
        handle.write(raw.getvalue())
    return out.getvalue()

def main():
    args = argparse.ArgumentParser()
    args.add_argument('--root-reconciliation', type=pathlib.Path, required=True)
    args.add_argument('--destination', type=pathlib.Path, required=True)
    opt = args.parse_args()
    dest = opt.destination.absolute()
    assert dest.parent == BASE and not dest.exists(), str(dest)
    # This is the only predecessor output read before the completion gate.
    before = BASE / 'd10-immediate-predecessor-check-f4bb-1'
    terminal = read(before / 'complete.json')
    assert terminal['subject'] == PREDECESSOR and terminal['candidate'] == CANDIDATE
    assert terminal['scopedAccepted'] is True and terminal['orderedFullWitnessObjectsEqual'] is True
    assert terminal['cloneClean'] is True and terminal['privateScratchRemoved'] is True
    assert not terminal.get('error') and not terminal.get('cleanupError')
    root_raw = dual(opt.root_reconciliation)
    root = json.loads(root_raw)
    # Explicit provenance assertions are required; no inference from a green wrapper.
    assert root['candidateSubject'] == CANDIDATE and root['predecessorSubject'] == PREDECESSOR
    assert root['mainCompositionSubject'] == MERGE
    assert root['sourceDifferenceOnlyReviewedD10File'] is True
    assert root['candidateWrapperFalseDueStale8198Comparison'] is True
    assert root['staleComparisonDifferingWitnessObjects'] == 2
    assert root['immediatePredecessorCompleteSha256'] == sha(dual(before / 'complete.json'))
    current = BASE / 'd10-exact-membership-check-04cc28f-1'
    after = read(current / 'complete.json')
    assert after['subject'] == CANDIDATE and after['scopedAccepted'] is False
    assert after['privateScratchRemoved'] is True and after['errors'] == ['AssertionError()']
    assert root['candidateCompleteSha256'] == sha(dual(current / 'complete.json'))
    candidate_receipt = read(BASE / 'd10-exact-membership-actual-commit.json')
    merge_receipt = read(BASE / 'main-b739-composition-actual-commit.json')
    assert candidate_receipt['commit'] == CANDIDATE and candidate_receipt['parent'] == PREDECESSOR
    assert candidate_receipt['paths'] == ['scripts/d10_supersession.py']
    assert merge_receipt['commit'] == MERGE and merge_receipt['parents'][0] == CANDIDATE
    assert merge_receipt['sourceChanged'] is False
    assert merge_receipt['mainAdoptionRows'] == 104 and merge_receipt['resolvedAdoptionRows'] == 285
    assert merge_receipt['renamedF3Observer'] == 'A-329' and merge_receipt['mainAdoption'] == 'A-326'
    left, right = read(before / 'witnesses.json'), read(current / 'witnesses.json')
    assert left['commit'] == PREDECESSOR and right['commit'] == CANDIDATE
    left_without_subject = {k:v for k,v in left.items() if k != 'commit'}
    right_without_subject = {k:v for k,v in right.items() if k != 'commit'}
    assert left_without_subject == right_without_subject
    rows = right['mutants']
    assert len(rows) == len({r['mutant'] for r in rows}) == 806
    counts = dict(collections.Counter(r['outcome'] for r in rows))
    assert counts == {'killed':646, 'held':160}
    for folder, complete, logname in [(before,terminal,'selftest'),(current,after,'reconciliation-selftest')]:
        steps = complete['steps']
        for step in steps:
            raw = dual(folder / (step['name'] + '.log'))
            assert step['bytes'] == len(raw) and step['sha256'] == sha(raw)
        final = next(s for s in steps if s['name'] == logname)
        assert final['exit'] == 0
        printed = [tuple(line.split()[:2]) for line in (folder / (logname+'.log')).read_text().splitlines()
                   if line.startswith(('killed ', 'held '))]
        assert len(printed) == 806
        assert collections.Counter(printed) == collections.Counter((r['outcome'],r['mutant']) for r in rows)
    mutation = read(current / 'mutation-results.json')
    assert mutation['subject'] == CANDIDATE and len(mutation['mutants']) == 4
    assert all(m['intendedFailure'] is True and m['fixtureCount'] == 19 and
               m['intendedFailingFixture'] in m['failed'] for m in mutation['mutants'])
    baseline = (current/'d10-baseline.log').read_text().splitlines()
    passed = [line for line in baseline if line.startswith('PASS ')]
    assert len(passed) == len(set(passed)) == 19 and baseline[-1] == '19 fixtures, 0 failing'
    pool = (current/'pool.log').read_text()
    assert 'Ran 12 tests in ' in pool and pool.rstrip().endswith('OK')
    assert sum(line.startswith('test_') for line in pool.splitlines()) == 12
    predicates = (current/'reconciliation-check.log').read_text()
    assert '7 of 7 predicates without FAIL; PASS — counts derived, not asserted' in predicates
    for name in ['d10-baseline','pool','reconciliation-check']:
        assert next(s for s in after['steps'] if s['name']==name)['exit'] == 0
    dest.mkdir()
    payload = dest / 'payload'
    payload.mkdir()
    sources = []
    def copy(path, name):
        data = dual(path)
        target = payload / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        assert dual(target) == data == path.read_bytes()
        sources.append(dict(path=name, source=str(path), bytes=len(data), sha256=sha(data)))
    def sealed(folder, prefix):
        manifest = (folder / 'SHA256SUMS').read_text().splitlines()
        names = []
        for line in manifest:
            expected, name = line.split('  ',1)
            if name.startswith('*'):
                name = name[1:]
            assert not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
            assert sha(dual(folder/name)) == expected
            names.append(name)
        actual = sorted(p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file())
        assert actual == sorted(names + ['SHA256SUMS'])
        for name in actual:
            copy(folder/name,prefix+'/'+name)
    sealed(BASE/'d10-exact-adoption-membership-candidate-R1','frozen-d10-candidate')
    sealed(BASE/'main-b739-composition-R1','frozen-main-composition')
    for name in ['d10-exact-adoption-membership-source-review-R1-RAW.md',
                 'd10-exact-adoption-membership-source-review-R1-receipt.json',
                 'd10-exact-membership-actual-commit.json',
                 'main-b739-composition-R1-review-RAW.md','main-b739-composition-R1-review-data.json',
                 'main-b739-composition-R1-review-receipt.json','main-b739-composition-actual-commit.json',
                 'main-b739-merge-raw.txt','verify-d10-exact-membership.py','verify-d10-immediate-predecessor.py']:
        copy(BASE/name,'records-and-operators/'+name)
    for folder, prefix in [(current,'completed-04cc'),(before,'completed-immediate-predecessor')]:
        allowed = {s['name']+'.log' for s in read(folder/'complete.json')['steps']}
        allowed.update(['complete.json','progress.json','witnesses.json'])
        allowed.update(['canonical-selection.json','mutation-results.json'] if folder==current else ['admission.json'])
        actual = {p.name for p in folder.iterdir() if p.is_file()}
        assert actual == allowed, (folder, sorted(actual-allowed), sorted(allowed-actual))
        for name in sorted(allowed):
            copy(folder/name,prefix+'/'+name)
    # Preserve all completed profile records, including cProfile data, as inert bytes.
    profile = BASE/'reconciliation-check-profile-f4bb-1'
    for name in ['admission.json','complete.json','check.prof','check.stderr','check.stdout','cumulative-functions.json']:
        copy(profile/name,'completed-predecessor-profile/'+name)
    copy(opt.root_reconciliation,'root-reconciliation.json')
    copy(pathlib.Path(__file__),'assembly/assemble-d10-main-completed-proof-R1.py')
    copy(BASE/'d10-main-proof-assembly-contract-R1.md','assembly/CONTRACT.md')
    dump(payload/'RESULT.json',dict(candidate=CANDIDATE, predecessor=PREDECESSOR, mainComposition=MERGE,
        candidateTree=candidate_receipt['tree'],mainCompositionTree=merge_receipt['tree'],
        candidateWrapperAccepted=False, candidateWrapperLimitation='Stale8198 comparison: two metadata-derived old/new fragment differences',
        immediatePredecessorWrapperAccepted=True, fullWitnessObjectsEqualExceptTopCommit=True,
        population=806,counts=counts,printedPopulations=[806,806],
        fixturePopulation=19, intendedMutants=4,poolControls=12,reconciliationPredicates=7,
        candidateSteps=after['steps'],predecessorSteps=terminal['steps'],
        mainRows=104,resolvedUniqueRows=285,mainA326Preserved=True,unlandedObserverRenamed='A-329',
        runtimeBenefit='Unknown',hosted420SecondCompliance='Unknown',controlledBenchmark=False,
        fullFinalGates='Not established; 806 proof remains bound to04cc, not full merge acceptance'))
    (payload/'README.md').write_text('''# D10 exact membership and main composition scoped proof

[Observed] Frozen source candidate/review/actual04cc commit and separately reviewed actual2dfdd main composition are retained with exact original/resolved files. D10 exact validated identity membership skips unnecessary ancestry calls; the original nonmember fallback and fail-closed polarity remain. Source review verdict is ACCEPT — SOURCE REVIEW ONLY. Main source verdict is PASS — BOUNDED SOURCE COMPOSITION REVIEW:104 main rows preserved;285 unique resolved rows; mainA326 remains exact and the unlanded F3 observer/current reference moves toA329. Three composition paths, no implementation/runtime change; immutable earlier proof identities remain historical.

[Observed] Actual04cc owning run has19 fixture passes, four intended mutation failures,12 pool controls and seven reconciliation predicates. Its full806-witness subprocess exits0 with646 killed/160 held, but the original complete.json remains scopedAccepted=false due to a stale8198 comparison with two metadata-derived old/new fragment differences. That wrapper is never relabelled PASS. The separate completed exact immediate-predecessor f4bb run and root reconciliation establish full ordered witness-object equality after removing only the top-level commit field, not merely equal counts. Each log independently matches806 unique witness labels and outcome counts. All raw completed metadata/logs and both wrappers remain verbatim; clones and TMP are excluded.

[Observed] Candidate/source packet README execution statuses and review Unknown statements describe frozen preparation/review time; actual completed evidence here owns the later scoped results. The predecessor profile is a seven-predicate --check profile, not an806-selftest profile. Cumulative nested times are not additive. Local durations across separate runs are not a controlled benchmark. [Unknown] Actual candidate runtime savings, hosted420-second budget compliance, successful genuine recovery, full final battery and full main-merge acceptance. The806 result remains bound to04cc, not the later merge.

[Observed] Assembly performs only metadata/source/log reads, copying, deterministic archiving and independent sha256sum calls. No product/checker/native/test/build/provider execution, primary/ledger/status edit or publication. Safe regular member paths use mtime0,uid/gid0,mode0644. Every copied source and every archive member is checked; a byte-identical rebuild and independent final checksum sweep are required.
''')
    dump(payload/'SOURCE-INDEX.json',sources)
    files=sorted((p.relative_to(payload).as_posix(),p.read_bytes()) for p in payload.rglob('*') if p.is_file())
    archive=pack(files)
    assert pack(files)==archive
    (dest/'proof.tar.gz').write_bytes(archive)
    members=[]
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as handle:
        retained=handle.getmembers()
        assert [m.name for m in retained]==[name for name,_ in files]
        for m,(name,data) in zip(retained,files):
            assert m.isfile() and m.uid==m.gid==m.mtime==0 and m.mode==0o644
            assert handle.extractfile(m).read()==data
            members.append(dict(path=name,bytes=len(data),sha256=sha(data)))
    index=dict(archiveSha256=sha(archive),archiveBytes=len(archive),memberCount=len(members),
               memberReadbackHashes=len(members),sourceDualHashCount=len(sources),
               deterministicRebuildEqual=True,members=members)
    dump(dest/'ARCHIVE-INDEX.json',index)
    final=sorted(p for p in dest.rglob('*') if p.is_file())
    (dest/'SHA256SUMS').write_text(''.join(sha(dual(p))+'  '+p.relative_to(dest).as_posix()+'\n' for p in final))
    subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=dest,check=True,capture_output=True,text=True)
    print(json.dumps({k:v for k,v in index.items() if k!='members'},indent=2))

if __name__ == '__main__':
    main()
