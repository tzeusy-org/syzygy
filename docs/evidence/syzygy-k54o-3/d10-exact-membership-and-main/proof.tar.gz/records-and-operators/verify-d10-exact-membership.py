"""Scoped D10 controls and complete canonical reconciliation in a clean subject clone."""
import collections, hashlib, importlib.util, json, os, pathlib, shlex, signal, subprocess, sys, tempfile, time
B=pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
P=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
C=B/'d10-exact-adoption-membership-candidate-R1'
subject=sys.argv[1]
assert subject==subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=P)
out=B/('d10-exact-membership-check-'+subject[:7]+'-1');out.mkdir()
clone=out/'clone'; records=[]; errors=[]
# tempfile supplies mode0700 outside the shared checkout's setgid ancestry.
scratch=pathlib.Path(tempfile.mkdtemp(prefix='f3-d10-check-',dir='/home/orca/.tmp'))
os.chmod(scratch,0o700)
env={**os.environ,'TMPDIR':str(scratch),'PYTHONDONTWRITEBYTECODE':'1'}
original=None; started=time.monotonic()
def run(name,argv,cwd,variables=None,expected=0):
 began=time.monotonic(); log=out/(name+'.log')
 with log.open('wb') as f:
  child=subprocess.Popen(argv,cwd=cwd,env={**env,**(variables or {})},stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=child.wait(timeout=900)
  except BaseException:
   try: os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError: pass
   try: child.wait(timeout=10)
   except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 raw=log.read_bytes(); row=dict(name=name,argv=argv,cwd=str(cwd),exit=code,seconds=time.monotonic()-began,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 records.append(row);(out/'progress.json').write_text(json.dumps(dict(subject=subject,steps=records),indent=2)+'\n');print(name,code,round(row['seconds'],3),flush=True)
 assert code==expected,row
 return raw.decode()
try:
 run('clone',['git','clone','--no-hardlinks','--no-checkout',str(P),str(clone)],B)
 run('checkout',['git','checkout','--detach',subject],clone)
 path=clone/'scripts/d10_supersession.py'; original=path.read_bytes(); bindings=json.loads((C/'bindings.json').read_bytes()); assert hashlib.sha256(original).hexdigest()==bindings['resolvedSha256']
 text=run('d10-baseline',['python3','scripts/d10_supersession.py','--selftest'],clone)
 assert text.count('PASS ')==19 and '19 fixtures, 0 failing' in text
 mutants=json.loads((C/'mutants.json').read_bytes())['mutants']; mutation_results=[]
 for m in mutants:
  source=original.decode();assert source.count(m['old'])==1
  try:
   path.write_text(source.replace(m['old'],m['new'],1))
   text=run('mutant-'+m['id'],['python3','scripts/d10_supersession.py','--selftest'],clone,expected=1)
   assert ('FAIL '+m['intendedFailingFixture']) in text and 'Traceback' not in text
   lines=[s for s in text.splitlines() if s.startswith(('PASS ','FAIL '))];assert len(lines)==19
   mutation_results.append(dict(**m,fixtureCount=len(lines),intendedFailure=True,failed=[s[5:] for s in lines if s.startswith('FAIL ')]))
  finally: path.write_bytes(original)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
 (out/'mutation-results.json').write_text(json.dumps(dict(subject=subject,sourceSha256=bindings['resolvedSha256'],mutants=mutation_results),indent=2)+'\n')
 spec=importlib.util.spec_from_file_location('battery',clone/'scripts/run_status_battery.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 battery=module.battery((clone/'PROJECT-STATUS.md').read_text());selected=[]
 for name,argv in [('pool',['python3','scripts/test_reconciliation_pool.py']),('reconciliation-check',['python3','scripts/check_spec_reconciliation.py','--check']),('reconciliation-selftest',['python3','scripts/check_spec_reconciliation.py','--selftest'])]:
  matches=[(command,variables) for command,variables in battery if shlex.split(command,comments=True)==argv];assert len(matches)==1
  command,variables=matches[0];selected.append(dict(name=name,command=command,variables=variables));(out/'canonical-selection.json').write_text(json.dumps(dict(population=len(battery),selected=selected),indent=2)+'\n')
  actual=shlex.split(command,comments=True)
  if name=='reconciliation-selftest':actual+=['--witnesses',str(out/'witnesses.json')]
  text=run(name,actual,clone,variables)
  if name=='pool':
   import ast
   tree=ast.parse((clone/'scripts/test_reconciliation_pool.py').read_text()); count=sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_') for n in ast.walk(tree));assert 'OK' in text and f'Ran {count} tests' in text
  if name=='reconciliation-check':assert 'FAIL ' not in text
  if name=='reconciliation-selftest':assert 'SELFTEST PASS:' in text
 witness=json.loads((out/'witnesses.json').read_bytes());baseline=json.loads((B/'ci-repair-check-8198e8e-1/reconciliation-witnesses.json').read_bytes());assert witness['commit']==subject and witness['mutants']==baseline['mutants']
 rows=witness['mutants'];assert len(rows)==806 and len({r['mutant'] for r in rows})==806
 printed=[tuple(line.split()[:2]) for line in (out/'reconciliation-selftest.log').read_text().splitlines() if line.startswith(('killed ','held '))]
 assert collections.Counter(printed)==collections.Counter((r['outcome'],r['mutant']) for r in rows)
 assert collections.Counter(r['outcome'] for r in rows)=={'killed':646,'held':160}
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
 result=dict(subject=subject,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=clone,text=True).strip(),scopedAccepted=True,fullFinalGate=False,steps=records,canonicalPopulation=len(battery),canonicalSelected=len(selected),witnessPopulation=len(rows),orderedWitnessObjectsEqualBaseline=True,baselineSubject=baseline['commit'],cloneClean=True)
except BaseException as e:
 errors.append(repr(e));result=dict(subject=subject,scopedAccepted=False,steps=records,errors=errors)
finally:
 if original is not None:(clone/'scripts/d10_supersession.py').write_bytes(original)
 try:scratch.rmdir();result['privateScratchRemoved']=True
 except OSError as e:result['privateScratchRemoved']=False;result.setdefault('cleanupErrors',[]).append(repr(e));result['scopedAccepted']=False
 result['seconds']=time.monotonic()-started
 (out/'complete.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if not result['scopedAccepted']:sys.exit(1)
