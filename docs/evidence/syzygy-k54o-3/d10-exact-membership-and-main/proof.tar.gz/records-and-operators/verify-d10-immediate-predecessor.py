import pathlib,subprocess,json,os,tempfile,time,hashlib,collections,signal,importlib.util,shlex
b=pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes');source=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w');candidate=json.loads((b/'d10-exact-membership-actual-commit.json').read_bytes());subject=candidate['parent'];out=b/'d10-immediate-predecessor-check-f4bb-1';out.mkdir();clone=out/'clone';scratch=pathlib.Path(tempfile.mkdtemp(prefix='f3-d10-base-',dir='/home/orca/.tmp'));scratch.chmod(0o700);env={**os.environ,'TMPDIR':str(scratch),'PYTHONDONTWRITEBYTECODE':'1'};steps=[]
def run(name,argv,cwd,variables=None):
 began=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:
  p=subprocess.Popen(argv,cwd=cwd,env={**env,**(variables or {})},stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=900)
  except BaseException:
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise
 raw=(out/(name+'.log')).read_bytes();steps.append(dict(name=name,argv=argv,exit=code,seconds=time.monotonic()-began,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)));(out/'progress.json').write_text(json.dumps(dict(subject=subject,steps=steps),indent=2)+'\n');print(name,code,round(steps[-1]['seconds'],3),flush=True);assert code==0,name
result=dict(subject=subject,candidate=candidate['commit'],steps=steps,scopedAccepted=False,fullFinalGate=False)
try:
 run('clone',['git','clone','--no-hardlinks','--no-checkout',str(source),str(clone)],b);run('checkout',['git','checkout','--detach',subject],clone);assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
 spec=importlib.util.spec_from_file_location('battery',clone/'scripts/run_status_battery.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);battery=m.battery((clone/'PROJECT-STATUS.md').read_text());matches=[(c,v) for c,v in battery if shlex.split(c,comments=True)==['python3','scripts/check_spec_reconciliation.py','--selftest']];assert len(matches)==1;command,variables=matches[0];(out/'admission.json').write_text(json.dumps(dict(subject=subject,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=clone,text=True).strip(),canonicalPopulation=len(battery),command=command,variables=variables,candidateReceipt=str(b/'d10-exact-membership-actual-commit.json'),reason='Prior8198 comparison differed in two metadata-derived old/new fragments; compare exact immediate predecessor, preserving complete objects.'),indent=2)+'\n')
 run('selftest',shlex.split(command,comments=True)+['--witnesses',str(out/'witnesses.json')],clone,variables)
 previous=json.loads((out/'witnesses.json').read_bytes());current=json.loads((b/'d10-exact-membership-check-04cc28f-1/witnesses.json').read_bytes());assert previous['commit']==subject;assert current['commit']==candidate['commit'];assert previous['mutants']==current['mutants'],'Immediate predecessor full witness objects differ';rows=previous['mutants'];assert len(rows)==len({r['mutant'] for r in rows})==806
 printed=[tuple(l.split()[:2]) for l in (out/'selftest.log').read_text().splitlines() if l.startswith(('killed ','held '))];assert collections.Counter(printed)==collections.Counter((r['outcome'],r['mutant']) for r in rows);assert collections.Counter(r['outcome'] for r in rows)=={'killed':646,'held':160};assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone)
 result.update(scopedAccepted=True,orderedFullWitnessObjectsEqual=True,population=len(rows),printedPopulation=len(printed),counts=dict(collections.Counter(r['outcome'] for r in rows)),cloneClean=True)
except BaseException as e:result['error']=repr(e)
finally:
 try:scratch.rmdir();result['privateScratchRemoved']=True
 except OSError as e:result['cleanupError']=repr(e);result['scopedAccepted']=False
 (out/'complete.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if not result['scopedAccepted']:raise SystemExit(1)
