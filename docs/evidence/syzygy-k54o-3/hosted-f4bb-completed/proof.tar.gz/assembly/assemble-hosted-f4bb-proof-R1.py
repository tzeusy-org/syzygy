#!/usr/bin/env python3
"""Package only retained completed metadata/logs and a sealed assessment."""
import gzip
import hashlib
import io
import json
import pathlib
import re
import shutil
import subprocess
import tarfile
from collections import Counter
from datetime import datetime

BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
DEST = BASE / 'hosted-f4bb-proof-final-R1'
HOSTED = BASE / 'hosted-f4bb-completed-R1'
ASSESS = BASE / 'ordinary-recovery-f4bbff-runtime-assessment-1'
SUBJECT = 'f4bbffea3582817e01cc7dc7eece6aed51472090'
TREE = '63ffa8665a26c4e0e94f656b8cfd72d2edf3453e'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def dual(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    data = path.read_bytes()
    other = subprocess.run(['sha256sum', str(path)], check=True,
                           capture_output=True, text=True).stdout.split()[0]
    assert digest(data) == other, str(path)
    return data

def verify_seal(folder):
    lines = (folder / 'SHA256SUMS').read_text().splitlines()
    names = []
    for line in lines:
        sha, name = line.split('  ', 1)
        assert pathlib.PurePosixPath(name).name == name
        assert digest(dual(folder / name)) == sha
        names.append(name)
    a = sorted(x.name for x in folder.iterdir())
    b = sorted(x.name for x in folder.glob('*'))
    assert a == b == sorted(names + ['SHA256SUMS'])
    return a

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def archive(files):
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for path, data in files:
            normalized = pathlib.PurePosixPath(path)
            assert not normalized.is_absolute() and '..' not in normalized.parts
            assert str(normalized) == path
            info = tarfile.TarInfo(path)
            info.size, info.mtime, info.uid, info.gid, info.mode = len(data), 0, 0, 0, 0o644
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(data))
    packed = io.BytesIO()
    with gzip.GzipFile(fileobj=packed, mode='wb', filename='', mtime=0) as handle:
        handle.write(raw.getvalue())
    return packed.getvalue()

hosted_names, assess_names = verify_seal(HOSTED), verify_seal(ASSESS)
assert len(hosted_names) == len(assess_names) == 6
summaries = {}
for family in ['node', 'governance']:
    jobs = json.loads((HOSTED / (family + '-jobs.json')).read_text())
    summary = json.loads((HOSTED / (family + '-summary.json')).read_text())
    assert len(jobs['jobs']) == jobs['total_count'] == len(summary)
    assert len({j['id'] for j in jobs['jobs']}) == len(summary)
    actual = []
    for job in jobs['jobs']:
        assert job['status'] == 'completed' and job['head_sha'] == SUBJECT
        seconds = (datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00')) -
                   datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))).total_seconds()
        actual.append(dict(name=job['name'], id=job['id'], status=job['status'],
                           conclusion=job['conclusion'], seconds=seconds))
    assert actual == summary
    summaries[family] = dict(total=jobs['total_count'],
                            conclusions=dict(Counter(j['conclusion'] for j in actual)),
                            over420=[j for j in actual if j['seconds'] > 420], jobs=actual)
assert summaries['node']['total'] == 10 and summaries['node']['conclusions'] == {'success': 8, 'failure': 2}
assert summaries['governance']['total'] == 6 and summaries['governance']['conclusions'] == {'success': 6}
rawlog = (HOSTED / 'stop-resume-job.log').read_text()
assert '6bae261f3a33af477406513336d4cbd865d1ea0d' in rawlog
assert 'Merge ' + SUBJECT + ' into fda6daf1d752e8796a2723eb2866842b15fcbb50' in rawlog
assert '7 tests' in rawlog and '1 failed' in rawlog and '6 skipped' in rawlog
assert '418612' in rawlog and '421624' in rawlog and '424.81s' in rawlog
assert 'owned resumed fixture joins failed' in rawlog
assert not DEST.exists(), str(DEST)
DEST.mkdir()
payload = DEST / 'payload'
payload.mkdir()
sources = []
def copy(source, rel):
    data = dual(source)
    target = payload / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    assert dual(target) == data == source.read_bytes()
    sources.append(dict(path=rel, source=str(source), bytes=len(data), sha256=digest(data)))

for folder, prefix, names in [(HOSTED, 'completed-hosted', hosted_names), (ASSESS, 'runtime-assessment', assess_names)]:
    for name in names:
        copy(folder / name, prefix + '/' + name)
copy(pathlib.Path(__file__), 'assembly/assemble-hosted-f4bb-proof-R1.py')
local = BASE / 'ordinary-recovery-f4bbff-proof-final-R1'
references = []
for name in ['proof.tar.gz', 'ARCHIVE-INDEX.json']:
    data = dual(local / name)
    references.append(dict(path=str(local / name), bytes=len(data), sha256=digest(data)))
dump(payload / 'PRIOR-REFERENCES.json', references)
dump(payload / 'SUMMARY.json', dict(
    metadataHead=SUBJECT, sourceTree=TREE, checkoutCommitObservedInRawLog='6bae261f3a33af477406513336d4cbd865d1ea0d',
    checkoutTreeEquivalence='Unknown: not independently established by these retained files',
    workflows=summaries, hostedReport=dict(source='raw job log only; no Vitest JSON retained',
    files=1, failedFiles=1, totalCases=7, selectedFailed=1, skipped=6,
    selectedCasePrintedMs=418612, filePrintedMs=421624, vitestPrintedSeconds=424.81,
    additionalReportedFailure='owned resumed fixture joins failed'),
    assessment='Sealed runtime assessment independently decodes two identical hosted failure objects; six boundary copies per object',
    firstBoundary=dict(kind='TIMER', owner='tool', turn=3, wallCapMs=30000, cpuCapMicroseconds=64000000, currentCpu=None, remainingCpu=None),
    limitations=['No complete hosted Vitest JSON or success receipt retained', 'No synthetic checkout tree-equivalence claim',
                 'No full F3 acceptance, demonstrated causal saving or final local battery'],
    sourceCopies=len(sources)))
(payload / 'README.md').write_text('''# Completed hosted f4bb checkpoint

[Observed] GitHub metadata binds published head `f4bbffea3582817e01cc7dc7eece6aed51472090`: Node run45924925029 has10 completed jobs,8 success and2 failure (stop-resume plus aggregate); governance run45924925005 has6/6 success. Complete job arrays match both retained summaries and their total_count fields. Stop-resume482s and reconciliation487s exceed the unchanged420s job bar; core3 is370s. Passing governance is scoped execution evidence, not timing acceptance.

[Observed] The original stop-resume raw log reports1 failed selected case plus6 skipped/7,418612ms selected,421624ms file and424.81s Vitest duration. It also reports `owned resumed fixture joins failed`; that failure is preserved. There is no retained hosted Vitest JSON or successful composed receipt. The log names synthetic checkout `6bae261f3a33af477406513336d4cbd865d1ea0d` merging the published head into main `fda6daf1d752e8796a2723eb2866842b15fcbb50`. [Unknown] Synthetic checkout tree equivalence is not independently established by these retained files; metadata head and executed checkout are distinct identities.

[Observed] The sealed runtime assessment directly decodes two identical hosted failure objects. Hosted acknowledgment-receipt STORE accepts362499.231→366426.403ms; the subsequent prepared-store-recheck rejects366426.783→366911.791ms, with tool/turn3's original30s timer at366857.119612ms inside that recheck. Local f4bb instead rejects its verdict-staged STORE453297.311→457921.193ms; timer457865.347640ms falls within the final audit-authority callback. These are the same retained boundary class at different frontiers. CPU at either timer remains null/Unknown under the unchanged64000000-microsecond cap. Returned phase promises, accepted physical writes and accepted earlier append spans do not establish recovery acceptance.

[Inferred] Source interpretation and possible next measurement seams belong to the separately sealed ASSESSMENT.md; its proposals are not executed or adopted by this checkpoint. [Unknown] Exclusive native policy costs, causal benefit from batching, successful current genuine recovery and full F3 acceptance. This package makes no owner-gate or limit-change claim.

[Observed] Five original hosted evidence files and their checksum manifest, the complete six-file runtime assessment, assembly definition and scripted indexes are retained unchanged. The completed local proof is referenced by archive/index digest. No source, ledger or status edits, product/native/build/test/provider execution or publication occurred. No TMP, observed fixture bodies, clones or dependencies are included. Members have safe relative paths,mtime0,uid/gid0,mode0644; byte-identical rebuild, complete member readback and independent SHA checks are required.

[Observed] Existing campaign insertion home: docs/review-campaigns/d10-f3-url-supervisor.md, after the current final A-328 paragraph (line339 at inspection), with an additional paragraph and no new heading. Existing raw partition selector already covers the F3 campaign; no new campaign fragment is needed.
''')
dump(payload / 'SOURCE-INDEX.json', sources)
files = [(p.relative_to(payload).as_posix(), p.read_bytes()) for p in payload.rglob('*') if p.is_file()]
files.sort()
packed = archive(files)
assert archive(files) == packed
(DEST / 'proof.tar.gz').write_bytes(packed)
members = []
with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as tar:
    readback = tar.getmembers()
    assert [m.name for m in readback] == [n for n, _ in files]
    for member, (name, data) in zip(readback, files):
        assert member.isfile() and member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
        retained = tar.extractfile(member).read()
        assert retained == data
        members.append(dict(path=name, bytes=len(data), sha256=digest(retained)))
index = dict(metadataHead=SUBJECT, archiveSha256=digest(packed), archiveBytes=len(packed),
             memberCount=len(members), memberReadbackHashes=len(members), sourceDualHashCount=len(sources),
             deterministicRebuildEqual=True, members=members)
dump(DEST / 'ARCHIVE-INDEX.json', index)
checks = [(p.relative_to(DEST).as_posix(), dual(p)) for p in sorted(DEST.rglob('*')) if p.is_file()]
(DEST / 'SHA256SUMS').write_text(''.join(digest(data) + '  ' + name + '\n' for name,data in checks))
subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=DEST,check=True,capture_output=True,text=True)
print(json.dumps({k:v for k,v in index.items() if k!='members'},indent=2))
