import subprocess, tempfile, os, json, hashlib, time
from pathlib import Path
root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert subject.startswith('7cf85e08d') and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
out=Path('/home/orca/.tmp/f3-native-admission-fixes/audit-budget-30-execution');out.mkdir()
tmp=Path(tempfile.mkdtemp(prefix='f3-',dir='/home/orca/.tmp'));tmp.chmod(0o700)
env=os.environ.copy();env.update(TMPDIR=str(tmp),VITEST_MAX_THREADS='1',VITEST_MIN_THREADS='1',VITEST_MAX_FORKS='1',VITEST_MIN_FORKS='1')
results=[]
def run(label,cmd):
 start=time.time()
 with (out/(label+'.log')).open('wb') as f: r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 result={'label':label,'command':cmd,'exit':r.returncode,'seconds':time.time()-start,'logSha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()};results.append(result);print(json.dumps(result),flush=True)
 return r.returncode
vitest=['node','node_modules/vitest/vitest.mjs','run','--maxWorkers','1']
assert run('audit',vitest+['--project','integration','packages/polaris-dossier/src/url-session-audit.test.ts'])==0
assert run('history',vitest+['--project','unit','packages/polaris-dossier/src/url-session-audit-history.test.ts'])==0
assert run('typecheck',['npm','run','typecheck'])==0
source=root/'packages/polaris-dossier/src/url-session-audit.ts';original=source.read_bytes();old=b'milliseconds: 30_000';new=b'milliseconds: 5000';assert original.count(old)==1
try:
 source.write_bytes(original.replace(old,new))
 killed=run('old-five-second-mutant',vitest+['--project','integration','packages/polaris-dossier/src/url-session-audit.test.ts','-t','keeps one setup cutoff'])!=0
 assert killed
finally:source.write_bytes(original)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
(out/'results.json').write_text(json.dumps({'subject':subject,'tmp':str(tmp),'tmpMode':oct(tmp.stat().st_mode & 0o7777),'sourceSha256':hashlib.sha256(original).hexdigest(),'results':results,'mutant':{'path':str(source.relative_to(root)),'old':old.decode(),'new':new.decode(),'killed':killed}},indent=2)+'\n')
