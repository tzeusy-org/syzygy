#!/usr/bin/python3
"""Scoped typecheck and hermetic observer controls, with exact source restoration."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
OUT = Path('/home/orca/.tmp/f3-native-admission-fixes/fourth-tool-phase-focused-1')
NODE = '/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM = '/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
FILE = 'packages/polaris-dossier/src/url-verdict-phase.test.ts'
HELPER = ROOT / 'packages/polaris-dossier/src/url-run-composed.testkit.ts'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    OUT.mkdir()
    scratch = OUT / 'tmp'
    scratch.mkdir(mode=0o700)
    selection = OUT / 'selection.json'
    selection.write_text(json.dumps({'mode': 'scoped-observer-control', 'tiers': {'unit': [FILE]}}) + '\n')
    env = os.environ.copy()
    env.update(PATH=str(Path(NODE).parent)+':/usr/bin:/bin', TMPDIR=str(scratch))
    subject = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    before = HELPER.read_bytes()
    records = []

    def run(name, argv, failed=False, signature=None):
        began = time.monotonic()
        with (OUT / (name+'.log')).open('wb') as log:
            result = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
        raw = (OUT / (name+'.log')).read_bytes()
        record = {'name': name, 'argv': argv, 'exit': result.returncode, 'seconds': time.monotonic()-began,
                  'sha256': digest(raw), 'bytes': len(raw)}
        records.append(record)
        (OUT/'progress.json').write_text(json.dumps({'subject': subject, 'steps': records}, indent=2)+'\n')
        assert result.returncode == (1 if failed else 0), record
        if name != 'typecheck':
            text = raw.decode()
            reports = [json.loads(line.split(':',1)[1]) for line in text.splitlines() if line.startswith('syzygy-tmpdir-report:')]
            assert len(reports)==1 and reports[0]['errors']==[]
            rows = reports[0]['files']
            assert len(rows)==1 and rows[0]['path']==FILE and rows[0]['project']=='unit'
            assert rows[0]['passed']==(0 if failed else 1) and rows[0]['failed']==(1 if failed else 0)
            assert rows[0]['skipped']==0 and rows[0]['todo']==0 and len(rows[0]['tests'])==1
            owner = [json.loads(line.split(' ',1)[1]) for line in text.splitlines() if line.startswith('tmpdir-result ')]
            assert len(owner)==1 and owner[0]['cleanup'] and owner[0]['errors']==[]
            assert owner[0]['census']['leftovers']==[] and owner[0]['census']['errors']==[]
            assert owner[0]['denominator']['problems']==(['failed-files'] if failed else [])
            assert not owner[0]['child']['signal'] and not owner[0]['child']['interrupted']
            if failed:
                assert 'AssertionError:' in text and signature in text
        print(name, 'EXPECTED-FAIL' if failed else 'PASS', f'{record["seconds"]:.3f}s', flush=True)

    unit = [NODE, 'scripts/check_unit_tmpdir.mjs', '--selection', str(selection)]
    try:
        run('typecheck', [NODE, NPM, 'run', 'typecheck'])
        run('baseline', unit)
        source = before.decode()
        mutants = [
            ('chained-promise', '    return original;\n', '    return original.then(value => value);\n', 'expected Promise'),
            ('lost-rejection', "() => settle('rejected')", '() => undefined', 'expected { proof:'),
            ('retained-content', "void original.then(() => settle('returned'), () => settle('rejected'));", "void original.then(value => { Object.assign(stamp, { body: value }); settle('returned'); }, cause => { Object.assign(stamp, { body: cause }); settle('rejected'); });", 'expected { reproduction:'),
        ]
        for name, old, new, signature in mutants:
            assert source.count(old)==1, (name, source.count(old))
            HELPER.write_text(source.replace(old,new))
            record = {'name': name, 'old': old, 'new': new, 'subject': subject, 'originalSha256': digest(before), 'mutantSha256': digest(HELPER.read_bytes())}
            (OUT/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
            try:
                run(name, unit, True, signature)
            finally:
                HELPER.write_bytes(before)
                assert HELPER.read_bytes()==before
    finally:
        HELPER.write_bytes(before)
        assert HELPER.read_bytes()==before
        restored = not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
        (OUT/'final.json').write_text(json.dumps({'subject': subject, 'restored': restored, 'helperSha256': digest(before), 'steps': records},indent=2)+'\n')
        assert restored

if __name__ == '__main__':
    main()
