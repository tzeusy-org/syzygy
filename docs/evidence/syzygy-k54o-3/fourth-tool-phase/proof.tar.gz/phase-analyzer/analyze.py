#!/usr/bin/env python3
"""Read a completed, manifest-bound ordinary-recovery record; print safe metadata."""
import argparse
import hashlib
import json
import math
from pathlib import Path

SUBJECT = '22b540f0d8e1635e4fe36413d1dd4587be4a03b6'
TREE = 'bee00db67b88d28229874b85c2e2465d126f2112'
PRODUCTION_SHA256 = '382645bb414dca8abe9c5f625edeff9bd6602308cae195e80ec9524eee93ee32'
PHASE_FIXTURE_REFERENCE_SHA256 = '3b816f6d963758b8bf9c1af58a25bc12a97678ab861d25fa0f5a036b56b56974'
PHASE_TESTKIT_REFERENCE_SHA256 = 'dbdd12431dffa65c5d9816f8d319cb140f272d7bb5c1d1d1d1ff0e021694efae'
PHASES = ('reproduction', 'proof', 'staging')
FIXTURE_SHA256 = '0133c6e7fef5d3d91a0d2f283a8c3aeed7c92ea6f67f8f67cd03054fc15cdb43'
CASE = 'composed URL run with actual role processes runs the genuine production pipeline to stop-resume'
OPERATIONS = ('request', 'response', 'tool', 'audit', 'terminal')
SNAPSHOTS = ('workAtEntry', 'workAtFirstRefusedStage', 'workAtSettlement', 'workAtFault')
STAGES = ('invoke', 'host-current', 'mediate-peer', 'host-action', 'transfer-bounds',
          'plan-work-hold', 'create-work-budget', 'tool-before-plan-current',
          'tool-before-release-current', 'tool-before-audit-guard', 'prepared-store-append',
          'prepared-store-recheck', 'tool-release-guard', 'release', 'release-check', 'release-final-budget')
LEDGER_REASONS = ('clock', 'expired', 'cpu-limit', 'operation-wall-limit', 'operation-cpu-limit',
                  'invalid-operation', 'detector-limit', 'transform-limit', 'audit-read-limit', 'retired')
ENUMS = {
    'origin': ('check', 'finish', 'timer', 'operation'),
    'reason': ('invalid-cpu', 'regressing-cpu', 'invalid-remaining-cpu', 'negative-remaining-cpu',
               'wall-deadline', 'monotonic-wall-limit', 'cpu-limit', 'ledger-refused', 'timer', 'unclassified'),
    'operation': OPERATIONS,
    'ledgerState': ('open', 'stopped', 'complete'),
    'ledgerReason': LEDGER_REASONS,
}
NUMBERS = ('turn', 'beganMonotonicMilliseconds', 'beganCpuMicroseconds', 'beganWallMilliseconds',
           'expiresAt', 'cpuLimitMicroseconds', 'wallLimitMilliseconds', 'cpuMicroseconds',
           'remainingCpuMicroseconds', 'wallMilliseconds', 'monotonicMilliseconds')


def require(condition, code):
    if not condition:
        raise ValueError(code)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def number(value):
    return value if type(value) in (int, float) and math.isfinite(value) else None


def enum(value, allowed):
    return value if type(value) is str and value in allowed else None


def obj(value):
    return value if type(value) is dict else {}


def delta(left, right):
    return left - right if left is not None and right is not None else None


def stamp(value):
    value = obj(value)
    return {'startedMs': number(value.get('startedMs')), 'settledMs': number(value.get('settledMs')),
            'outcome': enum(value.get('outcome'), ('accepted', 'refused', 'rejected'))}


def boundary(value):
    value = obj(value)
    safe = {key: enum(value.get(key), allowed) for key, allowed in ENUMS.items()}
    safe.update({key: number(value.get(key)) for key in NUMBERS})
    cpu = delta(safe['cpuMicroseconds'], safe['beganCpuMicroseconds'])
    wall = delta(safe['wallMilliseconds'], safe['beganWallMilliseconds'])
    monotonic = delta(safe['monotonicMilliseconds'], safe['beganMonotonicMilliseconds'])
    return {
        'firstBoundaryFailure': safe,
        'missingFixedFields': [key for key in (*ENUMS, *NUMBERS) if key not in value],
        'unknownOrInvalidNonNullFields': [key for key in (*ENUMS, *NUMBERS)
                                          if value.get(key) is not None and safe[key] is None],
        'derivedFromLocalBoundaryOnly': {
            'cpuDeltaMicroseconds': cpu, 'wallDeltaMilliseconds': wall,
            'monotonicDeltaMilliseconds': monotonic,
            'cpuLimitExceeded': None if cpu is None or safe['cpuLimitMicroseconds'] is None
                else cpu > safe['cpuLimitMicroseconds'],
            'monotonicWallLimitReached': None if monotonic is None or safe['wallLimitMilliseconds'] is None
                else monotonic >= safe['wallLimitMilliseconds'],
            'absoluteWallDeadlineReached': None if safe['wallMilliseconds'] is None or safe['expiresAt'] is None
                else safe['wallMilliseconds'] >= safe['expiresAt'],
        },
    }


def verdict_phases(trace_name, trace, observer_began):
    host = stamp(obj(trace.get('stages')).get('host-action'))
    failures = [obj(obj(trace.get(key)).get('firstBoundaryFailure')) for key in SNAPSHOTS]
    tool = next((value for value in failures if value.get('operation') == 'tool'), {})
    tool_start = delta(number(tool.get('beganMonotonicMilliseconds')), observer_began)
    timer = delta(number(tool.get('monotonicMilliseconds')), observer_began) \
        if tool.get('origin') == 'timer' and tool.get('reason') == 'timer' else None
    phases = obj(trace.get('verdictPhases'))
    fixed = {}
    for key in PHASES:
        value = obj(phases.get(key))
        start, end = number(value.get('startedMs')), number(value.get('settledMs'))
        outcome = enum(value.get('outcome'), ('returned', 'rejected'))
        status = 'absent' if key not in phases else 'Unknown'
        if start is not None:
            if 'settledMs' not in value and 'outcome' not in value:
                status = 'unsettled-at-capture'
            elif end is not None and end >= start and outcome is not None:
                status = 'settled'
        fixed[key] = {'status': status, 'startedMs': start, 'settledMs': end, 'outcome': outcome,
            'elapsedMilliseconds': delta(end, start),
            'startAfterHostActionStartMilliseconds': delta(start, host['startedMs']),
            'settlementBeforeHostActionEndMilliseconds': delta(host['settledMs'], end),
            'startAfterFirstLatchedToolAdmissionMilliseconds': delta(start, tool_start),
            'settlementBeforeFirstLatchedToolTimerMilliseconds': delta(timer, end)}
    return {'trace': trace_name, 'invocationOrdinal': number(trace.get('ordinal')),
        'hostActionRelativeMilliseconds': host,
        'firstLatchedToolTurn': number(tool.get('turn')),
        'firstLatchedToolOperationStartRelativeMilliseconds': tool_start,
        'firstLatchedToolTimerRelativeMilliseconds': timer,
        'containerStatus': 'absent' if 'verdictPhases' not in trace else
            'present' if type(trace['verdictPhases']) is dict else 'Unknown',
        'fixedPhases': fixed}


def analyze(directory, expected_subject, expected_tree, expected_terminal_sha256):
    terminal_path = directory / 'terminal.json'
    require(terminal_path.is_file() and not terminal_path.is_symlink(), 'terminal-not-regular-file')
    terminal_bytes = terminal_path.read_bytes()
    require(sha(terminal_bytes) == expected_terminal_sha256, 'terminal-digest-mismatch')
    terminal = json.loads(terminal_bytes)
    require(type(terminal) is dict and terminal.get('complete') is True, 'terminal-not-complete')
    require(terminal.get('subject') == expected_subject and terminal.get('tree') == expected_tree, 'subject-or-tree-mismatch')
    require(terminal.get('rawFilesComplete') is True and terminal.get('populationValid') is True,
            'terminal-raw-population-not-complete')
    declared = terminal.get('rawFiles')
    require(type(declared) is list and bool(declared), 'raw-file-manifest-missing')
    raw, bindings = {}, []
    for index, row in enumerate(declared):
        require(type(row) is dict, 'invalid-raw-file-row')
        name = row.get('path')
        require(type(name) is str and name not in ('', '.', '..', 'terminal.json')
                and Path(name).name == name and '/' not in name and '\\' not in name
                and name not in raw, 'invalid-or-duplicate-raw-file-name')
        path = directory / name
        require(path.is_file() and not path.is_symlink(), 'raw-file-not-regular-file')
        data = path.read_bytes()
        digest = sha(data)
        require(type(row.get('bytes')) is int and row['bytes'] == len(data)
                and row.get('sha256') == digest, 'raw-file-binding-mismatch')
        raw[name] = data
        bindings.append({'manifestOrdinal': index, 'bytes': len(data), 'sha256': digest})
    actual_files = {path.name for path in directory.iterdir() if path.is_file() or path.is_symlink()}
    require(actual_files == set(raw) | {'terminal.json'}, 'unmanifested-or-missing-record-file')
    require('vitest.json' in raw, 'vitest-not-manifest-bound')
    # No raw JSON/log other than terminal is interpreted until every binding passes.
    report = json.loads(raw['vitest.json'])
    assertions = [a for suite in report['testResults'] for a in suite['assertionResults']]
    selected = [a for a in assertions if a.get('fullName') == CASE]
    require(len(selected) == 1, 'selected-assertion-not-unique')
    case = selected[0]
    if 'selectedAssertion' in terminal:
        require(terminal['selectedAssertion'] == case, 'terminal-selected-assertion-mismatch')
    result = {
        'subject': expected_subject, 'tree': expected_tree, 'terminalSha256': sha(terminal_bytes),
        'schemaSourceReferenceAt22b540': {'subject': SUBJECT, 'tree': TREE,
            'productionSha256': PRODUCTION_SHA256, 'originalFixtureSha256': FIXTURE_SHA256},
        'preparedObserverReference': {'revision': 2, 'fixtureSha256': PHASE_FIXTURE_REFERENCE_SHA256,
            'testkitSha256': PHASE_TESTKIT_REFERENCE_SHA256},
        'verifiedRawFilePopulation': len(raw), 'rawFileBindings': bindings,
        'vitestSha256': sha(raw['vitest.json']), 'retainedAssertionPopulation': len(assertions),
        'selectedCase': CASE, 'selectedStatus': enum(case.get('status'), ('passed', 'failed', 'pending', 'skipped', 'todo')),
        'selectedDurationMilliseconds': number(case.get('duration')),
        'terminalAccepted': terminal.get('accepted') if type(terminal.get('accepted')) is bool else None,
        'diagnosticStatus': 'Unknown', 'records': [], 'verdictPhaseStatus': 'Unknown', 'verdictPhaseRecords': [],
    }
    messages = case.get('failureMessages', [])
    if case.get('status') != 'failed' or not messages or type(messages[0]) is not str or not messages[0].startswith('Error: {'):
        result['unknownReason'] = 'no-original-fixture-first-error-json'; return result
    message = messages[0]
    # Exact fixture Error(JSON.stringify(...)) envelope; never search for nested braces.
    failure, end = json.JSONDecoder().raw_decode(message, len('Error: '))
    require(type(failure) is dict and 'failure' in failure and 'resumeDiagnostic' in failure,
            'not-original-fixture-failure-capture')
    require(not message[end:] or message[end:].startswith('\n'), 'unexpected-first-error-json-suffix')
    result['failureJsonSha256'] = sha(message[len('Error: '):end].encode('utf-8'))
    resume = obj(failure.get('resumeDiagnostic')); broker = obj(resume.get('broker'))
    result['observerBeganAbsoluteMonotonicMilliseconds'] = number(resume.get('began'))
    result['brokerInvocationCount'] = number(broker.get('invocations'))
    result['brokerFaultRelativeMilliseconds'] = number(broker.get('faultMs'))
    result['snapshotLocationPopulation'] = 2 * len(SNAPSHOTS)
    for trace_name in ('latestInvocation', 'firstRefusedInvocation'):
        trace = obj(broker.get(trace_name))
        for key in SNAPSHOTS:
            snapshot = trace.get(key)
            row = {'trace': trace_name, 'snapshot': key, 'invocationOrdinal': number(trace.get('ordinal')),
                   'invocationTimingRelativeMilliseconds': stamp(trace.get('timing')),
                   'firstRefusedStage': enum(trace.get('firstRefusedStage'), STAGES),
                   'stagesRelativeMilliseconds': {stage: stamp(trace['stages'][stage]) for stage in STAGES
                                                 if stage in obj(trace.get('stages'))},
                   'snapshotStatus': 'absent' if key not in trace else 'null' if snapshot is None else 'present'}
            if type(snapshot) is dict:
                row['cumulativeLedgerSnapshot'] = {
                    'state': enum(snapshot.get('state'), ('open', 'stopped', 'complete')),
                    'reason': enum(snapshot.get('reason'), LEDGER_REASONS),
                    'cpuMicroseconds': number(snapshot.get('cpuMicroseconds')),
                    'wallMilliseconds': number(snapshot.get('wallMilliseconds')),
                    'expiresAt': number(snapshot.get('expiresAt')),
                }
                row['boundaryStatus'] = 'retained' if 'firstBoundaryFailure' in snapshot else 'absent-at-this-snapshot'
                if 'firstBoundaryFailure' in snapshot:
                    row.update(boundary(snapshot['firstBoundaryFailure']))
            result['records'].append(row)
    # Count the complete decoded record, without rendering arbitrary keys/values.
    result['verdictPhaseRecords'] = [verdict_phases(name, obj(broker.get(name)), number(resume.get('began')))
                                     for name in ('latestInvocation', 'firstRefusedInvocation')]
    stack, occurrences, dictionaries, phase_containers, phase_slots = [failure], 0, 0, 0, 0
    while stack:
        value = stack.pop()
        if type(value) is dict:
            dictionaries += 1
            occurrences += int('firstBoundaryFailure' in value)
            phase_containers += int('verdictPhases' in value)
            phase_slots += sum(key in obj(value.get('verdictPhases')) for key in PHASES)
            stack.extend(value.values())
        elif type(value) is list:
            stack.extend(value)
    extracted = sum('firstBoundaryFailure' in row for row in result['records'])
    result['firstBoundaryFailureOccurrencesInCompleteFailureRecord'] = occurrences
    result['extractedOccurrences'] = extracted
    result['unmappedOccurrences'] = occurrences - extracted
    result['completeFailureRecordDictionaryPopulation'] = dictionaries
    mapped_containers = sum('verdictPhases' in obj(broker.get(name))
                            for name in ('latestInvocation', 'firstRefusedInvocation'))
    mapped_slots = sum(key in obj(obj(broker.get(name)).get('verdictPhases'))
                       for name in ('latestInvocation', 'firstRefusedInvocation') for key in PHASES)
    result['verdictPhaseCensus'] = {'completeRecordContainers': phase_containers,
        'mappedContainers': mapped_containers, 'unmappedContainers': phase_containers - mapped_containers,
        'completeRecordFixedSlots': phase_slots, 'mappedFixedSlots': mapped_slots,
        'unmappedFixedSlots': phase_slots - mapped_slots}
    result['verdictPhaseStatus'] = 'retained-fixed-phase-metadata' if mapped_slots else 'Unknown'
    result['diagnosticStatus'] = 'retained-boundary-metadata' if extracted else 'Unknown'
    if not extracted:
        result['unknownReason'] = 'no-boundary-metadata-at-retained-snapshot-locations'
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('completed_output_directory', type=Path)
    parser.add_argument('--subject', required=True, help='Actual full completed subject commit')
    parser.add_argument('--tree', required=True, help='Actual full completed subject tree')
    parser.add_argument('--terminal-sha256', required=True, help='Previously recorded digest of completed terminal.json')
    args = parser.parse_args()
    try:
        for value, length in [(args.subject, 40), (args.tree, 40), (args.terminal_sha256, 64)]:
            require(len(value) == length and all(c in '0123456789abcdef' for c in value), 'invalid-expected-binding')
        print(json.dumps(analyze(args.completed_output_directory, args.subject, args.tree, args.terminal_sha256),
                         indent=2, allow_nan=False))
    except (OSError, ValueError, KeyError, TypeError, AttributeError, RecursionError, OverflowError):
        # Never print exception text: parsers and OS errors can contain private input.
        print(json.dumps({'analysisStatus': 'refused', 'diagnosticStatus': 'Unknown',
                          'reason': 'input-completion-binding-or-schema-validation-failed'}))
        raise SystemExit(2)
