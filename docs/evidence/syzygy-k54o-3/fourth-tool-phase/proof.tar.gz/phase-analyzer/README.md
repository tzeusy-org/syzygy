# Narrow verdict-phase analyzer successor

[Observed] This source-only preparation extends the validated analyzer at `/home/orca/.tmp/f3-native-admission-fixes/first-boundary-analysis-preparation/analyze.py`, SHA-256 `a5e3136f3f4cd289fd2629daca5a02ae8896ac5d61058033d351186a877bd966`. That file is unchanged. `analyzer.patch` shows the complete successor delta. No product, test, provider, fixture, native recovery or future-output analysis was executed while preparing it.

After an actual attempt completes, and after reviewing this successor, supply the actual completed bindings:

```sh
python3 /home/orca/.tmp/f3-native-admission-fixes/first-boundary-phase-analysis-preparation/analyze.py /actual/completed/output-directory \
  --subject ACTUAL_FULL_COMMIT \
  --tree ACTUAL_FULL_TREE \
  --terminal-sha256 ACTUAL_COMPLETED_TERMINAL_SHA256
```

These are placeholders, not executable bindings or a predicted future head. The subject/tree must be full lowercase 40-character Git identities, and the terminal digest a full lowercase SHA-256. The script checks the exact terminal digest before decoding it, requires terminal complete and exact subject/tree equality, and preserves the predecessor's complete manifest/raw-file population validation. Every declared raw file is read, size-checked and SHA-256-checked before Vitest is interpreted. Extra unmanifested record files, missing files, symlinks and traversal refuse analysis; subdirectories are not traversed or read. Output goes only to stdout. The decoder creates no files and performs no Git, network, provider or process-execution calls.

[Observed] The original genuine stop-resume assertion is still selected uniquely from the manifest-bound Vitest report. The terminal's selected assertion, if retained, must match. The first failure JSON is decoded exactly after `Error: ` with `JSONDecoder.raw_decode`, requiring the original fixture's failure-capture keys. No regex searches for nested JSON and no raw bodies, errors, arbitrary keys, inputs, private paths or TMP content are printed. Existing first-boundary scalar extraction, original caps/baselines, cumulative ledger labeling, null propagation and generic fixed validation-error output remain.

The added output is limited to two retained invocation summaries, `latestInvocation` and `firstRefusedInvocation`, and exactly three fixed `verdictPhases` keys:

| Phase | Source call in the frozen observer revision 2 |
| --- | --- |
| reproduction | Fresh undefined-purpose `input.reproduce()` |
| proof | `input.audit.readOrderedDesignReviewProof()` |
| staging | `input.artifacts.stageOrderedDesignVerdict()` |

Each phase renders only numeric `startedMs`/`settledMs`, the fixed `returned`/`rejected` outcome, and arithmetic from those retained values. Missing phase means absent/unobserved, not zero. A valid start without either settlement field means `unsettled-at-capture`; it does not assert that work is still running after terminal completion. Missing/invalid/nonfinite values stay null/Unknown. Valid settlement requires a nonregressing finite end and a fixed outcome. The raw negative elapsed difference, if any, remains visible as arithmetic while status stays Unknown. **Returned means settlement only:** it may include null or an ordinary refusal value; it is not acceptance, proof validity, staging validity, eligibility or permission. Rejected conveys no private error reason.

The phase report preserves each retained invocation ordinal and its original host-action stamp. Start offsets and settlement margins are arithmetic comparisons to that host action. Where a snapshot retains a tool-owned first-boundary failure, the report also preserves that latch's turn, admission time, and timer time when its actual origin/reason are timer/timer. Fields explicitly say `firstLatchedTool...`: the session-wide first latch is not automatically the operation belonging to every later trace. Verify its turn, ordinal and interval correspondence before attributing it. Missing tool metadata or a non-timer first failure yields null for timer alignment; cumulative shared ledger CPU is never substituted. No clock or CPU sample is taken.

The complete decoded failure is traversed once to count dictionaries, every `firstBoundaryFailure` occurrence, every `verdictPhases` container, and occurrences of only the three fixed phase slots. The report compares those complete-record populations with the known mapped locations. A nonzero unmapped count is a coverage gap; no arbitrary extra container is rendered. Latest/first-refused copies may describe the same invocation and must not be added as independent executions. Repeated calls overwrite a phase slot in the fixture; this is not a call count or complete timeline. Inclusive phase spans must not be added to their containing tool/host spans or treated as exclusive CPU cost. Earlier/later omitted invocations and gaps remain Unknown.

[Observed] Frozen schema references are explicit in the output. `schemaSourceReferenceAt22b540` names the already verified production diagnostic and original fixture at actual commit `22b540f0d8e1635e4fe36413d1dd4587be4a03b6`. `preparedObserverReference` names the prepared observer revision 2 fixture SHA `3b816f6d963758b8bf9c1af58a25bc12a97678ab861d25fa0f5a036b56b56974` and testkit SHA `dbdd12431dffa65c5d9816f8d319cb140f272d7bb5c1d1d1d1ff0e021694efae`, verified against `/home/orca/.tmp/f3-native-admission-fixes/fourth-tool-phase-preparation-22b-2/manifest.json`. Those are **reference schema bytes, not a claim that a future subject already contains them**. The owning operator must bind the actual executed source separately. The script neither guesses a future source hash nor fetches a future commit.

[Unknown] A passing or differently failing case can lack the original fixture JSON capture. The report keeps its actual assertion status and reports diagnostic/phase Unknown with empty records; pass alone proves no diagnostic absence. Null pre-budget snapshots, preadmission failures, unclassified private exceptions and timer CPU retain the predecessor's limitations. A completed staging span or accepted protected store append does not establish the writer's required subsequent currentness/reread checks, acknowledgment or terminal eligibility. No elapsed saving, cap change, guard omission, cached pass or new acceptance result follows from these stamps.

Preparation verification is static: Python AST parsing, complete patch inspection, unchanged predecessor digest, and the frozen observer fixture/testkit hashes. No analyzer invocation against an output directory or synthetic case was performed. `SHA256SUMS` binds the three prepared files; the root can inspect them before any later use.
