#!/bin/sh
set -eu
SYZYGY_POC_BROWSER=/home/orca/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-8198e8-R1/run.py --subject 8198e8e34e394c8918a86db3dec02dc1ef1fa8f2 --output /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-8198e8-1
