REVISE

# Fresh source composition review: pending main278 merge

[Inferred] REVISE for the packet's material scope/provenance wording only. The staged source composition itself passes this source-only review; no source correction is indicated. Full acceptance, verification, browser rendering, merge readiness and the eventual source merge commit remain outside this verdict.

[Observed] Review subject: /home/orca/.tmp/f3-native-admission-fixes/main278-composition-R1, bound by manifest SHA256 cde98a7b0e5a9f12125c309eacffc97413ed0d28176c55423607915e38098702. Primary checkout: /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w. Actual HEAD is 00f9c6f821baf83eac0dada118afdccc0e524088; MERGE_HEAD is 278265bce97d1903e8b89ccc6062ac6e3763c17f. Their computed merge base is 08e1c4172885f9a9fb678ee7ffe3c08d52bac99e, matching previousMain. Review used read-only git/source inspection, scripted hashing and in-memory line composition. No tests, typechecks, builds, native programs, heavy work, browser/provider calls, repository edits, staging operations or commits were performed. Only this outside raw report was written. Engineering-bar, test-rigor and the relevant heart-and-soul evidence/security/decision rules apply.

## Finding

[Inferred] R1 — README.md materially misidentifies the branch-side renderer changes. Its sentence says: “Dossier-site has branch A-303 changes plus incoming already-adopted A-308 mobile stylesheet changes”. The bound branch-before.patch instead changes URL-supervised effectiveRun disclosure and metadata: run-sentence wording, notice wording, data-effective-run, and the effectiveRun member in dossier.json. Omitting those actual branch-side behavior changes makes the composition's review scope misleading.

[Observed] The A-303 glossary definition markup is already in the common base. Commit c33dc523f5db26c01b69a4656d61e172ece4db9f is an ancestor of previous main08e1, branch00f9 and incoming main278. The sole <dfn> source line is byte-identical across previous main, first parent, incoming parent and staged result; SHA256 of that line without newline is 91cdf3f6b72f580ddb044365c0d36c7d19507f1bf34f0aeeb125936805af68f3. This preservation is correct but it is not the branch-only difference under composition.

[Inferred] Required correction: describe the renderer as preserving existing A-303 glossary behavior, composing the branch's effectiveRun URL-supervised disclosure/data attributes/dossier.json metadata with incoming already-adopted A-308 mobile styles. Keep the source bytes unchanged. Freeze the corrected scope note and retain this original raw review rather than overwriting it. Current README.md SHA256 is 811a06bc8331cc038505a1394833d24591baafed7391fb5bfdc1ecd6f40de637.

## Source and stage checks

[Observed] The staged-path population has exactly 15 paths, matching both the complete manifest file set and the incoming delta path set from previous main08e1 to incoming main278. Each of the 15 current files matches its manifest byte count and SHA256; each equals its stage-0 index blob. git ls-files --stage over those paths has 15 stage-0 entries. git ls-files -u returns no entries; git diff --name-only returns no unstaged paths. Both copied source files in the frozen packet equal their current/index bytes.

[Observed] The 13 paths other than AGENT-ADOPTIONS.md and dossier-site.ts equal incoming main278 byte-for-byte, independently compared via git show. They are dossier-reading.browser.test.ts; the candidate grammar-diagnostics design; the settled-mobile-reflow evidence JSON; the two review-campaign pages; the six settled-reflow raw reviews; and the two grammar-diagnostics raw reviews. This establishes composition fidelity, not a new review or execution of those already incoming artifacts.

[Observed] All three frozen scoped patches match their manifest byte counts and digests. Independently running read-only git diff with the pinned subjects reproduces each patch exactly:

- incoming-scoped.patch: previous main08e1 to incoming main278, ledger and site; SHA256 b80059e5d91fa5effe11a020d9bcf93dcb72a989c4c25ef76bfa806665599e39.
- resolved-scoped.patch: first parent00f9 to staged index, ledger and site; SHA256 e81cbf207a30853b7d15026acb831315d4bef35fbfc51e00d4d06fd73b4d6efc.
- branch-before.patch: previous main08e1 to first parent00f9, site; SHA256 2db979b7cd43b62ea8f419e3c48f8e524a6fa49554d8fe29ea14c3a2dbfe321a.

## Adoption ledger preservation

[Observed] A regex sweep counts 242 existing adoption rows in the first parent and 243 in the staged result. A separate literal startswith sweep confirms both counts. More strongly, the complete first-parent ledger is a byte-for-byte prefix of the staged ledger, and the staged ledger equals that complete original byte sequence plus exactly the unchanged incoming A-308 row. The row comparison independently confirms every one of the 242 old rows remains byte-identical. Incoming main adds only A-308 against its own previous-main ledger (89 versus 88 rows). The single incoming A-308 row equals the staged final row exactly.

[Observed] Staged ledger: 251845 bytes, SHA256 792df5c39d4cd1282d4d7222b83afa9fd3a8751296a785c397bc197cecf043da. A-303 remains unchanged. Incoming A-308 cites commit 35694c659d71cb3f03bc5c2ac4726e47413da988, and that commit is an ancestor of incoming main278. Its row includes the revert command and existing evidence link. This integration does not relabel the adoption as an owner approval.

## Renderer composition

[Observed] Staged dossier-site.ts: 169731 bytes, SHA256 121711bff09f722a1c033c7c961adce16fbb6c582a4d4935952e57cd11759d7a. Staged dossier-reading.browser.test.ts: 32196 bytes, SHA256 21ec293e01f65e6d3e74cc65c8ee8b7469035329eb4eb8149ce1cc6f2746ba42.

[Observed] Against the common-base site, branch edits occupy four disjoint ranges around run disclosure/main attributes and dossier.json metadata. Incoming edits occupy four disjoint ranges in style assembly: code-path overflow-wrap:anywhere; the max-width:800px fixed citation popup; the seven-entry LOCAL_REFLOW_CSS map; and its insertion only into local chrome styles. The incoming site delta does not modify the glossary, provider transport, source admission, authentication, screening, execution, resource limits or specifications. In-memory reconstruction independently applied both parents' disjoint line edits to the common-base source and produced the staged source exactly. Comparing staged source to incoming source independently shows precisely the preexisting branch effectiveRun changes, with no additional renderer edit.

[Inferred] These comparisons support preservation of A-303's existing definition markup and exact glossary targets, the branch's existing URL-supervised effectiveRun disclosure/metadata behavior, and incoming A-308's mobile presentation rules. There is no composition-introduced product behavior beyond those parents' deltas. The grammar diagnostic design remains a candidate with no new implementation/source admission. No incoming openspec or doctrine path is changed in this 15-path population. Existing security boundaries are not rewritten by the composition.

## Authority and pending evidence

[Observed] VIS-4 states: “The owner adopts doctrine and decides four classes of change; agents decide everything else, record it and report it”. Its agent-adoption rule requires a commit-linked adoption row and a revert command when the change lands. A-308 is already recorded in main. The packet calls this ordinary agent integration, does not claim owner approval, and does not invent a new owner gate. The eventual integration's report/adoption record remains root's responsibility; this staged review does not supply a fabricated commit identity or certify completed adoption.

[Unknown] No browser, rendered-page, typecheck, canonical battery or full suite result is established for these staged bytes. Full final checks remain pending in the authorized execution lane. This is a review before creating the source merge commit. The current packet needs the scope-note correction in R1, while the source composition itself requires no change on this review's evidence.
