#!/usr/bin/env python3
"""Parse retained decoded text and existing local metadata/Git objects only."""
from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
SCRATCH = ROOT.parent
REPO = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
PR_HEAD = '9c878b13f5ea7b819b4817517c675810d4b0f23c'
JOB_ID = 138823853861
SOURCE = 'scripts/check_spec_reconciliation.py'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    log = ROOT / 'reconciliation-decoded.log'
    raw = log.read_bytes()
    text = raw.decode('utf-8')
    lines = text.splitlines()
    phases = []
    decoder = json.JSONDecoder()
    for marker in re.finditer(r'SELFTEST_PROFILE\s+(?=\{)', text):
        record, _end = decoder.raw_decode(text, marker.end())
        phases.append(record)
    # Independent line-based parser must recover precisely the same ordered rows.
    line_phases = [json.loads(line.split('SELFTEST_PROFILE ', 1)[1])
                   for line in lines if 'SELFTEST_PROFILE {' in line]
    assert phases == line_phases
    assert len(phases) == len({p['phase'] for p in phases}) == 57
    previous = json.loads((ROOT / 'earlier-frozen-hosted-timing-context.json').read_text())
    assert phases == previous['currentPhases']
    save('profile-extraction.json', {'decodedLogSha256': sha(raw), 'phases': phases,
                                    'independentParserEquality': True,
                                    'exactEqualityToEarlierFrozenProfile': True})
    terminals = [line for line in lines if 'SELFTEST PASS:' in line]
    assert len(terminals) == 1
    terminal = re.search(r'(\d+) of (\d+) mutants.*?; (\d+) of (\d+) controls.*?\(commit ([0-9a-f]+)\)', terminals[0])
    assert terminal
    numbers = [int(terminal.group(i)) for i in range(1, 5)]
    witnessed = []
    for line in lines:
        plain = re.sub(r'^\S+Z ', '', line)
        match = re.fullmatch(r'(killed|held|SURVIVED|BROKEN)\s+(\S+)\s+(.*?) \(failed: (.*?)\)', plain)
        if match:
            witnessed.append({'outcome': match[1], 'identity': match[2],
                               'expectedPrinted': match[3], 'failedPrinted': match[4]})
    independent = re.findall(r'\b(killed|held|SURVIVED|BROKEN) +[^ \n]+ +[^\n]*?\(failed: [^\n]*?\)', text)
    outcomes = collections.Counter(row['outcome'] for row in witnessed)
    assert len(witnessed) == len(independent) == 679
    assert outcomes == collections.Counter(independent) == {'killed': 566, 'held': 113}
    assert numbers == [566, 566, 113, 113]
    save('printed-witnesses.json', {'decodedLogSha256': sha(raw), 'rows': witnessed,
                                   'count': len(witnessed), 'outcomes': dict(outcomes),
                                   'independentCountAgreement': True,
                                   'limitation': 'Printed identities/expectations/outcomes only; no structured --witnesses artifact was emitted by this hosted command.'})
    executions = []
    for index, line in enumerate(lines[:-1]):
        if '[command]/usr/bin/git log -1 --format=%H' in line:
            match = re.fullmatch(r'\S+ ([0-9a-f]{40})', lines[index + 1])
            if match:
                executions.append({'sha': match[1], 'commandLine': index + 1,
                                   'valueLine': index + 2, 'command': line, 'value': lines[index + 1]})
    assert len(executions) == 1
    execution = executions[0]
    assert execution['sha'].startswith(terminal[5])
    lookup = subprocess.run(['git', 'show', '-s', '--format=%H%n%T%n%P', execution['sha']],
                            cwd=REPO, capture_output=True, text=True)
    pr_source = subprocess.check_output(['git', 'show', f'{PR_HEAD}:{SOURCE}'], cwd=REPO)
    metadata_file = ROOT / 'job-metadata.json'
    job = json.loads(metadata_file.read_text())
    assert job['id'] == JOB_ID
    assert job['head_sha'] == PR_HEAD and job['conclusion'] == 'success'
    save('job-metadata.json', job)
    local = {'exitCode': lookup.returncode, 'output': lookup.stdout.strip(),
             'error': lookup.stderr.strip()[:700], 'fetchPerformed': False}
    save('execution-commit-binding.json', {'testedExecution': execution,
                                          'terminalCommitPrefix': terminal[5],
                                          'associatedPrHead': PR_HEAD,
                                          'localObjectLookup': local,
                                          'prCheckerSourceSha256': sha(pr_source),
                                          'mergeTreeAndParentBinding': 'Unknown: merge object unavailable locally' if lookup.returncode else lookup.stdout.splitlines(),
                                          'mergeCheckerSourceEquality': 'Unknown: not inferred from PR head/job association'})
    summary = {'logRepresentation': 'UTF-8 bytes reconstituted exactly from cached GitHub connector decoded-log string; original HTTP bytes Unknown',
               'decodedLogSha256': sha(raw), 'decodedLogBytes': len(raw), 'decodedCharacters': len(text),
               'cachedStringSha256': sha((ROOT / 'cached-decoded-log-string.json').read_bytes()),
               'jobId': JOB_ID, 'runId': job['run_id'], 'associatedPrHead': PR_HEAD,
               'testedExecutionMerge': execution['sha'],
               'canonicalRule7Scope': 'The observed selftest PASS applies to the tested execution merge only; not automatically the PR head or any later candidate.',
               'profileCount': len(phases), 'profileTotalMs': next(p['elapsedMs'] for p in phases if p['phase'] == 'total'),
               'printedWitnessCount': len(witnessed), 'outcomes': dict(outcomes),
               'retainedJobMetadataSha256': sha(metadata_file.read_bytes()),
               'earlierFrozenTimingContextSha256': sha((ROOT / 'earlier-frozen-hosted-timing-context.json').read_bytes()),
               'metadataStartedAt': job['started_at'], 'metadataCompletedAt': job['completed_at'],
               'conclusion': 'selftest job succeeded, but its493-second job duration exceeded420 seconds; no workflow, PR or landing acceptance claim',
               'limits': ['Connector-decoded text binding is not an original HTTP-byte digest.',
                          'No Git fetch or checker/test execution performed.',
                          'Full merge parents/tree/source equality remain Unknown if local merge object lookup failed.',
                          'Printed679 rows do not replace missing structured --witnesses tuples/path/mutation bytes.',
                          'Earlier frozen timing packet remains unchanged; this is a portable provenance addendum.']}
    save('provenance-addendum.json', summary)
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode='wb', mtime=0, filename='') as zipped:
        zipped.write(raw)
    (ROOT / 'reconciliation-decoded.log.gz').write_bytes(compressed.getvalue())
    print(json.dumps({'packet': str(ROOT), 'decodedLogSha256': sha(raw),
                      'decodedLogBytes': len(raw), 'testedMerge': execution['sha'],
                      'mergeObjectAvailable': lookup.returncode == 0,
                      'profiles': len(phases), 'witnesses': len(witnessed),
                      'outcomes': dict(outcomes)}, indent=2))


if __name__ == '__main__':
    main()
