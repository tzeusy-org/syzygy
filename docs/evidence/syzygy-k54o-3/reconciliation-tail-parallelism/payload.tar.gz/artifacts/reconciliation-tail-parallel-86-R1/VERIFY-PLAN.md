# Deferred verification — do not execute before fresh source review/slot release

No helper, checker, test, benchmark or build was executed in preparing this source packet.

After review, root may apply exact source to its isolated committed verification clone and run the existing full command with existing optional metadata arguments:

    SELFTEST_PROFILE=1 python3 scripts/check_spec_reconciliation.py --selftest --witnesses NEW_OUTSIDE_WITNESS_PATH

This preserves the canonical --selftest command and does not add a filter. Retain stdout/stderr/profile, exact subject/tree/source SHA and elapsed time. Compare every ordered structured tuple(mutant,path,old,new,expected,failed,outcome) against exact86's retained736-witness JSON; compare counts independently against printed terminal/log identities. Read all outcomes. Do not count commit metadata equality as witness parity. A full PASS and actual new hosted timing are required, with no inferred420 guarantee.

Proportional isolated dispatch controls can extract only the existing executor/join/new adapter plus the candidate's five tail statements into a synthetic namespace, without importing any checker or executing real fixtures. Verify10 literal family tokens/argument shapes, canonical witness order under fixed noncanonical work order, workers1 fallback, unsupported-fork fallback, and a fork pool. Inject a worker exception and require original exception propagation plus parent state restoration. Inject missing, duplicate, noninteger and out-of-range canonical result indices and require the original join refusal. Full real witness parity remains separate and mandatory.

Meaningful sole-fragment mutants for those controls:

1. Remove `results.sort(key=lambda result: result[0] if type(result[0]) is int else -1)` -> synthetic canonical-order assertion must fail, rather than treating a generic error as a valid kill.
2. Change `_TAIL_WORK_ORDER = (9, 0, 1, 7, 8, 6, 3, 2, 5, 4)` to `_TAIL_WORK_ORDER = (9, 0, 1, 7, 8, 6, 3, 2, 5, 5)` -> exact join population must raise `RuntimeError('selftest task result population differs')`.
3. Change `arguments = (figure_base,) if family is poc_d10_cases else (tmp, figure_base)` to `arguments = (tmp, figure_base)` -> base-only poc synthetic signature must fail with its intended argument TypeError; full real poc family must not be skipped.
4. In only the new tail finally block, change `_EDITION_STATE = None` to `pass` -> caught worker-exception control must fail state-restoration assertion.

These are prepared source mutations, not executed results. No new canonical test declaration is proposed. Existing whole-family fixture/witness predicates own behavior; synthetic controls own dispatch/guard failures only.
