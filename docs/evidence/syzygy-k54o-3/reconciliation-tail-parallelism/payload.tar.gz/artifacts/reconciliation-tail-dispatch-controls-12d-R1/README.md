# Extracted tail dispatch controls — source preparation only

Exact committed subject12d52359459231612a4370ca18e35883f1795f8e; source SHA2569bf7e2736d0acf0534ae88a99d925f775df7b7b8b4078d47d3dc85ca9aeef104. No checker imports, real family bodies, repository mutation, tests/build/canonical execution or control execution occurred during preparation. Fresh source review and root's heavy-slot release precede execution.

The opt-in script reads the frozen full source only as bytes/AST. It compiles exactly five committed helper definitions, the literal work-order assignment, and the exact five tail-orchestration statements inside a tiny function with the original global declaration. No checker import or top-level checker statement executes. A registered types.ModuleType in sys.modules gives fork workers stable picklable identities. Ten distinct synthetic family functions replace real fixture bodies; poc_d10_cases has its real base-only signature and is the actual object selected by `family is poc_d10_cases`. A transparent profiler stub calls that synthetic function unchanged.

Eleven prepared controls: canonical full ten-family output/arguments for workers1, workers2/no-fork fallback, and fork2; missing/duplicate/string-index/bool-index/out-of-range result rejection with no partial publication; original synthetic worker-error propagation and parent state clearing in all three modes. Fork must be available for its control; an unavailable method fails rather than skips. Serial errors retain object identity; fork errors retain exact registered class/message, not unsupported cross-process object identity.

Four prepared sole-fragment mutants are fully retained with old/new fragments, committed source SHA and computed mutant SHA. Remove-sort and duplicate-order must raise exactly RuntimeError('selftest task result population differs') from the unchanged strict join. The poc-argument mutant must raise the exact intended positional-argument TypeError. Clear-removal first verifies the original worker error, then must fail AssertionError('TAIL_STATE_RESTORED'). No generic exception is accepted as a kill. Each executed result must also agree with its retained intended type/message. The remove-sort plan's earlier unreachable canonical-order failure is corrected here.

After fresh review and root slot release only:

    python3 dispatch_controls.py --output NEW_OUTSIDE_RESULT_JSON

The output path must not exist. The script binds itself, subject source, selected AST and mutation table; it writes one result JSON with actual11-control/four-mutant denominator and exact diagnostics. It does not import the checker or run a real fixture. This scope never substitutes for root's separate full canonical736-object ordered parity run or actual hosted timing. No new canonical test is added. All results in this packet remain Unknown/unexecuted until that explicit invocation.
