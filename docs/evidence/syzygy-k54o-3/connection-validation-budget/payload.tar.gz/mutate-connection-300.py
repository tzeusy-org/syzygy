from pathlib import Path
import subprocess, tempfile, os, json, hashlib, time
root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert subject.startswith('de00d5601') and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
out=Path('/home/orca/.tmp/f3-native-admission-fixes/connection-300-mutants');out.mkdir()
tmp=Path(tempfile.mkdtemp(prefix='f3-',dir='/home/orca/.tmp'));tmp.chmod(0o700)
env=os.environ.copy();env['TMPDIR']=str(tmp)
mutants=[('bridge-default','session-bridge.ts','milliseconds: 300_000','milliseconds: 180_000','integration','session-bridge.test.ts','preserves request bytes'),('transport-cap','session-machine-transport.ts','limits.milliseconds > 300_000','limits.milliseconds > 180_000','integration','session-machine-transport.test.ts','bounded ordered capture'),('whole-path-cap','url-ordered-design-work-budget.ts','enforcement.relayMilliseconds > 300_000','enforcement.relayMilliseconds > 180_000','unit','url-ordered-design-work-budget.test.ts','holds the whole path')]
results=[]
for label,file,old,new,tier,test,name in mutants:
 p=root/'packages/polaris-dossier/src'/file;b=p.read_bytes();assert b.count(old.encode())==1
 try:
  p.write_bytes(b.replace(old.encode(),new.encode()));start=time.time()
  with (out/(label+'.log')).open('wb') as f:r=subprocess.run(['node','node_modules/vitest/vitest.mjs','run','--project',tier,'--maxWorkers','1','packages/polaris-dossier/src/'+test,'-t',name],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  result={'label':label,'path':str(p.relative_to(root)),'subject':subject,'old':old,'new':new,'exit':r.returncode,'seconds':time.time()-start,'logSha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()};results.append(result);print(json.dumps(result),flush=True)
  assert r.returncode!=0
  assert "Failed Tests" in (out/(label+".log")).read_text()
 finally:p.write_bytes(b)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
