import subprocess, tempfile, os, json, hashlib, time
from pathlib import Path
root=Path('/home/orca/.tmp/f3-composed-fix-verify-2zcu1v00/w')
subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert subject.startswith('de00d5601') and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
out=Path('/home/orca/.tmp/f3-native-admission-fixes/connection-300-execution');out.mkdir()
tmp=Path(tempfile.mkdtemp(prefix='f3-',dir='/home/orca/.tmp'));tmp.chmod(0o700)
env=os.environ.copy();env.update(TMPDIR=str(tmp),VITEST_MAX_THREADS='1',VITEST_MIN_THREADS='1',VITEST_MAX_FORKS='1',VITEST_MIN_FORKS='1')
results=[]
def run(label,cmd):
 start=time.time()
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 result={'label':label,'command':cmd,'exit':r.returncode,'seconds':time.time()-start,'logSha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()};results.append(result);print(json.dumps(result),flush=True)
 (out/'results.json').write_text(json.dumps({'subject':subject,'tmp':str(tmp),'tmpMode':oct(tmp.stat().st_mode&0o7777),'results':results},indent=2)+'\n')
 return r.returncode
vitest=['node','node_modules/vitest/vitest.mjs','run','--maxWorkers','1']
base='packages/polaris-dossier/src/'
assert run('unit',vitest+['--project','unit',base+'session-profile.test.ts',base+'url-ordered-design-work-budget.test.ts'])==0
assert run('integration',vitest+['--project','integration']+[base+f for f in ['session-bridge.test.ts','session-relay.test.ts','session-machine-transport.test.ts','session-launch.test.ts']])==0
assert run('typecheck',['npm','run','typecheck'])==0
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
