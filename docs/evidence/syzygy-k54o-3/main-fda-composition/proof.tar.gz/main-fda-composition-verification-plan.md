# F3 / main composition: bounded verification plan

[Observed] Prepared by source inspection only; no command below was executed.
Subject: composition tree `861050427e7953040e611a4485c87faade10c75c`, F3
`89fe6d265d5e542d0b1c3d8d1927de708a9cc2d6` and main
`fda6daf1d752e8796a2723eb2866842b15fcbb50`. Fresh review must cover the final
applied source; if it changes, bind verification to that actual commit/tree.

## Prerequisites and isolation

- Run from the root of a fresh full-history clone at the actual installing
  source commit, outside the primary checkout. A tree-only export is inadequate:
  governance, marker checks, selftests and recorded historical subjects use Git
  history and HEAD. Record the actual commit/tree, command, output and exit.
- Run `npm ci` inside that clone before Node checks. Never inherit another
  checkout's workspace links or `dist` outputs. Typecheck uses source and needs
  no product build. Do not build merely to run these focused checks.
- Use Node 24.6.0; Linux `/proc`; Python with pidfd support; an unprivileged
  account. Pool tests need Linux/fork; reconciliation fixtures use Git, FIFOs
  and Unix filesystem facilities. Full canonical battery also needs PyYAML.
- Keep one heavy command active at a time; no simultaneous native recovery,
  mutation campaign, full unit run or Python selftest. Default pool limits
  remain unchanged (up to eight workers, `SELFTEST_TIMEOUT` default 3600 s;
  collection child 120 s/1 GiB). Do not extend deadlines or retry to green.
- Store logs/witnesses outside the clone and repository; inspect all output,
  skipped cases and denominators. Every failed attempt stays in the record.

## Focused sequence after fresh source review

All commands below run in that fresh clone, serially.

1. Record `git rev-parse HEAD` and `git rev-parse HEAD^{tree}`, then run:

   ```sh
   npm run typecheck
   node node_modules/vitest/vitest.mjs run --project unit apps/three-surface-poc/src/ci-selection.test.ts --allowOnly=false --passWithNoTests=false --retry=0
   ```

   [Observed] The selector file contains 14 `it` declarations. Require exactly
   that one file and 14 executed passing cases, no skipped-only file or retry.
   This direct focused Vitest form follows the existing TMPDIR driver's usage;
   `npm test -- <file>` is not a supported narrowing interface.

2. Exercise the retained lane router without running a scenario:

   ```sh
   node scripts/run_integration_lane.mjs --selftest
   node scripts/run_integration_lane.mjs --check
   ```

   [Observed] Selftest should report its control plus 14 rejected mutations.
   Current declared integration population is 146 distinct files; expected
   routing summary is 146 files, seven composed cases, core slices 48+48+49,
   and seven lanes. The 145 non-composed files occur exactly once; the composed
   file's three observer cases occur only in core-1 and four native cases each
   occur in their one named lane. `--check` compares actual Vitest discovery
   to `INTEGRATION_TESTS`, the composed-case filters and the workflow matrix.
   It performs discovery, not native scenario execution, and writes no receipt.
   This does not prove seven successful lanes or valid run receipts.

3. Run main's owning pool controls, then the checker components:

   ```sh
   python3 scripts/test_reconciliation_pool.py
   python3 scripts/check_spec_reconciliation.py --check
   python3 scripts/check_governance.py
   python3 scripts/check_governance.py --selftest
   python3 scripts/check_merge_conflict_markers.py
   python3 scripts/check_merge_conflict_markers.py --selftest
   python3 scripts/count_polaris_effective_scenarios.py --selftest
   ```

   [Observed] The pool file has 12 unittest methods; require `Ran 12 tests`
   and `OK` with no skipped tests. They own scope reuse/refusal, order,
   retained failures, fresh forks, SystemExit and dead-worker timeout behavior.
   `--check` must print all seven predicate results, not merely exit zero.
   The current generated census contains CAP1 42 requirements/57 scenarios,
   POC 32/61, PWB 17/63 and POLARIS 39/597 (130 requirements, 778 scenarios
   total). Compare output to the current complete census rather than a prior
   main count; v2.34's derived-base amendment is now part of the composition.
   Governance and scenario selftests must report their own actual populations;
   inspect every refusal/skip rather than assuming a fixed prior denominator.

4. Run the one heavier owning reconciliation selftest by itself:

   ```sh
   python3 scripts/check_spec_reconciliation.py --selftest --witnesses /home/orca/.tmp/f3-native-admission-fixes/main-fda-composition-selftest-witnesses.json
   ```

   [Observed] This is the canonical `--selftest` command with its existing
   witness-output option; choose another evidence filename if it exists.
   Require the clean, signed-addition and adopted-addition baseline passes,
   every emitted mutant killed by its named predicate and every control held.
   Inspect the witness population against the complete family table, including
   `vbase_cases`; reject duplicate/missing mutant identities or unexplained
   population differences. The prior 792 entries (639 mutants/153 controls)
   predate the new v2.34 family, so they are a historical baseline, not this
   candidate's required final denominator. Do not run a second heavy baseline
   merely for timing; compare output/evidence only when a concern requires it.

[Observed] Component commands above were selected from the candidate's actual
`PROJECT-STATUS.md` “How to verify this page” block (140 commands), except the
Node commands, which come from package scripts, the workflow and existing
selector evidence. This list is a scoped plan, not a replacement battery.

## Existing timing evidence and limits

| Check | Retained prior evidence | Planning implication |
|---|---|---|
| Pool controls | `docs/evidence/syzygy-7rkx/pool-mutation-2026-11-27.json`: clean baseline 7 s at `6d3f8f2a1...` | [Inferred] Seconds to a short minute under ordinary load; death controls intentionally wait 3 s twice. Their own bound assertions still apply. |
| Reconciliation selftest | `paired-selftest-2026-11-27.json`: repaired merged file 378.0 s with four workers at end load 33.81; earlier cleaner full-pair after 230.3 s | [Inferred] Reserve several minutes and exclusive heavy-job placement. Neither sample binds this larger composed tree or its default worker count. |
| Old checker before main pool | Same retained merged pair: 1038.6 s before, 378.0 s after | [Observed] Historical comparison only; do not restore or rerun the old checker merely to verify composition. |
| Selector/typecheck/lane discovery | No retained duration established by the inspected selector record | [Unknown] Duration until measured on the actual source. The selector record proves a prior selected run, not current timing. |

[Observed] Optional native prerequisite command is
`node scripts/check_dossier_native_integration.mjs`. It checks 11 prerequisites:
Linux x64/unprivileged account, exact Node and executable permissions, byte-pinned
Claude, Git HTTP helper and OpenSSH client, loopback SSH tools and `/run/sshd`,
compiler/zsh/Git, bubblewrap namespaces, prlimit, strace, and Python pidfd/proc.
It probes inert processes but does not launch Claude or a native scenario.
Package provisioning may need host privileges; do not change installed packages
or improvise another profile to make the plan pass. Actual native lane execution
continues under the separately authorized original recovery procedure and bounds.

## Later complete verification

[Unknown] Focused checks cannot establish genuine F3 recovery PASS, seven lane
success receipts, hosted seven-minute budget, or a complete repository battery.
`npm run check:all` remains deferred until genuine recovery PASS and the root's
complete-verification step. Its full integration/e2e tests launch product/native
fixtures; do not run it early under this source-composition plan.

[Observed] Before any eventual “battery green” claim, use the fresh actual-commit
clone and read the canonical block through its existing runner. For one command
at a time the existing interface is:

```sh
python3 scripts/run_status_battery.py --jobs 1
```

The default `npm run check:all` invokes the same runner with four concurrent
battery commands. If one-heavy-job placement is still required at that later
step, explicitly sequence the existing five check:all phases and use the runner's
`--jobs 1` option for the battery, recording the exact equivalent sequence;
do not silently run the default parallel battery. No new runner or framework is
needed. A passing scoped command never substitutes for the later full suite,
complete lane receipts or source-bound fresh-clone battery.
