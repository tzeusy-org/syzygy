# Optional PROCESS-LESSONS append draft — not applied

- PR metadata's `baseRefOid` does not establish the current default-branch tip.
  At the `2026-11-26T23:13:05.072587+00:00` observation of PR #839, metadata
  still named base `4b86e4285e7c78ddf049f64c9a3fd95fc0952cf3` and head
  `89fe6d265d5e542d0b1c3d8d1927de708a9cc2d6` while `git ls-remote`
  independently observed actual `refs/heads/main` at
  `fda6daf1d752e8796a2723eb2866842b15fcbb50`. Before deciding main is
  integrated, or interpreting CI status on that basis, inspect the live
  default-branch ref (`git ls-remote https://github.com/tzeusy-org/syzygy.git refs/heads/main`) separately from
  PR base metadata. This diagnoses ref identity; it does not establish the
  cause of CI absence/status and adds no new process gate. Evidence:
  `/home/orca/.tmp/f3-native-admission-fixes/main-fda-composition-proof-final-R1/payload/main-fda-current-ref-receipt.json`
  (SHA-256 `2f4a03adf73d0ad28f1a231b8569cb97b4f4ab36feea2b96ada26c1299556417`),
  and actual merge receipt
  `main-fda-composition-actual-commit.json` in that same source-proof folder.
  The merge's repository correction record is
  `docs/evidence/syzygy-k54o-3/main-fda-composition/README.md`. At installation,
  replace scratch evidence links with the root's actual retained proof path;
  no final archive path is invented here.
