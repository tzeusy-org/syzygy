import ast, hashlib, json, pathlib, re, subprocess
import yaml
O = pathlib.Path(__file__).resolve().parent
subject = json.loads((O / 'SUBJECT.json').read_text())
repo = '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w'
refs = {k: v['oid'] for k, v in subject['inputs'].items()}
tree = subject['candidateTree']
def git(*args):
    return subprocess.check_output(['git', '-C', repo, *args])
def paths(ref):
    return {row.split('\t')[1]: row.split('\t')[0] for row in git('ls-tree', '-r', '-z', ref).decode().split('\0') if row}
ours, main, candidate = (paths(refs['ours']), paths(refs['theirs']), paths(tree))
checks = []
def check(label, condition, detail=None):
    checks.append({'check': label, 'held': bool(condition), 'detail': detail})
    assert condition, label
class UniqueSafeLoader(yaml.SafeLoader):
    pass
def unique(loader, node, deep=False):
    pairs = loader.construct_pairs(node, deep=deep)
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate YAML key {key}')
        result[key] = value
    return result
UniqueSafeLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique)
workflow = yaml.load((O / 'resolved/.github/workflows/node-ci.yml').read_text(), Loader=UniqueSafeLoader)
jobs = workflow['jobs']
expected_lanes = ['core-1', 'core-2', 'core-3', 'complete', 'delivery-stop', 'stop-resume', 'eligible-stop-resume']
check('workflow parses with unique mapping keys', isinstance(jobs, dict))
check('all seven mandatory lanes and fail-fast false', jobs['integration']['strategy'] == {'fail-fast': False, 'matrix': {'lane': expected_lanes}})
check('each tier pins Node 24.6.0', all(next(step for step in jobs[tier]['steps'] if step.get('uses') == 'actions/setup-node@v4')['with']['node-version'] == '24.6.0' for tier in ['unit', 'integration', 'e2e']))
integration_runs = '\n'.join(str(step.get('run', '')) for step in jobs['integration']['steps'])
check('integration has no generic selected-tier execution', 'scripts/run_ci_tier.mjs integration' not in integration_runs)
check('integration executes one lane command', integration_runs.count('node scripts/run_integration_lane.mjs "$INTEGRATION_LANE"') == 1)
check('PR integration prints selector and explicit fallback', 'scripts/select_ci_tests.mjs' in integration_runs and 'Integration fallback:' in integration_runs)
main_workflow = yaml.load((O / 'theirs/.github/workflows/node-ci.yml').read_text(), Loader=UniqueSafeLoader)
for tier in ['unit', 'e2e']:
    selected_steps = [step for step in main_workflow['jobs'][tier]['steps'] if step.get('if') == "github.event_name == 'pull_request'"]
    check(f'main {tier} PR selector/selected steps preserved', all(step in jobs[tier]['steps'] for step in selected_steps), len(selected_steps))
for name in ['check_spec_reconciliation.py', 'test_reconciliation_pool.py']:
    path = O / 'resolved/scripts' / name
    ast.parse(path.read_text(), filename=str(path))
check('checker and main pool test parse as Python AST', True)
def functions(snapshot):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse((O / snapshot / 'scripts/check_spec_reconciliation.py').read_text()).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
mf, of, cf = (functions(n) for n in ['theirs', 'ours', 'resolved'])
for name in ['_run_scope', 'scoped_check_outcomes', '_map_cases', '_fork_map', '_selftest_timeout', '_selftest_workers', '_guarded', '_run_families', '_after_refusal_cases', 'vbase_cases']:
    check('main function preserved: ' + name, mf[name] == cf[name])
for name in ['_read_memo_scope', '_profile_selftest_call']:
    check('F3 function preserved: ' + name, of[name] == cf[name])
check('superseded F3 entry/edition scheduler absent', all(name not in cf for name in ['_run_edition', '_run_entry', '_join_case_results']))
critical_main = ['ci-selection.ts', 'scripts/select_ci_tests.mjs', 'scripts/run_ci_tier.mjs', 'scripts/check_unit_tmpdir.mjs', 'apps/three-surface-poc/src/ci-selection.test.ts', 'scripts/test_reconciliation_pool.py']
for path in critical_main:
    check('main file exact: ' + path, candidate[path] == main[path])
critical_ours = ['scripts/run_integration_lane.mjs', 'scripts/provision_dossier_native_cli.mjs', 'scripts/check_dossier_native_integration.mjs']
for path in critical_ours:
    check('F3 file exact: ' + path, candidate[path] == ours[path])
dossier = [path for path in ours if path.startswith('packages/polaris-dossier/')]
check('F3 entire dossier package bytes preserved', all(candidate.get(path) == ours[path] for path in dossier) and set(path for path in candidate if path.startswith('packages/polaris-dossier/')) == set(dossier), len(dossier))
frozen = [path for path in ours if path.startswith(('docs/reviews/', 'docs/evidence/'))]
changed_prior = [path for path in frozen if candidate.get(path) != ours[path]]
check('prior review/evidence changes limited to main generated census', changed_prior == ['docs/evidence/spec-readability-reconciliation-2026-10-02/census.json'] and candidate[changed_prior[0]] == main[changed_prior[0]], {'population': len(frozen), 'remainder': changed_prior})
check('every prior raw review unchanged', all(candidate.get(path) == ours[path] for path in ours if path.startswith('docs/reviews/')), len([path for path in ours if path.startswith('docs/reviews/')]))
ledger = (O / 'resolved/.syzygy/governance/decisions/AGENT-ADOPTIONS.md').read_text()
getrows = lambda text: {match.group(1): line for line in text.splitlines() if (match := re.match(r'\| (A-\d+) \|', line))}
cr = getrows(ledger)
check('279 distinct adoption rows, one each', len(cr) == 279 and len(re.findall(r'^\| A-\d+ \|', ledger, re.M)) == 279)
mr = getrows((O / 'theirs/.syzygy/governance/decisions/AGENT-ADOPTIONS.md').read_text())
orows = getrows((O / 'ours/.syzygy/governance/decisions/AGENT-ADOPTIONS.md').read_text())
check('every main adoption row unchanged', all(cr[key] == row for key, row in mr.items()), len(mr))
check('F3 row only renamed and otherwise exact', cr['A-323'] == orows['A-267'].replace('| A-267 |', '| A-323 |', 1))
check('every other F3 adoption row unchanged', all(cr[key] == row for key, row in orows.items() if key != 'A-267'), len(orows) - 1)
check('no conflict markers in candidate delta text', all(not re.search(rb'^(<<<<<<< |=======\r?$|>>>>>>> )', (O / 'resolved' / path).read_bytes(), re.M) for path in subject['deltaFromOursPaths']))
result = {'subjectTree': tree, 'kind': 'source-only static inspection; no imported repository code or execution checks', 'checks': checks}
(O / 'STATIC-VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
print(f'Static predicates held: {len(checks)}; no execution result claimed; subject tree {tree}')
