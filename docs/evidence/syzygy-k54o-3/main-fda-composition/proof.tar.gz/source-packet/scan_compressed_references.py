import pathlib, json, subprocess, gzip, tarfile, zipfile, io, re
O = pathlib.Path(__file__).resolve().parent
repo = '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w'
pop = json.loads((O / 'compressed-reference-population.json').read_text())
result = {'objects': len(pop), 'members': 0, 'uncompressedBytes': 0, 'hits': [], 'nestedCompressedMembersNotScanned': []}
rx = re.compile(rb'(?<![A-Za-z0-9])A-267(?![0-9])')
def scan(stream, path):
    total = count = 0
    previous = b''
    while True:
        chunk = stream.read(1024 * 1024)
        if not chunk:
            break
        data = previous + chunk
        cutoff = max(0, len(data) - 8)
        count += sum(match.start() < cutoff for match in rx.finditer(data))
        previous = data[cutoff:]
        total += len(chunk)
    count += sum(1 for _ in rx.finditer(previous))
    result['members'] += 1
    result['uncompressedBytes'] += total
    if count:
        result['hits'].append({'path': path, 'matches': count})
def scan_member(stream, path):
    if path.endswith(('.gz', '.zip', '.xz', '.bz2', '.zst')):
        result['nestedCompressedMembersNotScanned'].append(path)
    else:
        scan(stream, path)
for record in pop:
    data = subprocess.check_output(['git', '-C', repo, 'cat-file', 'blob', record['oid']])
    path = record['path']
    if path.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
            for member in archive:
                if member.isfile():
                    scan_member(archive.extractfile(member), path + '!' + member.name)
    elif path.endswith('.gz'):
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
            scan(stream, path)
    elif path.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for member in archive.infolist():
                if not member.is_dir():
                    with archive.open(member) as stream:
                        scan_member(stream, path + '!' + member.filename)
    else:
        raise ValueError(path)
(O / 'compressed-reference-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'nestedCompressedMembersNotScanned'}, indent=2))
print('Nested compressed members not scanned:', len(result['nestedCompressedMembersNotScanned']))
