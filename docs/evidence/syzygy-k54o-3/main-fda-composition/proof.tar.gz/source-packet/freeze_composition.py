import ast, collections, hashlib, json, os, pathlib, re, subprocess
O = pathlib.Path(__file__).resolve().parent
repo = '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w'
refs = {'base': '4b86e4285e7c78ddf049f64c9a3fd95fc0952cf3', 'ours': '89fe6d265d5e542d0b1c3d8d1927de708a9cc2d6', 'theirs': 'fda6daf1d752e8796a2723eb2866842b15fcbb50', 'conflicted': 'f3cd84b621fe21b6a38d6dd0a242c1d366872cad'}
def git(*args, data=None, env=None):
    return subprocess.check_output(['git', '-C', repo, *args], input=data, env=env)
def oid(ref, path):
    row = git('ls-tree', '-z', ref, '--', path)
    return row.decode().split()[2] if row else None
index_env = dict(os.environ, GIT_INDEX_FILE=str(O / 'candidate.index'))
git('read-tree', refs['conflicted'], env=index_env)
authored = sorted(p.relative_to(O / 'resolved').as_posix() for p in (O / 'resolved').rglob('*') if p.is_file())
for path in authored:
    blob = git('hash-object', '-w', '--stdin', data=(O / 'resolved' / path).read_bytes()).decode().strip()
    git('update-index', '--add', '--cacheinfo', '100644', blob, path, env=index_env)
tree = git('write-tree', env=index_env).decode().strip()
main_delta = git('diff', '--name-only', '-z', refs['base'], refs['theirs']).decode().split('\0')[:-1]
changed = git('diff', '--name-only', '-z', refs['ours'], tree).decode().split('\0')[:-1]
all_paths = sorted(set(main_delta + authored))
missing = []
for label, ref in refs.items():
    for path in all_paths:
        blob = oid(ref, path)
        if blob is None:
            missing.append({'snapshot': label, 'path': path})
            continue
        target = O / label / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(git('cat-file', 'blob', blob))
for path in changed:
    target = O / 'resolved' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(git('show', tree + ':' + path))
for name, left in [('composition-from-ours.patch', refs['ours']), ('resolution-only.patch', refs['conflicted'])]:
    (O / name).write_bytes(git('diff', '--no-ext-diff', '--no-textconv', '--binary', left, tree))
(O / 'absent-input-paths.json').write_text(json.dumps(missing, indent=2) + '\n')
metadata = {'kind': 'source-only candidate, not an execution or review verdict', 'inputs': {k: {'oid': v, 'tree': git('rev-parse', v + '^{tree}').decode().strip()} for k, v in refs.items()}, 'candidateTree': tree, 'mainDeltaCount': len(main_delta), 'mainDeltaPaths': main_delta, 'authoredResolutionPaths': authored, 'deltaFromOursCount': len(changed), 'deltaFromOursPaths': changed, 'primaryHEADAtFreeze': git('rev-parse', 'HEAD').decode().strip(), 'primaryStatusAtFreeze': git('status', '--short').decode(), 'notRun': ['product', 'build', 'native', 'tests', 'fixtures', 'repository imports'], 'newInstallingAdoption': 'deferred until root actual source commit; no fabricated commit'}
(O / 'SUBJECT.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({k: metadata[k] for k in ['candidateTree', 'mainDeltaCount', 'authoredResolutionPaths', 'deltaFromOursCount', 'primaryHEADAtFreeze', 'primaryStatusAtFreeze']}, indent=2))
