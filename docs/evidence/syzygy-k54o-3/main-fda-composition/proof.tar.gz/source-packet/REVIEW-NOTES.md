# Source-only composition R1

[Observed] Candidate tree: `861050427e7953040e611a4485c87faade10c75c`.
Inputs, exact 51 main paths, exact 52 paths from F3 and original tree identities
are in `SUBJECT.json`. No commit, ref, primary index or checkout was changed.

Authored resolution paths:

- `.github/workflows/node-ci.yml`
- `.syzygy/governance/decisions/AGENT-ADOPTIONS.md`
- `CONTRIBUTING.md`
- `docs/evidence/syzygy-k54o-3/main-fda-composition/README.md`
- `scripts/check_spec_reconciliation.py`

[Inferred] Semantic choices for independent review:

1. Preserve main selector/selected unit/e2e behavior. PR integration prints the
   plan and explicitly falls back to the whole seven-lane F3 denominator,
   including native setup and commit-specific success receipts. This spends
   CI efficiency; the adopted time budget still needs hosted evidence. Never
   run the whole selected integration tier once in each matrix cell.
2. Preserve main's entire family isolation/timeout/bare-outcome run-scope
   implementation and its exact tests. Keep F3's optional preparation/prefix/
   family profiling and memo scopes for standalone read invocations. Drop the
   superseded F3 entry/edition scheduler rather than nesting its pool inside
   main's fresh daemon workers. Existing worker/resource limits are unchanged.
3. Preserve main's A-267 derived-base 2.34 row and all four live references.
   Reassign the unlanded F3 pidfd row to unused A-323; change no other field.
   A correction addendum scopes the old identity without rewriting raw evidence.
4. Carry every other automatic merge result, including main's spec-only
   derived-base amendment and its generated census; add no runtime field bridge.
   Main's new selector tests, pool tests and selectors retain exact main bytes.
   F3's dossier package, lane router, native prerequisite checker and provisioner
   retain exact F3 bytes. Existing F3 raw reviews and archives are unchanged.

[Observed] `STATIC-VERIFICATION.json` retains 39 static structural/equality
predicates and their denominators. The prior evidence/review population has
one expected differing blob: main's generated
`docs/evidence/spec-readability-reconciliation-2026-10-02/census.json`, retained
exactly from main. Existing raw review bytes do not change.

[Observed] `adoption-collisions.json` compares complete common ledger rows:
one collision, A-267; the ledger populations are 278 F3 and 103 main. The two
reference text files are exact-token tracked-text output. Compressed-reference
population/results declare the 104-object, 3,309-member direct archive sweep
and its 33 unsearched nested-compressed members. This bounds the census;
no absence claim is made about that remainder.

[Unknown] No runtime, test, fixture, native, product or build result exists
for this candidate. Fresh independent source review is required before source
application. The root's later actual source commit must carry the installing
adoption row and report the integration-efficiency tradeoff; no future hash
or new version tag was invented. There is no new owner-class decision.

`composition-from-ours.patch` is the complete 52-path candidate diff.
`resolution-only.patch` changes only the five authored paths over the
conflicted merge tree. The source snapshots preserve absent paths explicitly
in `absent-input-paths.json`. `SHA256SUMS` binds every retained packet file
except itself; `DIFF-PATH-MANIFEST.json` additionally binds all candidate delta
blobs. Nothing in this packet executes repository code.
