"""Prepared, unexecuted runner. Use only after fresh review in an isolated clone."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
PRIMARY = Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w').resolve()
def digest(data):
    return hashlib.sha256(data).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('checkout', type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
checkout = args.checkout.resolve()
if checkout == PRIMARY or PRIMARY in checkout.parents:
    raise SystemExit('Refuses the shared primary; prepare an isolated verification clone.')
out = args.output.resolve()
if out == checkout or checkout in out.parents:
    raise SystemExit('Evidence output must be outside the verification checkout.')
out.mkdir(parents=True, exist_ok=False)
plan = json.loads((ROOT / 'validation-plan.json').read_text())
parents = json.loads((ROOT / 'parents.json').read_text())
expected = {}
for name in parents['baselineByFile']:
    data = (ROOT / 'candidate' / name).read_bytes()
    if (checkout / name).read_bytes() != data:
        raise SystemExit(f'Candidate source mismatch: {name}')
    expected[name] = digest(data)
subject = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
results = {'subjectCommit': subject, 'sourceSha256': expected, 'runs': [],
           'limitation': 'Only listed owning cases and exact mutants; no native end-to-end or timing acceptance claim.'}

with tempfile.TemporaryDirectory(prefix='native-coverage-controls-', dir=out) as temporary:
    os.chmod(temporary, 0o700)
    environment = dict(os.environ, TMPDIR=temporary)
    def execute(identifier, project, files, title=None):
        report = out / f'{identifier}.vitest.json'
        command = [str(checkout / 'node_modules/.bin/vitest'), 'run', '--project', project,
                   '--maxWorkers', '1', '--reporter=json', '--outputFile', str(report), *files]
        if title:
            command += ['-t', title]
        with (out / f'{identifier}.log').open('wb') as log:
            process = subprocess.run(command, cwd=checkout, env=environment,
                                     stdout=log, stderr=subprocess.STDOUT, timeout=180)
        record = {'id': identifier, 'argv': command, 'exit': process.returncode,
                  'logSha256': digest((out / f'{identifier}.log').read_bytes())}
        if report.exists():
            actual = json.loads(report.read_text())
            record['denominator'] = {key: actual.get(key) for key in ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'numRuntimeErrorTestSuites']}
            assertions = [assertion for suite in actual.get('testResults', [])
                          for assertion in suite.get('assertionResults', [])]
            record['failedAssertions'] = [assertion.get('fullName') for assertion in assertions if assertion.get('status') == 'failed']
            record['passedAssertions'] = [assertion.get('fullName') for assertion in assertions if assertion.get('status') == 'passed']
        results['runs'].append(record)
        (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        return record
    for index, run in enumerate(plan['owningRuns']):
        record = execute(f'baseline-{index + 1}', run['project'], run['files'])
        if record['exit'] or not record.get('passedAssertions'):
            raise SystemExit('Baseline did not establish passing assertions; inspect retained output.')
    for mutant in plan['mutants']:
        file = checkout / mutant['file']
        original = file.read_bytes()
        text = original.decode()
        if text.count(mutant['old']) != 1:
            raise SystemExit(f'Exact mutation target mismatch: {mutant["id"]}')
        altered = text.replace(mutant['old'], mutant['new']).encode()
        record = None
        try:
            file.write_bytes(altered)
            record = execute(mutant['id'], mutant['project'], [mutant['testFile']], mutant['title'])
            record['mutation'] = {**mutant, 'beforeSha256': digest(original), 'afterSha256': digest(altered)}
            # Assertion failures require human inspection: a fixture timeout/load
            # error is not evidence for the intended predicate.
            record['status'] = 'assertion-failed-inspect-cause' if record['exit'] and record.get('failedAssertions') else 'UNESTABLISHED'
        finally:
            file.write_bytes(original)
            if digest(file.read_bytes()) != expected[mutant['file']]:
                raise SystemExit('Source restoration failed')
            (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        if record['status'] == 'UNESTABLISHED':
            raise SystemExit('Mutation evidence unestablished; inspect output before continuing.')
print(json.dumps({'subjectCommit': subject, 'runs': len(results['runs']), 'output': str(out),
                  'status': 'Terminal; inspect every mutation failure cause before claiming detection.'}))
