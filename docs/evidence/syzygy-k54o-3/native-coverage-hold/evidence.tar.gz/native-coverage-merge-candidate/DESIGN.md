# Native coverage merge candidate R2 — source only

Subject parents are exact ours `7af36744b8f02ac25a3cd0a0b056c3f42398e024`
and main `a9fe89c0d20dab58de29483d1a3c7a717b79fb6e` (A-305). This is
an outside candidate, not the primary worktree, a commit, an adoption or a
completion claim. `parents.json` identifies the effective baseline of every
file. New main's coverage helper and its test use the main baseline; other
files use ours. Missing snapshots mean that file does not exist at that parent.

## Behavior and authority

[Observed] A-14 adopts URL dossier 2.1 and its local-machine credential
amendment. Its REQ-polaris-generation-025 requires complete request origins,
binding, classification, detector and durable audit checks. REQ-048's fixed
scopes are source_read, artifact_read, artifact_write, dossier_step and
inference-forward, restricted by role/kind and original run. None is widened.
The fixed typed-run-control-and-clarification species permits strict
host-created work-history controls, gives no new source authority, and requires
admitted source origins/classes for embedded source quotes. The exact policy
and spec bytes are retained in references; exact adoption rows are retained.

[Observed] A-305 adopts coverage-hold 2.28 over effective 2.18. The adopted
035 scenario says: “it submits the notice under the returned pair and records
it as sent once both pane operations succeed” (spec lines 327–328). It also
says “if literal input succeeds and Enter fails, the supervisor reports the
unsubmitted notice and sends no further coverage text into that live pane”
(336). Its bounded notice permits omitted descriptions with a count (341).

[Inferred / proposed agent adoption] F3 has no pane write/Enter transport.
Those literal operations cannot truthfully be claimed for this native path.
The native adapter accepts an exact author-only coverage-held event only after
the existing publication current checks and durable metadata audit accept and
the checked event is queued. That outcome means audited queue acceptance,
not that a role polled, read, understood or repaired it. Publication false ends
the native run's dependent work through its existing fail-closed runtime.
There is no false fidelity verdict and no fake delivered fidelity packet.
The literal pane scenario remains an explicit adapter difference requiring
the coordinator's agent adoption under A-14/A-305 before use; no governed
specification is edited by this packet.

R2 native notices contain only fixed host bookkeeping, selected numeric
revisions and the number of omitted descriptions. Every description is
omitted and counted. IDs, paths, source quotes and arbitrary report strings
are not copied into work-history. Named reasons remain in the separately
checked coverage refusal/check advice; this packet does not assert those
ephemeral advice bytes are persisted. Repair uses only artifact_write of
drafts/next.json and the existing dossier_step check argv from the role's
launch instructions. The notice carries no host path or shell command.

## Minimal coupled changes

* polaris.ts starts from exact ours. The native loop uses CoverageHoldNotices
  with its closed native-control delivery mode. The helper receives the exact
  protected session-prompt result, and publication receives its selected pair.
  A held pair suppresses packet reattempts, does not mark a packet delivered,
  and ends blocked if that current draft's repair cycles are spent. Changed
  pairs still take the original protected delivery path.
* coverage-hold.ts keeps its legacy formatter, repair command, synchronous
  pane sender and five-attempt/unsubmitted semantics. Its sender can now be
  awaited and receives the selected pair. Only native-control mode uses the
  count-only notice. Sync legacy callers keep the default pane mode.
* session-control.ts adds one closed author-only coverage-held event with
  bounded numeric revisions and a nonempty valid Unicode message of at most
  4,000 UTF-16 units. Existing complete canonical/decoded/composition body and
  secret scans, current checks, audit, deduplication, reservations and finite
  capacities apply. Metadata-only audit retains only event digest/count.
* Polling returns a complete ordered prefix of at most sixteen events and
  at most one coverage notice. It stops before a second coverage notice;
  that event and all following events remain queued. It stages, validates and
  screens the delivery copy before synchronous closed/fault recheck and
  dequeue. Existing asynchronous current verification precedes staging;
  there is no new await between staging and dequeue. Successful polls do not
  truncate or drop events. Existing intentional queue clearing on a poisoned
  control/close remains unchanged.
* url-role-plan.ts adds author-only guidance that this is bookkeeping, not a
  verdict; repair goes through the existing constrained tools, never a shell.
* url-supervisor-state.ts admits exactly coverage-held-D/I notification keys
  with the existing revision bounds. Without this coupling, successful native
  notice persistence would fail the existing codec. No state format or
  migration is added; existing list, byte, node, ownership and file guards stay.

Four existing test files are extended; there are still 58 test declarations
in those files. No existing test title or matrix declaration is removed.
The incoming main coverage-hold-flow integration cases remain untouched and
must also be run after review (they protect the incumbent broker/pane form).

## Guard, profile and recovery preservation

[Observed, structural] The parser proof preserves all 31 other direct native
loop statements, its setup and final render/reproduction closures, and every
other top-level polaris declaration. Protected fidelity step arguments,
product-read construction/finally cleanup, fresh runtime.current refusal and
packet registration remain. Other role feedback, source, stop, admission,
rendering, final-product and authority paths are not rewritten.

Control bounds remain 65,536 bytes / 512 nodes / depth 8; maxEvents 256,
maxQueuedPerRole 64, ordinary poll count 16. Static independent closed-schema
arithmetic gives a conservative 32,960-byte / 272-node / depth-5 reply bound
with one maximum-size notice and fifteen maximum metadata events. See
envelope-proof.json. The actual numbered maximum metadata alternative is
264 bytes. No timer, parent/slack, profile budget or scope is increased.

Ordinary profile 2, ordered profile 9 and their fixed bridge/MCP inputs are
unchanged. Trusted author prompt bytes change, so their compiled profile
digest changes. The host bundle graph already captures all transitive inputs;
coverage-hold is a new host dependency and is captured, not hand-waved away.
Input-tree and derived registry/controller identities must be regenerated by
the normal build. Existing stopped-run profile/configuration/registry mismatch
checks remain fail-closed. An old runtime is not migrated into these bytes.
Actual regenerated identities and compiled-output equality are Unknown until
the coordinator builds and verifies the exact adopted source.

## Verification and limits

[Observed] Source-only TypeScript parsing reports no syntax diagnostics for
nine files. The exact structural comparisons and arithmetic scripts/results
are retained, and candidate.patch passes git apply --check against its frozen
mixed baseline outside the repository. These are not typechecking or tests.

[Unknown] Owning runtime tests, mutation outcomes, typecheck, native held-pair
behavior and hosted timing at the eventual merged commit. No test, build,
capture, provider request or heavy command was run for this packet. Prepared
commands and exact mutants are in validation-plan.json. Fresh independent
source review and owning checks precede adoption/publication. A genuine native
coverage fixture through the actual loop is still needed before claiming that
end-to-end behavior observed; helper/control assertions do not establish it.

R1 is retained under revisions/R1 as a rejected author draft: it copied reason
descriptions into a work-history control. No independent review or execution
was claimed for R1. R2 narrows that payload instead of creating a new receipt
protocol or masking unknown provenance.
