Historical author draft, revised before independent review. Native message copied producer reason descriptions into work-history. R2 uses count-only host bookkeeping. Never adopted or executed.
