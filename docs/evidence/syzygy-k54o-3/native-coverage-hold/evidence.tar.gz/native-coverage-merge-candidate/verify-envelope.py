"""Static closed-schema arithmetic; does not import or execute project code."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
metadata = [
    {"event": "draft-ready", "revision": 999999, "sequence": 256},
    {"event": "inventory-repair", "revision": 999999, "sequence": 256},
    {"event": "review-blocked", "review": "fidelity", "revision": 999999, "sequence": 256},
    {"event": "review-blocked", "review": "design", "revision": 999999, "sequence": 256},
    *({"event": "run-terminal", "outcome": outcome, "sequence": 256}
      for outcome in ["completed", "refused", "stopped", "Unknown"]),
    {"event": "design-round-prepared", "round": 999999,
     "path": "round-999999/design-view.json", "packetSha256": "a" * 64,
     "viewSha256": "b" * 64, "sequence": 256},
]
maximum = max(len(encoded(event)) for event in metadata)
assert maximum < 512
coverage = {"event": "coverage-held", "draftRevision": 999999,
            "inventoryRevision": 999999, "message": "", "sequence": 256}
assert len(encoded(coverage)) < 256
envelope = {"reply": {"ok": True, "kind": "session-control", "state": "events", "events": []},
            "classes": ["work-history"], "originIds": ["url-control:host:" + "a" * 64]}
assert len(encoded(envelope)) < 512
# JSON escaping uses at most six ASCII bytes per UTF-16 unit. This also safely
# covers non-ASCII, surrogate pairs and permitted tab/CR/LF characters.
bound = 6 * 4000 + 256 + 15 * 512 + 1024
# Count both object keys and values as nodes, which is conservative whichever
# side the project's parser charges. All events have at most six properties.
nodes = 16 * (1 + 2 * 6) + 64
assert bound < 65536 and nodes < 512
report = {"kind": "static arithmetic, no project execution", "metadataVariantsEnumerated": len(metadata),
          "largestNumberedMetadataBytes": maximum, "conservativeReplyBytes": bound,
          "existingMaxBytes": 65536, "conservativeNodes": nodes, "existingMaxNodes": 512,
          "conservativeDepth": 5, "existingMaxDepth": 8, "coverageMessagesPerPrefix": 1,
          "maximumPrefixEvents": 16,
          "scope": "Six closed event variants; all enum alternatives enumerated; revisions/round and sequence use existing maximums. No bound increase."}
(ROOT / "envelope-proof.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
