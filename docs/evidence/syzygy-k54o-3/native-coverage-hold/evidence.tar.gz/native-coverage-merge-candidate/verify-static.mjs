// Source parsing only: this imports TypeScript, never project modules or tests.
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const checkout = process.argv[2] ?? '/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w';
const ts = createRequire(path.join(checkout, 'package.json'))('typescript');
const hash = value => createHash('sha256').update(value).digest('hex');
const assert = (value, reason) => { if (!value) throw new Error(reason); };
const parents = JSON.parse(readFileSync(path.join(root, 'parents.json'), 'utf8'));
function parsed(side, name) {
  const bytes = readFileSync(path.join(root, side, name));
  const source = ts.createSourceFile(name, bytes.toString('utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert(source.parseDiagnostics.length === 0, `${side}/${name}: parse diagnostic`);
  return { bytes, source };
}
function shape(node) {
  const children = node.getChildren().filter(child => child.kind !== ts.SyntaxKind.EndOfFileToken);
  return [ts.SyntaxKind[node.kind], children.length ? children.map(shape) : node.getText()];
}
const digest = node => hash(JSON.stringify(shape(node)));
function visit(node, callback) { callback(node); ts.forEachChild(node, child => visit(child, callback)); }
function declarations(source) {
  const result = new Map();
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) || ts.isClassDeclaration(statement) || ts.isInterfaceDeclaration(statement) || ts.isTypeAliasDeclaration(statement)) {
      if (statement.name) result.set(statement.name.text, digest(statement));
    }
    if (ts.isVariableStatement(statement)) for (const item of statement.declarationList.declarations) if (ts.isIdentifier(item.name)) result.set(item.name.text, digest(item));
  }
  return result;
}
function tests(source) {
  const result = [];
  visit(source, node => {
    if (!ts.isCallExpression(node) || !node.arguments[0] || !ts.isStringLiteralLike(node.arguments[0])) return;
    const expression = node.expression;
    const direct = ts.isIdentifier(expression) && ['it', 'test'].includes(expression.text);
    const matrix = ts.isCallExpression(expression) && ts.isPropertyAccessExpression(expression.expression)
      && ts.isIdentifier(expression.expression.expression) && ['it', 'test'].includes(expression.expression.expression.text)
      && expression.expression.name.text === 'each';
    if (direct || matrix) result.push(node.arguments[0].text);
  });
  return result;
}
const files = {};
for (const name of Object.keys(parents.baselineByFile)) {
  const before = parsed('baseline', name), after = parsed('candidate', name);
  const old = declarations(before.source), current = declarations(after.source);
  const unchanged = [], changed = [];
  for (const [key, value] of old) (current.get(key) === value ? unchanged : changed).push(key);
  const record = { baselineCommit: parents.baselineByFile[name], beforeSha256: hash(before.bytes), afterSha256: hash(after.bytes),
    unchangedTopLevelDeclarations: unchanged, changedTopLevelDeclarations: changed,
    addedTopLevelDeclarations: [...current.keys()].filter(key => !old.has(key)), parseDiagnostics: 0 };
  assert(!after.bytes.toString().includes('<<<<<<<') && !after.bytes.toString().includes('>>>>>>>'), `conflict marker ${name}`);
  if (name.endsWith('.test.ts')) {
    record.beforeTestTitles = tests(before.source); record.afterTestTitles = tests(after.source);
    assert(JSON.stringify(record.beforeTestTitles) === JSON.stringify(record.afterTestTitles), `test declaration population changed ${name}`);
  }
  files[name] = record;
}
const name = 'packages/polaris-dossier/src/polaris.ts';
const oldStages = parsed('baseline', name).source.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'runUrlStages');
const stages = parsed('candidate', name).source.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'runUrlStages');
assert(oldStages && stages, 'native stage loop missing');
const getLoop = node => node.body.statements.find(ts.isForStatement);
const beforeLoop = getLoop(oldStages), afterLoop = getLoop(stages);
assert(beforeLoop && afterLoop, 'native for loop missing');
const isCoverage = node => node.getText().includes('fidelityDeliveryDue(');
const isPhase = node => node.getText().startsWith('phase = repairing');
const unchangedLoop = loop => loop.statement.statements.filter(node => !isCoverage(node) && !isPhase(node) && !node.getText().startsWith('let heldPair = false;')).map(digest);
assert(JSON.stringify(unchangedLoop(beforeLoop)) === JSON.stringify(unchangedLoop(afterLoop)), 'unrelated native loop statement changed');
const oldTop = oldStages.body.statements.filter(node => node !== beforeLoop).map(digest);
const newTop = stages.body.statements.filter(node => node !== afterLoop && !node.getText().startsWith('const coverage = ')).map(digest);
assert(JSON.stringify(oldTop) === JSON.stringify(newTop), 'unrelated native stage setup or render closure changed');
const fidelityCall = source => {
  const calls = [];
  visit(source, node => {
    if (ts.isCallExpression(node) && node.expression.getText() === 'step'
      && node.arguments[0]?.getText() === "['--json', 'session-prompt', run, 'review', '--kind', 'fidelity']") calls.push(digest(node));
  });
  return calls;
};
assert(JSON.stringify(fidelityCall(oldStages)) === JSON.stringify(fidelityCall(stages)), 'protected fidelity step arguments changed');
const criticalFragments = [
  "const products = beginRunProductReads(run, context.artifacts, 'review-packet', deadline, context.runtime.waitForProductSamples);",
  'finally { products.close(); }',
  "if (r.exit !== 0 || r.doc === null || !(await context.runtime.current())) { phase = 'fidelity packet delivery refused'; break; }",
  "try { await context.artifacts.registerPacket({ kind: 'fidelity', round: r.doc['round'] as number, packetSha256: r.doc['packetSha256'] as string },\n          context.runtime.waitForProductSamples); }",
];
const oldText = oldStages.getText(), newText = stages.getText();
for (const fragment of criticalFragments) assert(oldText.includes(fragment.replace('          context.runtime', '        context.runtime')) && newText.includes(fragment), `critical fidelity guard absent: ${fragment}`);
const control = parsed('candidate', 'packages/polaris-dossier/src/session-control.ts').source.getText();
const baselineControl = parsed('baseline', 'packages/polaris-dossier/src/session-control.ts').source;
const candidateControl = parsed('candidate', 'packages/polaris-dossier/src/session-control.ts').source;
for (const variable of ['BOUNDS', 'URL_CONTROL_LIMITS']) {
  assert(declarations(baselineControl).get(variable) === declarations(candidateControl).get(variable), `control bound changed ${variable}`);
}
assert(control.includes('const result = deliver(') && control.indexOf('const result = deliver(') < control.indexOf('queue.splice(0, count)'), 'dequeue precedes screened delivery copy');
const coverageBefore = parsed('baseline', 'packages/polaris-dossier/src/coverage-hold.ts').source;
const coverageAfter = parsed('candidate', 'packages/polaris-dossier/src/coverage-hold.ts').source;
for (const item of ['fidelityCoverageHold', 'coverageHoldMessage', 'submitCoverageNotice', 'COVERAGE_NOTICE_ATTEMPTS']) {
  assert(declarations(coverageBefore).get(item) === declarations(coverageAfter).get(item), `incumbent coverage behavior changed ${item}`);
}
const report = { mode: 'source-only TypeScript parser and structural comparison; no project execution', parents,
  files, loop: { preservedDirectLoopStatements: unchangedLoop(beforeLoop).length, preservedSetupAndRenderStatements: oldTop.length,
    protectedFidelityCallAst: fidelityCall(stages), exactFidelityFragments: criticalFragments }, controls: { boundsUnchanged: true, dequeueAfterCheckedCopy: true },
  limitation: 'Parser/AST checks do not establish type correctness, runtime outcomes, or genuine native coverage completion.' };
writeFileSync(path.join(root, 'static-proof.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(JSON.stringify({ files: Object.keys(files).length, parseDiagnostics: 0,
  testDeclarationsBefore: Object.values(files).reduce((sum, item) => sum + (item.beforeTestTitles?.length ?? 0), 0),
  testDeclarationsAfter: Object.values(files).reduce((sum, item) => sum + (item.afterTestTitles?.length ?? 0), 0),
  preservedLoopStatements: report.loop.preservedDirectLoopStatements }) + '\n');
