import { defineConfig } from 'vitest/config';
export default defineConfig({ test: {
  root: "/home/orca/.tmp/f3-native-admission-fixes/actual-registry-cleanup-controls-c140-execution-1/candidate-order", include: ['registry.test.ts'],
  setupFiles: ["/home/orca/.tmp/f3-native-admission-fixes/actual-registry-cleanup-controls-c140-execution-1/candidate-order/actual.setup.ts"],
  maxWorkers: 1, fileParallelism: false, isolate: true,
  testTimeout: 5000, hookTimeout: 5000,
} });
