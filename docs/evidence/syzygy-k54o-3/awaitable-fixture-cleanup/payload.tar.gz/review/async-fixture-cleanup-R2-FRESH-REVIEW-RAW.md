# Async fixture cleanup: bounded R2 source review

Verdict: PASS

This verdict accepts the reviewed source/control design. It is not an executable check result or full acceptance of the change.

Subject: c140a3528a9780212cc9b267d20099e218fd1dba.
Original candidate patch SHA-256: f3cdc6078b9bd96cf31546167c80e1fd7f76c53888d8d4a6ca9b737ba033cec8.
Control packet: /home/orca/.tmp/f3-native-admission-fixes/actual-registry-cleanup-controls-c140.
Control manifest SHA-256: a8e5192b4cbab21c3f5c6135fbe4b718bf169315cf8876f407ca4472977df0c3.
Prior review: /home/orca/.tmp/f3-native-admission-fixes/async-fixture-cleanup-FRESH-REVIEW-RAW.md, SHA-256 025ff391332abc3457d6b445e8fdca4ff051c371c9b40151940ee748054298df.

## F1 disposition

[Observed] The control packet supplies concrete source for the missing actual-registry control. run-controls.mjs:40-50 writes the frozen candidate setup into the isolated case directory and configures it as Vitest setupFiles; it does not reconstruct the registry dispatcher. The candidate setup copy is byte-identical to the original reviewed vitest.setup.ts, SHA-256 ff6204123fefeb3ffd874f7451edaa037a9924e742a401b0cd526d3d3a4f2b85.

[Observed] registry-order.test.ts:10-19 registers an older checker and a newer callback which suspends, then records completion and registers a third callback. The checker requires exactly Bstart, Bend, C before writing the receipt. run-controls.mjs:75-82 independently checks the receipt's subject, case, setup digest and exact final four-event sequence. This makes completion, LIFO order and live registration observable through the actual registry.

[Observed] registry-throw.test.ts:7-12 registers an older forbidden-receipt writer and a newer callback that rejects asynchronously with a distinctive error. run-controls.mjs:84-91 distinguishes the candidate's failed file with that rejection and no forbidden receipt from the swallowed-rejection mutant's successful file with the forbidden receipt. A red result alone is insufficient.

[Observed] The runner constructs seven isolated cases: two candidate controls and five exact source mutations. It checks one test and one file in the JSON report, file status, process exit, absence of timeout/signal errors, relevant markers and receipts before satisfying a predicate. It retains stdout, stderr, Vitest JSON, per-case predicate results and aggregate results. The manifest binds the six input files; raw mutation fragments and mutated setup digests remain reconstructible.

[Observed] A static hash/fragment sweep examined all six manifest entries and all five mutations: each file matches its declared digest, each old fragment occurs exactly once, and the predecessor mutant yields bytes identical to predecessor.setup.ts (SHA-256 038306b28cc5eb1212f8a44e4c2e347c31f46720be464e642143c38d945f3732). These are source-integrity observations, not executed mutant outcomes. The original three candidate files also still match their previously reviewed digests.

[Inferred] The concrete controls resolve F1's missing-reviewable-control finding. Removing await or restoring the predecessor reaches the checker before Bend/C; detached iteration reaches it without C; FIFO reaches it before the newer callback; swallowing rejection creates the forbidden receipt and removes the required failure. Thus each planned mutant targets the behavior that motivated the control, rather than an unrelated collection failure. Fixed delays only cause suspension; no assertion compares elapsed time.

[Inferred] This bounded outside fixture avoids adding another canonical integration test file. The canonical test delta remains the original +5 unit tests in +1 file. The isolated harness intentionally launches separate Vitest processes and belongs outside the hermetic unit tier; it does not change or bypass the repository unit guard for those five unit tests. No additional source revision is requested.

## Execution boundary and remaining acceptance

[Observed] This R2 review performed source reads, hash computation and static fragment comparison only. It executed no Vitest, fixture, build, product, provider or archive code, and edited no root file. The existing heavy battery was not disturbed. The source-only packet's executed=false remains an accurate report.

[Unknown] Whether the seven control predicates actually satisfy, whether installed Vitest emits the assumed JSON shape, and whether candidate/unit/render/typecheck runs pass remain unestablished. The original render afterAll timeout's cause, any speed improvement, and complete-suite success remain unproven.

Required next steps, after the exclusive heavy battery finishes:

1. Execute this exact frozen harness with the intended installed dependency checkout and a fresh outside output directory. Retain every case's artifacts and inspect the seven-case denominator and expected pass/failure/receipt combinations. Unexpected infrastructure or report-shape failures require diagnosis, not a claimed killed mutant. Verify setup and packet digests again at execution time.
2. Execute the original owning and new temp-dir unit files with the actual unit guard, typecheck, and the owning integration file packages/polaris-dossier/src/render.test.ts under the existing 30000 ms hook budget. Preserve output and failures. Run the previously requested helper-specific controlled mutants for await, live Set iteration and failure retention; the actual-registry controls supplement those controls rather than replacing them.
3. Complete the repository's required full verification for the exact final subject and adoption/reporting requirements. A previous concurrent battery that lacks these bytes does not accept this change. Keep all attempts/dispositions; do not retry until green or infer that asynchronous cleanup proves the original failure's cause.

[Inferred] The source review now passes, with F1 resolved at the concrete artifact level. Full acceptance is still pending those executable checks, under CC-TEST-1's regression requirement and CC-TEST-2's retained-artifact requirement.
