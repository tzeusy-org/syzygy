PASS

# Independent source review: narrow R4 helper-mutant diagnostic correction

[Inferred] PASS for source preparation. Replacing the two unsupported path-prefix diagnostic expectations with the exact observed cardinality assertion messages preserves the intended mutation predicates and incidental-error refusal guards. This is not an R4 execution pass.

[Observed] Subject: /home/orca/.tmp/f3-native-admission-fixes/tempdir-helper-mutant-controls-9319-R4. Manifest SHA256 3cdea422036f788eb5886df93c38bc2ca9bef7483dd9656ba9e2fc3b040dc248. R3-to-R4.patch SHA256 8fc5cab02d858c08f590af2f7b2e77fbe71e00b0f1cdbbbf86ac5bf449afc300. Source commit remains9319c199223dc02817cd7332e2104969ff8e5e72. Review inspected actual R3/R4 packet bytes, both prior independent source PASS reports, the retained R3 result/JSON/audit receipts, and the unchanged predicate implementation. No helper, runner, test, build, native program or supplied control was executed; no repository mutation occurred. Only read-only inspection, git show, hashing/data comparisons and this outside raw-report write were performed. The engineering/test-rigor and evidence rules apply.

[Observed] Recomputed the16 manifest file entries and both supplied subject digests; they match. The predecessor manifest equals actual R3 manifest df9326b167e88f4eebfbc72d5fd24840d03623e624cd6c514486896dfd806295. Independently generating a unified diff from actual R3/R4 mutants.json reproduces R3-to-R4.patch exactly. Comparing all five mutation records finds only two changed fields: snapshot-live-set.diagnostic and forget-before-removal.diagnostic. Every test title, old/new fragment, mutant SHA256, assertion text and line remains unchanged. Runner, reporter, canonical helper/test/setup bytes equal R3 exactly. Historical git show at9319 independently matches all three source bindings. All five old fragments are unique and produce their declared mutant hashes; all five declared assertion texts occur on their exact lines.

[Observed] The two new diagnostics are the complete observed assertion-message text after the standard AssertionError prefix, retained as exact string fragments:

- snapshot-live-set: expected [ …(2) ] to deeply equal [ …(3) ], at temp-dir.test.ts:55. It identifies the two removal calls versus the literal expected three calls including the concurrently registered directory.
- forget-before-removal: expected [ Array(1) ] to deeply equal [ …(2) ], at temp-dir.test.ts:69. It identifies the single retry call versus the literal expected failed-and-unresolved pair.

[Observed] Each retained R3 JSON selected assertion has exactly one failureMessages entry containing its respective new diagnostic and its declared assertion line. These texts match R4 verbatim after JSON decoding. The new mutants.json is ASCII-only and spells the ellipses using escaped Unicode. Its SHA256 is26f278e1c953db726a88403f2600a7b64c2d0add21b2694b096d78c3e28b7203.

[Inferred] Specificity is retained by the combination of exact source mutation/hash, one selected test title, exact assertion line, the complete cardinality message and unchanged error/denominator/exit predicates. No generic deep-equality failure, unrelated test failure, timeout or hook error is newly admitted. The canonical assertions still compare the exact path arrays, so the runner is consuming their reporter's truncated diagnostic rather than weakening the test itself.

[Observed] Unchanged run-mutants.py:113-149 requires one file/five assertions, one selected title, four skipped, exact pass/fail/pending/todo counters, exactly one selected failure message for mutants, no excluded-test messages, empty file-level error message, expected file status, structured callback/task/hook error populations, clean streams, expected child exit and no timeout. The revised strings are still combined with exact temp-dir.test.ts line matching. Vitest remains pinned to3.2.7. The R2/R3 exclusive scratch guard, exact HEAD/current/historical binding checks, owned-child settlement, exact-byte restoration and TMP cleanup implementations are unchanged; this narrow review does not re-execute those paths.

[Observed] Retained R3 execution /home/orca/.tmp/f3-native-admission-fixes/tempdir-helper-mutants-9319-R3-execution-1/result.json has SHA256 fab530510c07fd28def0f31ea6722c79f06d13e521f4f46bed6c8970dcab3d17. It reports total8/satisfied6; independently counting its eight result records reproduces both values. Three baseline records pass. Each of five mutant records has one failed selected test/four skipped/zero passed and its intended assertion location. Snapshot-live-set and forget-before-removal remain satisfied:false solely at their diagnosticMatched:false field, with the other recorded error/exit/location/denominator checks true. The per-case predicate receipts equal their entries in the aggregate result. This review does not relabel those two R3 controls as passed.

[Observed] For the two affected R3 cases, actual supplemental audit JSON has both callbacks present, empty callback error lists, one error-bearing test task containing one error, and no failed hooks; stderr is empty. Their receipts record sourceRestored:true, childReaped:true and tmpCleanup:removed. Those are historical receipts rather than a fresh claim about current checkout state or interruption handling.

| Retained R3 artifact | SHA256 |
|---|---|
| snapshot-live-set/vitest-result.json | aa9ab78a4c5ff6c5bed5baea51366738d9eda7fa65e10b7bad90945c01ddd3a5 |
| snapshot-live-set/predicate-result.json | b4571c4d48d2f6c7b6d445f10834ed612accd0b25e4d55b5725c1fe9372110b3 |
| forget-before-removal/vitest-result.json | 3fec5b0d5f25801a9ef7e397b71875fe54f88c0948db9745f9c743dc6d678de3 |
| forget-before-removal/predicate-result.json | a13ebcd6609f4342aface97880a988a4a381bdf62c16dc63cdfbec4eb68b0d02 |

[Unknown] Actual R4 three-baseline/five-mutant rerun, final score and cleanup outcomes remain pending. Historical R1 REVISE, R2 pre-test SGID failure and R3 six/eight results remain retained. This PASS is limited to the frozen R4 source preparation above; a later edit retires it.
