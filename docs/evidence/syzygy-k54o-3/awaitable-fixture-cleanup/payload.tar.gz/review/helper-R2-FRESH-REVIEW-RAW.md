PASS

# Fresh independent source review — R2 temporary-directory helper mutation controls

[Inferred] PASS for source preparation. The four R1 findings are addressed in the reviewed R2 source. This verdict authorizes no runtime-success claim and does not establish actual mutation kills or interruption outcomes.

[Observed] Reviewed subject: /home/orca/.tmp/f3-native-admission-fixes/tempdir-helper-mutant-controls-9319-R2. Manifest SHA256: e0effd641e96d9cff887a644c6a2d20419f0aa08946a1fde6acd67cb6663e04d. Source commit: 9319c199223dc02817cd7332e2104969ff8e5e72. Intended disposable execution checkout: /home/orca/.tmp/f3-native-admission-fixes/native-coverage-merge-execution/w, expected HEAD 00f9c6f821baf83eac0dada118afdccc0e524088. This review did not guard or certify that checkout's live status while its profiler is active.

[Observed] Scope was inspection only: packet source, retained R1 raw review, installed Vitest 3.2.7 reporter/runner source, hashing, byte comparisons, and historical git show reads. No runner, tests, builds, native programs, imports of reviewed sources, profiler interaction, or repository mutation occurred. The only write was this outside raw review. The test-rigor skill supplied the behavioral assertion and failure-quality bar.

## Frozen bindings

[Observed] Recomputed all seven manifest file entries; their digests match the manifest. Recomputed the manifest digest independently with Python hashlib and sha256sum; both produced the subject digest above. Direct byte comparisons show the helper, five-case canonical test file, setup, and mutants.json equal R1. The retained R1-FRESH-REVIEW-RAW.md is byte-identical to the original R1 REVISE raw. Historical git show at the frozen source commit independently matches each of the three source bindings.

| Artifact | SHA256 |
|---|---|
| run-mutants.py | bdf127058d6099df660369e016cc74ac4ba4962b078c9ea263a9fec8fc93ddd2 |
| error-audit-reporter.mjs | 8d8eb476528b898e50273e400270038fa81ba01e17127caebc4ce5faefe75b35 |
| mutants.json | 7acbda5787648b5be7f3f81d37cf68169911905a2d8a8dfa6687e5a0fa3d003b |
| packages/test-kit/src/temp-dir.ts | 790e6d40bf3c805cae8bb4487d58f5d800272299e82b2b12eac0e412a5c10dcd |
| packages/test-kit/src/temp-dir.test.ts | d0f67bf89e24a3a3f48020047797d20cd63ec0a5737d51d24de67e2bbd19bc79 |
| vitest.setup.ts | ff6204123fefeb3ffd874f7451edaa037a9924e742a401b0cd526d3d3a4f2b85 |

[Observed] Across five declared mutants, each old fragment occurs once, each exact old/new replacement has the declared mutant digest, and each exact assertion fragment occurs on its declared test line. These checks inspected data and bytes; they did not execute mutants.

## R1 finding resolution

1. [Inferred] R1 reporter denominator is fixed. run-mutants.py:119-124 requires five assertions, one selected title, four skipped, and the expected one passed or failed assertion, with total/pending/todo/passed/failed counters matching. Installed Vitest is pinned to 3.2.7 at :35-36. Installed @vitest/runner/dist/chunk-hooks.js:1030-1033 marks name-filtered tests skip; vitest/dist/chunks/index.VByaPkjc.js:1678-1685 maps skip to skipped and :1708 counts skipped tests in numPendingTests. The new denominator matches that implementation. Three distinct selected baselines precede five mutant cases (:215-222).

2. [Inferred] R2 incidental-failure acceptance is fixed. run-mutants.py:125-149 requires exactly one selected failureMessages entry for mutants, none for baselines, no excluded-test messages, empty file-level message, expected file status, exact selected assertion line, original diagnostic fragments, expected child exit, and no timeout. The supplemental reporter recursively records file/suite/test result errors and failed hook states (error-audit-reporter.mjs:8-26). Its two callback error arrays must be empty; nonselected task errors and failed hooks reject the case (:129-134). An intended assertion accompanied by an afterEach error produces extra selected errors/messages; afterAll or suite errors populate another task/file; unhandled errors populate the separately retained callback arrays. Missing/corrupt reports or reporter exceptions cannot satisfy evaluation. Extra stdout/stderr also rejects (:135-149).

   [Observed] Installed Vitest calls onTestRunEnd and onFinished at cli-api.DVe0nWUx.js:8886-8896 and supplies the structured errors to both. Its JSON reporter discards _errors at index.VByaPkjc.js:1765-1766, confirming why the supplemental reporter is needed. JSON failureMessages derive from task.result.errors (:1731); file message derives from file.result.errors (:1744). Its success receipt is the exact string checked by R2 (:1780). Reporter callbacks here are synchronous writes to shared module state; either callback ordering retains both callback fields by the time both have completed.

3. [Inferred] R3 scratch ownership is fixed for cooperating runners. run-mutants.py:240-248 requires the explicit disposable-checkout assertion, resolved scratch paths, a new output outside the checkout, and rejection of the bound primary source repository. :251-261 obtains a nonblocking exclusive flock keyed by checkout realpath before constructing Runner or invoking the initial guard. The descriptor stays open through all case cleanup, final guards, and result writing, and its inode is never unlinked. :40-46 retains full HEAD, clean status, and historical/current source bindings before and after cases. Exact-byte replacement (:47-60) refuses detected drift and performs no reset or stash. PREPARATION-RAW.md explicitly scopes the lock to cooperating runners and requires exclusive lane assignment; noncooperating writers are outside that guarantee. The active profiler must finish before execution is assigned this checkout.

4. [Inferred] R4 cleanup sequencing is fixed. run-mutants.py:155-164 establishes active case ownership before allocating TMP and blocks catchable signals until allocation bookkeeping is recorded. Intended source bytes are recorded before replacement (:182-184). Catchable signals are deferred across Popen assignment (:187-197), without inheriting a blocked signal mask into the child. The per-case finally calls cleanup_case (:205-207); cleanup blocks repeat catchable signals and settles the owned child before source restoration (:78-112). settle_child uses the owned new-session process group, TERM then KILL escalation, communicate and wait (:61-77). If settlement fails, restoration is not reached; recovery is recorded and TMP retained. Restoration accepts only exact original/intended bytes and refuses unrelated changed bytes (:88-107). Whole-run finally retries incomplete active-case recovery while still holding the lock (:223-230). TMP is deleted only within the owned recorded directory after settlement/restoration. SIGKILL/host-crash limits are documented in PREPARATION-RAW.md.

## Assertion meaning and remaining evidence boundary

[Inferred] Each mutant targets a meaningful observable behavior in the unchanged canonical test source: omit-rm-await reaches the call-count assertion at temp-dir.test.ts:50 before release; snapshot-live-set omits the concurrently registered directory from the expected call population at :55; swallow-rm-failure violates rejects.toBe at :65; forget-before-removal loses the failed directory from the retry call population at :69; public-sync-becomes-async violates the immediate existence check at :77. Expected path arrays and booleans are literal behavioral expectations rather than values copied from helper internals. Mutation count and exact assertion bindings remain unchanged from R1.

[Inferred] Transform, import, startup, timeout, extra hook/suite/unhandled, or report failures cannot independently count as a kill under the combined selected-assertion, diagnostic/location, exact error-population, stream, and exit predicates. A failure to produce the promised diagnostic formatting rejects the control rather than being accepted as a mutation kill.

[Unknown] Actual baseline status/counters, callback serialization, diagnostic wording, process interruption behavior, cleanup, runtime outcomes, and mutant score remain unexecuted. This PASS is limited to the frozen source packet above. A later edit retires this source verdict; runtime evidence must bind its own actual subject bytes and commit.
