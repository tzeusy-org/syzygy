REVISE

# Fresh source review: temporary-directory helper mutation controls

[Inferred] REVISE. Four source-level findings prevent accepting this runner packet. The mutation ideas and original-source bindings are sound; the runner needs corrections before execution.

[Observed] Subject: /home/orca/.tmp/f3-native-admission-fixes/tempdir-helper-mutant-controls-9319. Reviewed actual run-mutants.py, mutants.json, manifest.json, PREPARATION-RAW.md, helper, tests, setup, and the installed Vitest reporter/selection implementation. No test, runner, native program, build, provider operation, heavy gate, or repository mutation was executed. Only inspection, git show/status/rev-parse, hashing, and this outside raw-report write were performed. Engineering-bar and test-rigor govern this review. Findings below are static inferences tied to observed source, not observed runtime failures.

## Frozen bindings

[Observed] Source commit is 9319c199223dc02817cd7332e2104969ff8e5e72 in /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w. The current checkout is now 00f9c6f821baf83eac0dada118afdccc0e524088 and reports an empty git status --short; historical comparisons used git show at the specified 9319 commit, not current HEAD.

| Artifact | SHA256 |
|---|---|
| manifest.json | e5efa88cc842621f59ed21b35fe00f7a3bbc715648eb399eaf0e77912568770f |
| run-mutants.py | 512985ac4c806f6fec75fb3b01154bed1492cf85897ba8d80f03a81f50933fb0 |
| mutants.json | 7acbda5787648b5be7f3f81d37cf68169911905a2d8a8dfa6687e5a0fa3d003b |
| packages/test-kit/src/temp-dir.ts | 790e6d40bf3c805cae8bb4487d58f5d800272299e82b2b12eac0e412a5c10dcd |
| packages/test-kit/src/temp-dir.test.ts | d0f67bf89e24a3a3f48020047797d20cd63ec0a5737d51d24de67e2bbd19bc79 |
| vitest.setup.ts | ff6204123fefeb3ffd874f7451edaa037a9924e742a401b0cd526d3d3a4f2b85 |

[Observed] Recomputed the five manifest file digests: each matches. Independently retrieved the three original files with git show 9319:<path>: each digest matches its binding and each byte sequence equals the packet copy. For each of the five mutants, the old fragment occurs exactly once, applying the exact replacement produces its declared mutant SHA256, and the declared assertion text occurs on its exact declared test line. The three distinct selected tests are among the five real cases in the bound test file.

## Findings

1. [Inferred] R1 — The denominator rejects the installed reporter's actual filtered-test status (run-mutants.py:110-118).

   The runner counts only assertion status pending and requires four such assertions. Installed Vitest 3.2.7 sets a test excluded by testNamePattern to mode skip (node_modules/@vitest/runner/dist/chunk-hooks.js:1030-1033); its JSON reporter maps skip to skipped (node_modules/vitest/dist/chunks/index.VByaPkjc.js:1678-1685, 1725-1731). Its top-level numPendingTests includes skipped tests (:1708), but the individual assertion status remains skipped. Therefore a healthy selected baseline with four excluded cases fails this runner's denominator, stopping before mutations.

   Fix: validate one selected executed assertion plus exactly four excluded assertions with the actual skipped status; also validate the corresponding top-level totals and no unexpected statuses. Update the preparation claim, which currently promises four pending assertions. This is an exact schema correction, not a relaxation of failure evidence.

2. [Inferred] R2 — The kill predicate can accept an intended failure accompanied by incidental failures (run-mutants.py:107-124).

   Concatenating every selected failureMessages entry and checking fragments/location does not require exactly one failure. An intended assertion failure plus an afterEach failure still has one failed selected test and can satisfy every checked condition. The runner also ignores testResults[0].message, which this installed JSON reporter fills from file.result.errors[0] (:1742-1744), so a file-level afterAll error can accompany a counted kill. More broadly, this JSON reporter's onFinished explicitly discards _errors (:1765-1766), while Vitest sets exit code 1 for unhandled errors (cli-api.DVe0nWUx.js:9893-9894). Exit 1 plus the expected assertion is thus insufficient to exclude an unrelated unhandled error. PREPARATION-RAW.md's statement that an extra hook failure does not count is unsupported by the predicate.

   Fix: require exactly the one intended selected assertion failure, reject file/suite/hook errors, and retain/check a structured unhandled-error population using an outside reporter or equivalent existing structured event interface. Keep exact assertion location and diagnostic checks. A JSON-only report that drops the unhandled-error list cannot certify that population absent.

3. [Inferred] R3 — Clean status is not an exclusive scratch-ownership guard (run-mutants.py:16-37, 48-59, 63-65).

   The path check admits every checkout under /home/orca/.tmp and guard_clean only samples HEAD/status/source bytes. There is no lock or explicit ownership marker. Two runner processes can pass guard_clean on the same clean checkout; one may change the helper after the other's check, or one may restore it while the other child is still reading it. compare-before-replace protects some overwrites but does not prevent executing against the other runner's bytes or the compare/replace race acknowledged by the preparation. The sourceRepository checkout itself is also admitted if passed explicitly; the runner does not distinguish the shared primary checkout from its dedicated disposable execution clone.

   Fix: hold a nonblocking checkout-specific exclusive lock from before the initial guard through child settlement, source restoration and final guards. Require an explicit dedicated disposable-checkout marker/ownership assertion and reject the bound source repository path. Preserve refusal on concurrent byte drift; do not reset or stash anything. Document that the lock coordinates cooperating runners and that the checkout must remain assigned to this lane.

4. [Inferred] R4 — Error cleanup does not quiesce the child before restoring source, and TMP allocation precedes its cleanup scope (run-mutants.py:68-85, 94-102, 125-138).

   SIGTERM/SIGKILL escalation runs only for subprocess.TimeoutExpired. A KeyboardInterrupt or another exception after Popen enters finally, which restores the helper first at :128-130 and only then checks child.poll at :131. A running child is left alive and TMP retained; the child can continue after its source has been changed back. An interrupt between replace_exact at :88 and active_mutant assignment at :89 can also leave the mutation outside the restoration flag. Separately, errors while validating a fragment/digest or writing helper-source.ts/subject.json occur after mkdtemp but before the try, so that TMP has no cleanup finally.

   Fix: establish the ownership/cleanup scope immediately after allocation; track the intended installed bytes before attempting replacement; on every catchable error, terminate and reap the owned process group before restoring the helper, then clean or explicitly retain the owned TMP with a durable error record. Keep exact-byte restoration guards so a concurrent edit is preserved. If the child cannot be settled, retain the source/TMP conflict for operator recovery and do not claim successful restoration/cleanup. No process cleanup can promise recovery from an uncatchable SIGKILL, so document that boundary honestly.

## Positive review evidence and limits

[Inferred] The five intended predicates are meaningful: unawaited removal reaches the call-count assertion before releasing the gate; snapshot iteration omits the concurrently registered directory; swallowed rejection violates rejects.toBe; deleting before a failed removal loses the retry directory; asynchronous public cleanup violates the immediate existence check. Exact fragment/digest/assertion bindings are stronger than a generic nonzero exit. Actual diagnostic wording and runtime behavior remain unverified.

[Observed] The runner verifies a full caller-supplied HEAD, clean git status, and current plus historical digests before each case and after successful cleanup. Atomic replacement preserves the original mode and refuses mismatching bytes. Per-case source restoration and whole-run restoration are attempted with exact expected bytes. These are useful safeguards but do not discharge R3/R4.

[Unknown] No runtime control outcome is established by this review. The packet is preparation-only. Corrected runner and manifest bytes require a fresh review; these original bindings and this verdict must remain retained.
