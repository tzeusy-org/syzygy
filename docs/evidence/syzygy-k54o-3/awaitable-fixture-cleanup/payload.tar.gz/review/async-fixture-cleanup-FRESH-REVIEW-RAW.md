# Fresh source-only review: async fixture cleanup

Verdict: REVISE

Subject: baseline c140a3528a9780212cc9b267d20099e218fd1dba; candidate directory `/home/orca/.tmp/f3-native-admission-fixes/async-fixture-cleanup-c140-candidate`.
Patch SHA-256: f3cdc6078b9bd96cf31546167c80e1fd7f76c53888d8d4a6ca9b737ba033cec8
Manifest SHA-256: 4ad1b3dc173e538148c14475ff1fb78e2d1a4aa6bfccf5b609a1d9194f5e2564

[Observed] Source hashes match the manifest: vitest.setup.ts ff6204123fefeb3ffd874f7451edaa037a9924e742a401b0cd526d3d3a4f2b85; packages/test-kit/src/temp-dir.ts 790e6d40bf3c805cae8bb4487d58f5d800272299e82b2b12eac0e412a5c10dcd; packages/test-kit/src/temp-dir.test.ts d0f67bf89e24a3a3f48020047797d20cd63ec0a5737d51d24de67e2bbd19bc79. Both predecessor hashes were independently checked against the specified baseline files and match the manifest.

## Scope and governing references

[Observed] Reviewed the three frozen candidate files and patch, baseline counterparts, existing nearest test-kit tests, the owning render test's fixture wiring, the other implementation consumer of the file hook, Vitest configuration/tiering and the unit guard. Read the baseline AGENTS.md operating procedure, engineering-bar and test-rigor skills, CC-TEST policy, and trust-and-evidence doctrine. AGENTS.md is operating procedure, not substantive authority. No candidate review notes were opened. A broad hook-name source search also returned incidental old review snippets; they were not used as findings or acceptance authority.

[Observed] No tests, real fixture execution, build, product execution, provider execution, archive-code execution, or root edits were performed. Only source inspection and hash computation were performed; this raw report is written outside the repository.

## Finding F1 — required actual-registry control is not reviewable yet

Severity: medium; blocks acceptance of the changed teardown contract, not the cleanup algorithm design.

[Observed] `vitest.setup.ts:20-25` changes the real registry to await callbacks, pop them in reverse registration order, and drain callbacks registered during an await. Each new test instead installs a replacement registry (`packages/test-kit/src/temp-dir.test.ts:20-24`, and the fallback test at `:81`) and manually invokes a captured temp-dir callback (`:32`, `:49`, `:65`, `:68`). The five controls therefore never exercise the actual changed setup registry.

[Inferred] Restoring the predecessor setup while retaining the candidate temp-dir helper leaves these five controls able to pass: their direct callback invocation still returns and awaits the helper's promise. Likewise, reversing registry order, snapshotting away live additions, or swallowing callback errors would evade these controls. This is a material seam for file completion and cleanup; it is not protected merely by testing the helper in isolation.

The governing requirement is CC-TEST-1: "A defect fix includes a test that fails on the pre-fix behavior and passes on the fixed behavior"; canonical test-rigor rules 1-3 require behavior-focused regression and failure-path coverage. Engineering-bar's definition of done also requires exercised behavior and a regression test that fails on old behavior.

Required revision: supply a small, reviewable isolated fixture/harness outside the canonical suite that is bound to and executes the actual candidate setup bytes. It must prove awaiting, reverse callback order, live registration during an await, and rejection propagation. Its planned mutant controls must distinguish the predecessor setup, removing await, changing reverse order, detaching live callbacks, and swallowing errors. No new canonical integration test file or unrelated framework is required. Preserve the frozen three-file candidate until the added harness is independently reviewed; adding the harness does not establish any execution result.

## Source assessment apart from F1

[Inferred] Sequential `await rm(...)` followed by Set deletion is consistent with the stated intended behavior: successful removals stop being tracked, failed and not-yet-attempted removals remain available for explicit retry, and Set iteration includes a directory inserted while an earlier removal is pending. Public `removeTempDirs` remains synchronous and immediately effective; the non-Vitest exit handler still receives the synchronous function. Nothing here increases the hook timeout or claims greater total removal speed.

[Inferred] The live LIFO registry preserves reverse registration order, awaits both synchronous and asynchronous callbacks, and includes callbacks registered while another callback is awaited. On a thrown/rejected callback it remains fail-fast, as the predecessor was; it does not promise automatic retry or successful execution of older remaining callbacks. The helper's direct retry control is not evidence that the actual registry retries a failed callback.

[Inferred] The five unit controls each have an identifiable role: completion plus real removal, bounded sequential/live-directory removal, partial-failure retention and explicit retry, synchronous API compatibility, and synchronous exit fallback. Net canonical suite delta is +5 tests in +1 file. The synchronous control overlaps the nearest existing creation/removal test but adds the return-contract assertion; it is small compatibility protection rather than an unrelated new scenario family.

[Observed] Filesystem-only operations fit the repository's hermetic unit tier, whose guard explicitly allows local filesystem work. The process.once spy intercepts exit registration and delegates other events without starting a process. Global stubs and module state are restored/reset after tests. Installed Vitest source shows restoreAllMocks calls mockRestore, which resets one-shot implementations; this addresses the mocked rm queue-isolation concern for this pinned environment. No guard weakening is proposed. Existing synchronous hook consumers remain compatible with the widened callback type.

[Unknown] Typechecking, executable mock isolation, actual registry behavior, owning render behavior, and full-suite acceptance have not been established by this review. The original render afterAll timeout's cause and any improvement in wall time remain unproven.

## Required verification after the exclusive heavy battery is no longer running

1. Review the added actual-registry harness bound to the exact setup digest above. Execute it against the candidate and retain output. Exercise await completion, reverse order, live callback registration, and error propagation. Keep its own observer/cleanup independent from the callbacks under test so missing cleanup cannot manufacture a passing assertion.
2. Execute controlled registry mutants for predecessor setup, removed await, forward order, detached live callbacks, and swallowed error. Each relevant predicate must fail for its own stated reason. Retain exact old/new fragments, subject commit/digests, command, output, and disposition; a failure during collection or unrelated infrastructure refusal is not a killed predicate.
3. Run the existing owning unit file and the new temp-dir file with the unit guard active using focused repository Vitest commands. Run typecheck. Run the owning integration file `packages/polaris-dossier/src/render.test.ts` under its existing 30000 ms hook budget. Use fresh isolated run state and retain complete failures as well as passes. These runs establish scoped behavior, not the original failure's causality or a speed claim.
4. For the helper predicates, mutate synchronous file-hook registration, remove the await inside directory iteration, iterate a snapshot instead of the live Set, and clear tracking before successful removal; the relevant unit controls must fail. Verify a changed failure-retention predicate with exact unresolved directory/call expectations, not just an arbitrary red exit. Preserve/review the sync public API and exit-fallback controls too.
5. Keep this scoped acceptance separate from the canonical full check: after candidate/harness fixes and scoped checks, the final exact subject still needs the repository's required full verification and adoption/reporting. A previous or concurrent full run without these bytes cannot accept this change. No timeout increase, retry-until-green, ownership shortcut, or inferred causal explanation is authorized by this review.

[Inferred] F1 is the only requested source revision from this review. Once its concrete harness is reviewed, the implementation can proceed to the bounded verification above; source acceptance alone is not full acceptance.
