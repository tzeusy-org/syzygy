PASS

Supplemental eleven-family dispatch controls; not the required fresh-context merge review.

Subject: main08-integration-R1/candidate-checker.txt, scripts/check_spec_reconciliation.py frozen integration of c140a3528a9780212cc9b267d20099e218fd1dba and 08e1c4172885f9a9fb678ee7ffe3c08d52bac99e.
Subject SHA256: 6322bc4ee87b0a72e169b4e854ef4120e96a09c4aa5d20450a06a20297e66f9c.
Executed harness: main08-eleven-dispatch-controls-R2/dispatch_controls.py, SHA256 3e3e3000f9a95de8160c11219b472213b8d332445ae29a6b0c45281e84a5c221.
Extracted AST SHA256: dcd7b5047c4c0640212862c0ffc981103c3e9db6de7f69c1069bf854e4f77d72.
Results: main08-eleven-dispatch-controls-R2/results.json, SHA256 4e8681e8237607c965a7b739805f1745d1d57390065c0677fc9fb49b03c97a2f.

[Observed] Parent redirected this existing-context reviewer to supplemental isolated controls and assigned the required fresh-context merge review to a separate reviewer. This verdict applies only to the isolated control acceptance below. It does not replace that review or approve the complete merge.

[Observed] Adaptation preserves the retained original reconciliation-tail-dispatch-controls-12d-R1 packet. The new harness reads frozen checker bytes as AST and selects exactly the existing _map_cases, _selftest_workers, _run_edition, _run_tail_edition and _join_case_results definitions, the literal _TAIL_WORK_ORDER assignment, and the exact candidate tail orchestration statements inside a tiny wrapper. No checker import, checker top-level execution, real family body, real fixture, build, native job, full selftest or heavy job runs. Eleven independently authored synthetic family functions replace the real family bodies; the POC fake has the actual base-only signature and participates in the actual identity branch. A transparent profiler stub invokes those fakes unchanged.

[Observed] The adapted canonical family list is edit_account_cases, poc_d10_cases, reach_cases, readmit_cases, raw_read_cases, treeread_cases, verify_cases, qfile_cases, scripted_grade_cases, covhold_cases, term_brief_cases. The literal candidate dispatch permutation is (10, 0, 1, 7, 9, 6, 3, 2, 5, 4, 8). The synthetic expected output uses that independent canonical list and asserts original TMP/BASE arguments, including POC's distinct signature. Each fake emits its distinct family name so a skipped, duplicated or wrongly mapped family cannot satisfy expected output.

[Observed] Eleven of eleven controls passed, with their complete outputs inspected in results.json:

- Canonical eleven-family output, argument identities and cleared parent state: workers=1; workers=2 with fork unavailable; workers=2 with a real fork pool. The two serial modes also assert fixed dispatch execution order; fork asserts parent execution-state isolation.
- Missing, duplicate, noninteger string, noninteger bool and out-of-range result indices: each raises exactly RuntimeError('selftest task result population differs'), clears parent state and publishes no partial witnesses/failures.
- Original synthetic worker error: serial, no-fork fallback and fork each preserve the exact registered error class/message, clear parent state and publish no partial witnesses/failures. The serial modes additionally retain exception object identity.

[Observed] Four of four retained sole-fragment mutants were executed and killed by their intended diagnostic, rather than an arbitrary exception. mutations.json and results.json retain every exact old/new fragment, subject binding and computed mutant source SHA256:

- remove-sort: RuntimeError('selftest task result population differs'); mutant SHA256 3a6c3280785dd6cbb7d26fcd48454675020bba18b041572e9a3d89212fb0a1a5.
- duplicate-order (last index 8 becomes 4): RuntimeError('selftest task result population differs'); mutant SHA256 7317b088bb340672ba04f014773e9d381b8a18a53162faea54cdd13fd7249bc1.
- poc-arguments: TypeError('poc_d10_cases() takes 3 positional arguments but 4 were given'); mutant SHA256 34b18651dbefeb0be90511dccf547b877e6e8344a01760ec6dca20399a049b8c.
- remove-state-clear: first confirms the original synthetic worker error, then fails AssertionError('TAIL_STATE_RESTORED'); mutant SHA256 3b44b1bf4d2fa38cc4263ebd7d11da06fbadc12d7a5aa8659d7f7f76c272ff7c.

[Observed] The first adapted R1 run also passed those controls, but inherited a reporting defect: executed mutant rows copied the preparation field executed:false. That complete R1 harness/binding/results is retained unchanged. A separately retained R2 changes only the result-record field to executed:true and reruns the small control battery. R2's observed result fields agree with execution. Counts were independently checked from parsed arrays and textual outcome rows: eleven PASS control rows and four killed mutant rows.

[Observed] Supplemental source comparison verified the frozen main and published checker sources against read-only Git at the named parents. Source segments for every incoming main modified/added function except _selftest_cases match candidate exactly; this comparison intentionally compares function source excluding decorators, because the published branch adds its existing memo-scope decorators. The candidate orchestrator inserts scripted_grade_cases after qfile_cases and before covhold_cases, matching incoming main's canonical order. The isolated controls exercise precisely that eleven-family extension. The frozen integration manifest's seven artifacts and the original dispatch-control manifest's six artifacts were re-hashed after verification; mismatch-name lists are empty.

[Observed] Supplemental wording observation, separate from the passing controls: candidate line 11785 retains the comment 'Fixed measured longest-first order', while the integration README says the appended scripted_grade placement has no measured-placement claim. Dispatch behavior is unaffected, but the complete eleven-element ordering has not been shown measured by this review. This was reported to root for the source review's consideration.

[Unknown] Full merged fixture outcomes, full canonical witness population/parity, governance battery and actual hosted performance remain outside this isolated control result. No 420-second claim is made. The required fresh-context merge review and root's full merged checks remain separate acceptance gates.
