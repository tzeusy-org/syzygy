REVISE

Fresh independent source review: main08 integration R1

[Observed] Reviewed artifact: /home/orca/.tmp/f3-native-admission-fixes/main08-integration-R1
Manifest file SHA-256: 5701104734eab393de9de3ec000d7016b9bc1b560b2a5171f490cfc5cccafb61
Candidate checker SHA-256: 6322bc4ee87b0a72e169b4e854ef4120e96a09c4aa5d20450a06a20297e66f9c
Candidate adoption log SHA-256: aa00f0a583d10dcc1be469bc3d6621144fafcfbdc3645487ef9ba177d0b58208
Parents: published c140a3528a9780212cc9b267d20099e218fd1dba; incoming main 08e1c4172885f9a9fb678ee7ffe3c08d52bac99e.
Reviewed worktree: /home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w, staged merge.

Finding

1. [Observed] Low severity, scripts/check_spec_reconciliation.py:11785 (candidate-checker.txt:11785): the comment still says "Fixed measured longest-first order; returned indices remain canonical." It now describes an eleven-element tuple whose newly appended scripted_grade_cases placement is explicitly unmeasured in the artifact README. [Inferred] The unqualified comment presents the expanded dispatch order as measured and conflicts with the acceptance condition that this integration make no measured-placement or performance claim. Describe the measured predecessor order and the unmeasured appended family separately, or omit the measurement claim. No dispatch change is requested. This is a scoped documentation correction under the engineering bar's explicitness and current-documentation expectations; trust-and-evidence.md also states "An LLM assertion is Inferred, never Observed" and "Missing evidence never makes a claim Inferred."

Verification and acceptance coverage

[Observed] Independently recomputed SHA-256 and byte lengths for all seven manifest entries; 7/7 match. Both frozen parent checkers match git show at their named parent. Each full frozen patch matches git diff --cached against its named parent. Candidate checker and adoption bytes match both the index and the corresponding worktree files. The manifest identifies both exact parents.

[Observed] A complete index/parent blob census covered 12,294 published paths, 10,748 main paths and 12,323 staged paths. Only the adoption log and reconciliation checker have staged blobs different from both parent blobs. No path in either parent is deleted from the staged tree. Relative to published there are 35 changed paths: the other 33 equal incoming main, confirmed with an independent byte comparison. The published delta has no apps/, packages/, .github/, root package manifests, TypeScript configuration or Vitest configuration/tier change in the inspected population; the separate targeted git diff --numstat sweep is empty.

[Observed] The candidate adoption log preserves the entire published byte prefix and appends exactly the incoming A-307 row. Row enumeration gives 240 published, 88 incoming-main and 241 candidate adoption rows. Each parent's exact rows remain in their original relative order; the candidate row multiset equals the union of the two parent row multisets. No parent adoption row is removed or rewritten.

[Observed] Parsed each frozen checker with Python ast without importing or executing it. Candidate has 279 top-level function/class definitions, published 274. All five added definitions match main's full AST: is_scripted_grade_row, scripted_grade_rows, scripted_grade_disposition, scripted_grade_binding and scripted_grade_cases. Of the existing published definitions, 259 match unchanged; fourteen changed bodies match main independently after removing only the preserved PR cache decorators for comparison. Those fourteen are check_outcomes, census, polaris_expected, check_generated, check_routes, inputs, declared_source_historical_cases, url_source_cases, reach_cases, raw_read_cases, treeread_cases, verify_cases, qfile_cases and readmit_cases. The remaining changed definition, _selftest_cases, differs from published's AST only by inserting scripted_grade_cases after qfile_cases in tail_families. Incoming scripted-grading constants match main. Thus the incoming predicates, fixture body and status-route logic are retained in source.

[Observed] Incoming PROJECT-STATUS.md, openspec/README.md, count_polaris_effective_scenarios.py and the new adopted specification are among the 33 byte-identical main files. Two source-counting methods independently count 18 Scenario headings in the prior question-file REQ033 and 21 in the scripted-grading successor. Their computed SHA-256 values are respectively 147954d8089b52e98deadf9710c061324c670f8ddfc4b7406fedbb9ab8c18b18 and de530007005b65c3f7400d42dabfa2caf50e8b2cc6b00fe2044a31d61ce3ab49, matching the checker's bound subject literals. The incoming status source reports 39 requirements and 558 scenarios and retains the explicit 18-to-21 amendment route; runtime acceptance remains identified as outstanding.

[Observed] The original nineteen-family pool is unchanged. The canonical tail is edit_account, poc_d10, reach, readmit, raw_read, treeread, verify, qfile, scripted_grade, covhold, term_brief. The new work order is (10, 0, 1, 7, 9, 6, 3, 2, 5, 4, 8). Literal AST inspection confirms it is a permutation of 0..10 and each tail family appears once. Mapping the indices back to family names independently shows the predecessor dispatch sequence is retained exactly and scripted_grade is appended last: old covhold index8 becomes9 and old term_brief index9 becomes10.

[Observed] _map_cases, _join_case_results, _run_edition, _run_tail_edition and _selftest_workers match published's AST exactly. The canonical result sort, exact-int index population refusal, ordered witness/failure/message join, poc_d10 single-base argument special case, single-worker/non-fork fallback, worker selection and pool context remain unchanged. The _selftest_cases AST comparison also preserves its finally cleanup of _EDITION_STATE. The existing entry helpers, selftest, run and profiling helper match published's AST.

Scope and limits

[Observed] Read the artifact, applicable repository AGENTS.md, engineering-bar skill and the relevant trust/evidence doctrine via heart-and-soul. Per the review instructions, ran no archived checker, tests, full fixtures, build or provider process, and made no source edits or git mutations. Python scripts only read/hash/parse source and compare git blobs. This review's exact verdict is REVISE for finding 1. [Unknown] Runtime correctness, complete merged selftest/battery acceptance and performance of the eleven-family tail are not established by this source review.
