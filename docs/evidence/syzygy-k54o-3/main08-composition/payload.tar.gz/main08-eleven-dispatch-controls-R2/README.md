This outside-only packet adapts reconciliation-tail-dispatch-controls-12d-R1 to the exact frozen eleven-family main08 integration source. It retains five existing dispatch helpers, the literal scheduling constant and exact tail orchestration as AST, replacing real families with distinct synthetic functions. No checker import or real fixture runs.

The canonical family insertion is scripted_grade_cases after qfile_cases. Indices become (10,0,1,7,9,6,3,2,5,4,8). Controls cover workers=1, unsupported-fork fallback, real fork=2, five refused index populations and original worker-error/state restoration in all three modes. The original four sole-fragment mutants are retained with updated exact subject and mutation hashes. Expected errors are exact class/message checks.

Executed command:

    python3 dispatch_controls.py --output results.json

results.json records eleven passing controls and four intended mutant kills. R2 corrects only the R1 harness's copied preparation field executed:false to executed:true in observed mutant results; R1 is retained separately. Original source and retained original control packet were not edited.

This synthetic dispatch evidence does not replace fresh-context merge review, real full merged selftest/parity, governance checks or hosted timing. To rerun, provide a new output path; the harness refuses an existing output.
