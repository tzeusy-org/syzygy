"""Prepare one exact future subject; no build, capture, test or control replay."""
from pathlib import Path
from datetime import datetime,timezone
import argparse, hashlib, json, re, shutil, subprocess, sys
sys.path.insert(0,str(Path(__file__).parent/'templates'))
import a303_expected

HERE=Path(__file__).parent
REPO=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
SOURCE=Path('/home/orca/.local/state/syzygy-polaris-clones/redis-redis-8.10.2')
CAPTURE_ROOT=Path('/home/orca/.tmp/f3-exact-stage-8dcb0.FXKsif1O')
CAPTURE=CAPTURE_ROOT/'run-capture-admission.sh'
PACKET=Path('/home/orca/.tmp/f3-native-admission-fixes/f043-render-retention')
F043='f043a10aab6bf3baee0b1acd24c72b78d3654ded'
BASE='2446c64edb7bb9e0c89169bddd129efca36cad65'
SOURCE_COMMIT='498ecd0d6d007db11ddb3aea9428552598a78622'
A300='bdfe771a61d4a40c060981ddc6624a8889ce5ef4'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(REPO),*args])
def require(ok,why):
    if not ok:raise AssertionError(why)
def ancestor(old,new):return subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',old,new],capture_output=True).returncode==0
def pin(path):
    raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}
def copy(source,destination):
    require(source.is_file() and not source.is_symlink(),'regular frozen input: '+str(source))
    destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
def closure(commit):
    # Conservative complete implementation-input bound, not a guessed import graph.
    # Tests/scripts stay in the bound; nothing is executed during this census.
    raw=git('ls-tree','-r','-z','--full-tree',commit);rows=[];nonblobs=[]
    policy='.syzygy/governance/policies/POLARIS-DOSSIER-DECLARED-SOURCE-POLICY-v4.json'
    for entry in raw.split(b'\0'):
        if not entry:continue
        metadata,path=entry.split(b'\t',1);mode,kind,oid=metadata.decode().split();name=path.decode('utf8')
        selected=name.split('/')[0] in {'apps','packages','scripts'} or ('/' not in name and (name.endswith('.json') or name in {'.npmrc','.node-version','.nvmrc'})) or name==policy
        if not selected:continue
        row={'path':name,'mode':mode,'gitObject':oid,'kind':kind}
        if kind=='blob':
            body=git('cat-file','blob',oid);row.update({'bytes':len(body),'sha256':sha(body)})
        else:nonblobs.append(row)
        rows.append(row)
    require(rows and not nonblobs,'implementation-input closure contains non-blob entries')
    return {'commit':commit,'tree':git('rev-parse',commit+'^{tree}').decode().strip(),'selection':'Every tracked apps/**, packages/** and scripts/** path, all root JSON/npm/node manifests, and exact declared-source screening policy; conservative implementation-input superset, including tests. Not a claim of minimal reachable import graph.','files':rows,'filePopulation':len(rows)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--subject',required=True,help='Exact published final subject full SHA; never a branch or inferred final HEAD')
    ap.add_argument('--main',required=True,help='Actual merged-main full SHA included in that subject')
    args=ap.parse_args()
    for value,label in [(args.subject,'subject'),(args.main,'main')]:
        require(re.fullmatch('[a-f0-9]{40}',value) is not None,label+' must be a full lower-case Git SHA')
        require(git('rev-parse',value+'^{commit}').decode().strip()==value,label+' commit identity')
    require(args.subject!=F043,'f043 is retained predecessor, never the final subject')
    require(ancestor(args.main,args.subject),'supplied merged main is not included in supplied subject')
    require(ancestor(A300,args.main),'supplied main does not include the adopted A-300 merge')
    a303_binding=a303_expected.verify_source_binding(REPO,args.subject,args.main,PACKET/'inputs/frozen-draft-v4.json')
    require(ancestor(F043,args.subject) and ancestor(BASE,args.subject),'retained baseline ancestry mismatch')
    require((HERE/'factory-inputs.sha256').read_text().split()[0]==sha((HERE/'factory-inputs.json').read_bytes()),'factory input manifest checksum')
    factory_inputs=json.loads((HERE/'factory-inputs.json').read_bytes())
    for row in factory_inputs['factoryFiles']:
        p=HERE/row['path'];require(sha(p.read_bytes())==row['sha256'],'factory drift: '+row['path'])
    require(sha((PACKET/'MANIFEST.json').read_bytes())==factory_inputs['retentionManifestSha256'],'retention packet manifest drift')
    packet_manifest=json.loads((PACKET/'MANIFEST.json').read_bytes())
    for row in packet_manifest['files']:
        raw=(PACKET/row['path']).read_bytes();require(sha(raw)==row['sha256'] and len(raw)==row['bytes'],'retained artifact drift: '+row['path'])
    require(sha(CAPTURE.read_bytes())==factory_inputs['captureScriptSha256'],'existing pinned CLI capture script drift')
    source_commit=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()
    require(source_commit==SOURCE_COMMIT,'source clone commit')
    status=subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain','-z']);require(status==b'','source clone clean')
    listing=subprocess.check_output(['git','-C',str(SOURCE),'ls-tree','-r','-z','-l','--full-tree','HEAD'])
    require(sha(listing)==factory_inputs['sourceTreeListingSha256'],'full source listing drift')
    subject=args.subject;main_commit=args.main
    out=HERE/'subjects'/(subject+'--main-'+main_commit);out.mkdir(parents=True,exist_ok=False)
    for source in sorted((HERE/'templates').iterdir()):
        if source.is_file():copy(source,out/source.name)
    for filename in ['compare-bound-disclosure-v2.py','disclosure-canaries-v2.py','comparator-selftest-bound-disclosure-v2.json','disclosure-canaries-v2.json','COMPARATOR-REVIEW-RAW.md','comparison.json','comparison-bound-disclosure-v2.json']:
        copy(PACKET/'original-records'/filename,out/'retained'/filename)
    copy(HERE/'retained/run-capture-admission.sh',out/'retained/run-capture-admission.sh')
    for label in ['baseline','candidate']:
        target='2446' if label=='baseline' else 'f043'
        for source in sorted((PACKET/'sites'/label).rglob('*')):
            if source.is_file():copy(source,out/'frozen-sites'/target/source.relative_to(PACKET/'sites'/label))
    for filename in ['config.json','frozen-draft-v4.json']:copy(PACKET/'inputs'/filename,out/'inputs'/filename)
    copy(PACKET/'original-records/actual-input-binding.json',out/'retained/actual-input-binding.json')
    copy(PACKET/'MANIFEST.json',out/'retained/predecessor-packet-manifest.json')
    full_closure=closure(subject);(out/'source-closure.json').write_text(json.dumps(full_closure,indent=2)+'\n')
    ancestry={'subject':subject,'main':main_commit,'mainIncludedInSubject':True,'A300IncludedInMain':True,'A303MainAndSourceAdoptionVerified':True,'f043IncludedInSubject':True,'baseline2446IncludedInSubject':True,'scope':'Git ancestry of explicitly supplied immutable commits; publication and remote freshness are operator assertions, not inferred from local refs.'}
    (out/'ancestry.json').write_text(json.dumps(ancestry,indent=2)+'\n')
    for label,old in [('f043',F043),('merged-main',main_commit)]:
        (out/('source-delta-from-'+label+'.patch')).write_bytes(git('diff',old,subject,'--','apps','packages','scripts','package.json','package-lock.json','.syzygy/governance/policies/POLARIS-DOSSIER-DECLARED-SOURCE-POLICY-v4.json'))
        (out/('source-paths-from-'+label+'.txt')).write_bytes(git('diff','--name-status',old,subject))
    (out/'A300-first-parent-render.patch').write_bytes(git('diff',A300+'^1',A300,'--','apps/three-surface-poc/src/polaris-generation/dossier-render-local.ts','apps/three-surface-poc/src/polaris-generation/dossier-site.ts','.syzygy/governance/decisions/AGENT-ADOPTIONS.md'))
    arm='final-A303-'+subject
    binding=json.loads((PACKET/'original-records/actual-input-binding.json').read_bytes());inputs={row['kind']:row for row in binding['files']}
    settings={'subject':subject,'main':main_commit,'subjectTree':full_closure['tree'],'mainTree':git('rev-parse',main_commit+'^{tree}').decode().strip(),'repository':str(REPO),'sourceClone':str(SOURCE),'sourceCommit':SOURCE_COMMIT,'sourceTreeListingSha256':sha(listing),'configSource':inputs['config']['sourcePath'],'draftSource':inputs['draft']['sourcePath'],'configSha256':inputs['config']['sha256'],'draftSha256':inputs['draft']['sha256'],'draftSchema':'polaris-dossier-local-draft-v4','captureScript':str(CAPTURE),'captureScriptSha256':sha(CAPTURE.read_bytes()),'captureArm':arm,'captureCheckout':str(CAPTURE_ROOT/arm),'captureResults':str(CAPTURE_ROOT/(arm+'-capture')),'baselineCommit':BASE,'f043Commit':F043,'A300Merge':A300,'A303Binding':a303_binding,'retentionPacketManifestSha256':factory_inputs['retentionManifestSha256']}
    (out/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
    plan={'preparedAt':datetime.now(timezone.utc).isoformat(),'state':'PREPARED ONLY; no build/capture/test/control/native work executed by this factory','subject':subject,'actualMergedMain':main_commit,'factorySha256':sha(Path(__file__).read_bytes()),'sourceClosureSha256':sha((out/'source-closure.json').read_bytes()),'sourceClosureFilePopulation':full_closure['filePopulation'],'comparisons':[{'baseline':F043,'A215Transformation':False,'A303ExactExpectedView':True},{'baseline':BASE,'A215Transformation':True,'A303ExactExpectedView':True}],'reviewStatus':'Exact per-page region equality; A-300 has no target in frozen two-Unknown notices. No additional mask.','observationNormalization':'Only reviewed complete sidecar-bound attributes, derivation timestamps and hidden 64-character disclosure digest tokens. Raw sidecar must reconstruct by capturedAt replacement alone.','requiredPopulation':{'html':46,'files':50,'numericCells':147,'measuredPages':45},'controls':'Explicit later reproduce-controls.py: retained 202 + 31 controls with byte-identical outputs, plus new exact-region/outside/raw-sidecar predicates. Not executed by preparation.','captureScript':pin(CAPTURE),'heavySlot':'Only root releases the heavy slot. Wrapper requires --heavy-slot-released and refuses existing capture/results/comparison/control directories.','limitations':['Supplied subject and main are explicit immutable identities, not a claim that local HEAD is final.','Final capture and final static comparison remain Unknown until executed.','No native/Stop/recovery, counted Design/Fidelity, browser layout or timing acceptance.','Retained f043 PASS remains predecessor-only; no old factory or packet was rewritten.']}
    (out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    (out/'README.md').write_text(f'''Prepared only for exact supplied subject {subject}, including supplied merged main {main_commit}.

No build, capture, test suite, control replay or native execution was performed by preparation. Preserve the full schema-v4 draft and source/config pins. Do not call any earlier working HEAD final.

Only after root confirms this subject is published and releases the heavy slot:
  bash {out}/run-capture.sh --heavy-slot-released

This uses the existing frozen clean pinned CLI capture script once, records fresh pins before/after, then explicitly replays retained static controls and compares final→f043 with the exact source/adoption-bound A-303 expected view, and final→2446 with that same expected view plus only the existing A-215 additions. Both require exact review-status region and outside-main bytes, strict 46/50 populations, all 147 metric cells (two independently derived +33 byte cells, 145 exact unchanged cells) and all 45 measured-page byte counts. A-303 adds exactly three dfn wrappers and the exact derived glossary/depth1/total byte metrics; it grants no content or numeric mask. No broad region, digit, content, schema or numeric mask is admitted. A-300 has no target in this frozen uncounted v4 subject; a status change is a failure, not a new allowance.

Separate later lightweight commands (not run during preparation):
  python3 {out}/compare-final.py --verify-preparation-only
  python3 {out}/reproduce-controls.py
  python3 {out}/compare-final.py

Control/comparison output directories are created once and never overwritten. Running controls separately before the wrapper means the wrapper will refuse its existing controls-first-run directory; keep the default wrapper as the single sequence, or run the three stages explicitly without reusing an output directory. Any corrected comparator requires separately frozen new bytes and new output names; retain any FAIL verbatim.
''')
    frozen={'subject':subject,'main':main_commit,'files':[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(out.rglob('*')) if p.is_file()]}
    (out/'frozen-manifest.json').write_text(json.dumps(frozen,indent=2)+'\n')
    # Metadata pinning only. No comparator/selftest/build/capture is invoked.
    pinned=subprocess.run(['python3',str(out/'pin-inputs.py'),'--output',str(out/'prepared-input-pins.json')],capture_output=True,text=True)
    require(pinned.returncode==0,'metadata pin refused: '+pinned.stderr)
    sealed={'subject':subject,'main':main_commit,'files':[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(out.rglob('*')) if p.is_file()]}
    (out/'preparation-manifest.json').write_text(json.dumps(sealed,indent=2)+'\n')
    print(json.dumps({'preparedDirectory':str(out),'subject':subject,'main':main_commit,'preparationManifestSha256':sha((out/'preparation-manifest.json').read_bytes()),'captureCommand':['bash',str(out/'run-capture.sh'),'--heavy-slot-released'],'buildCaptureControlsNativeExecuted':False},indent=2))
if __name__=='__main__':main()
