"""Exact source/adoption-bound expected baseline; candidate bytes stay untouched."""
from pathlib import Path
import copy, hashlib, json, re, shutil, subprocess

HERE=Path(__file__).parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def require(ok,why):
    if not ok:raise AssertionError(why)
def binding():return json.loads((HERE/'a303-binding.json').read_bytes())

def verify_source_binding(repository,subject,main,draft):
    bound=binding()
    require(main==bound['main'],'A303 comparison requires the exact reviewed merged-main commit')
    require(sha(Path(draft).read_bytes())==bound['draftSha256'],'exact A303 frozen v4 draft')
    def git(*args):return subprocess.check_output(['git','-C',str(repository),*args])
    require(subprocess.run(['git','-C',str(repository),'merge-base','--is-ancestor',main,subject],capture_output=True).returncode==0,'A303 main included in subject')
    paths=[row['path'] for row in bound['sourceBindings']]
    require(sha(git('diff',main+'^1',main,'--',*paths))==bound['sourceDeltaSha256'],'A303 exact first-parent production delta')
    overlay=(HERE/'a303-subject-overlay.patch').read_bytes()
    require(sha(overlay)==bound['subjectOverlaySha256'],'exact reviewed F3 overlay artifact digest')
    actual_overlay=git('diff',main,subject,'--',*paths)
    require(sha(actual_overlay)==bound['subjectOverlaySha256'] and actual_overlay==overlay,'exact reviewed F3 subject overlay patch')
    for commit,rows in ((main,bound['sourceBindings']),(subject,bound['subjectSourceBindings'])):
        for row in rows:
            require(sha(git('show',commit+':'+row['path']))==row['sha256'],'A303 production-source binding: '+row['path'])
        ledger=git('show',commit+':.syzygy/governance/decisions/AGENT-ADOPTIONS.md').decode('utf-8')
        rows=[line for line in ledger.splitlines() if re.match(r'\|\s*A-303\s*\|',line)]
        require(rows==[bound['adoptionRowVerbatim']],'exact A303 adoption row')
    return {'main':main,'subject':subject,'bindingSha256':sha((HERE/'a303-binding.json').read_bytes()),'sourceAndAdoptionVerified':True}

def expected_baseline(before,destination,label,metrics):
    """Copy the sealed baseline, then change only enumerated expected bytes."""
    bound=binding();require(label in bound['baselines'],'known A303 baseline')
    rule=bound['baselines'][label]
    for name,wanted in rule['files'].items():
        path=before/name
        require(path.is_file() and not path.is_symlink() and sha(path.read_bytes())==wanted,'exact old A303 baseline: '+name)
    glossary=(before/'glossary.html').read_text(encoding='utf-8')
    definitions=re.findall(r'<dt id="([^"]+)">([^<]+)</dt>',glossary)
    require(definitions==[(row['id'],re.fullmatch(r'<dt id="[^"]+">([^<]+)</dt>',row['old'])[1]) for row in rule['definitions']],'exact three old glossary definitions')
    require(glossary.count('<dt ')==len(rule['definitions'])==3 and '<dfn' not in glossary,'exact old definition population')
    transformed=glossary
    for row in rule['definitions']:
        require(transformed.count(row['old'])==1,'one exact old glossary fragment: '+row['id'])
        transformed=transformed.replace(row['old'],row['new'],1)
    delta=metrics.measured_bytes(transformed)-metrics.measured_bytes(glossary)
    require(delta==len(transformed.encode('utf-8'))-len(glossary.encode('utf-8'))==33,'exact measured A303 +33 bytes')
    oldraw=(before/'size-report.json').read_bytes();old=json.loads(oldraw)
    require((json.dumps(old,indent=2)+'\n').encode()==oldraw,'canonical old size-report JSON bytes')
    require(len(old['pages'])==45,'45 measured pages')
    pages=[i for i,row in enumerate(old['pages']) if row['path']=='glossary.html']
    depths=[i for i,row in enumerate(old['perPageDepth']) if row['depth']==1]
    require(len(pages)==len(depths)==1,'one glossary page and one depth1 aggregate')
    require(old['pages'][pages[0]]['depth']==1,'glossary depth1')
    require(metrics.measured_bytes(glossary)==old['pages'][pages[0]]['bytes'],'baseline measured glossary bytes')
    cost=copy.deepcopy(old)
    cost['pages'][pages[0]]['bytes']+=delta
    cost['perPageDepth'][depths[0]]['bytes']+=delta
    cost['totalBytes']+=delta
    require(sum(row['bytes'] for row in cost['pages'])==cost['totalBytes'],'derived total byte sum')
    require(sum(row['bytes'] for row in cost['pages'] if row['depth']==1)==cost['perPageDepth'][depths[0]]['bytes'],'derived depth1 byte sum')
    oldhtml=(before/'size-report.html').read_text(encoding='utf-8');newhtml=oldhtml
    oldcells=metrics.metric_cells(oldhtml,old)
    for row in rule['sizeHtmlReplacements']:
        require(newhtml.count(row['old'])==1,'one exact bound metric representation')
        newhtml=newhtml.replace(row['old'],row['new'],1)
    newcells=metrics.metric_cells(newhtml,cost)
    require(len(oldcells)==len(newcells)==147,'147 numeric table cells per expected view')
    changed=[]
    for a,b in zip(oldcells,newcells):
        require({k:v for k,v in a.items() if k!='value'}=={k:v for k,v in b.items() if k!='value'},'same numeric-cell identities')
        if a!=b:changed.append((a,b))
    expected_cells={(0,depths[0],2),(1,pages[0],2)}
    require({(a['table'],a['row'],a['column']) for a,b in changed}==expected_cells and len(changed)==2,'only two exact metric table cells')
    require(all(b['value']-a['value']==delta for a,b in changed),'both metric cells derived +33')
    require(not destination.exists(),'fresh expected-view directory')
    shutil.copytree(before,destination)
    payloads={'glossary.html':transformed.encode('utf-8'),'size-report.json':(json.dumps(cost,indent=2)+'\n').encode('utf-8'),'size-report.html':newhtml.encode('utf-8')}
    for name,raw in payloads.items():(destination/name).write_bytes(raw)
    # Every untouched file remains exact; original baselines are never changed.
    files=sorted(path.relative_to(before).as_posix() for path in before.rglob('*') if path.is_file())
    require(files==sorted(path.relative_to(destination).as_posix() for path in destination.rglob('*') if path.is_file()),'expected-view file population')
    for name in files:
        require((destination/name).read_bytes()==payloads.get(name,(before/name).read_bytes()),'only enumerated expected files differ')
    return {'adoption':'A-303','bindingSha256':sha((HERE/'a303-binding.json').read_bytes()),'baseline':label,'changedFiles':[{'path':name,'originalSha256':sha((before/name).read_bytes()),'expectedSha256':sha(raw)} for name,raw in payloads.items()],'definitionCount':3,'measuredByteDelta':delta,'numericTableCellsChanged':2,'numericTableCellsUnchanged':145,'aggregateSummaryBoundToCost':True,'numericMasking':False}
