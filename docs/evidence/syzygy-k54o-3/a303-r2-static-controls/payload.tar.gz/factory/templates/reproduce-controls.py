"""Explicit opt-in static control replay; never executed by the factory."""
from pathlib import Path
import contextlib, importlib.util, io, json, re, sys, tempfile
sys.dont_write_bytecode=True
HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('final_comparator',HERE/'compare-final.py')
final=importlib.util.module_from_spec(spec);spec.loader.exec_module(final)

def main():
    settings=final.verify_preparation();m=final.helper()
    output=HERE/'controls-first-run';output.mkdir(exist_ok=False)
    with tempfile.TemporaryDirectory(prefix='static-control-fixtures-',dir=HERE) as temporary:
        fixtures=Path(temporary)
        # Only tiny, explicitly synthetic loader records are made. Static sites
        # and the full known v4 draft are reused; there is no real local store.
        for arm,label in [(m.BASELINE,'2446'),(m.CANDIDATE,'f043')]:
            run=fixtures/(arm+'-capture')/'state/run-synthetic-control';site=run/'site/0'
            site.parent.mkdir(parents=True);site.symlink_to(HERE/'frozen-sites'/label,target_is_directory=True)
            (run/'drafts').mkdir();(run/'drafts/rev-0.json').write_bytes((HERE/'inputs/frozen-draft-v4.json').read_bytes())
            (run/'run.json').write_text(json.dumps({'syntheticControlFixture':True,'subject':{'pinnedRevision':{'commit':m.SOURCE}}}))
            (fixtures/(arm+'-capture')/'render.json').write_text(json.dumps({'syntheticControlFixture':True,'outcome':'rendered','draftRevision':0,'pages':46,'designReview':{'counts':False},'fidelityReview':{'counts':False},'run':str(run),'site':str(site)}))
        m.ROOT=fixtures
        baseline=m.main(True)
        baseline_raw=(json.dumps(baseline,indent=2)+'\n').encode()
        final.require(baseline_raw==(HERE/'retained/comparator-selftest-bound-disclosure-v2.json').read_bytes(),'202 original controls changed')
        (output/'retained-202-controls.json').write_bytes(baseline_raw)
        canary=HERE/'retained/disclosure-canaries-v2.py';code=canary.read_text()
        import_line="spec=importlib.util.spec_from_file_location('corrected',P/'compare-bound-disclosure-v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)"
        final.require(code.count(import_line)==1,'retained canary import seam')
        code=code.replace(import_line,'# Frozen helper and explicit synthetic fixture root supplied by replay driver.')
        captured=io.StringIO()
        with contextlib.redirect_stdout(captured):exec(compile(code,str(canary),'exec'),{'__file__':str(canary),'__name__':'retained_disclosure_controls','m':m})
        disclosure_raw=captured.getvalue().encode();disclosure=json.loads(disclosure_raw)
        final.require(disclosure_raw==(HERE/'retained/disclosure-canaries-v2.json').read_bytes(),'31 retained disclosure controls changed')
        (output/'retained-31-disclosure-controls.json').write_bytes(disclosure_raw)
    before=HERE/'frozen-sites/f043';record=(before/'derived-structure.json').read_bytes();positives=[];negative=[]
    for name in m.paths(before):
        if not name.endswith('.html'):continue
        source=m.text(before/name);final.pair(name,source,source,record,record,m,False);positives.append(name)
    name='index.html';source=m.text(before/name);old_region=final.region(source)
    mutations=[
        ('reader-content','</main>','<p>new reader content</p></main>'),
        ('main-attribute','<main','<main data-unexpected="1"'),
        ('review-status-text',old_region,old_region.replace('none counts','now counts',1)),
        ('review-status-label',old_region,old_region.replace('data-label="Unknown"','data-label="Observed"',1)),
        ('review-status-population',old_region,old_region.replace('</ul>','<li>new status item</li></ul>',1)),
        ('review-status-style',old_region,old_region.replace('overflow-wrap:anywhere','overflow-wrap:normal',1)),
        ('outside-main','</head>','<meta name="unexpected" content="new"></head>'),
    ]
    for identity,old_fragment,new_fragment in mutations:
        mutant=source.replace(old_fragment,new_fragment,1)
        final.require(mutant!=source,'control mutation absent: '+identity)
        try:final.pair(name,source,mutant,record,record,m,False)
        except (AssertionError,UnicodeError) as error:negative.append({'id':identity,'subjectCommit':settings['f043Commit'],'old':old_fragment,'new':new_fragment,'beforeSha256':final.sha(source.encode()),'afterSha256':final.sha(mutant.encode()),'detected':True,'refusal':str(error)})
        else:raise AssertionError('new comparator control survived: '+identity)
    try:final.pair(name,source,source,record,record+b' ',m,False)
    except AssertionError as error:negative.append({'id':'raw-sidecar-whitespace','subjectCommit':settings['f043Commit'],'detected':True,'old':'raw sidecar EOF','new':'raw sidecar EOF plus one space','beforeSha256':final.sha(record),'afterSha256':final.sha(record+b' '),'refusal':str(error)})
    else:raise AssertionError('raw sidecar control survived')
    for name in positives:
        observed_region=final.region(m.text(before/name))
        final.require(re.search('[0-9a-fA-F]{64,}',observed_region) is None and 'bound to packet' not in observed_region,'A-300 no-target predicate')
    result={'subjectPreparedFor':settings['subject'],'mergedMain':settings['main'],'scope':'Static controls on immutable predecessor fixtures; no final capture/native acceptance','retainedPositiveBaselinePages':len(baseline['positivePages']),'retainedNegativeControls':len(baseline['detectedCanaries'])+len(disclosure['detectedCanaries']),'retainedChangedObservationPositives':len(disclosure['positiveChangedObservationCases']),'f043NoAdditionalStylePositivePages':positives,'newExactRegionAndOutsideControls':negative,'retainedOutputsByteIdentical':True}
    (output/'control-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'retainedNegativeControls':result['retainedNegativeControls'],'newComparatorNegativeControls':len(negative),'outputDirectory':str(output)},indent=2))
if __name__=='__main__':main()
