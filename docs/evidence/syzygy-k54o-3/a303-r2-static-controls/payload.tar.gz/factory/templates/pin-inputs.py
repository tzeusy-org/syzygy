"""Read-only Git/input pinning; writes only the requested new evidence files."""
from pathlib import Path
import argparse, datetime, hashlib, json, subprocess
HERE=Path(__file__).parent
def sha(b):return hashlib.sha256(b).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args])
def require(ok,why):
    if not ok:raise AssertionError(why)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    require(not args.output.exists(),'pin record already exists')
    settings=json.loads((HERE/'settings.json').read_bytes());manifest=json.loads((HERE/'frozen-manifest.json').read_bytes())
    if (HERE/'preparation-manifest.json').exists():
        sealed=json.loads((HERE/'preparation-manifest.json').read_bytes())
        for row in sealed['files']:
            p=HERE/row['path'];raw=p.read_bytes();require(not p.is_symlink() and sha(raw)==row['sha256'] and len(raw)==row['bytes'],'sealed preparation drift: '+row['path'])
    else:
        require(args.output==HERE/'prepared-input-pins.json','only initial metadata pin may precede the final preparation seal')
    for row in manifest['files']:
        p=HERE/row['path'];raw=p.read_bytes();require(not p.is_symlink() and sha(raw)==row['sha256'] and len(raw)==row['bytes'],'frozen preparation drift: '+row['path'])
    repo=Path(settings['repository']);source=Path(settings['sourceClone'])
    require(git(repo,'rev-parse',settings['subject']+'^{commit}').decode().strip()==settings['subject'],'subject commit')
    require(git(repo,'rev-parse',settings['subject']+'^{tree}').decode().strip()==settings['subjectTree'],'subject tree')
    require(git(repo,'rev-parse',settings['main']+'^{tree}').decode().strip()==settings['mainTree'],'main tree')
    require(git(source,'rev-parse','HEAD').decode().strip()==settings['sourceCommit'],'source clone commit')
    status=git(source,'status','--porcelain','-z');require(status==b'','source clone clean')
    listing=git(source,'ls-tree','-r','-z','-l','--full-tree','HEAD')
    require(sha(listing)==settings['sourceTreeListingSha256'],'full source tree listing')
    for path,key in [(Path(settings['configSource']),'configSha256'),(Path(settings['draftSource']),'draftSha256'),(Path(settings['captureScript']),'captureScriptSha256')]:
        require(sha(path.read_bytes())==settings[key],'live capture input drift: '+key)
    listing_path=args.output.with_suffix('.source-tree.bin');require(not listing_path.exists(),'source listing already exists')
    args.output.parent.mkdir(parents=True,exist_ok=True);listing_path.write_bytes(listing)
    record={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subject':settings['subject'],'main':settings['main'],'subjectTree':settings['subjectTree'],'mainTree':settings['mainTree'],'sourceCommit':settings['sourceCommit'],'sourceTree':git(source,'rev-parse','HEAD^{tree}').decode().strip(),'sourceTreeEntries':len(listing.split(b'\0'))-1,'sourceTreeListingSha256':sha(listing),'sourceTreeListingPath':str(listing_path),'sourceStatusSha256':sha(status),'sourceStatusEntries':0,'configSha256':settings['configSha256'],'draftSha256':settings['draftSha256'],'captureScriptSha256':settings['captureScriptSha256'],'correctedHelperSha256':sha((HERE/'retained/compare-bound-disclosure-v2.py').read_bytes()),'finalComparatorSha256':sha((HERE/'compare-final.py').read_bytes()),'sourceClosureSha256':sha((HERE/'source-closure.json').read_bytes()),'frozenManifestSha256':sha((HERE/'frozen-manifest.json').read_bytes()),'scope':'Full Git/input metadata pin only; no build/capture/native work by this script'}
    args.output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'pinRecord':str(args.output),'subject':settings['subject'],'main':settings['main'],'captureExecuted':False}))
if __name__=='__main__':main()
