"""Frozen final-capture comparisons; no capture/build/provider/native operation."""
from pathlib import Path
from html.parser import HTMLParser
import argparse, hashlib, importlib.util, json, re, subprocess, sys, tempfile
import a303_expected
sys.dont_write_bytecode=True
HERE=Path(__file__).parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,why):
    if not ok:raise AssertionError(why)
def read_json(path):return json.loads(path.read_bytes())
def helper():
    spec=importlib.util.spec_from_file_location('frozen_bound_disclosure',HERE/'retained/compare-bound-disclosure-v2.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def verify_preparation():
    sealed=read_json(HERE/'preparation-manifest.json')
    for row in sealed['files']:
        p=HERE/row['path'];raw=p.read_bytes()
        require(not p.is_symlink() and len(raw)==row['bytes'] and sha(raw)==row['sha256'],'sealed preparation drift: '+row['path'])
    manifest=read_json(HERE/'frozen-manifest.json')
    for row in manifest['files']:
        p=HERE/row['path'];raw=p.read_bytes()
        require(not p.is_symlink() and len(raw)==row['bytes'] and sha(raw)==row['sha256'],'frozen preparation drift: '+row['path'])
    settings=read_json(HERE/'settings.json')
    require(re.fullmatch('[a-f0-9]{40}',settings['subject']) is not None,'full subject SHA')
    require(re.fullmatch('[a-f0-9]{40}',settings['main']) is not None,'full merged-main SHA')
    a303_expected.verify_source_binding(settings['repository'],settings['subject'],settings['main'],HERE/'inputs/frozen-draft-v4.json')
    return settings

REGION=re.compile(r'<aside class="review-status" data-review-status-region="review-status" aria-label="Review status">.*?</aside>',re.S)
class RegionCount(HTMLParser):
    def __init__(self,source):
        super().__init__();self.count=0;self.feed(source);self.close()
    def handle_starttag(self,tag,attrs):
        if tag=='aside' and dict(attrs).get('data-review-status-region')=='review-status':self.count+=1
def region(source):
    rows=REGION.findall(source)
    require(len(rows)==RegionCount(source).count==1,'one exact named review-status region')
    return rows[0]
def raw_sidecars(old,new,m):
    m.validate_derived_pair(old,new)
    a=json.loads(old);b=json.loads(new)
    old_time=json.dumps(a['capturedAt']).encode();new_time=json.dumps(b['capturedAt']).encode()
    require(old.count(old_time)==1 and new.count(new_time)==1,'one raw capturedAt string per sidecar')
    require(old.replace(old_time,new_time,1)==new,'raw sidecar change beyond capturedAt')
def pair(name,before,after,old_record,new_record,m,add_a215=False):
    raw_sidecars(old_record,new_record,m)
    expected=m.styled_baseline(name,before) if add_a215 else before
    m.styles(name,expected);styles=m.styles(name,after)
    require(region(expected)==region(after),'review-status region differs; no A-300 target or allowance on frozen Unknown notices')
    old_open,a,old_outside=m.Parse(expected).main_parts();new_open,b,new_outside=m.Parse(after).main_parts()
    require(old_open==new_open,'unexpected main opening attributes')
    require(old_outside==new_outside,'outside-main bytes differ')
    a,oldslots=m.normalize_observation(name,a,old_record)
    b,newslots=m.normalize_observation(name,b,new_record)
    require(a==b,'reader main differs beyond explicit existing styles and bound observation slots')
    return {'path':name,'mainMatched':True,'mainOpeningExact':True,'reviewStatusRegionExact':True,'outsideMainExact':True,'A215AppliedToBaseline':add_a215,'styleCensus':styles,'observationBefore':oldslots,'observationAfter':newslots,'beforeHtmlSha256':sha(before.encode()),'afterHtmlSha256':sha(after.encode())}

def paths(site,m):
    require(site.is_dir() and not site.is_symlink(),'regular site directory')
    require(not any(p.is_symlink() for p in site.rglob('*')),'no rendered symlinks')
    result=m.paths(site)
    found=sorted(Path(x.decode()).relative_to(site).as_posix() for x in subprocess.check_output(['find',str(site),'-type','f','-print0']).split(b'\0') if x)
    require(result==found,'rglob/os.walk/find population disagreement')
    require(len(result)==50 and sum(n.endswith('.html') for n in result)==46,'exact 46 HTML / 50 file population')
    require({n for n in result if not n.endswith('.html')}=={'derived-structure.json','machine.json','size-report.json','dossier.json'},'exact machine-file population')
    return result

def metrics(site,m,names):
    cost=m.json_file(site/'size-report.json');cells=m.metric_cells(m.text(site/'size-report.html'),cost)
    require(len(cells)==147 and len(cost['pages'])==45,'exact metric denominators')
    measured=[r['path'] for r in cost['pages']]
    require(len(set(measured))==45 and set(measured)=={n for n in names if n.endswith('.html')}-{'size-report.html'},'complete measured-page population')
    for row in cost['pages']:require(m.measured_bytes(m.text(site/row['path']))==row['bytes'],'measured byte binding: '+row['path'])
    return cost,cells

def machine_files(before,after,m):
    old=(before/'derived-structure.json').read_bytes();new=(after/'derived-structure.json').read_bytes()
    raw_sidecars(old,new,m)
    for name in ['size-report.json','dossier.json']:
        require((before/name).read_bytes()==(after/name).read_bytes(),name+' bytes changed')
    old_machine=(before/'machine.json').read_bytes();new_machine=(after/'machine.json').read_bytes()
    a=json.loads(old_machine);b=json.loads(new_machine)
    require(a['derivedStructure']['sha256']==sha(old) and b['derivedStructure']['sha256']==sha(new),'machine sidecar digest bindings')
    a['derivedStructure'].pop('sha256');b['derivedStructure'].pop('sha256')
    require(a==b,'machine fields differ beyond derivedStructure.sha256')
    require(old_machine.count(sha(old).encode())==new_machine.count(sha(new).encode())==1,'one exact raw machine sidecar digest slot')
    require(old_machine.replace(sha(old).encode(),sha(new).encode(),1)==new_machine,'raw machine change beyond bound sidecar digest')
    return old,new

def strict_compare_sites(before,after,m,add_a215=False):
    old_names=paths(before,m);new_names=paths(after,m);require(old_names==new_names,'site file paths changed')
    old_cost,old_cells=metrics(before,m,old_names);new_cost,new_cells=metrics(after,m,new_names)
    require(old_cost==new_cost and old_cells==new_cells,'numeric metrics changed; no numeric allowance')
    old_record,new_record=machine_files(before,after,m)
    rows=[];failures=[]
    for name in [n for n in old_names if n.endswith('.html')]:
        try:rows.append(pair(name,m.text(before/name),m.text(after/name),old_record,new_record,m,add_a215))
        except (AssertionError,UnicodeError,KeyError) as error:failures.append({'path':name,'errorType':type(error).__name__,'reason':str(error)})
    return {'verdict':'PASS' if not failures else 'FAIL','htmlPopulation':46,'filePopulation':50,'matchedPages':len(rows),'A215AppliedToBaseline':add_a215,'reviewStatusPolicy':'exact per-page bytes; A-300 has no target on these Unknown notices','numericCellsPerSide':147,'measuredPagesPerSide':45,'numericMasking':False,'pageComparisons':rows,'failures':failures,'fullFiles':[{'path':name,'beforeSha256':sha((before/name).read_bytes()),'afterSha256':sha((after/name).read_bytes())} for name in old_names]}

def compare_sites(before,after,m,add_a215=False):
    paths(before,m)
    with tempfile.TemporaryDirectory(prefix='a303-expected-') as temporary:
        expected=Path(temporary)/'expected'
        transformation=a303_expected.expected_baseline(before,expected,before.name,m)
        record=strict_compare_sites(expected,after,m,add_a215)
        record['expectedBaselineTransformation']=transformation
        record['originalBaselineDirectory']=str(before)
        return record

def captured_final(settings,m):
    result=Path(settings['captureResults']);checkout=Path(settings['captureCheckout'])
    def git(*args):return subprocess.check_output(['git','-C',str(checkout),*args])
    require(git('rev-parse','HEAD').decode().strip()==settings['subject'],'captured checkout exact subject')
    require(git('rev-parse','HEAD^{tree}').decode().strip()==settings['subjectTree'],'captured checkout exact tree')
    require(git('status','--porcelain','-z')==b'','captured checkout clean')
    reports={name:read_json(result/(name+'.json')) for name in ['init','brief','check','render']}
    for name,wanted in [('init','initialized'),('brief','issued'),('check','passed'),('render','rendered')]:
        require(reports[name]['outcome']==wanted,'capture stage '+name)
    report=reports['render'];run=Path(report['run']);site=Path(report['site'])
    require(run.parent==result/'state' and run.name.startswith('run-') and site==run/'site/0','exact run/site capture directory binding')
    require(all(r['run']==str(run) for r in reports.values()),'one capture run across stages')
    require(report['draftRevision']==0 and report['pages']==46,'draft/site revision and page census')
    require(report['designReview']['counts'] is False and report['fidelityReview']['counts'] is False,'uncounted capture only')
    require(read_json(run/'run.json')['subject']['pinnedRevision']['commit']==settings['sourceCommit'],'run source commit')
    require(sha((run/'drafts/rev-0.json').read_bytes())==settings['draftSha256'],'entire checked frozen v4 draft')
    prepared=read_json(HERE/'prepared-input-pins.json')
    keys=['subject','main','subjectTree','mainTree','sourceCommit','sourceTree','sourceTreeEntries','sourceTreeListingSha256','sourceStatusSha256','sourceStatusEntries','configSha256','draftSha256','captureScriptSha256','correctedHelperSha256','finalComparatorSha256','sourceClosureSha256','frozenManifestSha256']
    for name in ['capture-before.json','capture-after.json']:
        pin=read_json(result/name)
        for key in keys:require(pin[key]==prepared[key],'capture pin drift: '+name+' '+key)
        raw=Path(pin['sourceTreeListingPath']).read_bytes()
        require(sha(raw)==pin['sourceTreeListingSha256'],'retained capture source listing')
    return site,reports

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-preparation-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args()
    settings=verify_preparation()
    if args.verify_preparation_only:
        print(json.dumps({'preparationVerified':True,'subject':settings['subject'],'main':settings['main'],'captureExecuted':False}));return
    m=helper();after,reports=captured_final(settings,m)
    out=args.output_dir or HERE/'comparison-first-run';out.mkdir(parents=True,exist_ok=False)
    results=[]
    for label,baseline,style in [('f043',HERE/'frozen-sites/f043',False),('2446',HERE/'frozen-sites/2446',True)]:
        try:record=compare_sites(baseline,after,m,style)
        except Exception as error:record={'verdict':'FAIL','errorType':type(error).__name__,'failure':str(error)}
        record.update({'subjectCommit':settings['subject'],'mergedMainCommit':settings['main'],'baselineCommit':settings['f043Commit'] if label=='f043' else settings['baselineCommit'],'comparatorSha256':sha(Path(__file__).read_bytes()),'correctedHelperSha256':sha((HERE/'retained/compare-bound-disclosure-v2.py').read_bytes()),'scope':'Exact frozen v4 static render comparison only; no native, counted Design/Fidelity, browser layout or timing acceptance'})
        (out/('comparison-final-to-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n');results.append({'baseline':label,'verdict':record['verdict'],'matchedPages':record.get('matchedPages')})
    print(json.dumps({'subject':settings['subject'],'main':settings['main'],'results':results,'outputDirectory':str(out)},indent=2))
    if any(r['verdict']!='PASS' for r in results):raise SystemExit(1)
if __name__=='__main__':main()
