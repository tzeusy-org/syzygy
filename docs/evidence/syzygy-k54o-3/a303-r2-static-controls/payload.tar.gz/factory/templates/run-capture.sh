#!/usr/bin/env bash
set -euo pipefail
if [[ ${1:-} != --heavy-slot-released || $# != 1 ]]; then
  printf '%s\n' 'Usage: bash run-capture.sh --heavy-slot-released (only after root releases the heavy slot)' >&2
  exit 2
fi
preparation=$(cd -- "$(dirname -- "$0")" && pwd)
mapfile -t capture_settings < <(python3 - "$preparation/settings.json" <<'PY'
import json,sys
s=json.load(open(sys.argv[1]))
for key in ['captureResults','captureScript','captureArm','subject','captureCheckout']:
 value=s[key]
 if '\n' in value or '\r' in value:raise SystemExit('newline in settings')
 print(value)
PY
)
test "${#capture_settings[@]}" = 5
results=${capture_settings[0]}
capture_script=${capture_settings[1]}
arm=${capture_settings[2]}
subject=${capture_settings[3]}
capture_checkout=${capture_settings[4]}
test ! -e "$results"
test ! -e "$capture_checkout"
test ! -e "$preparation/comparison-first-run"
test ! -e "$preparation/controls-first-run"
python3 "$preparation/compare-final.py" --verify-preparation-only
mkdir -p -- "$results"
python3 "$preparation/pin-inputs.py" --output "$results/capture-before.json"
# This frozen existing CLI script installs/builds only the exact clean Syzygy
# checkout and performs the pinned init/brief/check/render. It executes no Redis code.
set +e
bash "$capture_script" "$arm" "$subject"
capture_exit=$?
set -e
python3 "$preparation/pin-inputs.py" --output "$results/capture-after.json"
if [[ $capture_exit != 0 ]]; then
  printf 'Capture exited %s; retained reports and before/after pins.\n' "$capture_exit" >&2
  exit "$capture_exit"
fi
python3 "$preparation/reproduce-controls.py"
python3 "$preparation/compare-final.py"
