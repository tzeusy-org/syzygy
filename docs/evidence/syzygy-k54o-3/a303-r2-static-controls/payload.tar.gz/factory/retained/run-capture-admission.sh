#!/usr/bin/env bash
set -euo pipefail

capture_dir=$(dirname "$0")
arm=$1
revision=$2
checkout="$capture_dir/$arm"
results="$capture_dir/$arm-capture"
repo=/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w
source=/home/orca/.local/state/syzygy-polaris-clones/redis-redis-8.10.2
config=/home/orca/.tmp/f3-comprehension-781519d48/new-run-config.json
draft=/home/orca/.tmp/f3-matched-stage.CYZMqAy0/before-state/run-6d5534c1dc1867bfd6a8dea3045d35d3/drafts/rev-0.json

test "$(git -C "$source" rev-parse HEAD)" = 498ecd0d6d007db11ddb3aea9428552598a78622
test "$(sha256sum "$config" | cut -d ' ' -f1)" = 84b1976143d5b2b653d86193f5c9ea0330b3b0ec3b7e7afdeeca742e86a45068
test "$(sha256sum "$draft" | cut -d ' ' -f1)" = 927b9e84408d04fe922bd1d83add7553314f4202a91008f4dab347d47aad7d77
if [[ ! -d $checkout ]]; then
  git clone --quiet --local --no-checkout "$repo" "$checkout"
  git -C "$checkout" switch --detach "$revision"
fi
test "$(git -C "$checkout" rev-parse HEAD)" = "$revision"
test -z "$(git -C "$checkout" status --porcelain)"
mkdir -p "$results"
cd "$checkout"
npm ci --offline > "$results/npm-ci.log" 2>&1
npm run build > "$results/build.log" 2>&1
test -z "$(git status --porcelain)"
node apps/syzygy/dist/main.js dossier --json init "$source" --url https://github.com/redis/redis --config "$config" --state-root "$results/state" \
    > "$results/init.json" 2> "$results/init.stderr"
run=$(jq -er 'select(.outcome=="initialized")|.run' "$results/init.json")
case "$run" in
  "$results/state"/run-*) ;;
  *) exit 1 ;;
esac
node apps/syzygy/dist/main.js dossier --json brief "$run" > "$results/brief.json" 2> "$results/brief.stderr"
jq -e 'select(.outcome=="issued")|.run' "$results/brief.json" >/dev/null
mkdir -p "$run/drafts"
test ! -e "$run/drafts/next.json"
cp -- "$draft" "$run/drafts/next.json"
node apps/syzygy/dist/main.js dossier --json check "$run" > "$results/check.json" 2> "$results/check.stderr"
jq -e 'select(.outcome=="passed")|.run' "$results/check.json" >/dev/null
cmp -- "$draft" "$run/drafts/rev-0.json"
node apps/syzygy/dist/main.js dossier --json render "$run" > "$results/render.json" 2> "$results/render.stderr"
jq -e '.outcome=="rendered" and .draftRevision==0 and (.site|endswith("/site/0")) and .designReview.counts==false and .fidelityReview.counts==false' \
    "$results/render.json"
test -z "$(git status --porcelain)"
