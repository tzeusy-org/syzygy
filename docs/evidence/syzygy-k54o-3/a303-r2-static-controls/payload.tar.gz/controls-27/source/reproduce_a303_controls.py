#!/usr/bin/env python3
"""Opt-in 27 static controls; scratch fixtures only, no real render/build/native."""
from pathlib import Path
import argparse, ast, copy, gzip, hashlib, importlib.util, json, re, shutil, subprocess, sys, tempfile, types
from unittest import mock
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def require(ok,why):
    if not ok:raise AssertionError(why)
def json_bytes(data):return (json.dumps(data,indent=2)+'\n').encode('utf-8')
def read_json(path):return json.loads(path.read_bytes())
def census(site):return {p.relative_to(site).as_posix():sha(p.read_bytes()) for p in sorted(site.rglob('*')) if p.is_file()}
def replace(path,old,new):
    raw=path.read_text(encoding='utf-8');require(raw.count(old)==1,'exact mutation precondition: '+path.name)
    path.write_text(raw.replace(old,new,1),encoding='utf-8')
    return {'path':path.name,'old':old,'new':new,'beforeSha256':sha(raw.encode()),'afterSha256':sha(path.read_bytes())}
def load(name,path,source=None):
    if source is None:
        spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    else:
        module=types.ModuleType(name);module.__file__=str(path);exec(compile(source,str(path),'exec'),module.__dict__)
    return module


def expected_candidate(before,destination,label,bound,metrics,style):
    """Independent fixture oracle: never call the new expected-view helper."""
    shutil.copytree(before,destination)
    row=bound['baselines'][label]
    glossary=destination/'glossary.html'
    for definition in row['definitions']:replace(glossary,definition['old'],definition['new'])
    cost=read_json(destination/'size-report.json')
    next(page for page in cost['pages'] if page['path']=='glossary.html')['bytes']+=33
    next(depth for depth in cost['perPageDepth'] if depth['depth']==1)['bytes']+=33
    cost['totalBytes']+=33
    (destination/'size-report.json').write_bytes(json_bytes(cost))
    for change in row['sizeHtmlReplacements']:replace(destination/'size-report.html',change['old'],change['new'])
    if style:
        for path in destination.rglob('*.html'):
            rel=path.relative_to(destination).as_posix()
            path.write_text(metrics.styled_baseline(rel,path.read_text(encoding='utf-8')),encoding='utf-8')
    require(metrics.measured_bytes(glossary.read_text())-metrics.measured_bytes((before/'glossary.html').read_text())==33,'independent measured +33')
    require(read_json(destination/'size-report.json')['totalBytes']-read_json(before/'size-report.json')['totalBytes']==33,'independent total +33')
    return destination


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--prepared-directory',type=Path,required=True)
    ap.add_argument('--subject',required=True)
    ap.add_argument('--output-directory',type=Path,required=True)
    args=ap.parse_args();config=read_json(HERE/'control-binding.json');prepared=args.prepared_directory.resolve()
    require(re.fullmatch('[a-f0-9]{40}',args.subject) is not None,'explicit full subject SHA')
    require(args.subject==config['publishedSubject'],'controls bound to exact published subject')
    for name,expected in config['reviewedFiles'].items():require(sha((prepared/name).read_bytes())==expected,'reviewed byte binding: '+name)
    require(sha((HERE/'reproduce_a303_controls.py').read_bytes())==config['harnessSha256'],'harness binding')
    sys.path.insert(0,str(prepared))
    final=load('a303_control_comparator',prepared/'compare-final.py')
    settings=final.verify_preparation();require(settings['subject']==args.subject and settings['main']==config['main'],'prepared subject/main match')
    metrics=final.helper();a303=final.a303_expected;bound=a303.binding()
    args.output_directory.mkdir(parents=True,exist_ok=False)
    result={'state':'RUNNING','subject':args.subject,'main':settings['main'],'subjectTree':settings['subjectTree'],'harnessSha256':config['harnessSha256'],'controlBindingSha256':sha((HERE/'control-binding.json').read_bytes()),'reviewedFiles':config['reviewedFiles'],'sourceBindings':config['sourceBindings'],'positive':[],'negative':[],'scope':'Synthetic scratch copies, existing static parsers and read-only git. No real capture/build/native/checker invocation.'}
    def save(): (args.output_directory/'results.json').write_bytes(json_bytes(result))
    def removed_fragment(identity,raw):
        dest=args.output_directory/'mutant-inputs'/(identity+'.gz');dest.parent.mkdir(exist_ok=True)
        dest.write_bytes(gzip.compress(raw,mtime=0))
        return {'artifact':str(dest.relative_to(args.output_directory)),'sha256':sha(raw),'bytes':len(raw),'encoding':'gzip; exact removed bytes'}
    def deleted_fragment(identity,raw):
        destination=args.output_directory/'mutant-inputs'/(identity+'.gz')
        destination.parent.mkdir(exist_ok=True)
        destination.write_bytes(gzip.compress(raw,mtime=0))
        return {'artifact':destination.relative_to(args.output_directory).as_posix(),'sha256':sha(raw),'bytes':len(raw),'gzipMtime':0}
    def positive(identity,invoke):
        evidence=invoke();result['positive'].append({'id':identity,'outcome':'held','evidence':evidence});save()
    def negative(identity,mutations,invoke):
        try:invoke()
        except AssertionError as error:result['negative'].append({'id':identity,'outcome':'refused','mutations':mutations,'refusal':str(error)});save()
        else:raise AssertionError('negative control survived: '+identity)
    def compare(before,after,style=False):
        record=final.compare_sites(before,after,metrics,style)
        require(record['verdict']=='PASS','strict comparison refused: '+json.dumps(record.get('failures',[])))
        return record
    baselines={label:prepared/'frozen-sites'/label for label in ('f043','2446')}
    original={label:census(site) for label,site in baselines.items()}
    save()
    with tempfile.TemporaryDirectory(prefix='a303-control-scratch-') as temporary:
        root=Path(temporary);expected={label:expected_candidate(site,root/('expected-'+label),label,bound,metrics,label=='2446') for label,site in baselines.items()}
        for label in ('f043','2446'):
            def check(label=label):
                record=compare(baselines[label],expected[label],label=='2446');transform=record['expectedBaselineTransformation']
                require(record['matchedPages']==46 and record['filePopulation']==50,'complete strict population')
                require(transform['measuredByteDelta']==33 and transform['definitionCount']==3 and transform['numericTableCellsChanged']==2 and transform['numericTableCellsUnchanged']==145,'exact transformation census')
                return {'html':record['matchedPages'],'files':record['filePopulation'],'expectedTransformation':transform}
            positive(label+'-three-definitions-exact-view',check)
        def immutable():
            require(all(census(site)==original[label] for label,site in baselines.items()),'original baselines unchanged')
            return {'unchanged':True,'fileCounts':{label:len(rows) for label,rows in original.items()}}
        positive('immutable-original-baselines',immutable)
        require(all(census(site)==original[label] for label,site in baselines.items()),'original baselines unchanged')
        positive('full-read-only-source-binding',lambda:(a303.verify_source_binding(settings['repository'],args.subject,settings['main'],prepared/'inputs/frozen-draft-v4.json') or {'accepted':True}))
        def candidate_mutant(identity,mutate):
            target=root/identity;shutil.copytree(expected['f043'],target);changes=mutate(target)
            negative(identity,changes,lambda:compare(baselines['f043'],target))
        term=bound['baselines']['f043']['definitions'][1]
        candidate_mutant('missing-definition',lambda p:[replace(p/'glossary.html',term['new'],term['old'])])
        candidate_mutant('extra-definition',lambda p:[replace(p/'glossary.html','</dl>','<dt id="term-glossary/canary"><dfn>canary</dfn></dt><dd>canary</dd></dl>')])
        candidate_mutant('changed-definition-label',lambda p:[replace(p/'glossary.html','<dfn>PSYNC</dfn>','<dfn>PSYNC canary</dfn>')])
        candidate_mutant('changed-definition-fragment',lambda p:[replace(p/'glossary.html','id="term-glossary/PSYNC"','id="term-glossary/PSYNC-canary"')])
        candidate_mutant('changed-ordinary-byte',lambda p:[replace(p/'index.html','</main>','<p>Unrelated control paragraph.</p></main>')])
        def numeric_mutation(site,delta):
            file=site/'size-report.json';raw=file.read_bytes();cost=json.loads(raw);original_cost=read_json(baselines['f043']/'size-report.json')
            next(x for x in cost['pages'] if x['path']=='glossary.html')['bytes']+=delta-33
            next(x for x in cost['perPageDepth'] if x['depth']==1)['bytes']+=delta-33
            cost['totalBytes']+=delta-33;file.write_bytes(json_bytes(cost));changes=[{'path':file.name,'old':json.loads(raw),'new':cost,'beforeSha256':sha(raw),'afterSha256':sha(file.read_bytes())}]
            glossary_bytes=next(x['bytes'] for x in original_cost['pages'] if x['path']=='glossary.html');depth_bytes=next(x['bytes'] for x in original_cost['perPageDepth'] if x['depth']==1)
            for row in bound['baselines']['f043']['sizeHtmlReplacements']:
                new=row['new'].replace(str(glossary_bytes+33),str(glossary_bytes+delta)).replace(str(depth_bytes+33),str(depth_bytes+delta)).replace(str(original_cost['totalBytes']+33),str(original_cost['totalBytes']+delta))
                changes.append(replace(site/'size-report.html',row['new'],new))
            return changes
        candidate_mutant('wrong-plus32',lambda p:numeric_mutation(p,32))
        candidate_mutant('wrong-plus34',lambda p:numeric_mutation(p,34))
        def extra_field(p):
            file=p/'size-report.json';raw=file.read_bytes();cost=json.loads(raw);old=cost['unlabelledWords'];cost['unlabelledWords']=old+1;file.write_bytes(json_bytes(cost))
            return [{'path':file.name,'jsonPath':'unlabelledWords','old':old,'new':old+1,'beforeSha256':sha(raw),'afterSha256':sha(file.read_bytes())}]
        candidate_mutant('extra-metric-field',extra_field)
        total=read_json(expected['f043']/'size-report.json')['totalBytes']
        candidate_mutant('unbound-size-summary',lambda p:[replace(p/'size-report.html',f'All 45 pages: {total} bytes.',f'All 45 pages: {total+1} bytes.')])
        candidate_mutant('unrelated-table-cell',lambda p:[replace(p/'size-report.html','<tr><td>0</td><td>1</td>','<tr><td>0</td><td>2</td>')])
        missing=root/'missing-baseline-file'/'f043';shutil.copytree(baselines['f043'],missing);removed=(missing/'index.html').read_bytes();(missing/'index.html').unlink()
        negative('missing-baseline-file',[{'path':'index.html','old':removed_fragment('missing-baseline-file',removed),'new':None}],lambda:compare(missing,expected['f043']))
        def remove_candidate(p):
            raw=(p/'index.html').read_bytes();(p/'index.html').unlink();return [{'path':'index.html','old':removed_fragment('missing-candidate-file',raw),'new':None}]
        candidate_mutant('missing-candidate-file',remove_candidate)
        def extra_candidate(p):
            (p/'canary.txt').write_bytes(b'canary\n');return [{'path':'canary.txt','old':None,'new':'canary\n'}]
        candidate_mutant('extra-candidate-file',extra_candidate)
        drift=root/'old-baseline-drift'/'f043';shutil.copytree(baselines['f043'],drift);change=replace(drift/'glossary.html','</main>',' </main>')
        negative('old-baseline-drift',[change],lambda:compare(drift,expected['f043']))
        # Inject only the selected git-show result. Every actual Git request remains read-only.
        real_output=subprocess.check_output
        ledger_path='.syzygy/governance/decisions/AGENT-ADOPTIONS.md';adoption=bound['adoptionRowVerbatim']
        def source_mutant(identity,path,old,new):
            command=['git','-C',settings['repository'],'show',args.subject+':'+path]
            before=real_output(command);text=before.decode();require(text.count(old)==1,'exact source mutation precondition')
            after=text.replace(old,new,1).encode()
            def injected(args,*a,**kw):return after if args==command else real_output(args,*a,**kw)
            mutations=[{'path':path,'commit':args.subject,'old':old,'new':new,'beforeSha256':sha(before),'afterSha256':sha(after)}]
            with mock.patch.object(a303.subprocess,'check_output',side_effect=injected):negative(identity,mutations,lambda:a303.verify_source_binding(settings['repository'],args.subject,settings['main'],prepared/'inputs/frozen-draft-v4.json'))
        source_mutant('missing-adoption-row',ledger_path,adoption+'\n','')
        source_mutant('changed-adoption-row',ledger_path,adoption,adoption.replace('reader-facing','reader facing',1))
        source_path=bound['sourceBindings'][0]['path'];source_mutant('changed-render-source',source_path,'export function renderDossierSite(', 'export function renderDossierSiteCanary(')
        negative('wrong-main',[{'field':'main','old':settings['main'],'new':'0'*40}],lambda:a303.verify_source_binding(settings['repository'],args.subject,'0'*40,prepared/'inputs/frozen-draft-v4.json'))
        draft=root/'wrong-full-draft.json';raw=(prepared/'inputs/frozen-draft-v4.json').read_bytes();draft.write_bytes(raw+b' ')
        negative('wrong-full-draft',[{'path':'inputs/frozen-draft-v4.json','old':'EOF','new':'EOF + space','beforeSha256':sha(raw),'afterSha256':sha(draft.read_bytes())}],lambda:a303.verify_source_binding(settings['repository'],args.subject,settings['main'],draft))
        bad_digest=copy.deepcopy(bound);bad_digest['subjectOverlaySha256']='0'*64
        with mock.patch.object(a303,'binding',return_value=bad_digest):
            negative('wrong-overlay-digest',[{'path':'a303-binding.json','jsonPath':'subjectOverlaySha256','old':bound['subjectOverlaySha256'],'new':'0'*64}],lambda:a303.verify_source_binding(settings['repository'],args.subject,settings['main'],prepared/'inputs/frozen-draft-v4.json'))
        overlay_command=['git','-C',settings['repository'],'diff',settings['main'],args.subject,'--',*[r['path'] for r in bound['sourceBindings']]]
        original_overlay=real_output(overlay_command);bad_overlay=original_overlay+b'# control changes actual overlay\n'
        def overlay_injected(command,*a,**kw):return bad_overlay if command==overlay_command else real_output(command,*a,**kw)
        with mock.patch.object(a303.subprocess,'check_output',side_effect=overlay_injected):
            negative('wrong-overlay-patch',[{'path':'read-only git diff main..subject','old':'EOF','new':'EOF# control changes actual overlay\n','beforeSha256':sha(original_overlay),'afterSha256':sha(bad_overlay)}],lambda:a303.verify_source_binding(settings['repository'],args.subject,settings['main'],prepared/'inputs/frozen-draft-v4.json'))
        comparator_source=(prepared/'compare-final.py').read_text();tree=ast.parse(comparator_source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compare_sites');old=ast.get_source_segment(comparator_source,node);new='def compare_sites(before,after,m,add_a215=False):\n    return strict_compare_sites(before,after,m,add_a215)'
        require(comparator_source.count(old)==1,'exact transform-removal mutant')
        mutant=load('a303_bypass_transform_mutant',prepared/'compare-final.py',comparator_source.replace(old,new,1))
        def bypass():
            record=mutant.compare_sites(baselines['f043'],expected['f043'],metrics,False);require(record['verdict']=='PASS','positive fixture rejects omitted transform')
        negative('bypass-transform-mutant',[{'path':'compare-final.py','old':old,'new':new,'sourceSha256':sha(comparator_source.encode()),'mutantSha256':sha(comparator_source.replace(old,new,1).encode())}],bypass)
        helper_source=(prepared/'a303_expected.py').read_text();mutant_source=helper_source
        guards=[("require(delta==len(transformed.encode('utf-8'))-len(glossary.encode('utf-8'))==33,'exact measured A303 +33 bytes')","require(delta==len(transformed.encode('utf-8'))-len(glossary.encode('utf-8')),'mutant accepts any measured delta')"),("require({(a['table'],a['row'],a['column']) for a,b in changed}==expected_cells and len(changed)==2,'only two exact metric table cells')","pass  # mutant omits numeric-cell identity guard")]
        mutations=[]
        for old,new in guards:
            require(mutant_source.count(old)==1,'exact numeric-guard source mutant');mutant_source=mutant_source.replace(old,new,1);mutations.append({'path':'a303_expected.py','old':old,'new':new})
        bad_bound=copy.deepcopy(bound);definition=bad_bound['baselines']['f043']['definitions'][1];old=definition['new'];new=old.replace('<dfn>','<dfn data-canary="1">');definition['new']=new;bad_delta=33+len(new.encode())-len(old.encode());mutations.append({'path':'a303-binding.json','jsonPath':'baselines.f043.definitions[1].new','old':old,'new':new})
        original_cost=read_json(baselines['f043']/'size-report.json');old_values=[next(x['bytes'] for x in original_cost['pages'] if x['path']=='glossary.html'),next(x['bytes'] for x in original_cost['perPageDepth'] if x['depth']==1),original_cost['totalBytes']]
        for i,row in enumerate(bad_bound['baselines']['f043']['sizeHtmlReplacements']):
            old=row['new'];row['new']=old.replace(str(old_values[i]+33),str(old_values[i]+bad_delta));mutations.append({'path':'a303-binding.json','jsonPath':f'baselines.f043.sizeHtmlReplacements[{i}].new','old':old,'new':row['new']})
        bad_helper=load('a303_numeric_guard_mutant',prepared/'a303_expected.py',mutant_source);bad_helper.binding=lambda:bad_bound
        # Prove the malformed coherent binding is rejected by the real guard.
        with mock.patch.object(a303,'binding',return_value=bad_bound):
            try:a303.expected_baseline(baselines['f043'],root/'guard-original-must-refuse','f043',metrics)
            except AssertionError:pass
            else:raise AssertionError('real numeric guard did not reject malformed binding')
        bad_helper.expected_baseline(baselines['f043'],root/'guard-mutant-view','f043',metrics)
        require(sha((root/'guard-mutant-view/glossary.html').read_bytes())!=sha((expected['f043']/'glossary.html').read_bytes()),'guard mutant actually broadens expected output')
        mutations.append({'sourceSha256':sha(helper_source.encode()),'mutantSha256':sha(mutant_source.encode()),'badBindingSha256':sha(json_bytes(bad_bound)),'badDelta':bad_delta})
        def independent_oracle():
            changed=(root/'guard-mutant-view/glossary.html').read_text();before=(baselines['f043']/'glossary.html').read_text()
            require(metrics.measured_bytes(changed)-metrics.measured_bytes(before)==33 and changed==(expected['f043']/'glossary.html').read_text(),'independent three-fragment/+33 oracle rejects numeric-guard mutant')
        negative('loosen-numeric-guard-mutant',mutations,independent_oracle)
    require(all(census(site)==original[label] for label,site in baselines.items()),'all original baselines remain exact')
    require([r['id'] for r in result['positive']]==config['positiveIds'] and [r['id'] for r in result['negative']]==config['negativeIds'],'exact ordered27control population')
    require(len(result['positive'])==4 and len(result['negative'])==23,'4positive/23negative denominator')
    result.update(state='PASS',executedControls=27,originalBaselinesUnchanged=True);save()
    print(json.dumps({'state':result['state'],'subject':args.subject,'positives':4,'negatives':23,'output':str(args.output_directory)}))

if __name__=='__main__':main()
