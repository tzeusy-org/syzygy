# A303 R2control harness — source only

Executable27control harness:4positive+23negative. It retains original25proposal identities and adds wrong-overlay-digest and wrong-overlay-patch. Exact helper/comparator/binding/overlay bytes and published9c878b13 subject are pinned by control-binding.json. Syntax and ASTliteral-control-ID census passed; no helper/control execution occurred.

Each candidate and baseline mutation affects only fresh scratch copies. Source/adoption mutants inject one exact read-only git-show result; overlay mutation injects one exact read-only git-diff result. No repository writes occur. Deletion mutants retain exact removed raw bytes as deterministic gzip; source/config mutants retain exact old/new fragments and original/mutant SHA. The final result must contain the ordered4positive/23negative identities and unchanged original baseline censuses. Unexpected exceptions abort instead of being counted as successful negatives.

The numeric guard mutant is required first to demonstrate malformed coherent binding refusal by the original guard, then acceptance by the weakened guard; the independent exact3-fragment/+33oracle must reject that broadened expected view. Omitted-transform mutant must fail the independent exact positive fixture. Controls construct synthetic expected candidates directly from exact reviewed fragments, never by invoking the new helper as their own oracle.

Run only the explicit command in control-binding.json after fresh source review and heavy-slot release. The exact subject must first be prepared through the reviewed R2factory. Existing233+8controls execute separately unchanged. Actual final capture still required; static controls establish no native/recovery/hosted timing acceptance.
