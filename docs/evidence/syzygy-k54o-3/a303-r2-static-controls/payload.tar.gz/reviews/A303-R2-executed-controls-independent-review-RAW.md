[Inferred] The retained records support the stated static-control outcomes and denominators. They establish no actual final render/capture or native acceptance result.

[Observed] Reviewed read-only on 2026-11-25: A303-R2-control-execution-9c/results.json; the three controls-first-run JSON files under final-render-capture-factory-A303-R2/subjects/9c878b13f5ea7b819b4817517c675810d4b0f23c--main-1a4903374ea928b0489953e8cdedb22f1a6debf2; their reproduction drivers and directly used comparator/control source. No controls were rerun and no source or fixture was mutated.

A303 R2 execution

[Observed] results.json records state PASS, subject 9c878b13f5ea7b819b4817517c675810d4b0f23c, tree bc89690012bb7bb7de7a973c8e4f04071b378c6b, and main 1a4903374ea928b0489953e8cdedb22f1a6debf2. Its actual arrays contain 4 held positives and 23 refused negatives: 27 unique IDs, matching the exact ordered IDs in control-binding.json and executedControls=27. Python enumeration and independent jq counts agree; neither outcome array has a nonmatching outcome.

[Observed] The four positives are two independent synthetic expected-site comparisons (f043 and 2446), original-baseline immutability, and full read-only source/adoption/overlay binding. Each site comparison records 46 matched HTML files / 50 total files, three exact glossary definitions, measured +33 bytes, two changed and 145 unchanged numeric table cells, bound aggregate summary, and no numeric masking. Current frozen-site censuses independently contain 46 HTML / 50 files per baseline. These are two scratch candidate sites, not two actual captures.

[Observed] The 23 negatives cover missing/extra/altered glossary definitions; an unrelated reader byte; +32/+34 numeric changes; an extra numeric-field change; an unbound summary; an unrelated table cell; missing baseline/candidate and extra candidate files; old-baseline drift; missing/changed adoption row; changed renderer source; wrong main, full draft, overlay digest and overlay patch; transform bypass; and weakened numeric guards. Each record includes mutation details and refusal text. The two retained gzip deletion fixtures decompress to their recorded byte counts and hashes.

[Observed] The driver marks a positive held only after its invocation returns, and a negative refused only when the tested invocation raises AssertionError; a surviving negative aborts. Completion also requires unchanged original file censuses, exact ordered IDs, and the 4/23 denominator. The prepared comparator separately enforces file populations, physical-byte metrics, numeric identity, machine-file bindings, and HTML comparisons. The harness and binding hashes, and all four reviewed prepared-file hashes, match the result's recorded bindings.

[Inferred] Refusal reasons constrain interpretation: missing/extra/changed definitions and +32/+34 cases stop at measured-byte binding, rather than proving each downstream predicate independently. The bypass mutant fails the positive fixture when the expected-view transform is omitted. The numeric-guard mutant is deliberately allowed to produce a coherent malformed +49 view; the independent three-fragment/+33 oracle rejects it. That last result demonstrates the oracle detects broadened output, not that the weakened comparator itself refuses it. Subject source is explicitly bound separately from main: dossier-site.ts differs between them and dossier-finding.ts matches.

Older 233 + 8 reproduction

[Observed] retained-202-controls.json contains 46 positive page IDs and 202 distinct detected canary IDs. The source constructs 46 × 4 page mutations plus 18 targeted metric/population/disclosure/numeric mutations. retained-31-disclosure-controls.json contains 31 distinct detected:true negatives and two changed-observation positives (index.html and maps/directories.html). Both output files are byte-identical to the corresponding retained predecessor records.

[Observed] control-summary.json records 233 retained negatives (=202+31), 46 additional f043 self-comparison positive pages, and eight detected:true new negatives: reader content, main attribute, review-status text, label, population, style, outside-main bytes, and raw-sidecar whitespace. Python and jq independently confirm 202, 31 and 8; the 31 and 8 arrays have no nondetected remainder. The two 46-page positive lists are separate checks and must not be presented as 92 distinct pages.

[Observed] The older replay creates synthetic loader records, reuses frozen 2446/f043 sites and the full known v4 draft, executes the retained selftest/canaries, and requires their serialized outputs to equal predecessor outputs exactly. The original 202 and 31 controls count rejection on AssertionError or UnicodeError; the eight added checks similarly require rejection (raw-sidecar uses AssertionError). Final pair() checks exact review-status region, main opening, outside-main bytes, permitted observation slots, and raw-sidecar capturedAt-only change. This replay exercises the old fixtures; it is not an A303 final-capture comparison.

Limits and evidence bindings

[Unknown] Actual final capture/render, production output equivalence, native performance/recovery, real checker success, and provider/network behavior remain Unknown under this review. Neither execution driver invokes a real capture/build/native/checker; the new driver uses scratch copies and scoped injected results for read-only Git calls. This audit reads retained execution records and source and does not independently replay them. The controls' counts cannot be promoted into a final-capture PASS or native acceptance.

[Observed] SHA-256 evidence bindings:

- New results.json: 4f3058e8f844b6f3c62f3e77dabb9586cf3cd3ce7ee4a6d4e395af9094b8d08d
- Old retained-202-controls.json: 9e52312373559c76f0c58bd8031af016c32890bac76fc6a1f1bb6358f62f901a
- Old retained-31-disclosure-controls.json: 64cb8f2ab64114433185c7cad31bc1fc86442100db81c9146e86129fff703c26
- Old control-summary.json: f6f4eb35aed91bb8755c039a21e4fa68052980a851776771549c8dc53222371f
- New driver: 9be76865745e5ce8e5e7fb9914c84f8b339d343ec4d54769f60ff73d01892d53
- New control binding: 3153c6dbb8385e490e5cf3f10af7d64bff047ac10bced14e7e9b06d412461d34
