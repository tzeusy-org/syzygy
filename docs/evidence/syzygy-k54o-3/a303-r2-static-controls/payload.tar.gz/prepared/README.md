Prepared only for exact supplied subject 9c878b13f5ea7b819b4817517c675810d4b0f23c, including supplied merged main 1a4903374ea928b0489953e8cdedb22f1a6debf2.

No build, capture, test suite, control replay or native execution was performed by preparation. Preserve the full schema-v4 draft and source/config pins. Do not call any earlier working HEAD final.

Only after root confirms this subject is published and releases the heavy slot:
  bash /home/orca/.tmp/f3-native-admission-fixes/final-render-capture-factory-A303-R2/subjects/9c878b13f5ea7b819b4817517c675810d4b0f23c--main-1a4903374ea928b0489953e8cdedb22f1a6debf2/run-capture.sh --heavy-slot-released

This uses the existing frozen clean pinned CLI capture script once, records fresh pins before/after, then explicitly replays retained static controls and compares final→f043 with the exact source/adoption-bound A-303 expected view, and final→2446 with that same expected view plus only the existing A-215 additions. Both require exact review-status region and outside-main bytes, strict 46/50 populations, all 147 metric cells (two independently derived +33 byte cells, 145 exact unchanged cells) and all 45 measured-page byte counts. A-303 adds exactly three dfn wrappers and the exact derived glossary/depth1/total byte metrics; it grants no content or numeric mask. No broad region, digit, content, schema or numeric mask is admitted. A-300 has no target in this frozen uncounted v4 subject; a status change is a failure, not a new allowance.

Separate later lightweight commands (not run during preparation):
  python3 /home/orca/.tmp/f3-native-admission-fixes/final-render-capture-factory-A303-R2/subjects/9c878b13f5ea7b819b4817517c675810d4b0f23c--main-1a4903374ea928b0489953e8cdedb22f1a6debf2/compare-final.py --verify-preparation-only
  python3 /home/orca/.tmp/f3-native-admission-fixes/final-render-capture-factory-A303-R2/subjects/9c878b13f5ea7b819b4817517c675810d4b0f23c--main-1a4903374ea928b0489953e8cdedb22f1a6debf2/reproduce-controls.py
  python3 /home/orca/.tmp/f3-native-admission-fixes/final-render-capture-factory-A303-R2/subjects/9c878b13f5ea7b819b4817517c675810d4b0f23c--main-1a4903374ea928b0489953e8cdedb22f1a6debf2/compare-final.py

Control/comparison output directories are created once and never overwritten. Running controls separately before the wrapper means the wrapper will refuse its existing controls-first-run directory; keep the default wrapper as the single sequence, or run the three stages explicitly without reusing an output directory. Any corrected comparator requires separately frozen new bytes and new output names; retain any FAIL verbatim.
