MATCH WITH EXPLICIT BOUND OBSERVATION METADATA NORMALIZATION

Subject: f043a10aab6bf3baee0b1acd24c72b78d3654ded
Baseline:2446c64edb7bb9e0c89169bddd129efca36cad65 (F3-inclusive admission subject, not non-F3 main).
Corrected comparator SHA256:f8e7571292cea78469a48926a825cd08d71348bdb5e2f9610912d6892bcd7e20
Correction patch SHA256:8c90c517de690b68eb8b61d5e194ebfc50af2aa26799d5fdb63a20a73b362770
Corrected raw result SHA256:e564a22dbacc8652d5e9a15d9bed473d94f54e4082f350f3a262edc70984c4a9
Full source/config/v4-draft pins, inventories, result hashes and provenance:actual-capture-binding.json and captured before/after input pins.

[Observed] The isolated exact-source capture reached initialized, issued, passed and rendered at draft revision0/site0. Its Redis commit/config/full frozen v4 draft pins matched before and after. The HTML/file populations are46/50, checked with rglob, os.walk and independent find. Actual full config/draft inputs are retained privately in actual-inputs; source Git tree metadata is retained in the before/after records.

[Observed] The original strict comparator FAIL is preserved unchanged in comparison.json. Its full46-page diagnostic sweep passed44 paths and refused index.html and maps/directories.html. It had admitted record-digest attributes but omitted existing hidden evidence-disclosure copies of that same digest. The original synthetic positives reused one record and missed this varying-record case. This was an observation-slot omission in the prepared comparator, not evidence of a worthKnowing reader-content change.

[Observed] Both actual sidecars have the same4476-byte size and differ only at /capturedAt by recursive field comparison. Their raw SHA256 values are39287a2751da172168fc6fc6cc7858d495144280941d0c2ea0fcc7aa332dd081 and96ec22ac3413bdd785624c29b07520a815537bfeec2ad56f3993b4c50cb0efa1. Each rendered side has21 hidden disclosure digest tokens on each of the two derived pages:42 per capture. A regex exact-body census and an independent HTMLParser enclosing-item census agree. Each slot is bound to its fact identity/path/rule/version/revision, enclosing data-derived-record attribute and the raw sidecar digest. The complete adjacent prose must match before only its64-character digest token is normalized. Other free digest occurrences remain reader content.

[Observed] The separately frozen corrected comparator exited0 and matched46/46 reader main regions and main opening attributes with only91 exact A-215 style additions and explicit observation metadata normalization (43 digest attributes,2 timestamps,42 hidden disclosure tokens per capture). Outside-main bytes match on the46 paired pages. All147 numeric metric cells remain unchanged; numeric masking is disabled, and the measured byte count of45 measured pages is checked. size-report.json and dossier.json are byte-identical; machine.json differs only at /derivedStructure/sha256. No schema-version replacement, worthKnowing markup/content normalization or broad digest replacement is used.

[Observed] Corrected synthetic checks retain202 detected negative canaries across46 positive baseline pages. Two positive cases now vary the actual observation timestamp and full sidecar digest. Another31 negative canaries detect changed prose, source path, current revision, displayed derived value, headings/content/schema/sidecar value, attribute/text/sidecar digest mismatches, extra digest occurrences and derived-item population drift. Every new canary records its old/new fragment, subject and outcome.

[Unknown] Native/Stop/recovery, counted Design/Fidelity, browser reflow and hosted timing acceptance. This fixed v4 matched-rendering result establishes no general claim for other drafts or schemas. The corrected comparator was authored by this agent; root's independent source review of these frozen bytes remains pending. No recapture/build was run for the correction, and primary/index/commits were untouched by this task.
