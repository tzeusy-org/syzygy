import argparse, hashlib, json, os, re, subprocess
from pathlib import Path
from html.parser import HTMLParser

ROOT = Path('/home/orca/.tmp/f3-exact-stage-8dcb0.FXKsif1O')
BASELINE = 'admission-2446c64ed'
CANDIDATE = 'admission-f043a10aab6b'
SUBJECT = 'f043a10aab6bf3baee0b1acd24c72b78d3654ded'
BASE_COMMIT = '2446c64edb7bb9e0c89169bddd129efca36cad65'
SOURCE = '498ecd0d6d007db11ddb3aea9428552598a78622'
DRAFT_SHA = '927b9e84408d04fe922bd1d83add7553314f4202a91008f4dab347d47aad7d77'
STYLE = ' style="overflow-wrap:anywhere"'
REGION = re.compile(r'(<aside class="review-status" data-review-status-region="review-status" aria-label="Review status"><h2>Review status</h2><ul)(>.*?</ul></aside>)', re.S)
ISO = re.compile(r'20[0-9]{2}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3}Z')
h = lambda b: hashlib.sha256(b).hexdigest()
def require(ok, why):
    if not ok: raise AssertionError(why)
def text(p): return p.read_bytes().decode('utf-8', errors='strict')
def json_file(p): return json.loads(text(p))
def paths(directory):
    a = sorted(p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file())
    b = sorted((Path(base)/n).relative_to(directory).as_posix() for base,_,names in os.walk(directory) for n in names if (Path(base)/n).is_file())
    require(a == b, 'rglob/os.walk census disagreement')
    return a

def population(a, b):
    require(len(a) == len(b) == 46 and a == b, 'HTML path population mismatch')

class Parse(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source=source; self.lines=source.splitlines(keepends=True); self.stack=[]
        self.main=[]; self.main_end=[]; self.review_ul=[]; self.size_links=[]; self.size_tables=0
        self.feed(source); self.close()
    def position(self):
        line,col=self.getpos(); return sum(map(len,self.lines[:line-1]))+col
    def handle_starttag(self, tag, attrs):
        d=dict(attrs); raw=self.get_starttag_text(); at=self.position()
        if tag=='main': self.main.append((at, at+len(raw), raw))
        review=any(t=='aside' and a.get('data-review-status-region')=='review-status' for t,a in self.stack)
        size=any(t=='section' and a.get('id')=='size-report' for t,a in self.stack)
        if tag=='ul' and review: self.review_ul.append((raw,d))
        if tag=='table' and size: self.size_tables+=1
        if tag=='a' and size and self.size_tables==2: self.size_links.append((raw,d))
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.stack.append((tag,d))
    def handle_endtag(self, tag):
        if tag=='main': self.main_end.append(self.position())
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i][0]==tag: self.stack=self.stack[:i]; break
    def main_parts(self):
        require(len(self.main)==len(self.main_end)==1, 'one main start/end required')
        at,start,raw=self.main[0]; end=self.main_end[0]
        require(start<=end, 'main range order')
        inner=self.source[start:end]
        second=re.findall(r'<main\b[^>]*>(.*?)</main>',self.source,re.S)
        require(second==[inner], 'parser/regex main extraction disagreement')
        return raw,inner,self.source[:start]+self.source[end:]

def styled_baseline(name, source):
    parsed=Parse(source)
    require(len(parsed.review_ul)==1 and parsed.review_ul[0][0]=='<ul>', 'baseline review ul shape')
    transformed,n=REGION.subn(lambda m:m[1]+STYLE+m[2],source)
    require(n==1, 'exact named review ul location count')
    if name=='size-report.html':
        require(len(parsed.size_links)==45, 'independent baseline size-link census')
        table=re.findall(r'<section id="size-report">.*?</section>',transformed,re.S)
        require(len(table)==1, 'size section shape')
        section=table[0]
        transformed_section,n=re.subn(r'(<tr><td><a href="[^"]+")(>)',lambda m:m[1]+STYLE+m[2],section)
        require(n==45, 'exact size-table link additions')
        transformed=transformed.replace(section,transformed_section,1)
    return transformed

def styles(name, source):
    parsed=Parse(source)
    require(len(parsed.review_ul)==1 and parsed.review_ul[0][0]=='<ul'+STYLE+'>', 'candidate review ul exact style shape')
    if name=='size-report.html':
        require(len(parsed.size_links)==45, 'independent candidate size-link census')
        require(all(a.get('style')=='overflow-wrap:anywhere' and set(a)=={'href','style'} for _,a in parsed.size_links), 'size-table exact attribute admission')
    return {'reviewStatusUl':len(parsed.review_ul),'sizeTablePathLinks':len(parsed.size_links)}

def normalize_observation(name, source, record_bytes):
    if name not in {'index.html','maps/directories.html'}: return source, None
    record=json.loads(record_bytes.decode('utf-8', errors='strict'))
    timestamp=record['capturedAt']; require(isinstance(timestamp,str) and ISO.fullmatch(timestamp), 'derived capturedAt exact ISO shape')
    require(record['revision']==SOURCE and record['format']=='polaris-dossier-derived-structure/1', 'derived source/format identity')
    digest=h(record_bytes)
    found=re.findall(r'data-derived-record="([^"]+)"',source)
    expected_count=22 if name=='index.html' else 21
    require(len(found)==expected_count and set(found)=={'sha256:'+digest}, 'bound derived-record attribute slots')
    context='listed at '+timestamp+', by rule top-level-unit version 1.'
    require(source.count(context)==1, 'timestamp exact derivation-prose slot')
    replaced=source.replace(context,'listed at [capturedAt], by rule top-level-unit version 1.',1)
    replaced=re.sub(r'data-derived-record="sha256:'+digest+'"','data-derived-record="sha256:[bound-record]"',replaced)
    return replaced,{'capturedAt':timestamp,'derivedRecordSha256':digest,'digestAttributeSlots':expected_count,'timestampSlots':1}

def pair(name, before, after, old_record, new_record):
    expected=styled_baseline(name,before)
    census=styles(name,after)
    old_open,a,old_outside=Parse(expected).main_parts(); new_open,b,new_outside=Parse(after).main_parts()
    require(old_open==new_open, 'unexpected main opening attributes')
    a,oldslots=normalize_observation(name,a,old_record); b,newslots=normalize_observation(name,b,new_record)
    require(a==b, 'reader main differs beyond exact A-215 styles and bound observation slots')
    return {'path':name,'wholeHtmlExact':before==after,'beforeHtmlSha256':h(before.encode()),'afterHtmlSha256':h(after.encode()),
      'mainComparison':'exact after enumerated A-215 additions and bound observation fields only','styleCensus':census,
      'observationBefore':oldslots,'observationAfter':newslots,'outsideMainExact':old_outside==new_outside,
      'beforeOutsideSha256':h(old_outside.encode()),'afterOutsideSha256':h(new_outside.encode())}

def measured_bytes(source):
    result,n=re.subn(r'<aside class="review-status" data-review-status-region="review-status" aria-label="Review status">.*?</aside>','',source,flags=re.S)
    require(n==1, 'measured region count')
    result=re.sub(r'<span class="term-pop"[^>]*>.*?(?:<span class="visually-hidden ev">)?<span class="marking [a-z-]+">[^<]*</span>(?:</span>)?</span>','',result,flags=re.S)
    return len(result.encode('utf-8'))

def metric_cells(source, cost, validate=True):
    section=re.findall(r'<section id="size-report">.*?</section>',source,re.S)
    require(len(section)==1,'size report exact section')
    rows=re.findall(r'<tr\b[^>]*>(.*?)</tr>',section[0],re.S)
    require(len(rows)==50, 'metric table row denominator')
    result=[]; groups=[cost['perPageDepth'],cost['pages']]; start=0
    for group_i,group in enumerate(groups):
        header=re.findall(r'<th>(.*?)</th>',rows[start],re.S)
        require(header==(['Link depth','Pages','Bytes','Words'] if group_i==0 else ['Page','Depth','Bytes','Words']), 'metric headings preserved')
        for index,row in enumerate(group):
            cells=re.findall(r'<td>(.*?)</td>',rows[start+index+1],re.S); require(len(cells)==4, 'metric row four cells')
            expected=[row['depth'],row['pages'],row['bytes'],row['words']] if group_i==0 else [None,row['depth'],row['bytes'],sum(row['wordsByReadingLevel'].values())+row['unlabelledWords']]
            for column,value in enumerate(expected):
                if value is None: continue
                require(re.fullmatch(r'0|[1-9][0-9]*',cells[column]) is not None,'numeric metric grammar')
                if validate: require(int(cells[column])==value,'numeric metric bound to size-report.json')
                result.append({'table':group_i,'row':index,'column':column,'value':int(cells[column])})
        start+=len(group)+1
    first=cost['firstReadingLevel']
    expected=f'the overview</a>, {first["bytesThroughFirstLevel"]} bytes and {first["words"]} words, of an entry page of {first["entryPageBytes"]} bytes. All {len(cost["pages"])} pages: {sum(p["bytes"] for p in cost["pages"])} bytes.'
    if validate: require(section[0].count(expected)==1, 'summary numbers bound to own size report')
    return result

def load(arm):
    report=json_file(ROOT/(arm+'-capture')/'render.json'); require(report['outcome']=='rendered' and report['draftRevision']==0 and report['pages']==46,'render stage')
    require(report['designReview']['counts'] is False and report['fidelityReview']['counts'] is False,'not counted reviews')
    run=Path(report['run']); site=Path(report['site'])
    require(run.parent==ROOT/(arm+'-capture')/'state' and run.name.startswith('run-'),'capture run directory binding')
    require(site==run/'site/0','site stage 0')
    require(json_file(run/'run.json')['subject']['pinnedRevision']['commit']==SOURCE,'run source pin')
    require(h((run/'drafts/rev-0.json').read_bytes())==DRAFT_SHA,'full checked draft pin')
    return site

def main(selftest):
    before=load(BASELINE); all_before=paths(before); html=[p for p in all_before if p.endswith('.html')]
    require(len(html)==46 and len(all_before)==50,'baseline page/file census')
    old_record=(before/'derived-structure.json').read_bytes()
    if selftest:
        detected=[]; positives=[]
        def rejects(label, call):
            try: call()
            except (AssertionError,UnicodeError): detected.append(label); return
            raise AssertionError('canary survived: '+label)
        for name in html:
            original=text(before/name); candidate=styled_baseline(name,original)
            pair(name,original,candidate,old_record,old_record); positives.append(name)
            for label,mutant in [('extra-main-content',candidate.replace('</main>','<p>reader mutation</p></main>',1)),
              ('unexpected-main-attribute',candidate.replace('<main','<main data-unexpected="1"',1)),
              ('newline',candidate.replace('</main>','\r\n</main>',1)),
              ('wrong-review-style',candidate.replace('<ul'+STYLE+'>','<ul style="overflow-wrap:normal">',1))]:
                rejects(name+':'+label,lambda n=name,x=original,y=mutant:pair(n,x,y,old_record,old_record))
        original=text(before/'size-report.html'); candidate=styled_baseline('size-report.html',original)
        for label,mutant in [('changed-href',candidate.replace('<tr><td><a href="','<tr><td><a href="changed-',1)),
          ('changed-heading',candidate.replace('Link depth','Changed heading',1)),
          ('changed-link-text',re.sub(r'(<tr><td><a [^>]+>)([^<]*)',r'\1changed text',candidate,count=1)),
          ('wrong-path-link-style',re.sub(r'(<tr><td><a [^>]*style=")overflow-wrap:anywhere',r'\1overflow-wrap:normal',candidate,count=1)),
          ('additional-link-attribute',candidate.replace('<tr><td><a href="','<tr><td><a data-unexpected="1" href="',1)),
          ('changed-metric',candidate.replace('<td>91213</td>','<td>91214</td>',1))]:
            require(mutant!=candidate,'canary input actually mutated')
            rejects('size-report:'+label,lambda y=mutant:pair('size-report.html',original,y,old_record,old_record))
        for label,other in [('missing-page',html[:-1]),('added-page',html+['unexpected.html'])]: rejects(label,lambda o=other:population(html,o))
        for name in ['index.html','maps/directories.html']:
            original=text(before/name); candidate=styled_baseline(name,original)
            for label,mutant in [('wrong-derived-record',candidate.replace('data-derived-record="sha256:','data-derived-record="sha256:0',1)),('wrong-time-slot',candidate.replace('listed at ','listed near ',1)),('timestamp-as-extra-reader-text',candidate.replace('</main>','<p>'+json.loads(old_record)['capturedAt']+'</p></main>',1)),('digest-as-extra-reader-text',candidate.replace('</main>','<p>'+h(old_record)+'</p></main>',1))]:
                rejects(name+':'+label,lambda n=name,x=original,y=mutant:pair(n,x,y,old_record,old_record))
        cost=json_file(before/'size-report.json'); metric_cells(text(before/'size-report.html'),cost)
        badcost=json.loads(json.dumps(cost)); badcost['pages'][0]['bytes']+=1
        rejects('numeric-binding-to-sidecar',lambda:metric_cells(text(before/'size-report.html'),badcost))
        badgrammar=text(before/'size-report.html').replace('<td>91213</td>','<td>091213</td>',1)
        require(badgrammar!=text(before/'size-report.html'),'numeric grammar mutant applied')
        rejects('numeric-grammar-leading-zero',lambda:metric_cells(badgrammar,cost))
        for row in cost['pages']: require(measured_bytes(text(before/row['path']))==row['bytes'],'baseline measured byte binding '+row['path'])
        return {'mode':'synthetic baseline selftest only; no candidate capture','positivePages':positives,'detectedCanaries':detected,'baselineHtmlCount':46,'baselineFileCount':50,'numericMasking':False}
    for arm,commit in [(BASELINE,BASE_COMMIT),(CANDIDATE,SUBJECT)]:
        actual=subprocess.check_output(['git','-C',str(ROOT/arm),'rev-parse','HEAD'],text=True).strip(); require(actual==commit,'capture checkout commit')
        require(subprocess.check_output(['git','-C',str(ROOT/arm),'status','--porcelain','-z'])==b'','capture checkout cleanliness')
    after=load(CANDIDATE); all_after=paths(after); population(html,[p for p in all_after if p.endswith('.html')]); require(all_before==all_after,'full file population changed')
    prepared=json_file(Path(__file__).parent/'prepared-input-pins.json')
    pin_records=[]
    for label in ['capture-before.json','capture-after.json']:
        p=json_file(ROOT/(CANDIDATE+'-capture')/label); require(p['candidateCommit']==SUBJECT and p['sourceCommit']==SOURCE and p['draft']['sha256']==DRAFT_SHA and p['config']['sha256']=='84b1976143d5b2b653d86193f5c9ea0330b3b0ec3b7e7afdeeca742e86a45068','fresh capture pins')
        require(p['sourceTree']==prepared['sourceTree'] and p['candidateTree']==prepared['candidateTree'] and p['sourceStatusEntries']==0,'fresh full Git source identity')
        listing=p['fullSourceTreeListing']; raw=Path(listing['path']).read_bytes()
        require(h(raw)==listing['sha256']==prepared['fullSourceTreeListing']['sha256'] and len(raw.split(b'\0'))-1==p['sourceTreeEntries']==prepared['sourceTreeEntries'],'retained full tree listing')
        require(p['comparator']['sha256']==h(Path(__file__).read_bytes()) and p['captureScript']['sha256']==prepared['captureScript']['sha256'],'capture mechanism pin')
        pin_records.append(p)
    new_record=(after/'derived-structure.json').read_bytes(); a=json.loads(old_record);b=json.loads(new_record);a.pop('capturedAt');b.pop('capturedAt');require(a==b,'derived metadata changed beyond capturedAt')
    oldcost=json_file(before/'size-report.json');newcost=json_file(after/'size-report.json')
    oldcells=metric_cells(text(before/'size-report.html'),oldcost,False);newcells=metric_cells(text(after/'size-report.html'),newcost,False)
    changed=[{'before':x,'after':y} for x,y in zip(oldcells,newcells) if x!=y]
    metrics={'before':oldcells,'after':newcells,'changed':changed,'allowedChangedColumns':[],'numericMasking':False,'sizeReportsEqual':oldcost==newcost}
    (Path(__file__).parent/'comparison-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    metric_cells(text(before/'size-report.html'),oldcost);metric_cells(text(after/'size-report.html'),newcost)
    require(oldcost==newcost and not changed,'unexpected size metrics; see comparison-metrics.json; no numeric delta is allowlisted')
    for directory,cost in [(before,oldcost),(after,newcost)]:
        for row in cost['pages']: require(measured_bytes(text(directory/row['path']))==row['bytes'],'measured byte binding '+row['path'])
    rows=[pair(p,text(before/p),text(after/p),old_record,new_record) for p in html]
    return {'subjectCommit':SUBJECT,'baselineCommit':BASE_COMMIT,'baselineScope':'F3-inclusive admission baseline, not non-F3 main','htmlPopulation':46,'filePopulation':50,'pageComparisons':rows,'metricCells':{'before':oldcells,'after':newcells,'changed':changed,'allowedChangedColumns':[],'numericMasking':False},'fullFiles':[{'path':p,'beforeSha256':h((before/p).read_bytes()),'afterSha256':h((after/p).read_bytes())} for p in all_before],'nativeAcceptance':'Unknown','scope':'Reader main and main opening attributes verified; outside-main bytes and full-file hashes reported without equivalence claim'}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--selftest',action='store_true');args=ap.parse_args()
    try: print(json.dumps(main(args.selftest),indent=2))
    except Exception as error:
        print(json.dumps({'verdict':'FAIL','subjectCommit':SUBJECT,'baselineCommit':BASE_COMMIT,'errorType':type(error).__name__,'failure':str(error)},indent=2))
        raise SystemExit(1)
