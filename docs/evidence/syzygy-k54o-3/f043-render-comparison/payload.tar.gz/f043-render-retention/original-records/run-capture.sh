#!/usr/bin/env bash
set -euo pipefail
preparation=$(dirname "$0")
capture_root=/home/orca/.tmp/f3-exact-stage-8dcb0.FXKsif1O
arm=admission-f043a10aab6b
revision=f043a10aab6bf3baee0b1acd24c72b78d3654ded
results="$capture_root/$arm-capture"
# Invoke only after the parent confirms native runs are terminal. Not run during preparation.
test ! -e "$results"
mkdir -p "$results"
python3 "$preparation/fresh-pins.py" --output "$results/capture-before.json"
bash "$capture_root/run-capture-admission.sh" "$arm" "$revision"
python3 "$preparation/fresh-pins.py" --output "$results/capture-after.json"
python3 "$preparation/compare.py" > "$preparation/comparison.json"
