Prepared only for exact subject f043a10aab6bf3baee0b1acd24c72b78d3654ded; no capture/build/install/native execution performed.

Run only after root releases the heavy slot and confirms this exact source is published:
  bash /home/orca/.tmp/f3-native-admission-fixes/final-render-subject-preparation/subjects/f043a10aab6bf3baee0b1acd24c72b78d3654ded/run-capture.sh
If the final published source differs, prepare a new directory instead:
  python3 /home/orca/.tmp/f3-native-admission-fixes/final-render-subject-preparation/prepare-subject.py --subject <full-final-published-SHA>

Read plan.json and prepared-input-pins.json. Redis/source/config/full-draft pins remain fixed. The draft is v4, not v10. The worthKnowing source guard admits marks only for v13; unchanged v4 rendering is an inference until actual output is compared. No worthKnowing markup, text, schema-version replacement, metric masking or new normalization is admitted.

The exact prior A-215 style additions and bound observation slots remain the only allowances. Reader main bytes, main attributes, numeric metrics, links, headings and newline spelling remain strict. Outside-main and whole-file differences are reported without whole-page equivalence claim. Existing F3-inclusive baseline2446c64ed is not a non-F3 main comparator. This is not native, Design, Fidelity or timing acceptance.

Synthetic selftests inspect retained baseline pages only. The wrapper records fresh pins before/after capture and refuses an existing results directory. SourceAssessment bindings expose any relevant source drift since c5e41bbddd038ac1d67578e2e5cd5b1d40132661 rather than assuming it away.
