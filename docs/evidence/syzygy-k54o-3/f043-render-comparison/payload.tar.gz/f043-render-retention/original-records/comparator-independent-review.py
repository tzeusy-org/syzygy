"""Independent whole-file expected-byte reconstruction; imports no reviewed comparator."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib, html, json, subprocess
from collections import Counter

P = Path(__file__).parent
H = lambda b: hashlib.sha256(b).hexdigest()
inventory = json.loads((P/'actual-capture-inventory.json').read_bytes())
sites = [Path(inventory[k]) for k in ['baselineSite', 'candidateSite']]
all_paths = []
for directory in sites:
    # Separate executable traversal, not comparator paths()/rglob/os.walk.
    names = sorted(Path(x.decode()).relative_to(directory).as_posix() for x in subprocess.check_output(['find',str(directory),'-type','f','-print0']).split(b'\0') if x)
    assert len(names) == 50 and sum(n.endswith('.html') for n in names) == 46
    all_paths.append(names)
assert all_paths[0] == all_paths[1]
for row in inventory['paths']:
    for i, prefix in enumerate(['before', 'after']):
        b = (sites[i]/row['path']).read_bytes()
        assert H(b) == row[prefix+'Sha256'] and len(b) == row[prefix+'Bytes']
assert sorted(row['path'] for row in inventory['paths']) == all_paths[0]
records = [(s/'derived-structure.json').read_bytes() for s in sites]
objects = [json.loads(b) for b in records]
assert objects[0] != objects[1]
assert {k:v for k,v in objects[0].items() if k != 'capturedAt'} == {k:v for k,v in objects[1].items() if k != 'capturedAt'}
assert len(records[0]) == len(records[1]) == 4476
digests = list(map(H,records))

class Scan(HTMLParser):
    def __init__(self, source, record, digest):
        super().__init__(convert_charrefs=True)
        self.stack=[]; self.disclosures=[]; self.attr_count=0; self.source=source
        self.record=record; self.digest=digest; self.active=None; self.parts=None
        self.feed(source); self.close()
        assert self.active is None and self.parts is None
    def handle_starttag(self, tag, attrs):
        a=dict(attrs); assert len(a)==len(attrs)
        if 'data-derived-record' in a:
            assert a['data-derived-record']=='sha256:'+self.digest
            self.attr_count+=1
        if tag=='li' and 'data-derived-id' in a:
            assert self.active is None
            self.active=a
        if tag=='span' and a.get('class')=='visually-hidden ev' and self.active:
            assert self.parts is None
            self.parts=[]
        self.stack.append(tag)
    def handle_endtag(self,tag):
        if tag=='span' and self.parts is not None:
            a=self.active; fact=next(f for f in self.record['facts'] if f['id']==a['data-derived-id'])
            for key, expected in {'fact':fact['fact'],'path':fact['path'],'rule':fact['rule'],'rule-version':str(fact['ruleVersion']),'revision':self.record['revision'],'record':'sha256:'+self.digest}.items():
                assert a['data-derived-'+key]==expected
            assert a['data-epistemic']=='observed'
            wanted=f" Evidence: label Observed; derived by Syzygy by rule {fact['rule']} version {fact['ruleVersion']}; source path {fact['path']}; record sha256:{self.digest}; current for revision {self.record['revision']}."
            assert ''.join(self.parts)==wanted
            self.disclosures.append(fact['id']); self.parts=None
        if tag=='li' and self.active:
            assert self.parts is None
            self.active=None
    def handle_data(self,data):
        if self.parts is not None:self.parts.append(data)

rows=[]
for name in [n for n in all_paths[0] if n.endswith('.html')]:
    before,after=[(s/name).read_text(encoding='utf8') for s in sites]
    # Reconstruct candidate from predecessor, replacing complete known fragments;
    # no normalized candidate, digest regex, whitespace or numeric mask.
    a='<aside class="review-status" data-review-status-region="review-status" aria-label="Review status"><h2>Review status</h2><ul>'
    assert before.count(a)==1
    expected=before.replace(a,a[:-1]+' style="overflow-wrap:anywhere">')
    style_count=1
    if name=='size-report.html':
        start=expected.index('<section id="size-report">'); end=expected.index('</section>',start)
        section=expected[start:end]
        table=section.split('<table>')[2]
        assert table.count('<a href=')==45
        cost=json.loads((sites[0]/'size-report.json').read_bytes())
        assert len(cost['pages'])==45
        for row in cost['pages']:
            fragment='<a href="'+html.escape(row['path'],quote=True)+'">'
            assert table.count(fragment)==1
            table=table.replace(fragment,fragment[:-1]+' style="overflow-wrap:anywhere">')
        expected=expected[:start]+section.split('<table>')[0]+'<table>'+section.split('<table>')[1]+'<table>'+table+expected[end:]
        style_count+=45
    disclosure_count=0
    if name in ['index.html','maps/directories.html']:
        for i,source in enumerate([before,after]):
            parsed=Scan(source,objects[i],digests[i]); ids=parsed.disclosures
            assert len(ids)==len(set(ids))==21 and set(ids)=={f['id'] for f in objects[i]['facts']}
            assert parsed.attr_count==(22 if name=='index.html' else 21)
            assert source.count(digests[i])==parsed.attr_count+len(ids)
            assert source.count(objects[i]['capturedAt'])==1
        expected=expected.replace('data-derived-record="sha256:'+digests[0]+'"','data-derived-record="sha256:'+digests[1]+'"')
        fragments=Counter('source path '+html.escape(fact['path'],quote=True).replace('&#x27;','&#39;')+'; record sha256:'+digests[0]+'; current for revision '+objects[0]['revision']+'.' for fact in objects[0]['facts'])
        for fragment,count in fragments.items():
            assert expected.count(fragment)==count
            expected=expected.replace(fragment,fragment.replace(digests[0],digests[1]))
        fragment='listed at '+objects[0]['capturedAt']+', by rule top-level-unit version 1.'
        assert expected.count(fragment)==1
        expected=expected.replace(fragment,fragment.replace(objects[0]['capturedAt'],objects[1]['capturedAt']))
        disclosure_count=21
    else:
        assert before.count(digests[0])==after.count(digests[1])==0
    assert expected==after, name+' whole-file reconstruction failed'
    # Independent string partition preserves the opening main tag as well.
    for source in [before,after]:assert source.count('<main')==source.count('</main>')==1
    oldat=before.index('>',before.index('<main'))+1
    newat=after.index('>',after.index('<main'))+1
    oldprefix=before[:oldat]; oldinner,oldsuffix=before[oldat:].split('</main>')
    newprefix=after[:newat]; newinner,newsuffix=after[newat:].split('</main>')
    assert (oldprefix,oldsuffix)==(newprefix,newsuffix)
    rows.append({'path':name,'fullExpectedBytesMatch':True,'outsideMainExact':True,'allowedStyleInsertions':style_count,'boundDisclosuresPerSide':disclosure_count})
for name in ['dossier.json','size-report.json']:
    assert (sites[0]/name).read_bytes()==(sites[1]/name).read_bytes()

class Measurement(HTMLParser):
    def __init__(self,source):
        super().__init__(); self.source=source; self.offsets=[0]; self.stack=[]; self.omit=[]
        for line in source.splitlines(keepends=True):self.offsets.append(self.offsets[-1]+len(line))
        self.feed(source);self.close();assert not self.stack
    def position(self):
        line,col=self.getpos();return self.offsets[line-1]+col
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:return
        omit=(tag=='aside' and attrs.get('data-review-status-region')=='review-status') or (tag=='span' and attrs.get('class')=='term-pop')
        self.stack.append((tag,self.position(),omit))
    def handle_endtag(self,tag):
        assert self.stack and self.stack[-1][0]==tag,('unbalanced measurement tree',tag)
        _,start,omit=self.stack.pop()
        if omit:self.omit.append((start,self.position()+len('</'+tag+'>')))
    def byte_count(self):
        cursor=0;parts=[]
        for start,end in sorted(self.omit):
            if start>=cursor:parts.append(self.source[cursor:start]);cursor=end
            else:assert end<=cursor
        parts.append(self.source[cursor:]);return len(''.join(parts).encode())

class NumericCells(HTMLParser):
    def __init__(self,source):
        super().__init__();self.in_size=False;self.current=None;self.cells=[];self.feed(source);self.close()
    def handle_starttag(self,tag,attrs):
        if tag=='section' and dict(attrs).get('id')=='size-report':self.in_size=True
        if tag=='td' and self.in_size:self.current=[]
    def handle_data(self,data):
        if self.current is not None:self.current.append(data)
    def handle_endtag(self,tag):
        if tag=='section':self.in_size=False
        if tag=='td' and self.current is not None:
            value=''.join(self.current)
            if value.isascii() and value.isdecimal():self.cells.append(int(value))
            self.current=None

for directory in sites:
    cost=json.loads((directory/'size-report.json').read_bytes())
    expected_cells=[r[key] for r in cost['perPageDepth'] for key in ['depth','pages','bytes','words']]
    expected_cells += [value for r in cost['pages'] for value in [r['depth'],r['bytes'],sum(r['wordsByReadingLevel'].values())+r['unlabelledWords']]]
    assert NumericCells((directory/'size-report.html').read_text()).cells==expected_cells and len(expected_cells)==147
    assert len(cost['pages'])==len({r['path'] for r in cost['pages']})==45
    assert set(r['path'] for r in cost['pages'])==set(n for n in all_paths[0] if n.endswith('.html'))-{'size-report.html'}
    for row in cost['pages']:
        assert Measurement((directory/row['path']).read_text()).byte_count()==row['bytes'],row['path']
machines=[json.loads((s/'machine.json').read_bytes()) for s in sites]
assert machines[0]['derivedStructure']['sha256']==digests[0]
assert machines[1]['derivedStructure']['sha256']==digests[1]
for value in machines:value['derivedStructure'].pop('sha256')
assert machines[0]==machines[1]
inputs=json.loads((P/'actual-inputs/binding.json').read_bytes())
for row in inputs['files']:
    assert H(Path(row['retainedPath']).read_bytes())==row['sha256']
    assert Path(row['retainedPath']).read_bytes()==Path(row['sourcePath']).read_bytes()
assert json.loads((P/'actual-inputs/frozen-draft-v4.json').read_bytes())['schemaVersion']=='polaris-dossier-local-draft-v4'
result={'subject':inventory['subjectCommit'],'baseline':inventory['baselineCommit'],'scriptSha256':H(Path(__file__).read_bytes()),'htmlPopulation':46,'filePopulation':50,'independentFindInventoryValidated':True,'wholeFileExpectedReconstructionMatches':len(rows),'styleInsertions':sum(r['allowedStyleInsertions'] for r in rows),'disclosuresPerSide':sum(r['boundDisclosuresPerSide'] for r in rows),'sidecarChangedKeys':['capturedAt'],'sidecarDigests':digests,'actualFullInputCopiesValidated':True,'numericCellsValidatedPerSide':147,'parserMeasuredPageByteCountsPerSide':45,'pages':rows,'nonHtmlFiles':['derived-structure.json: capturedAt only','machine.json: derivedStructure.sha256 only','size-report.json: byte-identical','dossier.json: byte-identical'],'scope':'Exact static bytes only; no native, design/fidelity, browser layout or timing acceptance.'}
print(json.dumps(result,indent=2))
