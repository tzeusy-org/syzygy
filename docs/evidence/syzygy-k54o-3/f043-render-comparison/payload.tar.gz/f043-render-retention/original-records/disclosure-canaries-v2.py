from pathlib import Path
import importlib.util,json,re,hashlib,tempfile
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('corrected',P/'compare-bound-disclosure-v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
before=m.load(m.BASELINE);after=m.load(m.CANDIDATE)
old=(before/'derived-structure.json').read_bytes();new=(after/'derived-structure.json').read_bytes()
results=[];positives=[]
def rejects(identity,call,old_fragment,new_fragment):
 try:call()
 except (AssertionError,UnicodeError) as error:
  results.append({'id':identity,'old':old_fragment,'new':new_fragment,'detected':True,'refusal':str(error)});return
 raise AssertionError('canary survived: '+identity)
for name in ['index.html','maps/directories.html']:
 source=m.text(before/name)
 # Explicitly exercise a changed capturedAt and the SHA256 of different full sidecar bytes.
 changed=m.synthetic_reobservation(m.styled_baseline(name,source),old,new)
 m.pair(name,source,changed,old,new);positives.append({'path':name,'oldSidecarSha256':m.h(old),'newSidecarSha256':m.h(new),'oldCapturedAt':json.loads(old)['capturedAt'],'newCapturedAt':json.loads(new)['capturedAt']})
 mutations=[
  ('adjacent-prose',' Evidence: label Observed; derived by Syzygy',' Evidence: label Inferred; derived by Syzygy'),
  ('source-path','source path .; record sha256:','source path .changed; record sha256:'),
  ('current-revision','; current for revision '+m.SOURCE+'.','; current for revision '+'f'*40+'.'),
  ('body-derived-value','Repository root: 22 files','Repository root: 23 files'),
  ('hidden-text-digest','; record sha256:'+m.h(new)+'; current for revision','; record sha256:'+'0'*64+'; current for revision'),
  ('heading','<h1>','<h1>Changed heading '),
 ]
 for label,a,b in mutations:
  require_count=changed.count(a);m.require(require_count>0,'mutation target absent '+name+':'+label)
  mutant=changed.replace(a,b,1)
  rejects(name+':'+label,lambda y=mutant:m.pair(name,source,y,old,new),a,b)
 attr=re.search(r'(<li\b[^>]*data-derived-record="sha256:)([a-f0-9]{64})(")',changed)
 m.require(attr is not None,'enclosing item attribute target')
 mutant=changed[:attr.start(2)]+'0'*64+changed[attr.end(2):]
 rejects(name+':enclosing-attribute-digest',lambda:m.pair(name,source,mutant,old,new),attr[2],'0'*64)
 item=re.search(r'<li\b[^>]*data-derived-id="[^"]+"[^>]*>.*?</li>',changed,re.S);m.require(item is not None,'population mutation target')
 for label,mutant,a,b in [
  ('missing-disclosure-item',changed[:item.start()]+changed[item.end():],item[0],''),
  ('extra-disclosure-item',changed.replace('</main>',item[0]+'</main>',1),'',item[0]),
  ('extra-bound-disclosure-occurrence',changed.replace('</main>','<p>; record sha256:'+m.h(new)+'; current for revision '+m.SOURCE+'.</p></main>',1),'','<p>; record sha256:'+m.h(new)+'; current for revision '+m.SOURCE+'.</p>'),
  ('extra-free-digest-content',changed.replace('</main>','<p>'+m.h(new)+'</p></main>',1),'','<p>'+m.h(new)+'</p>'),
  ('unexpected-worth-knowing-content',changed.replace('</main>','<aside class="worth-knowing">Unexpected callout</aside></main>',1),'','<aside class="worth-knowing">Unexpected callout</aside>'),
 ]:
  rejects(name+':'+label,lambda y=mutant:m.pair(name,source,y,old,new),a,b)
 # Same parsed record but changed raw bytes must not match the old text/attribute digest.
 rejects(name+':sidecar-raw-digest-mismatch',lambda:m.pair(name,source,changed,old,new+b' '),'raw sidecar EOF','raw sidecar EOF plus one space')
 for label,change in [('derived-schema',lambda d:d.__setitem__('format','polaris-dossier-derived-structure/2')),('derived-value',lambda d:d['facts'][0].__setitem__('rootFiles',23))]:
  record=json.loads(new);change(record);raw=(json.dumps(record,indent=2)+'\n').encode()
  coherent=m.synthetic_reobservation(changed,new,raw)
  rejects(name+':'+label,lambda y=coherent,r=raw:m.pair(name,source,y,old,r),'format/1' if label=='derived-schema' else 'rootFiles:22','format/2' if label=='derived-schema' else 'rootFiles:23')
# Exercise the actual full-draft loader pin with only the draft schema changed in an isolated tiny record tree.
with tempfile.TemporaryDirectory(prefix='f3-disclosure-schema-',dir=P) as temp:
 root=Path(temp);arm='schema-canary';run=root/(arm+'-capture')/'state/run-canary';site=run/'site/0';site.mkdir(parents=True)
 (run/'drafts').mkdir();draft=json.loads((Path(m.json_file(m.ROOT/(m.BASELINE+'-capture')/'render.json')['run'])/'drafts/rev-0.json').read_bytes());draft['schemaVersion']='polaris-dossier-local-draft-v13'
 (run/'drafts/rev-0.json').write_text(json.dumps(draft))
 (run/'run.json').write_text(json.dumps({'subject':{'pinnedRevision':{'commit':m.SOURCE}}}))
 (root/(arm+'-capture')/'render.json').write_text(json.dumps({'outcome':'rendered','draftRevision':0,'pages':46,'designReview':{'counts':False},'fidelityReview':{'counts':False},'run':str(run),'site':str(site)}))
 actual_root=m.ROOT;m.ROOT=root
 try:rejects('full-draft-schema-pin',lambda:m.load(arm),'schemaVersion:polaris-dossier-local-draft-v4','schemaVersion:polaris-dossier-local-draft-v13')
 finally:m.ROOT=actual_root
record={'subjectCommit':m.SUBJECT,'baselineCommit':m.BASE_COMMIT,'correctedComparatorSha256':hashlib.sha256((P/'compare-bound-disclosure-v2.py').read_bytes()).hexdigest(),'canaryScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Lightweight deterministic source/output comparisons only; actual captured immutable records reused, no capture/build/native execution','positiveChangedObservationCases':positives,'detectedCanaries':results}
print(json.dumps(record,indent=2))
