import argparse, datetime, hashlib, json, subprocess
from pathlib import Path
HERE=Path(__file__).parent
REPO=Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
SOURCE=Path('/home/orca/.local/state/syzygy-polaris-clones/redis-redis-8.10.2')
CONFIG=Path('/home/orca/.tmp/f3-comprehension-781519d48/new-run-config.json')
DRAFT=Path('/home/orca/.tmp/f3-matched-stage.CYZMqAy0/before-state/run-6d5534c1dc1867bfd6a8dea3045d35d3/drafts/rev-0.json')
CAPTURE=Path('/home/orca/.tmp/f3-exact-stage-8dcb0.FXKsif1O/run-capture-admission.sh')
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda root,*args:subprocess.check_output(['git','-C',str(root),*args])
def pin(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
head=git(SOURCE,'rev-parse','HEAD').decode().strip();assert head=='498ecd0d6d007db11ddb3aea9428552598a78622'
status=git(SOURCE,'status','--porcelain','-z');assert status==b''
tree=git(SOURCE,'ls-tree','-r','-z','-l','--full-tree','HEAD')
tree_file=args.output.with_suffix('.source-tree.bin');tree_file.write_bytes(tree)
config=pin(CONFIG);assert config['sha256']=='84b1976143d5b2b653d86193f5c9ea0330b3b0ec3b7e7afdeeca742e86a45068'
draft=pin(DRAFT);assert draft['sha256']=='927b9e84408d04fe922bd1d83add7553314f4202a91008f4dab347d47aad7d77'
subject='f043a10aab6bf3baee0b1acd24c72b78d3654ded'
record={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateCommit':subject,'candidateTree':git(REPO,'rev-parse',subject+'^{tree}').decode().strip(),'sourceCommit':head,'sourceTree':git(SOURCE,'rev-parse','HEAD^{tree}').decode().strip(),'sourceStatusPorcelainSha256':sha(status),'sourceStatusEntries':0,'fullSourceTreeListing':pin(tree_file),'sourceTreeEntries':len(tree.split(b'\0'))-1,'config':config,'draft':draft,'captureScript':pin(CAPTURE),'comparator':pin(HERE/'compare.py'),'pinScript':pin(Path(__file__)),'scope':'Full source Git identity/tree listing and full-file config/draft digests; no capture/build performed by this pin script'}
args.output.write_text(json.dumps(record,indent=2)+'\n')
