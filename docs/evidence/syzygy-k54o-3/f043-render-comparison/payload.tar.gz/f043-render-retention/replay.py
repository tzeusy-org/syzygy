"""Offline frozen-artifact replay. Does not initialize/build/run observed code."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
P=Path(__file__).parent
def sha(b):return hashlib.sha256(b).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');args=ap.parse_args()
manifest=json.loads((P/'MANIFEST.json').read_bytes())
actual=sorted(p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file() and p.name not in {'MANIFEST.json','MANIFEST.sha256'})
assert actual==[r['path'] for r in manifest['files']]
for row in manifest['files']:
    b=(P/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
assert (P/'MANIFEST.sha256').read_text().split()[0]==sha((P/'MANIFEST.json').read_bytes())
if args.verify_only:
    print(json.dumps({'manifestVerifiedFiles':len(actual),'subject':manifest['subjectCommit']}));raise SystemExit
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
corrected=module('corrected',P/'original-records/compare-bound-disclosure-v2.py')
strict=module('strict',P/'original-records/compare.py')
before=P/'sites/baseline';after=P/'sites/candidate'
old=(before/'derived-structure.json').read_bytes();new=(after/'derived-structure.json').read_bytes()
paths=corrected.paths(before);assert paths==corrected.paths(after) and len(paths)==50
html=[n for n in paths if n.endswith('.html')];assert len(html)==46
rows=[corrected.pair(n,corrected.text(before/n),corrected.text(after/n),old,new) for n in html]
assert rows==json.loads((P/'original-records/comparison-bound-disclosure-v2.json').read_bytes())['pageComparisons']
refused=[]
for name in html:
    try:strict.pair(name,strict.text(before/name),strict.text(after/name),old,new)
    except AssertionError as e:refused.append({'path':name,'reason':str(e)})
assert [r['path'] for r in refused]==['index.html','maps/directories.html']
for site in [before,after]:
    cost=corrected.json_file(site/'size-report.json')
    assert len(corrected.metric_cells(corrected.text(site/'size-report.html'),cost))==147
    assert len(cost['pages'])==45
    for row in cost['pages']:assert corrected.measured_bytes(corrected.text(site/row['path']))==row['bytes']
print(json.dumps({'subjectCommit':manifest['subjectCommit'],'baselineCommit':manifest['baselineCommit'],'manifestVerifiedFiles':len(actual),'fullCaptureHtml':len(html),'fullCaptureFiles':len(paths),'correctedStaticMainMatches':len(rows),'outsideMainExact':sum(r['outsideMainExact'] for r in rows),'originalStrictRejected':refused,'numericCellsPerSide':147,'measuredPagesPerSide':45,'status':'PREDECESSOR STATIC PASS ONLY; final-head recapture required'},indent=2))
