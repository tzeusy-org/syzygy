# Frozen predecessor render evidence

Subject: `f043a10aab6bf3baee0b1acd24c72b78d3654ded`. Baseline: `2446c64edb7bb9e0c89169bddd129efca36cad65` (F3-inclusive admission baseline).

This outside-only packet retains the complete 46-HTML/50-file capture for each side, the original strict FAIL, corrected bound-disclosure static PASS, raw independent review, full frozen config/draft, provenance records and recorded controls. It contains no clone, Git object store, local state/store/cache or executable observed-project source. The retained old absolute paths are provenance, not replay dependencies. Original files under original-records/ are byte-for-byte copies; their old paths have not been rewritten.

Run from any extracted location using Python's standard library:

```sh
python3 replay.py --verify-only
python3 replay.py
python3 replay-independent.py
```

The first command verifies the exact file population and manifest hashes. The second replays both original/corrected comparator pair functions against retained static pages and checks 147 numeric cells plus 45 measured byte counts on each side. It verifies historical capture bindings through retained hashes; it does not re-run the original environment-dependent main()/Git/capture checks. The third is the independent full-file reconstruction with only artifact-resolution changes, shown in independent-portability.patch. It verifies complete expected bytes and independently parses numeric cells and measured-page regions. These commands do not build, install, capture, initialize a run, contact services or execute observed source. Original canary scripts/outputs are retained as review evidence, not portable environment fixtures.

The manifest binds all files except itself and its checksum. Archive metadata and gzip time are deterministic. Extract the archive into an empty directory; do not merge it into a live state directory.

Status: **PREDECESSOR FULL CAPTURE; CORRECTED 46/46 STATIC COMPARISON PASS ONLY.** Current main's A-300 counted-review presentation merge requires a fresh exact-final-head capture. See FINAL-HEAD-COMPARISON-PLAN.md. This packet is not final-head, native, Stop/recovery, counted Design/Fidelity, browser-layout, hosted-timing or release acceptance.
