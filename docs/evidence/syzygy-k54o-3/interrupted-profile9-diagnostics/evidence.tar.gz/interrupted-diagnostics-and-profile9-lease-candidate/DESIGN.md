# Combined interrupted diagnostics and profile9 observer repair

Exact baseline d8 file is identical at7af. Retain frozen R1 diagnostics delta unchanged and update only the two initial ordered-design-startup observer expected bound literals120000 to145000, as adopted A240. Expected values remain independent literals, not imports from implementation.

[Observed] Original7af genuine interrupted run failed129.220926s before any Design connection/inference. Its actual swallowed assertion identity is not retained. [Inferred] The observer old upper bound120000 contradicts the adopted actual145000 ordered lease for the observed large original run remainder; the source wraps reproduction before returning it and can throw into the supervisor outer catch. This is a source-forced incompatibility; do not claim direct observation of the swallowed assertion object.

Acceptance: R1 metadata-only/no additional authority/product/IO constraints; preserve all assertions/declarations/options/timeouts, changing only both observer expected lease caps to the correct145000 literals with original caller clipping. No new test declaration or relaxed production guard. Retain R1 original review/cost report as historical partial scope; require fresh verdict for completeR2. Native run and typecheck not yet executed on these bytes.
