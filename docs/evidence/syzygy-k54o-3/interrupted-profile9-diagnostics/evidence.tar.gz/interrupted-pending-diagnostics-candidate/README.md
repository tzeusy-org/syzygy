Source-only diagnostic candidate; no execution and no independent verdict.

Apply only candidate.patch after fresh review and exact baseline-file hash comparison. The only implementation delta is candidate/packages/polaris-dossier/src/url-run-composed.test.ts. Baseline and reference files are immutable exact d8 source copies for review; do not apply references. CANDIDATE-RAW.md records scope, source proof, cost and limitations; source-checks.json and cost-metrics.json are passive artifact checks. bindings.json binds every retained file except itself. No primary checkout was edited.
