REVISE

Source-only independent review of ordered-operation-first-refusal-candidate-89fe6d-1.

[Observed] Subject base commit: 89fe6d265d5e542d0b1c3d8d1927de708a9cc2d6; tree: 2e1ea5cbae11f224a81e0c658564862d0071a693. Frozen packet: /home/orca/.tmp/f3-native-admission-fixes/ordered-operation-first-refusal-candidate-89fe6d-1. bindings.json SHA-256: 403ab6d60e05471292db5495af8c57828a03ebb2b2915cc712f08a9b3be3a89b. source.patch SHA-256: befe9b3301160068e2f5055887d64d2cc481f59930850371d854b5e0e2920f31. Candidate production source SHA-256: e6ad8c2a6daaa0188d04832ee170fc38812e28e6f48f94ad422593b66370cc11. Candidate owning host-test source SHA-256: 0078f49c24438ef73d74f108fd7fe0b96efbf1eb79d594a41ad6aeddcf618c8b.

[Observed] The packet's 23 bound files were checked for byte count and SHA-256 against bindings.json using Python hashlib; a second 23-file sha256sum sweep confirmed the digests. Both retained base sources match git show at the subject commit. The eight proposed mutant old fragments each occur exactly once in the production candidate. Source declaration enumeration confirms 10 to 12 declarations; independently enumerated parameter cardinalities confirm 21 to 32 expanded cases, net +11. These are static artifact checks, not product or test execution.

Governing references and review boundary

[Observed] Read heart-and-soul, engineering-bar and test-rigor; the supplied acceptance.md; the relevant A-14/REQ-polaris-generation-035 adoption and bounded-operation clauses; VIS-2 trust/evidence; the frozen production/test diff and relevant budget, writer, broker, host, transport and attempt references. REQ-035 states: "Apply the same limits and currentness at every subsequent operation and stop at the first failure." Acceptance item 3 states: "Timer/catch CPU is Unknown unless a separately timestamped prior sample is explicitly distinguished; do not label prior values current." Review covers this passive diagnostic and its owning cases, not performance or recovery.

Finding 1 — Unclassified check exceptions retain untimestamped CPU values

[Observed] candidate/packages/polaris-dossier/src/url-ordered-design-session.ts:247 passes observed to recordFailure('check', 'unclassified', observed). Lines 232-233 fill observed.cpuMicroseconds before calling work.remainingRunCpuMicroseconds(). If that second dependency throws a private exception, the first record is unclassified but retains a numerical CPU value without a separately identified sample timestamp. A later throwing dependency can also leave numerical remaining capacity or clocks in this unclassified record. First-write retention then preserves this record through the outer catch/finish/cleanup; those later paths cannot correct it.

[Inferred] This violates acceptance item 3 and the README claim that arbitrary rejection CPU remains null/Unknown. Preserve already-read samples for an identified direct predicate; an initiating unclassified dependency exception must preserve the declared Unknown semantics. No extra CPU/authority sampling or general admission framework is justified. This is a bounded correction in the existing check catch.

Finding 2 — The nearest new cases do not protect this catch uncertainty

[Observed] candidate/packages/polaris-dossier/src/url-ordered-design-host.test.ts:648 exercises returned invalid/negative/wall/CPU/ledger predicates, and line 682 exercises the stage promise rejection, original timer and finish regression. None initiates an arbitrary check dependency exception after a successful CPU read. The existing stage rejection enters boundary.rejected(), so its null assertion does not detect finding 1. A mutation replacing the unclassified check catch's Unknown fields with the earlier observed fields therefore has no owning proposed assertion.

[Inferred] Extend the nearest genuine final-budget callback case with this distinct dependency-throw scenario, asserting fixed unclassified discrimination, actual owner/turn, null/Unknown current CPU metadata, absence of the private exception and unchanged sample/authority counts. Retain a one-occurrence source mutant bound to that intended assertion. Keep limits and existing genuine selector/assertions/timeouts unchanged. Test-rigor expectations 2 and 3 apply. Mutation plans should identify stable assertion signatures so subsequent execution can distinguish intended detection from setup or cleanup failure.

Explicit accepted limitation for the successor

[Observed] The read guard at candidate production lines 250-254 can reject audit-read input or ledger charging before check(), and is currently classified by its enclosing unclassified rejection path. The root explicitly confirms that this guard is outside this CPU/wall/check/timer classifier scope. Require the successor README/acceptance addendum to say so; this review does not require a read-classification framework or additional read species. Pre-construction/admission throws and null pre-budget work snapshots also remain documented Unknown edges.

Other reviewed properties

[Inferred] The candidate preserves the original operation admission predicates and direct check short-circuit order, original baselines and expiry computation, caps, CPU/remaining/authority calls, generic outward errors, counters and cleanup flow by source inspection. The record is scalar-only and immutable, first-write retention precedes later stop/finish catches, nested ownership is derived from actual boundary fields, and timer metadata introduces no CPU read. The original timer may race between actual tool3 and audit2; accepting either timer owner while separately pinning the nested arbitrary rejection is appropriate. Existing non-null workSnapshot is the bounded integration path; healthy completion requires absent diagnostic metadata. The host-test placement exercises real controller ownership and is justified over the mocked release callback fixture.

[Observed] No product, build, native, compiler, fixture, test or mutation execution occurred in this review. No primary source was edited. Only this review artifact was written.

[Unknown] Type correctness, actual test outcomes, intended mutant detection, timer behavior, runtime cost, the next initiating genuine refusal, successful recovery and full acceptance. REVISE is a source-review verdict for the two bounded findings above, not a performance or recovery conclusion. Any successor bytes require a newly bound review.
