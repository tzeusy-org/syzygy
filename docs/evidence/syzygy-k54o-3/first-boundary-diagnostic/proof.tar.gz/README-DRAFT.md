# First-boundary diagnostic: source, failed-run and owning-PASS staging R2

[Observed] Historical source-candidate state only: the retained R2 packet's
opening paragraph describes an outside-checkout candidate that grants no
application/execution authority, and its runtime paragraphs say unverified.
Those statements describe the source-authoring stage. The root subsequently
installed the reviewed source as actual commit
`1a98aaebf5f590241b52d7cf195c7d2761121956`, tree
`6a290bc886dd0df52ad3ba96fd2a8cc44a7e778f`. The complete 26-file frozen
packet is retained verbatim in `source-R2/`, including the original R1 raw
`REVISE`; `review/f3-ordered-first-refusal-source-R2-review-RAW.md` records
R2 `PASS`. The actual-commit receipt binds the two reviewed source digests
across the intervening main composition. No prior verdict was rewritten.

[Observed] The production change records passive immutable first-boundary
failure metadata on the existing work snapshot, retaining the actual owning
operation, original admission baselines and already-read direct-predicate
samples. Timer and unclassified asynchronous/private dependency failures keep
unavailable current samples Unknown. Existing checks, calls, errors, caps,
deadlines, retirement and cleanup remain; the scalar diagnostic carries no
private input, exception text or source body. The source packet retains the
exact acceptance, governing references, two-file delta and original test and
mutation census: 33 expanded owning cases and nine proposed mutants.

## Completed owning attempt at 1a98

[Observed] `owning-1a98/operator/` retains the sealed owning definition and its
original manifest/SHA list, including exact source substitutions and the root's
mutant-admission correction. The raw operator review is
`review/f3-1a98-owning-operator-review-RAW.md`; its `PASS` concerns the operator
definition and does not assert the later run passed.

[Observed] The completed terminal record at `owning-1a98/raw/terminal.json`
binds actual commit `1a98aaeb...`, completion true, acceptance false and exit 1
(SHA-256 `1fc56ad84b82b82423ecc600f886cec0f10adc155ef2a9650c5b9aa9722d5cde`).
Typecheck passed; the full owning file contained exactly 33 assertions:
32 passed, one failed, none skipped/pending. The failing identity is
“native authenticated ordered host retains the genuine last tool budget
predicate without extra samples: ledger-refused”, with signature
`F3-ORDERED-FIRST-REFUSAL/sample-counts`. No mutant was attempted because the
baseline was not accepted. This failed attempt remains failed.

[Observed] The terminal and root failure reconciliation record source/tools
and retained runtime unchanged, no forced owned children, no pending cleanup
signals or cleanup errors, and joined cleanup. The terminal's eight named
`rawFiles` were copied individually and hash-checked, including the exact
known production source backup (SHA-256 `382645bb...`). The copied `progress.json`
is an explicitly historical checkpoint with `complete: false`; it is retained
because the completed terminal seals it as a raw member. The completed terminal,
not that checkpoint, owns the final run disposition.

[Observed] No private fixture TMP directory, retained TMP contents, arbitrary
backup, clone, node_modules, in-progress operator or blind output-directory
copy is included. The retained source backup is only the exact known
`url-ordered-design-session.ts` original named in the terminal and source
backup metadata. Paths and inventories in JSON remain metadata; their named
runtime/fixture bodies are not copied.

## R3 fixture correction and actual successor

[Observed] The root failure reconciliation identifies a real fixture error:
the ledger captured `Date.now` before the late spy, so that read remains real
and the spy intercepts one wall read; the monotonic closure dynamically calls
`performance.now`, so the corresponding spy sees two monotonic reads. R3 changes
one expected wall-count literal plus two explanatory comment lines. It does
not add a production clock sample or alter the already-reviewed production
behavior.

[Observed] `source-R3/` retains the exact fixture successor, failed baseline
artifacts and source bindings. Its source review records `PASS` in
`review/f3-ordered-first-refusal-ledger-spy-R3-review-RAW.md` (SHA-256
`96476a74f2fe2641c7077211e75f7009afaf318b31ee52304592cb44438bb6d0`).
The actual successor is
`22b540f0d8e1635e4fe36413d1dd4587be4a03b6`, tree
`bee00db67b88d28229874b85c2e2465d126f2112`, bound by
`ordered-first-refusal-R3-actual-commit.json`. Production session SHA-256
remains `382645bb414dca8abe9c5f625edeff9bd6602308cae195e80ec9524eee93ee32`.
The same 33-case and nine-mutant scope and original caps remain.

[Observed] Historical R3 candidate state only: its original README says
“Candidate not applied, no execution while authoring.” That describes the
source-only R3 authoring stage before actual `22b540f0...` was installed;
the original bytes remain unchanged. Its separate Unknown declaration of new
owning/genuine acceptance is not converted into success by the source review.

[Observed] Historical R1 staging state only: the prior staging README said
new owning verification and mutation outcomes at `22b540f0...` were Unknown.
Those outcomes are superseded by the completed scoped owning result below;
the exact earlier draft remains under `history/staging-R1-drafts/`. Genuine
recovery and F3 acceptance remain Unknown. No active ordinary-recovery output
was read or copied. No final proof archive or archive checksum exists yet;
the root will add the completed genuine result before finalizing. Old
unexecuted ordinary-1a operator material is not copied here.

## Completed owning verification at 22b

[Observed] `owning-22b/operator/` retains the current sealed owning definition:
26 entries bound by its original SHA list plus the SHA list itself (27 files),
seal SHA-256
`c4cb01970328f95a759edb21cdc7c2f343270e85ca6dc7b65260e448f7bbb694`.
Its fresh raw operator review is
`review/f3-22b540-owning-operator-review-RAW.md` (SHA-256
`e77fc754e4dd5339a34db68d84f8af262613f2ec5c894e900437fda41253b007`).
The operator review's PASS covers its definition; the run's accepted result
comes from the completed terminal and root reconciliation, not that verdict.

[Observed] Completed `owning-22b/raw/terminal.json` binds actual
`22b540f0d8e1635e4fe36413d1dd4587be4a03b6`, tree
`bee00db67b88d28229874b85c2e2465d126f2112`, with `complete: true`,
`accepted: true` and exit zero. Terminal SHA-256 is
`afa07dd756aa3e477488786600b26f2e14dd31789e680f983799de19c6ba36bf`.
Typecheck passed (22.467 seconds); the complete baseline passed all 33 cases
(196.005 seconds), with the root reconciling the population by two methods.
Each of nine exact production mutants produced its intended AssertionError:
one failed selected case and 32 selection-skipped cases, not an incomplete
baseline. Total owning duration was 378.174 seconds. The failed 1a98 baseline
above remains separately failed and is not reclassified by this successor.

[Observed] `root-owning-22b540-reconciliation.json` independently records all
33 baseline cases, nine intended mutant signatures and dual-hash matching for
all 35 declared raw files. Those 35 files plus the terminal were individually
copied from the completed terminal allowlist and hash-checked. The selected
source backup is the same exact known production session source; no private
TMP or fixture body was copied. The sealed checkpoint `progress.json` remains
historical intermediate output; the completed terminal owns the disposition.

[Observed] The source, tools and all 11 retained runtime objects remained
unchanged. No forced owned children, pending cleanup signals, remaining owned
children or cleanup errors were recorded. This is owning diagnostic/mutation
verification; the original genuine case was not selected by it.

## Test growth and recorded cost

[Observed] The source delta adds two test declarations and 12 expanded
integration cases (21 to 33); it removes none. The retained
`root-first-boundary-test-costs.json` binds the actual passing baseline JSON.
Its added 12-case cohort sums to 117,636.313153 milliseconds of the
191,152.834417 milliseconds summed across all 33 cases in that same run.
The complete baseline's wall duration is separately 196.005 seconds. These
are within-run cohort durations, not an observed predecessor comparison,
net runtime delta, speedup, CI-budget claim or waiver. The original 30.05-second
real timer wait and native authenticated guards make this deliberate
verification cost. The nine intended mutant failures demonstrate that the
covered diagnostic behaviors are independently protected; this proof adds no
new test framework or deadline extension to make the active genuine run pass.

## Current sealed original-recovery definition

[Observed] `ordinary-22b/operator/` retains 14 SHA-bound entries plus their
original SHA list (15 files), seal SHA-256
`b8239d9d8b4b5fa1ca758d403a1e59052c64ec6a9fcaec543b7be4061109edbc`.
The raw fresh review records PASS in
`review/f3-22b-original-operator-review-RAW.md`, SHA-256
`b31098aa946bf25a2176cb9f751b64f7c5cbc759654d3d4187dbc1a5443c5a7a`.
This is the current sealed original runner definition without an overlay;
its definition/review is retained, not its active output. Source-freeze
`noExecution`/pending fields inside that historical prepared packet describe
the definition stage, not the result of the subsequently started run.

[Unknown] Original genuine recovery outcome and F3 acceptance. The root reports
that the ordinary recovery is active, so no output folder, terminal substitute,
partial log or runtime artifact from that active run is included. Full gates
remain deferred until genuine PASS. The first-boundary analysis preparation
has not been used and is not copied here.

## Proposed later adoption

[Observed] `DRAFT-ADOPTION-METADATA.json` and `DRAFT-LEDGER-ROW.md` propose
unreserved A-325 for actual `1a98aaeb...` plus test-only successor `22b540f0...`.
A-325 was unused in the 279-row ledger at frozen primary `22b540f0...` (maximum
A-323); separate main proof A-324 remains for the root to install/recheck.
A-325 was rechecked unused at the same actual `22b540f0...` ledger for this
R2 stage. No row was appended. Re-read the actual ledger before later append
and retain the failed baseline when reporting the successor's scoped PASS.

`COPIED-ARTIFACT-INVENTORY.json` records 156 copied artifacts (75 retained
from R1 and 81 added here), their exact source paths and digests. They were
selected from frozen source/operator manifests and seals, completed terminal
raw-file allowlists, and the explicitly named completed root reviews/receipts. Drafts and
this staging inventory are not a final execution proof. This staging work
executes no product, native fixture, test or compiler and changes no primary
source, commit, push or existing raw archive.
