# Ordinary22b540 operator acceptance

1. Source-only review binds actual22b540/treebee00d and the byte-identical admitted R3 runner, original build and exact genuine stop-resume command, product600s/30s limits and configured workers.
2. Current source/tool/global/local/native/browser closure and367 current expected source/dependency inputs must be bound. Fresh build supplies actual10 outputs; no stale ignored runtime or old source row may be admitted as newly built. All actual rows, full populations and before/after/final identities must agree.
3. Existing firstBoundaryFailure rides original whole workSnapshot capture without instrumentation or claims about null/pre-admission records.
4. Actual JSON has exactly7 cases, one exact selected passed/failed identity and6 skips, consistent aggregates; accepted requires the selected PASS, report success and exit0. Honest FAIL is retained distinctly from incomplete.
5. Preserve admitted finite cooperative deadlines, ordinary child signal mask, owned subreaper/pidfd joining, private TMP and independent final checks. Unknown/forced cleanup, pending signals or drift prevents completion/acceptance; source is never overwritten.
6. Operator review PASS is preparation only. Hold until owning host33/nine-mutant acceptance and explicit root execution GO. No source/build/native/product/genuine execution during review.

[Unknown] Owning runtime outcome, native performance and original genuine-case result at packet freeze.

[Observed] Current source lineage is unchanged R2 production plus the R3 host-test successor; prior32/33 owning failure is retained, current owning/genuine outcomes Unknown. All prior limits and six criteria remain.
