#!/bin/sh
set -eu
SYZYGY_POC_BROWSER=/home/orca/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-22b540-R1/run.py --subject 22b540f0d8e1635e4fe36413d1dd4587be4a03b6 --output /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-22b540-1
