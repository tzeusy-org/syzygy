#!/bin/sh
set -eu
SYZYGY_POC_BROWSER=/home/orca/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/owning-verification-1a98aae-R1/launch.py --subject 1a98aaebf5f590241b52d7cf195c7d2761121956 --bindings /home/orca/.tmp/f3-native-admission-fixes/owning-verification-1a98aae-R1/bindings.json --output /home/orca/.tmp/f3-native-admission-fixes/owning-verification-1a98aae-1
