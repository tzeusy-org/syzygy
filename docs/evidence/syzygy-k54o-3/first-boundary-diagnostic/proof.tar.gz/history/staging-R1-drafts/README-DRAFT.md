# First-boundary diagnostic: source and failed-run staging R1

[Observed] Historical source-candidate state only: the retained R2 packet's
opening paragraph describes an outside-checkout candidate that grants no
application/execution authority, and its runtime paragraphs say unverified.
Those statements describe the source-authoring stage. The root subsequently
installed the reviewed source as actual commit
`1a98aaebf5f590241b52d7cf195c7d2761121956`, tree
`6a290bc886dd0df52ad3ba96fd2a8cc44a7e778f`. The complete 26-file frozen
packet is retained verbatim in `source-R2/`, including the original R1 raw
`REVISE`; `review/f3-ordered-first-refusal-source-R2-review-RAW.md` records
R2 `PASS`. The actual-commit receipt binds the two reviewed source digests
across the intervening main composition. No prior verdict was rewritten.

[Observed] The production change records passive immutable first-boundary
failure metadata on the existing work snapshot, retaining the actual owning
operation, original admission baselines and already-read direct-predicate
samples. Timer and unclassified asynchronous/private dependency failures keep
unavailable current samples Unknown. Existing checks, calls, errors, caps,
deadlines, retirement and cleanup remain; the scalar diagnostic carries no
private input, exception text or source body. The source packet retains the
exact acceptance, governing references, two-file delta and original test and
mutation census: 33 expanded owning cases and nine proposed mutants.

## Completed owning attempt at 1a98

[Observed] `owning-1a98/operator/` retains the sealed owning definition and its
original manifest/SHA list, including exact source substitutions and the root's
mutant-admission correction. The raw operator review is
`review/f3-1a98-owning-operator-review-RAW.md`; its `PASS` concerns the operator
definition and does not assert the later run passed.

[Observed] The completed terminal record at `owning-1a98/raw/terminal.json`
binds actual commit `1a98aaeb...`, completion true, acceptance false and exit 1
(SHA-256 `1fc56ad84b82b82423ecc600f886cec0f10adc155ef2a9650c5b9aa9722d5cde`).
Typecheck passed; the full owning file contained exactly 33 assertions:
32 passed, one failed, none skipped/pending. The failing identity is
“native authenticated ordered host retains the genuine last tool budget
predicate without extra samples: ledger-refused”, with signature
`F3-ORDERED-FIRST-REFUSAL/sample-counts`. No mutant was attempted because the
baseline was not accepted. This failed attempt remains failed.

[Observed] The terminal and root failure reconciliation record source/tools
and retained runtime unchanged, no forced owned children, no pending cleanup
signals or cleanup errors, and joined cleanup. The terminal's eight named
`rawFiles` were copied individually and hash-checked, including the exact
known production source backup (SHA-256 `382645bb...`). The copied `progress.json`
is an explicitly historical checkpoint with `complete: false`; it is retained
because the completed terminal seals it as a raw member. The completed terminal,
not that checkpoint, owns the final run disposition.

[Observed] No private fixture TMP directory, retained TMP contents, arbitrary
backup, clone, node_modules, in-progress operator or blind output-directory
copy is included. The retained source backup is only the exact known
`url-ordered-design-session.ts` original named in the terminal and source
backup metadata. Paths and inventories in JSON remain metadata; their named
runtime/fixture bodies are not copied.

## R3 fixture correction and actual successor

[Observed] The root failure reconciliation identifies a real fixture error:
the ledger captured `Date.now` before the late spy, so that read remains real
and the spy intercepts one wall read; the monotonic closure dynamically calls
`performance.now`, so the corresponding spy sees two monotonic reads. R3 changes
one expected wall-count literal plus two explanatory comment lines. It does
not add a production clock sample or alter the already-reviewed production
behavior.

[Observed] `source-R3/` retains the exact fixture successor, failed baseline
artifacts and source bindings. Its source review records `PASS` in
`review/f3-ordered-first-refusal-ledger-spy-R3-review-RAW.md` (SHA-256
`96476a74f2fe2641c7077211e75f7009afaf318b31ee52304592cb44438bb6d0`).
The actual successor is
`22b540f0d8e1635e4fe36413d1dd4587be4a03b6`, tree
`bee00db67b88d28229874b85c2e2465d126f2112`, bound by
`ordered-first-refusal-R3-actual-commit.json`. Production session SHA-256
remains `382645bb414dca8abe9c5f625edeff9bd6602308cae195e80ec9524eee93ee32`.
The same 33-case and nine-mutant scope and original caps remain.

[Observed] Historical R3 candidate state only: its original README says
“Candidate not applied, no execution while authoring.” That describes the
source-only R3 authoring stage before actual `22b540f0...` was installed;
the original bytes remain unchanged. Its separate Unknown declaration of new
owning/genuine acceptance is not converted into success by the source review.

[Unknown] New owning verification at actual `22b540f0...`, mutation outcomes,
genuine recovery and F3 acceptance. Current operator bindings and any
in-progress folders are deliberately outside this stage. No final proof archive
or archive checksum exists yet. The root will add completed current-subject
results and operator proof before finalizing; old unexecuted ordinary-1a
operator material is not copied here.

## Proposed later adoption

[Observed] `DRAFT-ADOPTION-METADATA.json` and `DRAFT-LEDGER-ROW.md` propose
unreserved A-325 for actual `1a98aaeb...` plus test-only successor `22b540f0...`.
A-325 was unused in the 279-row ledger at frozen primary `22b540f0...` (maximum
A-323); separate main proof A-324 remains for the root to install/recheck.
No row was appended. Re-read the actual ledger before later append and retain
the failed baseline when reporting any successor result.

`COPIED-ARTIFACT-INVENTORY.json` records 75 copied artifacts, their exact
source paths and digests. All were selected from frozen source/operator
manifests or the completed terminal's explicit raw-file allowlist. Drafts and
this staging inventory are not a final execution proof. This staging work
executes no product, native fixture, test or compiler and changes no primary
source, commit, push or existing raw archive.
