# Prepared analysis of the completed ordinary-recovery record

[Observed] `analyze.py` is a read-only, standard-library decoder prepared for subject `22b540f0d8e1635e4fe36413d1dd4587be4a03b6`, tree `bee00db67b88d28229874b85c2e2465d126f2112`. It has not been run against the pending ordinary-recovery attempt. This preparation supplies no new execution result, capacity estimate, or optimization claim.

After the owning operator has produced a completed output directory, run:

```sh
python3 /home/orca/.tmp/f3-native-admission-fixes/first-boundary-analysis-preparation/analyze.py /actual/completed/output-directory
```

The script prints JSON to stdout and writes nothing. Redirect the report outside the primary checkout if retention is wanted. Do not point it at a live attempt. It requires `terminal.json` to report `complete: true`, the exact subject/tree above, `rawFilesComplete: true`, and `populationValid: true`. It reads and verifies the bytes and SHA-256 of every declared raw file before interpreting any of their content. Declared files must be unique regular files directly in that directory; symlinks, traversal, and extra unmanifested record files cause refusal. Subdirectories are not inputs and are not traversed. The terminal's own bytes are hashed in the output; this is a binding to the record, not an independently authenticated signature.

[Observed] The decoder follows the retained predecessor `ordinary-3bd8be-assessment-metadata.py`: select the exact original genuine stop-resume assertion from the manifest-bound `vitest.json`, then decode its first failure message with `JSONDecoder.raw_decode`. The prefix must be exactly `Error: {`; parsing starts immediately after `Error: `. It does not use a regular expression or search for a nested object. The decoded capture must contain the original fixture's `failure` and `resumeDiagnostic` keys. If the terminal also retains `selectedAssertion`, it must equal the selected Vitest assertion. Error text, remaining stack, bodies, argv, raw values from unknown fields, and private paths are never printed. Validation failures produce a fixed generic refusal without exception text.

[Observed] Source bindings were obtained from immutable Git blobs at that actual subject, without executing product code:

| Source | SHA-256 | Bytes | Relevant lines |
| --- | --- | ---: | --- |
| `packages/polaris-dossier/src/url-ordered-design-session.ts` | `382645bb414dca8abe9c5f625edeff9bd6602308cae195e80ec9524eee93ee32` | 41551 | 78–99 diagnostic shape; 207–275 admitted boundary capture and original checks |
| `packages/polaris-dossier/src/url-run-composed.test.ts` | `0133c6e7fef5d3d91a0d2f283a8c3aeed7c92ea6f67f8f67cd03054fc15cdb43` | 238439 | 1553–1565 snapshot port; 1585/1602/1609/1617 captures; 1867–1879 retained trace; 3561 onward JSON error capture |

The output names these source digests, the actual terminal digest, every verified raw file digest by manifest ordinal, the Vitest digest, and the decoded JSON substring digest. No source or current checkout lookup occurs during analysis. The preparation deliberately binds this subject rather than guessing a future head.

The report enumerates the eight possible snapshot locations: four capture fields (`workAtEntry`, `workAtFirstRefusedStage`, `workAtSettlement`, `workAtFault`) under each of `resumeDiagnostic.broker.latestInvocation` and `firstRefusedInvocation`. Missing and null snapshots stay distinct. Each row preserves the retained invocation ordinal, invocation timing, fixed broker stage timings and first refused stage. The boundary's `operation` and `turn` identify its owner; this may be a nested audit operation. These summary copies are retained occurrences, not distinct operations or independent failures. Array order in the report is source/capture order; it does not manufacture chronology from optional fields.

Only the fixed 22b540 boundary scalar fields are rendered. Unknown enum values and nonfinite/non-numeric values become null and their fixed field names are flagged. Local CPU, monotonic and wall deltas use only the boundary's own retained baseline and observed sample; a null operand yields null. Cap comparisons are arithmetic comparisons of those retained samples, not additional enforcement decisions and not substitutes for `origin`/`reason`. The report separately labels ledger CPU/wall as `cumulativeLedgerSnapshot`; those values are never used as operation-current CPU or as the local baseline. No new CPU or authority samples are taken.

A full structural traversal counts `firstBoundaryFailure` keys throughout the decoded failure record without rendering arbitrary keys. The count is compared with the extracted known snapshot occurrences; a nonzero `unmappedOccurrences` is an explicit coverage gap requiring inspection rather than invented attribution. No execution is needed to author this census.

[Unknown] These limits remain:

- A passing, pending, skipped, or differently failing case may have no original fixture JSON error capture. The report retains its actual assertion status and reports diagnostic Unknown; a passing test alone does not prove diagnostic absence from unretained runtime snapshots.
- No boundary field in a retained non-null snapshot means absent at that snapshot, not proof that the whole session had no refusal. Null snapshots can precede work-budget creation; omitted snapshots may reflect an unavailable port or a caught snapshot error. Failures before successful operation construction remain outside this diagnostic.
- `unclassified` records identify the first observed admitted boundary and preserve any available ledger state/reason, but do not reveal private dependency errors or distinguish all audit-read, authority and other private exceptions. Check/finish/async catch current samples are null. Timer current CPU and remaining CPU are null; timer clocks do not imply a CPU sample at those times.
- First-write metadata can appear identically in later snapshot copies after retirement or cleanup. Their capture timestamps do not replace its own observed clocks. Relative trace timestamps use `resumeDiagnostic.began` as the observer's absolute monotonic origin; boundary monotonic clocks are absolute, and boundary wall clocks/deadlines are epoch milliseconds. Cross-clock subtraction is not performed.
- Retained snapshot/event populations are bounded by the original fixture. This report neither reconstructs omitted history nor attributes exclusive stage cost, inclusive CPU overlap, or the cause of a failure without its retained discriminator. Caps and all authority, product proof, secret checks and original genuine fixture assertions remain unchanged.

Preparation verification is static only: Python AST parsing and review of the decoder against the immutable source references. No product, fixture, test, native case, provider call, or pending-output analysis was executed here.
