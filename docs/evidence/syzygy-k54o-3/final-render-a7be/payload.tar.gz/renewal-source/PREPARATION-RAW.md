Source-only R6 preparation.

Exact main:08e1c4172885f9a9fb678ee7ffe3c08d52bac99e
Prior main:bb064295c160c7365d916eaf8a8cfd274914f516
Future subject:Unknown/unselected.

Observed:35changed paths,+1249/-13; independent raw/name-only path census agrees. Apps/packages unchanged;65app-family members identical;2render-source files/A303row/delta/4824byteoverlay exact. Full closure932objects hashed. Frozen retained inputs rehashed.8executable files byte-identical; only new outside metadata. No imports/execution of factory/helper/controls/product/build/capture/native/provider; Python AST parsing only.

Unknown:actual final render/parity/control outcomes.
