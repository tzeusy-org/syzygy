[Observed/source] R6 exact-main metadata renewal from bb064295c160c7365d916eaf8a8cfd274914f516 to 08e1c4172885f9a9fb678ee7ffe3c08d52bac99e. Frozen R5 source/prepared subjects remain unchanged and are not adopted as current captures. Eight Python/shell executable bytes remain identical, retaining exact-main/ancestry/source/adoption/draft guards and all masks/predicates.

35changed paths,+1249/-13; no apps/packages difference. Both bound render sources, all65app-generation files, exact A303 row/delta and4824-byte historical9c F3 overlay are unchanged. Renewed main closure has932inputs; future subject closure remains explicit/dynamic. Frozen Redis/config/v4draft/baselines remain exact. A303 still requires3definitions/+33bytes,2numeric cells/145unchanged,46HTML/50files/45measuredpages;31controls(4positive/27negative) plus separate233+8 remain.

[Unknown] Final subject, capture/parity/control outcomes and timing acceptance. No subject preparation/build/capture/control/module/provider/native execution. Fresh source review required. Future command only after explicit published subject selection:
  python3 /home/orca/.tmp/f3-native-admission-fixes/final-render-capture-factory-A303-R6/prepare-final-subject.py --subject EXACT_FUTURE_FULL_SHA --main 08e1c4172885f9a9fb678ee7ffe3c08d52bac99e

Do not run during source review. Exact08e1 is required; later main needs another explicit reuse audit. R6-source.patch records this metadata-only delta; inherited R4/R5patches are historical provenance.
