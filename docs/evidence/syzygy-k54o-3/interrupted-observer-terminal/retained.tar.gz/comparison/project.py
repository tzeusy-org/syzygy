"""Read retained metadata only; do not execute project code or inspect credentials."""
import gzip
import hashlib
import json
import pathlib
import re
import subprocess

BASE = pathlib.Path('/home/orca/.tmp/f3-native-admission-fixes')
OUT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
SUBJECTS = [('f571', 'native-f571c0ac1-stop-resume'), ('b5c7', 'native-b5c7bb12e-stop-resume')]
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')
def duration(stamp):
    return None if 'settledMs' not in stamp else round(stamp['settledMs'] - stamp['startedMs'], 6)
def union(intervals):
    total = 0.0
    end = None
    for start, finish in sorted(intervals):
        if end is None or start > end:
            total += finish - start
        elif finish > end:
            total += finish - end
        end = max(finish, end or finish)
    return round(total, 6)
report = {}
for tag, folder in SUBJECTS:
    directory = BASE / folder
    raw = (directory / 'check-all.log').read_bytes()
    result = json.loads((directory / 'result.json').read_text())
    subject = json.loads((directory / 'subject.json').read_text())
    records = {}
    for number, line in enumerate(raw.decode().splitlines(), 1):
        if line.startswith('owned interrupted stop ') and '{' in line:
            label, payload = line.split('{', 1)
            records[label.strip()] = {'logLine': number, 'value': json.loads('{' + payload)}
    assert len(records) == 4
    native = [entry['value'] for label, entry in records.items() if ' native ' in label]
    steps = {}
    for entry in native:
        for step in entry['inference']['steps']:
            steps[step['ordinal']] = step
    count = native[-1]['inference']['count']
    assert set(steps) == set(range(1, count + 1))
    # Independent lexical census, restricted to the two native projection lines.
    lexical = set()
    for label, entry in records.items():
        if ' native ' in label:
            lexical.update(map(int, re.findall(r'"ordinal":\s*(\d+),\s*"mediate":', json.dumps(entry['value']))))
    assert lexical == set(steps)
    finished = records['owned interrupted stop finished']['value']
    pending = records['owned interrupted stop pending']['value']
    audit = next(x for x in finished['auditTrace']['retained'] if x['ordinal'] == 2)
    connections = []
    def find_connections(value, path=''):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ['connections', 'connectionCount', 'transportCounts', 'boundMs']:
                    connections.append(path + '/' + key)
                find_connections(child, path + '/' + key)
        elif isinstance(value, list):
            for i, child in enumerate(value): find_connections(child, path + '/' + str(i))
    find_connections(records)
    write(tag + '-raw-snapshots.json', records)
    (OUT / (tag + '-check-all.log.gz')).write_bytes(gzip.compress(raw, mtime=0))
    write(tag + '-subject.json', subject)
    write(tag + '-result.json', result)
    rows = []
    for ordinal, step in sorted(steps.items()):
        rows.append({'ordinal': ordinal, 'mediate': step['mediate'], 'mediateElapsedMs': duration(step['mediate']),
                     'effect': step.get('effect'), 'effectElapsedMs': duration(step.get('effect', {})),
                     'preEffectElapsedMs': None if 'effect' not in step else round(step['effect']['startedMs']-step['mediate']['startedMs'], 6),
                     'audit': step.get('audit'), 'auditElapsedMs': duration(step.get('audit', {}).get('timing', {}))})
    current_rows = {}
    for key in ['latestRelayCurrent', 'latestHostCurrent']:
        trace = pending[key]
        current_rows[key] = {'trace': trace, 'elapsedMs': duration(trace), 'stageDurationsMs': [
            {'phase': x['phase'], 'elapsedMs': duration(x['timing'])} for x in trace['stages']]}
    appends = []
    for entry in audit['appends']:
        stamps = [x for x in entry['callbacks'] if 'settledMs' in x]
        appends.append({'ordinal': entry['ordinal'], 'kind': entry['kind'], 'event': entry.get('event'),
                        'startedMs': entry['startedMs'], 'settledMs': entry.get('settledMs'), 'elapsedMs': duration(entry),
                        'outcome': entry.get('outcome'), 'callbackCalls': entry['callbackCalls'],
                        'retainedCallbacks': len(entry['callbacks']),
                        'callbackUnionMs': union([(s['startedMs'], s['settledMs']) for s in stamps]),
                        'parentCurrentUnionMs': union([(s['startedMs'], s['settledMs']) for s in stamps if s['phase']=='current'])})
    # Completion timestamps are adjacent wrappers, not the same clock sample.
    # Their differences estimate the relative-trace origin; do not label exact offsets.
    offsets = []
    for event in ['attempt-allowed', 'send-attempt', 'send-outcome', 'response-admitted']:
        outer = [r for r in rows if r['audit'] and r['audit']['event']==event and r['audit'].get('timing', {}).get('outcome')=='accepted']
        inner = [a for a in appends if a['event']==event and a['outcome']=='accepted']
        for left, right in zip(outer, inner):
            offsets.append({'event': event, 'ordinal': left['ordinal'], 'estimatedOriginMs': right['settledMs']-left['audit']['timing']['settledMs']})
    report[tag] = {'subject': subject['subject'], 'tree': subject['tree'], 'elapsedSeconds': result['elapsedSeconds'],
                   'peakRssKiB': result['numberedVitestPeakRssKiB'], 'rawLogSha256': sha(raw),
                   'declaredLogShaMatches': result['logSha256']==sha(raw), 'snapshotCount':len(records),
                   'inferenceCount':count, 'unionOrdinalCount':len(steps), 'independentLexicalOrdinalCount':len(lexical),
                   'acceptedMediations':sum(r['mediate'].get('outcome')=='accepted' for r in rows),
                   'pendingMediations':[r['ordinal'] for r in rows if 'settledMs' not in r['mediate']],
                   'inferences':rows, 'currentAtPending':current_rows,
                   'samples':native[-1]['samples'], 'firstRuntimeFailure': native[-1].get('firstRuntimeFailure'),
                   'storeRefusals':native[-1]['resumeStoreRefusals'], 'broker':native[-1]['broker'],
                   'orderedAudit':native[-1]['orderedAudit'], 'connectionFieldsAnywhereInAllSnapshots':connections,
                   'baseAuditCallbackCalls':audit['callbackCalls'], 'baseAuditAppendCalls':audit['appendCalls'],
                   'baseAuditAppends':appends, 'baseAuditLatestCallbacks':audit['callbacks'], 'estimatedOrigins':offsets,
                   'lastSample':native[-1]['latestSample']}
    paths = ['url-run-composed.test.ts','session-relay.ts','url-ordered-design-host.ts',
             'url-ordered-design-session.ts','url-run-ordered-attempt.ts','url-session-audit.ts','url-machine-store.ts']
    hashes = {}
    for name in paths:
        path = 'packages/polaris-dossier/src/' + name
        source = subprocess.check_output(['git','show',subject['subject']+':'+path],cwd=REPO)
        hashes[path] = sha(source)
        (OUT / (tag+'-'+name+'.txt')).write_bytes(source)
    report[tag]['sourceSha256'] = hashes
report['comparison'] = {'peakRssReductionKiB':report['f571']['peakRssKiB']-report['b5c7']['peakRssKiB'],
                         'peakRssReductionPercent':100*(report['f571']['peakRssKiB']-report['b5c7']['peakRssKiB'])/report['f571']['peakRssKiB'],
                         'clockCaution':'Audit callbacks/bootstrap use absolute process performance.now; inference/current/native snapshots use observeDesignRun-local rounded clock. Estimated origin differences are not exact same-sample clock bindings.',
                         'causalCaution':'A305 and other source changes coexist between subjects. Two runs do not isolate observer causality or establish a throughput guarantee.',
                         'populationCaution':'Pending and final first-four/rolling-eight native snapshots jointly cover every numbered inference, but omit most inner per-inference fields and all retained connection fields.',
                         'noOverlappingSum':'Native audit is nested in effect, nested in mediate. Base current/machine callbacks nest inside append. Union metrics count overlapping intervals only once; do not add columns.'}
write('metrics.json',report)
write('MANIFEST.json',{f.name: {'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(OUT.iterdir()) if f.is_file() and f.name!='MANIFEST.json'})
print(json.dumps({'subjects': [report[k]['subject'] for k in ['f571','b5c7']], 'inferenceUnions':[report[k]['unionOrdinalCount'] for k in ['f571','b5c7']], 'metricsSha256':sha((OUT/'metrics.json').read_bytes())}))
