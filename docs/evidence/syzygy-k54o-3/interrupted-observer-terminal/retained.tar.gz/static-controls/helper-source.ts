function withoutObserverHistory<T>(history: { mockClear(): unknown }, invoke: () => T): T {
  try { return invoke(); }
  finally { history.mockClear(); }
}