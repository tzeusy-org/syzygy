[Observed] Prepared static controls bound to commit 3682da0aca3acfb7a92e2e3cfb3f4dec081ff7b3 and its exact test source. These controls have not been executed. The reviewed ten-target census is copied unchanged from the source candidate; its originalBody and originalSpy fields define the predicates. The previous one-shot AST inspection program was not retained, so check-wrappers.mjs materializes those same documented predicates for independent execution.

The checker requires one matching spy declaration and one mockImplementation arrow per target, the matching history handle, a zero-argument callback, and the exact original callback body. It parses syntax with the pinned installed TypeScript 5.9.3 parser and never imports test/product modules. Each negative changes only one helper call into its unchanged original body, and must reject solely that target for missing-wrapper. No duplicate product guards, new repository tests, or timing/performance claims.

Root may run after review:

    node /home/orca/.tmp/f3-native-admission-fixes/observer-wrapper-static-controls-3682/run-static-controls.mjs /home/orca/.tmp/f3-native-admission-fixes/observer-wrapper-static-results-3682

Expected [Inferred], pending execution: baseline accepts 10/10; each of 10 wrapper-removal mutants rejects exactly its changed target for missing-wrapper, with the other nine retained. The fresh output sibling records all ten complete mutant source files, exact SHA256 digests, and predicate results. This is a static presence/body-identity check, not runtime coverage. Root has separately executed the existing helper contract and its exact mockClear-removal mutant.
