import ts from '/home/orca/.tmp/f3-native-admission-fixes/native-coverage-merge-execution/w/node_modules/typescript/lib/typescript.js';
import { readFileSync } from 'node:fs';
const census = JSON.parse(readFileSync(new URL('./source-census.json', import.meta.url), 'utf8'));
if (census.targetPopulation !== 10 || census.targets.length !== 10 || new Set(census.targets.map(t => t.variable)).size !== 10)
  throw new Error('target population must be the reviewed ten distinct handles');
export function checkObserverWrappers(source) {
  const tree = ts.createSourceFile('subject.ts', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if (tree.parseDiagnostics.length) throw new Error('source parse diagnostics');
  const declarations = new Map(), implementations = new Map();
  function visit(node) {
    if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name)) {
      const key = node.name.text;
      declarations.set(key, [...(declarations.get(key) ?? []), node]);
    }
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression)
        && node.expression.name.text === 'mockImplementation' && ts.isIdentifier(node.expression.expression)) {
      const key = node.expression.expression.text;
      implementations.set(key, [...(implementations.get(key) ?? []), node]);
    }
    ts.forEachChild(node, visit);
  }
  visit(tree);
  const results = census.targets.map(target => {
    const errors = [], declaration = declarations.get(target.variable) ?? [], implementation = implementations.get(target.variable) ?? [];
    if (declaration.length !== 1 || declaration[0].initializer?.getText(tree) !== target.originalSpy) errors.push('spy-binding');
    if (implementation.length !== 1) errors.push('implementation-count');
    let wrapper, inner;
    const callback = implementation[0]?.arguments[0];
    if (!callback || !ts.isArrowFunction(callback)) errors.push('callback-arrow');
    else {
      wrapper = callback.body;
      if (!ts.isCallExpression(wrapper) || !ts.isIdentifier(wrapper.expression) || wrapper.expression.text !== 'withoutObserverHistory') errors.push('missing-wrapper');
      else {
        if (wrapper.arguments.length !== 2 || wrapper.arguments[0].getText(tree) !== target.variable) errors.push('history-binding');
        inner = wrapper.arguments[1];
        if (!inner || !ts.isArrowFunction(inner) || inner.parameters.length !== 0) errors.push('invoke-arrow');
        else if (inner.body.getText(tree) !== target.originalBody) errors.push('original-body');
      }
    }
    return { variable: target.variable, target: target.target, errors,
      wrapper: errors.length === 0 ? { start: wrapper.getStart(tree), end: wrapper.end, body: inner.body.getText(tree) } : undefined };
  });
  return { accepted: results.every(r => r.errors.length === 0), population: results.length, results };
}
