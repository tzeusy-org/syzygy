import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { checkObserverWrappers } from './check-wrappers.mjs';
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const packet = new URL('./', import.meta.url);
const binding = JSON.parse(readFileSync(new URL('binding.json', packet), 'utf8'));
const manifest = JSON.parse(readFileSync(new URL('manifest.json', packet), 'utf8'));
for (const item of manifest.files) {
  const bytes = readFileSync(new URL(item.path, packet));
  if (bytes.length !== item.bytes || digest(bytes) !== item.sha256) throw new Error(`packet digest mismatch: ${item.path}`);
}
if (digest(readFileSync(binding.typescript.path)) !== binding.typescript.sha256) throw new Error('installed parser drift');
if (process.argv.length !== 3) throw new Error('usage: node run-static-controls.mjs NEW_OUTSIDE_OUTPUT_DIRECTORY');
const output = resolve(process.argv[2]);
if (dirname(output) !== dirname(resolve(packet.pathname))) throw new Error('output must be a fresh sibling of this outside packet');
mkdirSync(output, { recursive: false });
const source = readFileSync(new URL('url-run-composed.test.ts', packet), 'utf8');
if (digest(source) !== binding.sourceSha256) throw new Error('bound source mismatch');
const baseline = checkObserverWrappers(source);
if (!baseline.accepted || baseline.population !== 10) throw new Error('baseline must accept ten wrappers');
const controls = [];
for (const item of baseline.results) {
  // The sole source mutation unwraps this call, preserving its complete original expression.
  const mutant = source.slice(0, item.wrapper.start) + item.wrapper.body + source.slice(item.wrapper.end);
  const result = checkObserverWrappers(mutant);
  const failures = result.results.filter(r => r.errors.length);
  if (result.accepted || failures.length !== 1 || failures[0].variable !== item.variable
      || failures[0].errors.length !== 1 || failures[0].errors[0] !== 'missing-wrapper')
    throw new Error(`wrong mutant rejection: ${item.variable}`);
  writeFileSync(`${output}/${item.variable}.test.ts`, mutant);
  controls.push({ variable: item.variable, mutantSha256: digest(mutant), mutation: 'replace only withoutObserverHistory(handle, () => originalExpression) with originalExpression', result });
}
const report = { state: 'Observed static predicate controls; no test/product module execution', binding,
  baseline, denominator: controls.length, rejected: controls.filter(c => !c.result.accepted).length, controls };
writeFileSync(`${output}/results.json`, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ baseline: baseline.accepted, population: baseline.population, rejected: report.rejected, denominator: report.denominator, output }));
