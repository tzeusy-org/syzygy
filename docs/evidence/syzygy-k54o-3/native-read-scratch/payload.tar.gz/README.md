# Native scratch borrowing proof — fd6c

[Observed] Exact source fd6caec7d78fe0de748f85ec05757677de2e88cf changes two files from0028. Both originals/candidates, patch/bindings and both verbatim PASS reviews are retained. The reissue corrects scope/count wording; original history remains. Private1MiB scratch is borrowed, unavailable while active and returned only to an empty slot. Synchronous nesting gets distinct active buffers. Every fresh byte/SHA/stat/EOF/authority check remains.

[Observed] Complete owning17/17 and original typecheck pass; one sole-fragment mutant yields the intended digest refusal (1failed/16selection skips/17), then exact candidate restored. Operators record integration maxWorkers1. Source snapshots, no-owned-children and privateTMP cleanup pass. Five full12421-row snapshots remain external, indexed by exact SHA/length/population/row digest. Candidate-bound checks ran at baseHEAD0028; source was committed later asfd6c. Raw preparation/unexecuted labels remain historical.

[Observed/diagnostic] The compiled0028 module scratch comparison completed96warm pairs against genuine admitted frozen0e14 target/program, with mean group wall improvements5–13% and synthetic retained320MiB mode. It proves no cold/full-runtime/recovery benefit. Actual pairs/operator/results are retained inertly.

[Observed/failed] Ordinary0028 failed at600s after4Design forwards. Separate --cpu-prof0028 failed before timeout through a2s resource-census timeout/inspection-failed SIGTERM,0forwards. Exact causal assessment206d0083… preserves this distinction. Numeric gzip retains all8profiles/2,891,954samples and signed-3µs delta with independent computations. Wall sampling weights are not process CPU; runtime Node attribution remainsUnknown. Raw8profiles remain external and indexed.

[Unknown] Production build/genuine recovery atfd6c and final full-suite/source/main acceptance. Packaging makes no adoption and runs no product/test/build or source/docs/ledger edit.

All code/operators/patches are inert.txt. Members are sorted regular0644,uid/gid/mtime0; gzip mtime0/no filename. Two builds are byte-identical. Every member is independently reread/hash-verified through Python and GNUtar+sha256sum. No checkout/dependencies/PID/ACTIVE/running artifacts are included. External index binds each original path, archive path, bytes, SHA, subjects and scope.
