# Scratch borrowing after byte references: compiled-only diagnostic

[Observed] One authorized measurement execution completed in15.645632s, exit0. Actual population96warm pairs/192samples:4cases ×2memory modes ×12pairs,6baseline-first and6candidate-first per group. No failed measurement attempts or retries.384measured native commands plus2setup-ref commands; all192sample child-CPU deltas are positive (minimum3342µs). The97raw JSON lines independently enumerate96pairs and1scope-close record; recomputed means match all8summary groups. No canonical test, build, profile, source edit or adoption occurred.

[Observed] MODULE/SOURCE is clean0028c1bb8fd92da2837dd0bb919a2e155224b535. TARGET/Genuine admitted PROGRAM is the frozen clean0e14c3439fb59cf5405e3306c6d8de671a49206d checkout. The target lacks origin/main: the three-command refs/policy/refs population proves transport/policy checks, not parent authority. Runtime admission succeeded before and after. Actual addon/supervisor/Git SHA match the current404-input/10-output manifest; all404inputs and10outputs were hash-verified before measurement and snapshotted unchanged after. Both variants use the byte-identical actual primary meter module.

[Observed] Candidate changes only read-scratch management and the absolute shared-meter import needed for its outside location. It borrows available scratch or allocates1MiB, clears the available slot before the loop, and returns in finally only if the slot remains empty. Fresh full byte comparisons, initial SHA capture, stat/path/EOF checks and10000ms native timeout remain unchanged. There are no worker/heap/deadline overrides.

| Memory mode | Case | Baseline mean ms | Candidate mean ms | Wall Δ | Host CPU Δ | Child CPU Δ | Candidate wall wins |
|---|---|---:|---:|---:|---:|---:|---:|
|ordinary|head-sync|14.302|12.761|-10.77%|-30.65%|-2.28%|11/12|
|ordinary|head-async|12.494|11.842|-5.22%|-22.26%|+2.90%|9/12|
|ordinary|refs-policy-refs-sync-not-parent-authority|36.147|32.855|-9.11%|-30.13%|+1.82%|11/12|
|ordinary|refs-policy-refs-async-not-parent-authority|37.581|32.534|-13.43%|-38.89%|+2.75%|12/12|
|retained-320MiB|head-sync|15.264|14.265|-6.54%|-48.24%|+0.98%|8/12|
|retained-320MiB|head-async|14.225|12.557|-11.73%|-29.32%|-0.93%|8/12|
|retained-320MiB|refs-policy-refs-sync-not-parent-authority|51.470|48.756|-5.27%|-7.65%|+1.24%|7/12|
|retained-320MiB|refs-policy-refs-async-not-parent-authority|45.811|42.622|-6.96%|-10.62%|-4.07%|6/12|

[Observed] Matched-population aggregate wall and host CPU:
- ordinary: wall1206.287→1079.901ms (-10.48%); host CPU531114→357419µs (-32.70%). Shared-process RSS spans89.957–111.008MiB.
- retained-320MiB: wall1521.242→1418.401ms (-6.76%); host CPU485328→396075µs (-18.39%). Shared-process RSS spans425.512–476.387MiB.

[Observed] Both scopes healthy before close, drained and closed cleanly. Cumulative child CPU receipts baseline810060µs and candidate812312µs include setup; no owned children remain and private scratch was removed. Exact source/module/operator bytes remained unchanged; both roots remain clean at their separately recorded commits. Raw pairs preserve wall, host/child CPU, RSS, output hashes and order.

[Inferred] This fixed warm population supports a modest allocation-related optimization candidate: wall means improved5.22–13.43%, with lower host CPU in every group. Child CPU varies in both directions, consistent with the scratch change acting in host JavaScript rather than changing Git work. This single small population does not establish distribution tails or a durable production speedup. Synchronous nested calls would borrow distinct active buffers; the first completed call may occupy the free slot and a later return discards its buffer, retaining at most one free1MiB allocation. That ownership argument is source inspection, not an executed reentrancy test.

[Unknown] Cold construction/first-capture benefit, isolated per-variant RSS/GC effects, full-runtime hashing benefit, and genuine600s recovery outcome are unmeasured. Both variants share one process; RSS cannot isolate their independent footprints. Retained320MiB is synthetic diagnostic RSS. The measurement JSON conservatively inherits the old harness wording “synchronous and non-reentrant”; the new borrowing pool addresses active-buffer aliasing, but no asynchronous read/await may be introduced while borrowed without re-evaluating ownership. No predicate cache, authority-bracket change or adoption follows from archive preparation or this run.

Bindings:

- Native source TS SHA256 `12c65529eb41bd4f00a040dd283855cab3b12b75fe49128037e007061bcd3ce1`
- Original compiled module SHA256 `0f7b0b171e84727f182a8da857800c067a057113e8782a38d7934cac15b39867`
- Candidate compiled module SHA256 `fcd922230e648fa6e20026e9e429d74f3088c6150f2c0fe6faf8dc3fc218c294`
- Primary404-input manifest SHA256 `75aa3341e156e563a0e16d277bc56a608152887312ee2d05ca5dde5632c45e66`
- Measurement SHA256 `e5cbc76a1bed358f1b11a05bdad47da9353f0ed30f48fe32f8394f0f1a8239b7`
- Raw pairs log SHA256 `ffc81a273732d2db98ba4b771b4b55b040d4cd88e757157446469739f0f7fed2`
- Operator SHA256 `d0a156e1fbbe494926c7c5cb86abf82f9f1550aa33425c2511b52c7f3f96d53d`
