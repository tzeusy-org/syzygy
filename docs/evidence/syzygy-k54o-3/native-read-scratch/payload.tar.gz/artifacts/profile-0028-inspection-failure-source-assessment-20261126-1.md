# Exact 0028 profiled recovery: source-bound inspection failure assessment

[Observed] Scope: retained JSON observations/logs plus source inspection only. No product, test, probe, build, benchmark, or diagnostic code was executed. CPU profiles were not read or reparsed. No primary file was changed. The subject records name commit `0028c1bb8fd92da2837dd0bb919a2e155224b535`, tree `1b3d1c0d275ab4a5cfc972d3e427a12f0146d6bd`, the same test source digest and built-runtime manifest digest. The profiled command adds `--cpu-prof`; its timing is diagnostic, not acceptance evidence.

## Finding

[Observed] The profiled run identifies the precise first refusal at the launcher boundary. In `extracted-observations/native-finished.json`, both `launcherInspection.firstRefusal` and `roleInspections.design.firstRefusal` report sample 55, startedMonotonicMs 521278.511726:

- process phase accepted at +1626.930537ms;
- storage phase started at +0.3533179999794811ms, with no settled outcome;
- refusal phase `storage`, cause `bounded-timeout`, elapsedMs 2273.8092559999786;
- no verify or confirm entry for this sample.

[Observed] The preceding 54 authority samples were verified and confirmed, with verifyRefused/verifyRejected/confirmRefused/confirmRejected all recorded as 0 over that 54-sample authority population. The final role outcome is `inspection-failed`, signal `SIGTERM`, exitCode null; resumed-exit reports exit 1, runtime failure `role-ended`. The test assertion then rejects exit 1 at url-run-composed.test.ts:3362. The retained test line reports 528848ms; wrapper result is 563.9304778089863 seconds. These are different denominators from the 545786ms complete test-file run and 559.12s Vitest duration.

[Inferred] This run failed because the resource census wait expired while storage remained pending. It did not fail at the five-second authority envelope, the 60-second producer envelope, an authority drift refusal, or a recorded storage/process quantity limit. The recorded cause is sufficiently precise to select that failure path; it does not identify which filesystem operation or competing work consumed the wall time.

## Source path

[Observed] Definitions below are in `packages/polaris-dossier/src/` under `/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w`:

1. `session-launch.ts:17-23`: ordinary inspectionMilliseconds is 2000. Ordered Design uses a 5000ms complete inspection envelope while explicitly retaining the ordinary two-second resource census bound.
2. `launchRestrictedUrlSession`, `session-launch.ts:643-649`: each inspection begins only when no sample is pending; resourceMilliseconds is min(limits.inspectionMilliseconds, URL_LAUNCH_LIMITS.inspectionMilliseconds). The observed 5000ms launcher inspection therefore gives this census 2000ms.
3. `session-launch.ts:675-697`: ordered Design postpones authority verification until after census. The process walk starts concurrently with storage; the state phase remains `storage` until storage succeeds and publication proceeds.
4. `session-launch.ts:677-721`: an inner bounded() joins the resource census using resourceMilliseconds. Its timeout observer records the error as phase `storage`, cause `bounded-timeout`. The sampledStorageBytes and peakProcesses publication checks follow successful census; sample 55 did not reach those checks.
5. `bounded`, `session-launch.ts:30-46`: the finite deadline rejects the promise race after the monotonic deadline. A delayed timer can report more than 2000ms elapsed; the record's 2273.809ms does not imply a changed bound. This bounds waiting and does not cancel arbitrary underlying IO.
6. `session-launch.ts:741-746`: the rejection records the first refusal then calls stop('inspection-failed'). `stop`, lines 623-631, preserves the reason and sends SIGTERM, followed by bounded cleanup and possible SIGKILL. SIGTERM is the response to the inspection failure, not evidence of an externally initiated termination.
7. `session-launch.ts:767-770`: waitForSample() returns false once shutdown begins. `url-run-sessions.ts:404-415` joins those samples; its terminal handler at 421-435 converts a non-clean role ending into `role-ended`. `polaris.ts:1374-1378` renders `checked session boundary unavailable` when runtime.current() or waitForProductSamples() fails without an operator-stop indication. This explains the surface message without treating that generic message as the underlying refusal.

[Observed] The resumed producer instead rendered successfully: initial remaining 59956ms, elapsed 16430.984949999955ms, remaining 43525ms, admission accepted, producerRefusal false. Resume store refusal arrays are empty with omitted 0. The resumed Design observer records inference count 0, broker invocations 0, and no MCP ingress starts in its retained native-finished summary. These observations are consistent with Design terminating before the first resumed request crossed those observed boundaries; they do not prove the entire host had no competing work.

## Comparison with ordinary recovery

[Observed] Ordinary recovery.log reports `Test timed out in 600000ms`. Its finished observation remains `supervised-resume`, Design forwards 4, terminal null. Its latest authority sample 1094 verified and confirmed. The first retained launcher refusal is sample 1095, startedMonotonicMs 605983.586363, storage operation-rejected after 38.08709499996621ms, detail open-directory/filesystem-rejected/ENOENT. Native-finished records afterEachStartedMs 605959.837737 and observation at 606028.533331.

[Inferred] That ordinary ENOENT is temporally after afterEach cleanup began and is consistent with a disappearing scratch root during cleanup. It cannot explain why the ordinary test reached its 600000ms timeout. The ordinary record does not establish the profiled storage-timeout cause. Conversely the profiled run ended through a concrete storage timeout before the outer test timeout and cannot be presented as a reproduction of the ordinary hang/slow path. No shared root cause is established.

## Repair target and missing evidence

[Inferred] The concrete failure site to investigate is the descriptor-anchored storage census and its scheduling inside `launchRestrictedUrlSession`, specifically `storage()` (`session-launch.ts:352-512`) and the fixed four-stat batches / directory reads / close joins at 397-481. Preserve the two-second census bound, complete-count requirement, descriptor anchoring, no-follow/type/link/depth/entry checks, disappearance rules and close-error precedence. This record does not justify a particular semantic repair, increasing a timeout, omitting a census, reusing a prior count, or weakening a guard.

[Unknown] The slow operation within sample 55 is not retained: no path-free per-operation count/duration, active directory depth, enumerated-entry count, outstanding close/read/stat status, threadpool queue delay, event-loop delay, GC pause, or concurrent synchronous authority-work attribution is attached to that census. The process phase's 1.627s completion suggests the shared resource join was slow, but it does not distinguish filesystem work, threadpool contention, or delayed event-loop continuations. Profiling overhead and host load contribution are not isolated. The ordinary critical path after four forwards is independently unproven. Correlation with the separate CPU-profile analysis is the next useful evidence; a confirmed performance hotspot could select a repair that keeps these checks and bounds intact. There is no evidence here to prescribe the prepared native scratch-reuse change as the fix for this refusal.

## Input and source SHA-256 bindings

[Observed] Digests computed using sha256sum. Execution directory names below are relative to `/home/orca/.tmp/f3-native-admission-fixes/`.

| Input | SHA-256 |
|---|---|
| native-production-recovery-profile-0028-execution-1/subject.json | cee636cf11a629ba6f962baefd5dafbc7dbe4631a8fe514cb8b001575873f1c7 |
| native-production-recovery-profile-0028-execution-1/result.json | 3ddc28a4f9dcaef8ceb09543a2c6ef90ce1a32c60621cac436ce25173cdc3df3 |
| native-production-recovery-profile-0028-execution-1/recovery.log | fe56aa71069e70a2674bfcc9d6f0a09579a005527fd8ee4fed96b3d41d217c62 |
| native-production-recovery-profile-0028-execution-1/extracted-observations/native-finished.json | 5c742995e07e71591219dbda93c83b0b3ada9009cd29cf4f3b29b9dc1f022d10 |
| native-production-recovery-profile-0028-execution-1/extracted-observations/finished.json | b27d180d1377fd5765f2d783e8e347bb12b7586fffc641b2131e5e436f116f7f |
| native-production-recovery-profile-0028-execution-1/extracted-observations/resume-failure.json | 402c808bd96d23f122db0932382189bf3c564c73bfd1ad1b49d586cbde2d34dc |
| native-production-recovery-0028-execution-1/subject.json | 67f033e2e74fd8032d3b36343d163d189584619e5dc7dcaaeb2a81784493b7e4 |
| native-production-recovery-0028-execution-1/result.json | e34ed1b5f158f619684292e77dccb19bfd5453fcbc383684d150549605c3b947 |
| native-production-recovery-0028-execution-1/recovery.log | 4b3d42746a9c31c473a53111e4de7e34348afb1d0f95a1d48947534a9535c0d9 |
| native-production-recovery-0028-execution-1/extracted-observations/native-finished.json | 8e3ab6f25c44f9744d0c717b7d253cb6b0b6f23dec5537b0d5b08ddd5770c15f |
| native-production-recovery-0028-execution-1/extracted-observations/finished.json | bc699d164a59f733e009a4d1037d99990687fb7011e8b5075ef6e41ef6806865 |

[Observed] Source paths below are relative to the primary root above.

| Source | SHA-256 |
|---|---|
| packages/polaris-dossier/src/session-launch.ts | de5c117778f248a296b5cb26d8d46572e5cd4d2342b1a8f0077a2adc8dddf176 |
| packages/polaris-dossier/src/url-run-sessions.ts | 1116c471ca2de89b4daaf7e4f1dc7e40d79f4afc82cf4d02195796a7126700e8 |
| packages/polaris-dossier/src/polaris.ts | 8a26c1cab1785cb0e71768cb0fe40b452c5cfe6bbcfb3a66f780f6f78a01110d |
| packages/polaris-dossier/src/url-run-composed.test.ts | bf6c2da5785db51ef61cbbd6fc58ac592fd03fd8031336bb69e5f83a4d1e1e82 |
