# Exact0028 V8 profile: failed diagnostic path

[Observed] This is the original genuine stop-resume command with --cpu-prof at exact0028c1bb8fd92da2837dd0bb919a2e155224b535 and runtime manifest75aa3341e156e563a0e16d277bc56a608152887312ee2d05ca5dde5632c45e66. The operator reports exit1 after563.930478s, unchanged/clean source, no owned children and private TMP removed. The selected test failed after528.848s; six cases were selection skips (1failed/7). It exited before the unchanged600s test deadline. It must remain separate from the ordinary0028 run that timed out at600s after4Design forwards. Profiling reached0forwards and0final assertions; no paired speed ratio or recovery acceptance follows.

[Observed] This real pre-cleanup failure is role-ended with Design inspection-failed/SIGTERM and “checked session boundary unavailable.” Sample54 verification and confirmation accepted. Sample55 starts at absolute521278.512ms; process census accepts after1626.931ms, storage remains pending and records bounded-timeout after2273.809ms. The recorded aggregate inspection limit is5000ms, but frozen session-launch.ts649 bounds process/storage by min(aggregate5000ms, ordinary resource2000ms). Terminal inspection-failed normalizes to524452.826ms,32.662s before failureStop557115.307ms. All54native verify/confirm samples accepted with0recorded refusals/rejections; inference count0. This evidence identifies the resource-census timeout, not why its storage scan could not finish under profiling.

[Observed] Bootstrap is already slow before any resumed inference: restore-plans47.606s, load-renderer1.394s, create-origins7.726s, restore-products47.531s, start-sessions17.430s. Create-machine15.087s and open-store0.916s are nested in start-sessions and are not additive. Resumed render completes16.431s into its60s lease: admission entry10.315s, accepted/settled15.844s;79artifact-authority callbacks total5.324s, nested in the render.

[Observed] Exact profile population8files/43,468,859bytes/2,891,954samples: one owning test worker, one inferred root runner, five idle pool workers and one inferred short pool bootstrap. Role classification follows sampled modules, not filenames. Sample-first ancestor unions and independently computed node-first subtree/frontier totals agree for every profile. There is one signed negative delta,-3µs, in the root runner; it is retained without clipping. Profile spans differ from summed signed deltas by their recorded residuals, total11945µs. Concurrent profiles are not summed into command wall time or CPU.

[Observed] Owning worker522960 has377,823samples and557.668755s signed sampling weight. The following disjoint leaf/path partition was additionally recomputed independently from raw node IDs and parent structure; both counts and signed weights agree:

| Category | Signed sampled seconds | Samples |
|---|---:|---:|
|idle|231.527151|183768|
|garbage-collector|33.259519|20133|
|other-sampled-leaf|157.322802|88286|
|other-hash-update-leaf|21.622642|16271|
|native-runSync-leaf-unresolved-wait|73.441754|48330|
|native-image-read-leaf|24.792181|11596|
|native-image-bytecompare-subtree|6.974474|4361|
|native-image-allocation-subtree|6.227610|3617|
|native-image-other-leaf|2.497439|1458|
|native-image-hash-update-leaf|0.003183|3|

[Observed] Native-image current ancestry totals40.494887s, including24.792181s fresh reads,6.974474s Buffer.equals/compare descendants,6.227610s allocation descendants,2.497439s other validation work and0.003183s initial SHA update. Global Hash.update leaf weight is21.625825s:0.003183s native and21.622642s other. Nearest recorded project hash callers account for session-launch.fileDigest14.093156s, machine-peer.pinnedExecutable3.738063s, runtime anonymous frame2.206924s, and support.sha2561.366569s. These hash-caller projections are part of the hash total, not additional work. Global FastBuffer self weight18.361293s includes the native allocation portion; global GC33.259519s cannot be assigned to that allocation source.

[Unknown] The runtime anonymous frame has runtime-module provenance, but no independently verified source map identifies it as readNodeDigest or Node hashing. Direct Node-only hash weight is therefore Unknown, not zero. Native runSync leaf73.441754s is unresolved sampled blocking/execution weight; it does not separate helper CPU, waiting, scheduling or host overhead. Idle231.527151s can include async IO, timers and role waiting; it is not proof of spare CPU. No sampling weight is a process CPU receipt.

[Inferred] Routine native-image SHA is no longer a major observed weight on this path; fresh reads, byte comparisons, allocation and unresolved native runSync remain. The independently measured scratch-borrow diagnostic targets allocation and possible GC, with modest5–13%warm wall improvements; this profile does not establish its genuine recovery effect. The changed path/work population prevents claiming a causal performance ratio against0e14. Full-runtime Node reference retention is not prioritized by these samples: the complete global non-native hash weight is21.623s and its Node share remains unresolved. No authority check, freshness bracket, resource bound or deadline should be removed on this evidence.

[Observed] Input bindings:18exact0028source files were frozen from git-show and checked against preparation SHA256 plus independent sha256sum; later root candidate edits do not change these frozen bytes. Original8profiles/log/receipts remain untouched. Complete numeric/profile metadata is compressed with signed deltas, call paths, per-node totals and denominators; data: code URLs are represented by exact URL SHA/byte length. The oversized unissued intermediate is replaced by that metadata archive.

Bindings:
- recovery.log: 531411bytes, SHA256 `fe56aa71069e70a2674bfcc9d6f0a09579a005527fd8ee4fed96b3d41d217c62`
- Numeric archive: 4450685bytes, SHA256 `ba07753ba6fc74fc0534d600e71b56f70ed037f356891123fc43e8fe1952deaa`
- Summary SHA256 `9d4578341a9e54aa1c710cbfb76918397098891c25ed27d955023f971af012a6`
- Frozen source-binding SHA256 `51acab82ed72074f7b365a4cb56b817f12c5ba7a1a0eadab6ef9a2da1dc4aa31`
- Analyzer SHA256 `eb58408b72864a6a6dcd5fd7f8a72bb18d22e2c0264ff072b212fdf1f6b68e9b`
- Partition/compression operator SHA256 `10bd2d8e746de7cc0c199d9287f01b8fcab98411b8315ddd6c10489c244c355a`
