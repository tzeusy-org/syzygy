PASS

# Fresh source-only review: native read scratch preparation 0028

[Observed] Reviewed subject: the frozen outside-only preparation at /home/orca/.tmp/f3-native-admission-fixes/native-scratch-reuse-ts-preparation-0028, source head recorded as 0028c1bb8fd92da2837dd0bb919a2e155224b535. This verdict concerns the source delta and the stated acceptance criteria. It is not adoption, runtime validation, a performance finding, or full recovery evidence. No primary source was edited; no product, test, compiler, build, benchmark, or probe was executed.

## Frozen bindings

[Observed] SHA-256 values were computed from the reviewed files and matched the bindings for both originals, both candidates and the patch:

- PREPARATION.md: bbef5dd9bf597239d51e14637b39f1e116774034023be2b106ece96b0e1555b2
- bindings.json: 43410269ac2fdbf9e34dd045f066b65762cb27d696baa1e16d1fa3b32718f8f0
- candidate.patch: 48f62f2c573d1a8baf4b3238c1d6582423a412bcac05e333ad99b3d44624c404
- original/packages/polaris-dossier/src/policy-git-native.ts: 12c65529eb41bd4f00a040dd283855cab3b12b75fe49128037e007061bcd3ce1
- candidate/packages/polaris-dossier/src/policy-git-native.ts: b899ceba35cce3c6561a3e7bae7d8b97d5a05865468ce49dc5f37ccede9c2971
- original/packages/polaris-dossier/src/policy-git-native.test.ts: e5ca44eabfb5d0ba4520f4296814d30b2a570aee589a7c5beeaceb9c4e000462
- candidate/packages/polaris-dossier/src/policy-git-native.test.ts: d3017b4deee31e18a4c852a9dd4fc7fda3bb2582a57a4bcd130d7425d4bf15fc

[Observed] A newly generated unified diff of the two frozen source pairs exactly equals candidate.patch. All six recorded source/patch digests and lengths checked against the relevant binding entries where present; PREPARATION.md and bindings.json are additionally bound above. The compiled diagnostic was not read or executed.

## Reasons

1. [Inferred] Buffer ownership satisfies the stated bound. The module has one optional idle slot (candidate implementation lines 14-15). Each check takes that slot or allocates exactly 1,048,576 bytes, empties the slot, then records its borrow before the first read (41-46). A synchronous reentrant check therefore cannot obtain the outer active buffer. Finally returns a buffer only to an empty slot (67-69); a nested returned buffer wins and the outer surplus becomes collectible. Early failures before acquisition retain no borrow. No new buffer list, scope reference, descriptor, or authority result is retained by this slot.

2. [Observed] The full block from offset initialization through successful publication and return is byte-identical to the original. This preserves read-to-EOF, safe offset and size bounds, byte comparison against private authenticated bytes, initial-image copying and SHA-256, exact length checks, both final fd/path stat comparisons, and publication only after the checks. The initial fd/path stat and length checks remain in their original order. Everything from the post-current failure check through the end of the implementation is also byte-identical, preserving close behavior, job cleanup, scope cleanup, poison integration, and every invocation of current(). Initial pathname, ownership, file shape, mode, and same() predicates are unchanged. [Inferred] This is scratch reuse, with no new authorization-result cache and no skipped validation.

3. [Observed] The test diff is exactly one insertion of 26 lines at the existing multichunk/private-bytes case. The two complete files retain the same 17 it declarations in the same order, confirmed by regex and line-prefix counts. Every predecessor line survives unchanged; consequently the previous assertions survive, including the original drift, direct-executability, no-spawn, healthy, and irreversible-poison checks. The optional-await statement-leading expect-line count is 89 to 93; the broader expect-bearing-line count is 96 to 100. Test declaration growth is zero.

4. [Inferred] The added case meaningfully discriminates a naive shared-active-buffer implementation. The outer image has the base fixture plus a multichunk 0x71 footer. The nested image is asserted shorter than one chunk and has a 47-byte 0x72 footer at the same base-image offset. The spy performs the real outer read first and reenters before its bytes are consumed, recognizes the outer fd path, and sets its once flag before nesting. Nested validation finishes with nested Git reads; under naive shared active storage those different footer bytes would replace bytes the outer check expects to be 0x71, making the outer output expectation fail. Proper borrowing gives nesting separate active storage. Both outputs and actual reentry are asserted. The spy delegates both readSync overload forms and restores in finally (candidate test 309-326); nested scope registration precedes the spy.

5. [Inferred] The only additional persistent memory lifetime identified is one idle 1 MiB image scratch per module instance, potentially surviving scope closure until process/module collection. The slot retains the buffer alone, including its prior image bytes, without exposing its unfilled tail: every consumer still slices to the returned read size. Temporary extra buffers during synchronous reentrancy are bounded by active nesting and are not accumulated as idle buffers. This matches the disclosed lifetime allowance; no further lifetime concern was identified in this two-file delta.

## Governing bar and limits

[Observed] Applied the canonical engineering bar with adopted CC-BAR-1 precedence and CC-BAR-2 evidence expectations. The affected risk floor is CC-BAR-5 floor 6 (security), because this is executable-image admission. SEC-5 states: "Anything that matches the declared secret-detection policy, or cannot be classified, is excluded". [Inferred] This delta does not alter secret classification, screening, egress, or fail-closed predicates; it preserves the executable authentication checks under review.

[Unknown] Compilation, runtime behavior, executed mutation sensitivity, production GC behavior, and full recovery remain unestablished by this source-only review. The reasoning above is not an executed counterexample. No performance claim is made. These limitations do not constitute a source-review finding against the specified acceptance criteria.

[Observed] Blocking source-review findings: none identified within the two-file frozen delta and the declared acceptance scope. Exact verdict: PASS.
