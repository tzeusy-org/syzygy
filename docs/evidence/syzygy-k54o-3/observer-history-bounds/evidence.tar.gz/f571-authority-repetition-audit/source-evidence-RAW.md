# f571 authority source evidence — verbatim excerpts

Subject: `f571c0ac198bd38e7ac39c955c5ab3d5997298a6`. Tree: `542ae0775a6f0db84084f767785f7270d59033fe`.
Source transcript only; this is not an independent review or runtime timing measurement.

## packages/polaris-dossier/src/url-session-audit.ts:513–522
Whole-file SHA256: `f6359eb4d2d694196f7836d88619b04e94ed5ae2bbab3f2c8659c3689fe71f47`.
```typescript
    const checkCurrent = async (deadline: number): Promise<void> => {
      guard(deadline); if (await wait(track('callback', current), deadline) !== true) poison(); guard(deadline);
    };
    const io = async <T>(deadline: number, fn: () => Promise<T>, cleanup = false): Promise<T> => {
      // Closing verifies the historical physical prefix only; it grants no new
      // act and must still release descriptors after the run becomes stale.
      if (!cleanup) await checkCurrent(deadline);
      const result = await wait(track('filesystem', fn), deadline);
      if (!cleanup) { guard(deadline); await checkCurrent(deadline); }
      else if (poisoned || performance.now() >= deadline) poison();
```

## packages/polaris-dossier/src/url-session-audit.ts:600–626
Whole-file SHA256: `f6359eb4d2d694196f7836d88619b04e94ed5ae2bbab3f2c8659c3689fe71f47`.
```typescript
    };
    // The caller brackets a complete read-only prefix check with currentness.
    const inspectIdentities = async (deadline: number, changed?: ChangedSegment, cleanup = false): Promise<void> => {
      const inspect = inspectWithin(deadline, cleanup);
      await verifyDirectoryName(inspect);
      if (!sameDirectory(await inspect(() => directory.stat({ bigint: true })))) poison();
      const inspectSegment = async (role: ViewRole, segment: Segment): Promise<void> => {
        const expected = expectedSegment(role, segment, changed);
        for (const stat of [await inspect(() => segment.file.stat({ bigint: true })), await inspect(() => lstat(path.join(input.parent, segment.name), { bigint: true }))]) {
          if (!sameSegment(segment, expected, stat)) poison();
        }
        const buffer = Buffer.alloc(Math.min(65_536, Math.max(1, expected.prefix.length))); let offset = 0;
        while (offset < expected.prefix.length) {
          const wanted = Math.min(buffer.length, expected.prefix.length - offset);
          const read = await inspect(() => segment.file.read(buffer, 0, wanted, offset));
          if (read.bytesRead !== wanted || !buffer.subarray(0, wanted).equals(expected.prefix.subarray(offset, offset + wanted))) poison();
          offset += wanted;
        }
      };
      // Each role has its own descriptor. Keep the scan tracked until all
      // started reads settle, even after one role has poisoned the audit.
      const checked = await Promise.allSettled([...segments].map(([role, segment]) =>
        inspectSegment(role, segment).catch(poison)));
      if (checked.some(result => result.status === 'rejected')) poison();
    };
    for (const role of ROLES) {
      const name = `${input.name}-${role}.jsonl`;
```

## packages/polaris-dossier/src/url-session-audit.ts:816–847
Whole-file SHA256: `f6359eb4d2d694196f7836d88619b04e94ed5ae2bbab3f2c8659c3689fe71f47`.
```typescript
      checkEffectCurrent = checkCurrent, attemptDeadline?: number): Promise<DurableEvent> => {
      const checkBoundary = (): void => {
        guard(deadline);
        if (attemptDeadline !== undefined && Date.now() >= attemptDeadline) poison();
      };
      guard(deadline);
      if (records - declarations >= limits.events) poison();
      const row = encodeRow(event, records + 1, totals[role].records + 1, tip, totals[role].tipSha256);
      const offset = segments.get(role)!.prefix.length;
      if (durableBytes + row.bytes.length > limits.bytes) poison();
      let nextUsage: SessionResponseUsage | undefined;
      if (isRecord(event) && event.kind === 'usage') {
        const reported = event.payload as SessionResponseUsage;
        nextUsage = Object.fromEntries(Object.keys(zeroUsage()).map(k => [k, totals[role].usage[k as keyof SessionResponseUsage] + reported[k as keyof SessionResponseUsage]])) as unknown as SessionResponseUsage;
        usage(nextUsage);
        for (const key of Object.keys(zeroUsage()) as (keyof SessionResponseUsage)[]) if (!count(ROLES.reduce((n, r) => n + (r === role ? nextUsage![key] : totals[r].usage[key]), 0))) poison();
      }
      try {
        const tail = await io(deadline, async () => {
          await inspectIdentities(deadline);
          await checkEffectCurrent(deadline);
          const full = await writeRow(role, row.bytes, deadline, checkBoundary);
          await checkEffectCurrent(deadline);
          await segments.get(role)!.file.sync();
          await checkEffectCurrent(deadline);
          await directory.sync();
          await checkEffectCurrent(deadline);
          await inspectIdentities(deadline, { ...full, role });
          if (checkEffectCurrent !== checkCurrent) await checkEffectCurrent(deadline);
          return full;
        });
        publishRow(role, row, tail, deadline, checkBoundary);
```

## packages/polaris-dossier/src/url-session-audit.ts:950–1005
Whole-file SHA256: `f6359eb4d2d694196f7836d88619b04e94ed5ae2bbab3f2c8659c3689fe71f47`.
```typescript
    const verifyDurableEvent = (role: ViewRole, event: DurableEvent, observeRead?: (bytes: number) => void): Buffer => {
      if (poisoned) throw refused();
      const intent = managedAppend, writer = intent && segments.get(intent.role)!;
      let extent: SegmentPrefix | undefined;
      if (intent && writer) {
        const stat = fstatSync(writer.file.fd, { bigint: true });
        if (intent.full) extent = intent.full;
        else if (sameSegment(writer, writer, stat)) extent = writer;
        else {
          if (!sameSegmentIdentity(writer, stat) || stat.size !== BigInt(intent.prefix.length)) throw refused();
          extent = { prefix: intent.prefix, modified: stat.mtimeNs, changed: stat.ctimeNs };
        }
      }
      const expected = (name: ViewRole, segment: Segment): SegmentPrefix => intent?.role === name && extent ? extent : segment;
      const fd = openSync(input.parent, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
      try {
        const anchor = `/proc/self/fd/${fd}`;
        const verifyDirectory = (): void => {
          if (!sameDirectory(fstatSync(fd, { bigint: true })) || !sameDirectory(lstatSync(input.parent, { bigint: true }))
            || realpathSync(input.parent) !== input.parent) throw refused();
        };
        const verifyNames = (): void => {
          for (const [name, segment] of segments) {
            if (!sameSegment(segment, expected(name, segment), lstatSync(path.join(anchor, segment.name), { bigint: true }))) throw refused();
          }
        };
        verifyDirectory(); verifyNames();
        if (writer && extent) {
          const writerFd = writer.file.fd;
          if (!sameSegment(writer, extent, fstatSync(writerFd, { bigint: true }))) throw refused();
          const chunk = Buffer.alloc(Math.min(65_536, extent.prefix.length));
          for (let offset = 0; offset < extent.prefix.length; offset += chunk.length) {
            const end = Math.min(offset + chunk.length, extent.prefix.length), length = end - offset;
            const read = readSync(writerFd, chunk, 0, length, offset); observeRead?.(read);
            if (read !== length
              || !chunk.subarray(0, length).equals(extent.prefix.subarray(offset, end))) throw refused();
          }
          if (!sameSegment(writer, extent, fstatSync(writerFd, { bigint: true }))) throw refused();
        }
        const segment = segments.get(role)!;
        if (event.offset + event.bytes.length > segment.prefix.length) throw refused();
        const file = openSync(path.join(anchor, segment.name), constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
        try {
          const bytes = Buffer.alloc(event.bytes.length), prefix = expected(role, segment);
          if (!sameSegment(segment, prefix, fstatSync(file, { bigint: true }))) throw refused();
          const read = readSync(file, bytes, 0, bytes.length, event.offset); observeRead?.(read);
          if (read !== bytes.length || !bytes.equals(event.bytes)
            || !sameSegment(segment, prefix, fstatSync(file, { bigint: true }))) throw refused();
          verifyNames(); verifyDirectory();
          // A checked full extent fixes its stamp while the write promise is
          // outstanding. A later read or completion cannot accept new drift.
          if (intent && extent?.prefix === intent.prefix) intent.full = extent;
          return bytes;
        } finally { closeSync(file); }
      } finally { closeSync(fd); }
    };
```

## packages/polaris-dossier/src/url-session-audit.ts:1027–1033
Whole-file SHA256: `f6359eb4d2d694196f7836d88619b04e94ed5ae2bbab3f2c8659c3689fe71f47`.
```typescript
      const checkAttemptCurrent = async (deadline: number): Promise<void> => {
        if (!(Date.now() < attemptDeadline)) throw refused();
        await checkCurrent(deadline);
        const allowed = await wait(track('callback', attemptCurrent), deadline);
        await checkCurrent(deadline);
        if (allowed !== true || !(Date.now() < attemptDeadline)) throw refused();
      };
```

## packages/polaris-dossier/src/policy-snapshot.ts:143–180
Whole-file SHA256: `f14904311c318ef19bd008cfacd6f4d78c248ab79fbe84ce239f8d0901cc80fc`.
```typescript
export function committedUrlPoliciesCurrent(root: string, base: PolicyBinding, origin: PolicyBinding, parent?: UrlParentAdoption): boolean {
  try {
    const probe = currentPolicyProbe(root, base, origin, parent);
    const refsCurrent = (): boolean => parent === undefined || probe.refsCurrent(execFileSync('git', probe.refArgs,
      { ...probe.options, stdio: ['ignore', 'pipe', 'pipe'] }));
    if (!refsCurrent()) return false;
    const read = (commit: string): boolean | string => probe.check(commit, execFileSync('git', probe.args,
      { ...probe.options, input: probe.input(commit), stdio: ['pipe', 'pipe', 'pipe'] }));
    const initial = read(base.commit);
    return (typeof initial === 'string' ? read(initial) === true : initial) && refsCurrent() && probe.workingFilesCurrent();
  } catch { return false; }
}

/** Session and audit callbacks can wait for Git while role resource samples run. */
export async function committedUrlPoliciesCurrentAsync(root: string, base: PolicyBinding, origin: PolicyBinding, parent?: UrlParentAdoption): Promise<boolean> {
  try {
    const probe = currentPolicyProbe(root, base, origin, parent);
    const runGit = (args: readonly string[], input?: string): Promise<Buffer> =>
      new Promise((resolve, reject) => {
        const child = execFile('git', args, { ...probe.options, encoding: 'buffer' }, (error, stdout) => {
          if (error) reject(error);
          else resolve(stdout);
        });
        if (input === undefined) {
          child.stdin?.destroy();
          return;
        }
        if (!child.stdin) throw new Error('current policy input');
        child.stdin.on('error', reject);
        child.stdin.end(input);
      });
    const refsCurrent = async (): Promise<boolean> =>
      parent === undefined || probe.refsCurrent(await runGit(probe.refArgs));
    if (!(await refsCurrent())) return false;
    const read = async (commit: string): Promise<boolean | string> =>
      probe.check(commit, await runGit(probe.args, probe.input(commit)));
    const initial = await read(base.commit);
    return (typeof initial === 'string' ? await read(initial) === true : initial) && await refsCurrent() && probe.workingFilesCurrent();
```

## packages/polaris-dossier/src/policy-snapshot.ts:186–211
Whole-file SHA256: `f14904311c318ef19bd008cfacd6f4d78c248ab79fbe84ce239f8d0901cc80fc`.
```typescript
  const subjects = new Map([[base.path, base.sha256], [origin.path, origin.sha256]]);
  for (const subject of parent?.subjects ?? []) {
    const previous = subjects.get(subject.path);
    if (previous !== undefined && previous !== subject.sha256) throw new Error('conflicting URL parent binding');
    subjects.set(subject.path, subject.sha256);
  }
  const working = [...subjects].map(([file, digest]) => {
    const snapshot = readWorkingPolicy(path.join(root, file));
    if (sha256(snapshot.bytes) !== digest) throw new Error('current policy bytes');
    return snapshot;
  });
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith('GIT_')));
  Object.assign(env, { GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_OPTIONAL_LOCKS: '0', GIT_NO_LAZY_FETCH: '1' });
  const prefix = ['--no-replace-objects', '-C', root];
  const args = [...prefix, 'cat-file', '--batch-command'];
  const refArgs = [...prefix, ...URL_PARENT_REF_ARGS];
  const options = { env, maxBuffer: working.reduce((bytes, file) => bytes + file.bytes.length + 128, 4096), timeout: 10_000 };
  const head = 'info HEAD^{commit}';
  const input = (commit: string): string => [head, ...[...subjects.keys()].map(file => `contents ${commit}:${file}`), head, ''].join('\n');
  const refsCurrent = (output: Buffer): boolean => {
    const refs = parseUrlParentRefs(output);
    return refs !== null && refs.defaultCommit === parent?.defaultCommit && refs.tagObject === parent.tagObject;
  };
  const check = (commit: string, response: Buffer): boolean | string => {
    let offset = 0;
    const header = (type: 'commit' | 'blob') => {
```

## packages/polaris-dossier/src/url-stopped-run.ts:318–350
Whole-file SHA256: `9b117b18fd012a6f667aaa79020d935111e91b0c349529855338c04d7bdd0c85`.
```typescript
      if (previous !== undefined) return withStoppedBoundaryBytes(input.root, input.expected, bytes =>
        previous.bytes.equals(bytes) && matchesSubject(previous.boundary.record, input.expected, asOf) ? true : null) === true;
      const first = withStoppedBoundaryBytes(input.root, input.expected, bytes => {
        const boundary = decodeStoppedBoundary(bytes, input.expected, asOf);
        return boundary?.sha256 === input.sha256 ? { boundary, bytes: Buffer.from(bytes) } : null;
      });
      if (first === null) return false;
      // Retain only deterministic decoding of these exact bounded bytes.
      // Every later callback still reads them afresh and checks live authority.
      retained = { boundary: deepFreeze(first.boundary), bytes: first.bytes };
      return true;
    };
    const heldCurrent = (): boolean => {
      try { return own() && authorityCurrent() && markerCurrent() && boundaryCurrent(); }
      catch { return false; }
    };
    const ownsConsumedBoundary = (): boolean => consumedStat !== undefined && own() && markerCurrent();
    const recheckConsumedBoundary = (): boolean => ownsConsumedBoundary() && boundaryCurrent() && input.current() === true;
    const current = (): boolean => {
      try {
        // Check the live run record at release, after the blocking policy
        // probe and the fresh read of the consumed stop boundary.
        return ownsConsumedBoundary() && input.policy.current() === true && recheckConsumedBoundary();
      } catch { return false; }
    };
    const currentAsync = async (): Promise<boolean> => {
      try {
        if (!ownsConsumedBoundary() || input.current() !== true || await input.policy.currentAsync() !== true) return false;
        // The policy check may suspend. Recheck the lease, marker and exact
        // stopped bytes before admitting the freshly checked run record.
        return recheckConsumedBoundary();
      } catch { return false; }
    };
```

## packages/polaris-dossier/src/url-run-machine.ts:94–117
Whole-file SHA256: `260bc0eb8070b2053857cb8b2bf68de5016f2a05de52d9537832096a762a9827`.
```typescript
  const parentCurrent = (): boolean => input.current() && (input.resume === undefined || input.resume.current() === true);
  const reader = urlMachineReaderProgram(input.runtime);
  if (reader === null || new Set(requiredRoles).size !== requiredRoles.length
    || requiredRoles.some((role, index) => !URL_ROLES.includes(role) || (index > 0 && URL_ROLES.indexOf(role) <= URL_ROLES.indexOf(requiredRoles[index - 1]!)))
    || input.plans.length !== requiredRoles.length
    || input.plans.some((plan, index) => !isPreparedUrlRolePlan(plan) || plan.role !== requiredRoles[index]
      || plan.profile.input.binding.run !== input.runId || plan.profile.input.binding.role !== plan.role)
    || input.parent.subjects.find(subject => subject.path === URL_ORIGIN_POLICY_PATH)?.sha256 !== input.originPolicySha256
    || !parentCurrent() || (input.effectCurrent !== undefined && input.effectCurrent() !== true)
    || !(await input.reverify()) || !parentCurrent()
    || (input.effectCurrent !== undefined && input.effectCurrent() !== true)) throw refuse();
  const canonicalRoot = path.join(input.governanceRoot, 'governance/policies/dossier-machine-clients');
  // Preserve the shared checkout's reviewer access. Namespace exclusion, not
  // tightening the governance directory's ACL, protects it from role clients.
  if (input.resume === undefined) await mkdir(canonicalRoot, { recursive: true, mode: 0o770 });
  if (await realpath(canonicalRoot) !== canonicalRoot || !parentCurrent()) throw refuse();
  const resumed = input.resume;
  if (resumed !== undefined && (!isColdUrlRunMachineHistory(resumed.history)
    || resumed.identitySha256 !== resumed.history.identitySha256 || input.now() < resumed.history.observedAt || !resumed.current())) throw refuse();
  const claimCurrentAsync = resumed?.currentAsync;
  const storeOptions = { governanceRoot: input.governanceRoot, protectedRoot: input.protectedRoot,
    deadline: input.deadline, now: input.now, current: parentCurrent,
    ...(claimCurrentAsync === undefined ? {} : { currentAsync: async () =>
      input.current() && await claimCurrentAsync() === true && input.current() }) };
```

## packages/polaris-dossier/src/url-run-machine.ts:277–282
Whole-file SHA256: `260bc0eb8070b2053857cb8b2bf68de5016f2a05de52d9537832096a762a9827`.
```typescript
            // The peer checks effectCurrent before calling this verifier.
            // Drain the pending census before repeating that authority read.
            current: async () => await selectedLaunch.waitForSample() && current()
              && await input.reverify() === true && current(),
            effectCurrent: current, readImageCurrent: () => !stopped && !closing && effectCurrent(), audit: input.audit,
            chargeNativeCpuMicroseconds: input.chargeNativeCpuMicroseconds });
```

## packages/polaris-dossier/src/url-origin-ledger.ts:487–545
Whole-file SHA256: `e96a2783771ae5c22e9ca7403bb40a161a964d7bf603a53a653ebf65786a2a4c`.
```typescript
  function collectProvenance(receipts: readonly UrlOriginReceipt[]): { readonly graph: UrlOriginProvenance; readonly keys: readonly string[] } {
    const nodes: UrlOriginProvenanceNode[] = [], seen = new Map<string | UrlOriginReceipt, string>();
    const historicalGraphs = new Map<UrlOriginProvenance, Map<string, string>>();
    const append = (metadata: UrlOriginMetadata, parents: readonly string[], derivation: UrlOriginDerivation,
      referenceMode: UrlOriginProvenanceNode['referenceMode']): string => {
      if (nodes.length >= limits.receipts) fail();
      const key = `node-${nodes.length + 1}`; nodes.push({ key, metadata, parents, derivation, referenceMode }); return key;
    };
    const historical = (graph: UrlOriginProvenance, key: string): string => {
      let aliases = historicalGraphs.get(graph);
      if (!aliases) { aliases = new Map(); historicalGraphs.set(graph, aliases); }
      const prior = aliases.get(key); if (prior) return prior;
      const node = graph.nodes.find(value => value.key === key); if (!node) fail();
      const result = append(node.metadata, node.parents.map(parent => historical(graph, parent)), node.derivation, node.referenceMode);
      aliases.set(key, result); return result;
    };
    const visit = (receipt: UrlOriginReceipt): string => {
      // The bounded traversal is private and synchronous. Sample authority
      // at entry and release while still authenticating each receipt.
      const value = lookup(receipt), provenance = lineage.get(receipt);
      if (!provenance) fail();
      const prior = seen.get(receipt); if (prior) return prior;
      const referenceMode = plans.some(plan => plan.id === value.id) ? 'declared' : 'inherited';
      let key: string;
      if (provenance.historical !== undefined) {
        key = historical(provenance.historical.graph, provenance.historical.key);
        const prior = nodes.find(node => node.key === key)!;
        // Preserve original internal references while describing the fresh
        // imported root's current reference encoding. No old plan is registered.
        if (prior.referenceMode !== referenceMode) key = append(prior.metadata, prior.parents, prior.derivation, referenceMode);
      } else key = provenance.derivation === null ? fail()
        : append(metadataOf(value), provenance.parents.map(visit), provenance.derivation, referenceMode);
      seen.set(receipt, key); return key;
    };
    const keys = receipts.map(visit);
    return copy({ graph: { format: 'polaris-url-origin-provenance/2' as const, nodes }, keys });
  }
  function captureProvenance(receipts: readonly UrlOriginReceipt[]): ReturnType<typeof collectProvenance> {
    live();
    const captured = collectProvenance(receipts);
    live();
    return captured;
  }
  function provenanceFingerprint(captured: ReturnType<typeof collectProvenance>): string {
    return fingerprintUrlOriginProvenance(captured, { runId, sourceBindingSha256: sourceBindingSha256(record.subject),
      sourcePin: record.subject.pinnedRevision.commit, basePolicySha256: screen.policySha256, originPolicySha256: origin.sha256 });
  }
  // The same current receipt list supplies allocation metadata and its
  // separately checked lineage, which may retain historical allocation IDs.
  function inspectProvenance(receipts: readonly UrlOriginReceipt[]) {
    live();
    if (!Array.isArray(receipts)) fail();
    const count = receipts.length;
    if (!Number.isSafeInteger(count) || count < 1 || count > limits.parents) fail();
    const selected = Array.from({ length: count }, (_, index) => receipts[index]!);
    const metadata = Object.freeze(selected.map(receipt => metadataOf(lookup(receipt))));
    const semanticSha256 = provenanceFingerprint(collectProvenance(selected));
    live();
    return Object.freeze({ metadata, semanticSha256 });
```

## packages/polaris-dossier/src/url-design-product.ts:248–261
Whole-file SHA256: `2e5b5f3c67b42d5e262827bd4c70e02f272b58548a9d426b7f1da83fb9391e79`.
```typescript
    if (!leaseCurrent()) return null;
    const stable = (): ProductCheck => {
      if (!live() || !isDeepStrictEqual(screen, screening)) return 'retired';
      let currentProducts: ProductReadEvidence;
      try { currentProducts = products.revalidate(); }
      catch (error) { return readTermination(error); }
      const unchanged = isDeepStrictEqual(bindings, { record, declaration, renderer: renderer.identity, products: currentProducts.metadata })
        && sameProducts(checked, currentProducts) && input.products !== undefined && sameProducts(input.products, checked)
        && equalOrderedRenderValue(subject, { run: input.run, runId: input.runId, pinnedRevision: input.pinnedRevision, draftRevision: input.draftRevision,
          input: input.input, files: input.files, packet: input.packet, sourceBodies: input.sourceBodies });
      if (!unchanged) return 'retired';
      const actualParents = ledger.inspectProvenance(parents);
      return isDeepStrictEqual(parentMetadata, actualParents.metadata) && semanticParentsSha256 === actualParents.semanticSha256
        ? checkLease() : 'retired';
```

## packages/polaris-dossier/src/url-machine-store.ts:387–409
Whole-file SHA256: `070d866ee94b361d6e6bd13df25b4b44f4d1bd818b7e55d1f98f9daed7ed996b`.
```typescript
    let validatedState: { sha256: string; value: StoreState } | undefined;
    const archiveKeys = new WeakMap<StoreState, string>();
    const readArchive = async (state: StoreState): Promise<{ bytes: Buffer | null; value: UrlMachineArchive | null }> => {
      const bytes = await readFile(`${base}/canonical-history.json`, URL_MACHINE_ARCHIVE_LIMITS.bytes, true);
      if (state.format === 'url-machine-store-state/1') {
        if (bytes !== null) throw refused();
        return { bytes: null, value: null };
      }
      if (bytes === null || !state.archive || bytes.length !== state.archive.bytes || sha256(bytes) !== state.archive.sha256) throw refused();
      // Cache only semantic decoding, bound to exact physical bytes, pointer and
      // complete lifecycle history. Every read still verifies the actual file.
      let key = archiveKeys.get(state);
      if (key === undefined) {
        key = sha256(canonical({ pointer: state.archive, clients: state.clients.filter(item => item.audit.length > 0)
          .map(item => ({ clientId: item.clientId, audit: item.audit })) }));
        archiveKeys.set(state, key);
      }
      if (validatedArchive?.key === key) return { bytes, value: validatedArchive.value };
      const value = readUrlMachineArchive(bytes, state.archive, rootId, state.clients, live());
      if (value === null) throw refused();
      validatedArchive = { key, value };
      return { bytes, value };
    };
```

## packages/polaris-dossier/src/session-launch.ts:118–139
Whole-file SHA256: `de5c117778f248a296b5cb26d8d46572e5cd4d2342b1a8f0077a2adc8dddf176`.
```typescript
  if (prepared === undefined || inspectionTraces.has(preparation)) return null;
  const trace: InspectionTrace = { cadenceMs: prepared.limits.sampleMilliseconds,
    inspectionMs: prepared.limits.inspectionMilliseconds, samples: 0 };
  inspectionTraces.set(preparation, trace);
  return () => structuredClone(trace);
}

function beginInspectionTrace(trace: InspectionTrace, began: number) {
  const sample: InspectionSample = { ordinal: ++trace.samples, startedMonotonicMs: began, phases: {} };
  trace.latest = sample;
  const causes = new Map<unknown, InspectionRefusal>();
  let storageFailure: { error: unknown; detail: StorageInspectionFailure } | undefined;
  const elapsed = (): number => performance.now() - began;
  const reason = (phase: InspectionPhase, cause: InspectionRefusal['cause']): InspectionRefusal => ({ phase, cause, elapsedMs: elapsed() });
  const settle = (phase: InspectionPhase, outcome: InspectionPhaseOutcome): void => {
    const entry = sample.phases[phase];
    if (sample.refusal === undefined && entry !== undefined && entry.outcome === undefined) Object.assign(entry, { settledMs: elapsed(), outcome });
  };
  const fail = (refusal: InspectionRefusal): void => {
    sample.refusal = refusal;
    trace.firstRefusal ??= sample;
  };
```

