# f571 authority repetition audit

Exact subject: f571c0ac198bd38e7ac39c955c5ab3d5997298a6. This is a
read-only source audit, not a profiling run. Raw source excerpts and complete
inert source copies are bound in binding.json; the retained original stop
boundary is compressed without changing its bytes.

[Observed] The retained result reports exit 1 after 607.171404838562 seconds.
The parent's 16 accepted inference / latest approximately 37-second authority
cost / 624 sample observations are supplied diagnostic findings, not newly
independently timed by this audit. Their per-component time attribution remains
Unknown here.

[Observed] The exact stop boundary imported by this resume contains 60
provenance nodes, 60 distinct keys, 157 parent edges and at most 13 parents per
node. A full import visiting every unique key once would perform 1,830 key
comparisons in the current linear searches. cardinality.json includes the
source path, whole-file digest and a second enumeration method. The original
boundary is 97,763 bytes. Subsequent live graph sizes and the number of actual
provenance-validation invocations were not measured.

[Observed] url-origin-ledger.ts:487–522 has two linear lookup sites:
historical graph.nodes.find for every newly visited historical key, and
nodes.find for the imported root. Its aliases/seen maps already avoid repeated
parent recursion within one invocation. url-design-product.ts:251–261 calls
ledger.inspectProvenance inside stable(), so a fresh product-current check can
repeat the graph collection, frozen copy, graph validation and semantic hash.

[Inferred] Invocation-local first-key-preserving indexes would remove the
quadratic lookup term without caching any authority result: construct the
historical key index once per graph during one collectProvenance invocation;
keep the first occurrence exactly as Array.find does; update a local output
key index at append; preserve root/edge/append order, aliases and live checks.
But the actual 60-node population does not establish a material runtime cost.
The coordinator deferred this candidate. No index implementation or test was
authored, and no speedup or 420-second remedy is claimed.

[Observed] Successful normal audit commit has six base-current callback
invocations: two io brackets and four checkEffectCurrent calls around write,
segment sync and directory sync (url-session-audit.ts:513–522, 816–847).
Ordered commit substitutes checkAttemptCurrent and calls it five times; each
performs two base-current calls plus one attemptCurrent callback (1027–1033).
Together with io, that successful path has twelve base-current calls plus five
attemptCurrent calls. These counts describe this source path, not measured
runtime invocation totals; failure can stop earlier.

[Observed] Each policy-current callback still builds a checked working-file
snapshot, hashes those bounded bytes, probes exact refs before and after, and
reads the committed policy pair/parent subjects through cat-file bracketed by
HEAD identities (policy-snapshot.ts:143–253). An unchanged HEAD normally uses
one batch process plus two ref probes when parent authority is supplied. The
stopped claim independently rechecks held lock/marker/consumed boundary and
effective run authority after asynchronous policy verification
(url-stopped-run.ts:318–350). These are distinct freshness/revocation points.
Caching their Boolean outcomes across awaits or audit steps is not a safe
optimization supported by this evidence.

[Observed] Several tempting semantic caches already exist: store
validatedState and validatedArchive are bound to freshly read exact physical
bytes and complete lifecycle history (url-machine-store.ts:387–409); consumed
stop-boundary decoding is retained only while every callback rereads and
compares its actual bytes (url-stopped-run.ts:318–332); ledger metadata is
already memoized over owned frozen entries. They should not be proposed again
as new optimizations or widened into cached filesystem/currentness results.

[Observed] verifyDurableEvent can reread the complete in-progress writer
extent for every proof record it validates, in addition to the requested row
and fresh directory/name stamps (url-session-audit.ts:950–1005). inspectIdentities
also scans all role prefixes before and after append (600–626, 834–844).
[Inferred] This is a real prefix-size/read-count amplification surface as the
audit grows. Actual read bytes, number of repeated checks during one current
invocation and elapsed fraction were not measured here. Removing these reads
or substituting metadata checks would alter a tamper predicate, so no such
change is recommended on source inspection alone.

The narrow next evidence is bounded per-invocation counters/times at the
existing current/proof boundaries: base policy checks, attempt-current,
physical prefix reads/bytes, immutable graph collection/fingerprint and
sample-wait time, retained as totals/first failure rather than growing spy
histories. The separate causal reviewer owns observer-history/RSS and HTTP
timer diagnosis. No overlapping source edit or report rewrite was made here.

Nearest existing behavioral checks for any later graph-only candidate are the
shared-graph entry/release/semantic equivalence cases in url-origin-ledger.test.ts
and the fresh-ledger historical restore cases in url-run-artifacts.test.ts.
Any proposed change must preserve exact semantic hashes, selected root and
parent order, forged/missing/withdrawn input refusals and callback order/counts.
No new implementation-mirroring case or heavy verification was run or added.
