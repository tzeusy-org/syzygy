# f571 observer-history independent source review
Verdict: PASS
Subject: f571-observer-history-candidate; base f571c0ac198bd38e7ac39c955c5ab3d5997298a6
Manifest SHA-256: 18faacc68ae6a2fd9bca361b8c962f17f470e9bb84cd5e9ba0a3aa50645b77f7

[Observed] Independent source review only. I read the diagnosis as retained evidence and hypotheses, not causal proof. I inspected the candidate, pinned base, whole-file consumers, unchanged helper and installed Tinyspy/Vitest implementation. I ran read-only Git, hashing, text searches and TypeScript AST inspection. No test, build, mutation, native run or heavy operation was performed, and neither checkout nor candidate was changed.

[Inferred] No blocking source finding. The ten changes clear unused observer history while preserving the existing callbacks and authority checks. This SOURCE PASS establishes neither the memory hypothesis nor a runtime improvement.

[Observed] Binding: the verification checkout HEAD and tree match f571c0ac198bd38e7ac39c955c5ab3d5997298a6 / 542ae0775a6f0db84084f767785f7270d59033fe and its Git status is clean. Its source digest matches the manifest. The candidate manifest's four members match their recorded lengths and SHA-256 values. Candidate parsing has no syntax diagnostics.

[Observed] All ten selected implementations preserve their original callback parameters and body bytes against immutable f571, independently of the supplied census:

- snapshotProductFile, snapshotProductNames and assertProductFileUnchanged in the restoration observer;
- sessionMachineEffectCurrent, urlDesignProductLeaseState, isUrlDesignProductLeaseOpen, assertUrlDesignDeliveryViewCurrent, isCheckedUrlDesignProductExpiry and assertUrlDesignDeliveryReceiptCurrent in the Design observer;
- sessionMachineEffectCurrent in the outer base-audit observer.

[Inferred] Each new outer closure invokes the original body immediately and exactly once through withoutObserverHistory. The helper's try/finally returns the original value or promise and rethrows the original exception object. It adds no await, currentness invocation, predicate result substitution, alternate callback or timeout. The original guard wrapping, currentPhase/active/auditTrace ordering, acceptance predicates, metadata recording and bounded diagnostic tails remain intact.

[Observed] Whole-file consumer inspection covered the selected module exports, strings naming spy targets, new handle references, mocked histories and call-count assertions. Each new handle has only its declaration, mockImplementation installation and helper argument references. No selected installation feeds an asserted call counter, argument history or result history. Other exports' explicit counters and histories remain unchanged. AST comparison found all 320 expect-rooted assertion expressions and the existing test-declaration expressions identical.

[Observed] The cold-preparation watch deliberately preserves existing mock implementations/counters and remains unchanged. Its local filePort and leasePort mocks have explicit exactly-once assertions and are separate installations. In the restoration unit case, the later filePort mock replaces the restoration implementation rather than invoking the history-clearing closure. afterEach restores mocks after reverse cleanup. The candidate does not change those contracts, beginOrdered/resumedBegins history, initialSiteDescription history or claim-history consumers.

[Observed] The helper is byte-identical. Installed Tinyspy captures its result index before invoking the implementation and appends the original result afterward. Vitest mockClear resets history, contexts, instances and invocation order while retaining the implementation. Thus synchronous clearance occurs before the spy records this call's final result; it does not await or intercept promise settlement. For sequential invocations with overlapping pending promises, late settlements use the cleared live result slots ratherйымan retaining a slot per completed invocation. Synchronous reentrancy can retain results proportional to its active nesting, rather than an unbounded history across completed top-level calls; no new reentrant call is introduced here.

[Observed] The existing bounded-restoration case already checks synchronous return identity, thrown-object identity, original pending-promise identity, late fulfillment/rejection identity and bounded history after forty overlapping pending promises. Its assertions remain unchanged. Runtime execution of that regression case on the candidate remains required.

[Inferred] The change is scoped and reversible: one test file, ten history-only wrappers, no product source or screening change, and no new test declaration. No authority guard is dropped and no deadline, retry, cache or timeout is widened. Apply only to a successor containing the pinned base and verify integration against the merged bytes.

[Unknown] Actual candidate typecheck, lightweight observer checks, memory attribution, measured speedup, native stop/resume completion and final acceptance. The diagnosis's retained RSS and elapsed-time observations make this an experiment worth isolating; they do not prove the histories caused the timeout. Preserve those unknowns until root executes the bounded observer regression and an appropriately scheduled native run.
