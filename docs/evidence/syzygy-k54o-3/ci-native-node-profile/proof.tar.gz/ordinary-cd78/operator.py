import argparse, ctypes, datetime, hashlib, json, os, pathlib, subprocess, tempfile, time

parser=argparse.ArgumentParser()
parser.add_argument('--subject',required=True)
parser.add_argument('--output',required=True)
args=parser.parse_args()
root=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
out=pathlib.Path(args.output)
git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==args.subject
assert not git('status','--porcelain','--untracked-files=all')
assert not out.exists()
out.mkdir()
scratch=pathlib.Path(tempfile.mkdtemp(prefix='f3rec-',dir='/home/orca/.tmp'))
identity=scratch.stat()
environment=dict(os.environ,TMPDIR=str(scratch))
for name in ['NODE_OPTIONS','VITEST_MAX_THREADS','VITEST_MIN_THREADS','VITEST_MAX_FORKS','VITEST_MIN_FORKS','SYZYGY_COMPOSED_RETAIN','SYZYGY_F3_NATIVE_EVIDENCE_FILE']:
    assert not environment.get(name), 'ordinary recovery requires no '+name
node='/home/orca/.nvm/versions/node/v24.6.0/bin/node'
assert subprocess.check_output([node,'--version'],text=True).strip()=='v24.6.0'
assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
test='packages/polaris-dossier/src/url-run-composed.test.ts'
record={'subject':args.subject,'tree':git('rev-parse','HEAD^{tree}'),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testSHA256':sha(root/test),'TMPDIR':str(scratch),'phases':[],'ordinaryTestDeadlineMs':600000,'hookDeadlineMs':30000}
def run(name,command):
    row={'name':name,'command':command};record['phases'].append(row)
    began=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        child=subprocess.Popen(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        row['pid']=child.pid
        while True:
            try:code=child.wait(timeout=45);break
            except subprocess.TimeoutExpired:print(json.dumps({'phase':name,'seconds':time.monotonic()-began,'logBytes':(out/(name+'.log')).stat().st_size}),flush=True)
    row.update(exitCode=code,seconds=time.monotonic()-began,logSHA256=sha(out/(name+'.log')))
    (out/'progress.json').write_text(json.dumps(record,indent=2)+'\n')
    return code
code=90
try:
    assert run('build',['npm','run','build'])==0
    manifest=root/'packages/polaris-dossier/dist/runtime/manifest.json'
    m=json.loads(manifest.read_text());rows=[]
    for key,base in [('inputs',root),('files',manifest.parent)]:
        for item in m[key]:
            path=base/item['path'];data=path.read_bytes()
            assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],str(path)
            second=subprocess.check_output(['sha256sum','--',str(path)],text=True).split()[0]
            assert second==item['sha256'],str(path)
            rows.append({'population':key,'path':item['path'],'bytes':len(data),'sha256':second})
    record['runtime']={'manifestSHA256':sha(manifest),'inputTreeSHA256':m['inputTreeSha256'],'inputs':len(m['inputs']),'outputs':len(m['files']),'verifiedTwoMethods':len(rows)}
    (out/'runtime-verification.json').write_text(json.dumps(rows,indent=2)+'\n')
    command=[node,'node_modules/vitest/vitest.mjs','run','--project','integration',test,'--testNamePattern=runs the genuine production pipeline to stop-resume$','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')]
    code=run('recovery',command)
    data=json.loads((out/'vitest.json').read_text())
    record['counts']={k:data[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
    record['failures']=[{'name':a['fullName'],'messages':a['failureMessages']} for f in data['testResults'] for a in f['assertionResults'] if a['status']=='failed']
    assert data['numTotalTests']==7 and data['numPendingTests']==6
finally:
    reaped=[];deadline=time.monotonic()+10
    while True:
        try:pid,status=os.waitpid(-1,os.WNOHANG)
        except ChildProcessError:break
        if pid:reaped.append({'pid':pid,'status':status})
        elif time.monotonic()>deadline:raise RuntimeError('owned descendant still live; scratch retained')
        else:time.sleep(.05)
    now=scratch.stat();assert (now.st_uid,now.st_dev,now.st_ino)==(os.getuid(),identity.st_dev,identity.st_ino)
    record.update(exitCode=code,subjectUnchanged=git('rev-parse','HEAD')==args.subject,clean=not git('status','--porcelain','--untracked-files=all'),noOwnedChildren=True,ownedDescendantsReaped=reaped,scratchRemainders=sorted(p.name for p in scratch.iterdir()))
    # Retain this exclusively owned scratch until the actual result is inspected.
    (out/'terminal.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
assert record['subjectUnchanged'] and record['clean']
raise SystemExit(code)
