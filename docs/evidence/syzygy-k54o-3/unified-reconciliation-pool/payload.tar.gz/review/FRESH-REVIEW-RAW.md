# F3 unified reconciliation family pool — fresh source review
Verdict: PASS
Reviewed commit: a7bef3f82605e104830c72c671ba4266d581705d
Manifest SHA-256: b3b7284c5dba7e8dd435377b80c40cf30dcde7a83c6d1a304e856ea05defcb36

[Inferred] PASS for the requested source-only review. No revise-severity source finding. This verdict does not establish runtime parity, a passing live battery, or achievement of the hosted 420-second target.

[Observed] Subject packet: `/home/orca/.tmp/f3-native-admission-fixes/reconciliation-unified-family-pool-a7be-R1`. Original checker SHA-256: `3ad11631d2eaa337bfc82265c8941d98b7de0810234a1437280170801034b8c9`. Candidate checker SHA-256: `d1f0a8e9fa8928e01aba24536a62f1489eb943dd5936247067b92747c81a6f50`.

[Observed] Review used the packet, the predecessor checker blob at the named commit in `/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w`, that checkout's AGENTS.md and applicable craft policies, engineering-bar/test-rigor skill instructions, and the digest-bound retained profile named below. Operations were source reads, hashing, AST inspection, and independent arithmetic. The candidate, checker, fixtures, tests, builds, native tools and providers were not executed. No repository files were changed.

[Observed] Governing criteria include CC-REV-6: “Raw reviewer output is stored unchanged before synthesis”; CC-TEST-2: “The claim needs a gate artifact”; and CC-TEST-5: “Declared scope.” This raw records a source review, with the runtime obligations retained explicitly.

## Integrity and scope

[Observed] Independently hashed the manifest and each of its six file rows; byte lengths and SHA-256 values match. The original-checker digest also matches `git show a7bef3f82605e104830c72c671ba4266d581705d:scripts/check_spec_reconciliation.py`. Reconstructed unified diff equals candidate.patch byte-for-byte.

[Observed] Independent AST comparison confirms exactly two changed function definitions, `_selftest_cases` and `_run_edition`; removal of `_run_tail_edition`; no added functions; and 273 unchanged function definitions. Outside definitions, the only AST change replaces `_TAIL_WORK_ORDER` with `_EDITION_WORK_ORDER`. Predicates, family bodies, fixtures, worker selection, no-fork/one-worker fallback, strict join, profiling implementation and final reporting remain unchanged.

## Task population, bases and isolation

[Observed] Candidate lines 11652–11662 define exactly 31 distinct family tasks. Canonical order equals the predecessor's URL call followed by its 19 historical families followed by its 11 tail families. The fixed dispatch tuple at line 11784 has 31 distinct integers and its sorted population is exactly 0 through 30; both the tuple census and comparison with the canonical source family lists establish the denominator.

[Observed] URL retains `base`; the 19 historical families retain `figure_base`; all 11 tail families retain `base`. The historical copy/removal logic is unchanged and finishes before the pool starts. `_run_edition` selects the original canonical task index, then unpacks that task's own `(family, fixture_base)` pair. `poc_d10_cases` keeps its special single-base argument; every other family receives `(tmp, fixture_base)` before the witness/failure lists.

[Observed] Thirty families own distinct direct children of `tmp`; the POC family creates no tree and reads `base`. The complete concurrent tree population, independently extracted from family assignments and cross-checked against the source paths, is:

- URL: `url-source`.
- Historical: `figure-homes`, `derived-observed`, `ledger-packs-thesis`, `figure-kinds`, `manifest-recognizers`, `spec-repairs`, `computed-maps`, `record-bounds`, `spec-corrections`, `coverage-precheck`, `infrastructure-recognizers`, `index-and-task-routes`, `page-subsections`, `relation-types`, `hero-figure`, `readers-edition`, `cont-edition`, `model-edition`, `worth-edition`.
- Tail: `edit-account-v225`, `declared-source-reach`, `declared-source-readmission`, `dossier-raw-read-disclosure`, `dossier-run-tree-read-bounds`, `verify-text`, `question-file`, `scripted-benchmark-grading`, `covhold-text`, `term-brief`.

[Observed] The 30 names are distinct and none is a directory-prefix ancestor of another. Family writes target the copied trees. Earlier prefix/entry work completes before this pool; later scripted cases start after its join. No pooled family calls `_map_cases`; static traversal of named local call edges also finds no path to it. The pool therefore introduces no nested family pool.

[Inferred] No new dependency on a prior family's parent-process side effects is apparent. URL does not patch parent globals; moving its warmed reverse cache into a worker changes reuse opportunity, while the existing cache key includes patch digest, target path, body digest and application mode. Each read invocation restores its read memos. POC's temporary `_FILES_OVERRIDE`, `_SIGNED_MEMO` and `d10_supersession.amendment` changes restore in `finally`; this existing family already ran in a reusable tail worker. Its `sys.path` insertion is pre-existing. Fork workers inherit the prepared adoption hook and bases; serial/no-fork execution retains the same prepared state. These conclusions require the planned runtime controls and parity check before runtime acceptance.

## Ordering, messages and failure propagation

[Observed] `_run_edition` returns the canonical index, local witnesses, local failures and an empty messages list. Candidate lines 11669–11671 sort by that index, then call the unchanged `_join_case_results` with 31. The join requires exact-int indices equal to `range(count)` before extending output, so duplicates, missing tasks, out-of-range indices and bool/non-integer identities are refused. Invalid result shapes also raise rather than silently succeeding.

[Inferred] For completed successful dispatch, sorting restores the exact predecessor family sequence, and unchanged bodies preserve each family's witness/failure sequence. Families do not directly print canonical messages; their returned messages remain empty. Prefix messages, final witness formatting, final failure formatting and later scripted witnesses are unchanged. Opt-in SELFTEST_PROFILE timing lines are diagnostics whose execution order can change; they are not canonical witness ordering.

[Observed] Worker exceptions are not caught by `_run_edition`; the unchanged `pool.map` or serial list evaluation propagates them. `_EDITION_STATE` is cleared in `finally` even if mapping raises, and the existing outer selftest cleanup restores adoption globals and removes its temporary directory. Family failures remain accumulated and cause the unchanged final failure return. Concurrent exception selection/traceback presentation is not an asserted identity guarantee.

## Performance evidence and remaining verification

[Observed] Retained predecessor profile: `/home/orca/.tmp/f3-native-admission-fixes/hosted-a7bef3f82/reconciliation-profile.json`, independently hashed to `ddc340e6ab2078d156f1dcc1badd15b57788d5a53fdddd8ebd420cd967cb8126`, matching scheduling-model.json. It contains 61 entries, records total 410325.201802 ms, and contains one timing for each of the 31 pooled families. Descending family elapsed time independently reproduces `_EDITION_WORK_ORDER` exactly.

[Inferred] Independent greedy scheduling arithmetic reproduces the model below. Predecessor calculation is serial URL plus the historical pool in its original order plus the tail pool in its original fixed dispatch order. Candidate calculation uses the unified longest-first order. Durations are retained predecessor observations reused as model inputs; they are not measured candidate durations.

| Workers | Predecessor modeled seconds | Candidate modeled seconds | Modeled savings seconds |
| --- | ---: | ---: | ---: |
| 1 | 276.960155488 | 276.960155488 | 0 |
| 2 | 153.406362265 | 140.249548179 | 13.156814086 |
| 4 | 91.631309474 | 71.601109066 | 20.030200408 |
| 8 | 69.081377464 | 37.033872137 | 32.047505327 |

[Unknown] Actual candidate wall time, memory/I/O contention, scheduling overhead, and compliance with the hosted target remain unmeasured by this review. Removing serial URL and the historical/tail barrier plausibly improves utilization, but the model supplies no acceptance guarantee.

[Unknown] Runtime acceptance still requires the planned extracted fake dispatch controls and sole-predicate mutants, full ordered witness/message/failure parity, the canonical live battery in its authorized lane, and retained hosted timing for the exact candidate commit. This source PASS does not discharge those requirements.
