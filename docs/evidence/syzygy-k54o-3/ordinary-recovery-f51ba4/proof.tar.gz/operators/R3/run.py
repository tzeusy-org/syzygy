"""One original uninstrumented ordinary recovery; completion is distinct from PASS."""
import argparse, ctypes, datetime, hashlib, json, os, pathlib, signal, stat, subprocess, tempfile, time
_deadline = None
HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
NODE='/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM='/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
TEST='packages/polaris-dossier/src/url-run-composed.test.ts'
FULL_NAME='composed URL run with actual role processes runs the genuine production pipeline to stop-resume'
BLOCKED=['NODE_OPTIONS','VITEST_MAX_THREADS','VITEST_MIN_THREADS','VITEST_MAX_FORKS','VITEST_MIN_FORKS','SYZYGY_COMPOSED_RETAIN','SYZYGY_F3_NATIVE_EVIDENCE_FILE']
def require(ok, message):
    if not ok: raise RuntimeError(message)

def remaining():
    value = _deadline-time.monotonic() if _deadline is not None else 0
    require(value>0,'operator phase deadline expired')
    return value

def metadata(command,**kwargs):
    return subprocess.check_output(command,timeout=min(remaining(),30),**kwargs)

def read_bytes(path):
    chunks=[]
    with path.open('rb')as stream:
        while True:
            remaining();chunk=stream.read(1_048_576)
            if not chunk:break
            chunks.append(chunk)
    remaining();return b''.join(chunks)

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb')as stream:
        while True:
            remaining();chunk=stream.read(1_048_576)
            if not chunk:break
            digest.update(chunk)
    remaining();return digest.hexdigest()

def independent_hashes(rows):
    for offset in range(0,len(rows),256):
        batch=rows[offset:offset+256]
        output=metadata(['/usr/bin/sha256sum','--zero','--',*[row['path']for row in batch]])
        entries=output.split(b'\0');require(entries[-1]==b''and len(entries)-1==len(batch),'independent hash population mismatch')
        for entry,row in zip(entries[:-1],batch):
            digest,name=entry.split(b'  ',1)
            require(name.decode()==row['path']and digest.decode()==row['sha256'],'independent hash drift: '+row['path'])

def children():
    text = pathlib.Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text()
    return [int(pid) for pid in text.split()]

def drain(record):
    """Reap only our children. Signal a still-owned child only through its pidfd."""
    reaped = record.setdefault('ownedDescendantsReaped', [])
    forced = record.setdefault('forcedOwnedChildren', [])
    record.update(noOwnedChildren=False, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
    began = time.monotonic()
    while True:
        while True:
            try: pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                record.update(noOwnedChildren=True, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
                return
            if not pid: break
            reaped.append({'pid': pid, 'status': status})
        elapsed = time.monotonic() - began
        if elapsed > 20 or (_deadline is not None and time.monotonic()>=_deadline): raise RuntimeError('owned drain deadline expired; private TMP retained')
        if elapsed > 10:
            for pid in children():
                try:
                    fd = os.pidfd_open(pid)
                    try:
                        # A direct owned child cannot recycle its PID before our waitpid.
                        if pid in children():
                            sig = signal.SIGTERM if elapsed < 15 else signal.SIGKILL
                            signal.pidfd_send_signal(fd, sig)
                            forced.append({'pid': pid, 'signal': int(sig)})
                    finally: os.close(fd)
                except ProcessLookupError: pass
        time.sleep(.05)

def stop_leader(child):
    # Only kill the new session while its original leader remains unreaped.
    if child is not None and child.returncode is None:
        try: os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try: child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            child.wait(timeout=5)

def git(*args):
    return metadata(['/usr/bin/git',*args],cwd=ROOT).decode().strip()

def source(config):
    require(git('rev-parse','HEAD')==config['subject'] and git('rev-parse','HEAD^{tree}')==config['tree'],'subject/tree drift')
    require(not git('status','--porcelain','--untracked-files=all'),'ordinary observer requires clean committed source')

def verify(rows):
    unique={}
    for row in rows:
        remaining();previous=unique.setdefault(row['path'],row)
        require((previous['bytes'],previous['sha256'])==(row['bytes'],row['sha256']),'conflicting binding')
    for row in unique.values():
        remaining();path=pathlib.Path(row['path'])
        require(path.stat().st_size==row['bytes']and sha(path)==row['sha256'],'binding drift: '+str(path))
    independent_hashes(list(unique.values()))

def installed_tree(config,*,global_npm=False):
    base=pathlib.Path(config['globalNpmRoot'])if global_npm else ROOT/'node_modules';sample=base.lstat();require(stat.S_ISDIR(sample.st_mode),'installed root is not an ordinary directory')
    rows=[{'path':'.','kind':'directory','mode':stat.S_IMODE(sample.st_mode),'uid':sample.st_uid,'gid':sample.st_gid}];files=[];cache=None;pending=[base]
    while pending:
        directory=pending.pop();remaining()
        with os.scandir(directory)as scan: entries=sorted(scan,key=lambda item:item.name)
        for entry in entries:
            remaining();path=pathlib.Path(entry.path);sample=entry.stat(follow_symlinks=False)
            relative=str(path.relative_to(base));row={'path':relative,'mode':stat.S_IMODE(sample.st_mode),'uid':sample.st_uid,'gid':sample.st_gid}
            if stat.S_ISLNK(sample.st_mode):
                row.update(kind='symlink',target=os.readlink(path),resolved=str(path.resolve(strict=True)))
            elif stat.S_ISDIR(sample.st_mode):row['kind']='directory';pending.append(path)
            elif stat.S_ISREG(sample.st_mode):
                row['kind']='file'
                if not global_npm and relative==config['mutableResultCachePath']:
                    row['mutableResultCache']=True;cache={'path':str(path),'bytes':sample.st_size,'sha256':sha(path),'uid':sample.st_uid,'mode':stat.S_IMODE(sample.st_mode)}
                else:
                    row.update(bytes=sample.st_size,sha256=sha(path));files.append(dict(row,path=str(path)))
            else:raise RuntimeError('unexpected installed special file: '+relative)
            rows.append(row)
    rows.sort(key=lambda row:row['path'])
    require(rows==config['globalNpmTree'if global_npm else 'installedTree'],'complete '+('global npm 'if global_npm else '')+'installed file/directory/symlink population drift')
    require(global_npm or cache is not None,'known result cache missing or changed type')
    independent_hashes(files)
    return cache

def tools(config):
    installed_tree(config,global_npm=True)
    cache=installed_tree(config)
    verify(config['sourceAndTools']+config['nativeToolsAndHeaders']+[config['browser']]+config['workspacePackages'])
    verify([dict(row,path=str(ROOT/row['path']))for row in config['runtimeInputs']])
    return cache

def runtime(config,out,phase):
    manifest=ROOT/config['runtimeManifestPath'];doc=json.loads(read_bytes(manifest));rows=[]
    native=doc['nativeBuild']; nativeRows=[native['compiler'],native['git'],*native['headers']]
    key=lambda row:(row['path'],row['bytes'],row['sha256'])
    require(len({row['path']for row in nativeRows})==len(nativeRows) and sorted(map(key,nativeRows))==sorted(map(key,config['nativeToolsAndHeaders'])),'actual native build tool/header population drift')
    require(doc['node']==config['runtimeNode'],'actual runtime Node identity drift')
    expected={row['path']:row for row in config['runtimeInputs']}
    require(len(expected)==len(config['runtimeInputs']),'duplicate expected runtime input')
    for population,base in [('inputs',ROOT),('files',manifest.parent)]:
        declared=doc[population];paths=[row['path']for row in declared]
        require(len(paths)==len(set(paths)),'duplicate actual runtime path')
        require(set(paths)==(set(expected)if population=='inputs'else set(config['runtimeOutputPaths'])),'runtime population drift')
        for row in declared:
            relative=pathlib.PurePosixPath(row['path'])
            require(not relative.is_absolute()and '..'not in relative.parts,'runtime path escape')
            if population=='inputs':require((row['bytes'],row['sha256'])==(expected[row['path']]['bytes'],expected[row['path']]['sha256']),'runtime source differs from bound commit')
            path=base/row['path']
            rows.append(dict(row,population=population,absolutePath=str(path)))
    verify([dict(row,path=row['absolutePath'])for row in rows])
    value={'manifestSha256':sha(manifest),'manifestBytes':manifest.stat().st_size,'inputTreeSha256':doc['inputTreeSha256'],'inputs':len(doc['inputs']),'outputs':len(doc['files']),'rows':rows,'node':doc['node'],'nativeBuild':doc['nativeBuild']}
    (out/('runtime-'+phase+'.json')).write_text(json.dumps(value,indent=2)+'\n')
    return value

def interrupted(sig,frame):
    raise InterruptedError('operator signal '+str(sig))

def report_result(report,exit_code):
    assertions=[a for result in report['testResults']for a in result['assertionResults']]
    selected=[a for a in assertions if a['status']in['passed','failed']];skipped=[a for a in assertions if a['status']in['pending','skipped']]
    require(len(assertions)==7 and len(selected)==1 and len(skipped)==6 and selected[0]['fullName']==FULL_NAME,'exact1selected6skipped/7 population required')
    require(selected[0]['title']=='runs the genuine production pipeline to stop-resume'and selected[0]['ancestorTitles']==['composed URL run with actual role processes'],'selected case identity drift')
    passed=sum(a['status']=='passed'for a in assertions);failed=sum(a['status']=='failed'for a in assertions)
    require(report['numTotalTests']==len(assertions)and report['numPassedTests']==passed and report['numFailedTests']==failed and report['numPendingTests']==len(skipped),'aggregate/status contradiction')
    require(type(report['success'])is bool,'unknown report success')
    return {'counts':{key:report[key]for key in['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']},'selectedAssertion':selected[0],'populationValid':True,'accepted':exit_code==0 and report['success']and selected[0]['status']=='passed'and passed==1 and failed==0}

def main(args):
    global _deadline
    _deadline=time.monotonic()+900
    out=pathlib.Path(args.output)
    require(out.is_absolute()and out.parent==HERE.parent and not out.exists(),'new owned outside output required')
    out.mkdir();config=None;scratch=None;identity=None;child=None;began=time.monotonic()
    record={'subject':args.subject,'tree':None,'complete':False,'accepted':False,'exitCode':90,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testDeadlineMs':600000,'hookDeadlineMs':30000,'ordinaryConfiguredWorkers':True,'activeBudgetSeconds':900,'phases':[],'cleanupErrors':[],'operatorSha256':None,'bindingsSha256':None}
    for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,interrupted)
    def run(name,command):
        nonlocal child
        row={'name':name,'command':command};record['phases'].append(row);start=time.monotonic()
        with(out/(name+'.log')).open('wb')as log:
            child=subprocess.Popen(command,cwd=ROOT,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=child.pid
            while True:
                left=remaining()
                try:code=child.wait(timeout=min(45,left));break
                except subprocess.TimeoutExpired:print(json.dumps({'phase':name,'seconds':time.monotonic()-start,'logBytes':(out/(name+'.log')).stat().st_size}),flush=True)
        row.update(exitCode=code,seconds=time.monotonic()-start,logSha256=sha(out/(name+'.log')))
        (out/'progress.json').write_text(json.dumps(record,indent=2)+'\n')
        return code
    try:
        config=json.loads(read_bytes(HERE/'bindings.json'))
        require(args.subject==config['subject'],'explicit actual bound subject required')
        record.update(tree=config['tree'],operatorSha256=sha(pathlib.Path(__file__)),bindingsSha256=sha(HERE/'bindings.json'))
        require(record['operatorSha256']==config['operatorSha256'],'operator packet drift')
        environment=dict(os.environ)
        for key in BLOCKED:require(not environment.get(key),'ordinary runner override: '+key)
        require(environment.get('SYZYGY_POC_BROWSER')==config['browser']['path'],'exact bound browser required')
        source(config);record['resultCacheBefore']=tools(config)
        scratch=pathlib.Path(tempfile.mkdtemp(prefix='f3rec-',dir='/home/orca/.tmp'));scratch.chmod(0o700);identity=scratch.stat()
        environment['TMPDIR']=str(scratch);environment['PATH']=str(pathlib.Path(NODE).parent)+':/usr/bin:/bin'
        require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'owned subreaper unavailable')
        require(run('build',[NODE,NPM,'run','build'])==0,'original build failed')
        before=runtime(config,out,'before-test');record['runtimeBefore']={k:v for k,v in before.items()if k not in ['rows','nativeBuild']}
        command=[NODE,'node_modules/vitest/vitest.mjs','run','--project','integration',TEST,'--testNamePattern=runs the genuine production pipeline to stop-resume$','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')]
        record['exitCode']=run('recovery',command)
        report=json.loads(read_bytes(out/'vitest.json'));record.update(report_result(report,record['exitCode']))
        after=runtime(config,out,'after-test');record['runtimeUnchangedDuringCase']=before==after
        require(record['runtimeUnchangedDuringCase'],'runtime changed during case')
    except BaseException as error:
        record['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        _deadline=time.monotonic()+60
        record['cleanupBudgetSeconds']=60
        signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
        def attempt(phase,action):
            try:action()
            except BaseException as error:record['cleanupErrors'].append({'phase':phase,'type':type(error).__name__,'message':str(error)})
        attempt('leader-stop',lambda:stop_leader(child))
        attempt('owned-drain',lambda:drain(record))
        def final_bindings():
            source(config);record['resultCacheAfter']=tools(config);record['sourceToolsUnchanged']=True
        attempt('source-tools-final',final_bindings)
        def final_runtime():
            if record.get('runtimeBefore'):
                value=runtime(config,out,'final')
                require(before==value,'final built runtime drift');record['runtimeFinalUnchanged']=True
        attempt('runtime-final',final_runtime)
        def final_scratch():
            if scratch is not None:
                now=scratch.stat();require((now.st_uid,now.st_dev,now.st_ino)==(os.getuid(),identity.st_dev,identity.st_ino),'owned TMP identity drift')
                record.update(privateTMP=str(scratch),privateTMPTopLevel=sorted(p.name for p in scratch.iterdir()),privateTMPIdentityUnchanged=True)
        attempt('private-TMP-final',final_scratch)
        attempt('owned-drain-final',lambda:drain(record))
        record['cleanupPendingSignals']=[int(sig)for sig in signal.sigpending()if sig in[signal.SIGINT,signal.SIGTERM]]
        def raw_hashes():
            record['rawFiles']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(out.iterdir())if p.is_file()and p.name!='terminal.json']
            record['rawFilesComplete']=True
        attempt('raw-artifact-hashes',raw_hashes)
        record['complete']=bool(record.get('rawFilesComplete')and record.get('populationValid')and not record.get('error')and not record['cleanupErrors']and record.get('noOwnedChildren')and not record.get('forcedOwnedChildren')and record.get('sourceToolsUnchanged')and record.get('runtimeUnchangedDuringCase')and record.get('runtimeFinalUnchanged')and record.get('privateTMPIdentityUnchanged')and not record['cleanupPendingSignals'])
        if not record['complete']:record['accepted']=False
        record['elapsedSeconds']=time.monotonic()-began
        (out/'terminal.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps({'complete':record['complete'],'accepted':record['accepted'],'exitCode':record['exitCode'],'output':str(out),'error':record.get('error'),'cleanupErrors':record['cleanupErrors']}),flush=True)
    return record['exitCode']if record['complete'] else 90

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--subject',required=True);parser.add_argument('--output',required=True)
    raise SystemExit(main(parser.parse_args()))
