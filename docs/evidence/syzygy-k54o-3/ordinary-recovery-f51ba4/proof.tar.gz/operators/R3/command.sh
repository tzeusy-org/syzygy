#!/bin/sh
set -eu
SYZYGY_POC_BROWSER=/home/orca/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome exec /usr/bin/python3 /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-f51ba4-R3/run.py --subject f51ba4da628e2979d33bce310383c97f3dcf3e7e --output /home/orca/.tmp/f3-native-admission-fixes/ordinary-recovery-f51ba4-1
