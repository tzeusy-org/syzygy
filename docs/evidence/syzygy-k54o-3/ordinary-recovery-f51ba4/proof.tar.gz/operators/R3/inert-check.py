"""Exact operator helpers against private inert fixtures; no product/build/test run."""
import ast,hashlib,json,os,pathlib,signal,stat,subprocess,sys,tempfile,time
from pathlib import Path
packet=Path(__file__).resolve().parent;source=(packet/'run.py').read_text();tree=ast.parse(source);results=[]
def passed(name,**details):results.append(dict(control=name,passed=True,**details))
def refuses(name,action):
 try:action()
 except RuntimeError as error:passed(name,error=str(error))
 else:raise AssertionError('mutation admitted: '+name)
call=next(n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and isinstance(n.func.value,ast.Name)and n.func.value.id=='subprocess'and n.func.attr=='Popen')
run=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='run')
assert not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='pthread_sigmask'for n in ast.walk(run))
assert all(k.arg!='preexec_fn'for k in call.keywords)
checks=[n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='check_output']
metadata_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='metadata')
assert len(checks)==1 and checks[0]in list(ast.walk(metadata_node)) and any(k.arg=='timeout'for k in checks[0].keywords)
with tempfile.TemporaryDirectory(prefix='rec-guard-',dir='/home/orca/.tmp')as tmp:
 root=Path(tmp);original=signal.pthread_sigmask(signal.SIG_BLOCK,set())
 try:
  for extra in [set(),{signal.SIGINT}]:
   intended=original|extra;signal.pthread_sigmask(signal.SIG_SETMASK,intended);logPath=root/'child.log'
   with logPath.open('wb')as log:
    scope={'subprocess':subprocess,'command':[sys.executable,'-c','import json,signal;print(json.dumps(sorted(int(x)for x in signal.pthread_sigmask(signal.SIG_BLOCK,set()))))'],'ROOT':root,'environment':dict(os.environ),'log':log}
    child=eval(compile(ast.Expression(body=call),'<exact ordinary Popen expression>','eval'),scope);assert child.wait(timeout=5)==0
   actual=json.loads(logPath.read_text());assert actual==sorted(int(x)for x in intended)
   passed('exact Popen preserves intended entry mask',parentMask=sorted(int(x)for x in intended),childMask=actual)
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,original)
 wanted={'require','remaining','metadata','read_bytes','sha','independent_hashes','verify','installed_tree','runtime','report_result','drain','children'}
 functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in wanted]
 scope=dict(json=json,hashlib=hashlib,pathlib=pathlib,subprocess=subprocess,ROOT=root,os=os,stat=stat,time=time,signal=signal,_deadline=time.monotonic()+60,FULL_NAME='composed URL run with actual role processes runs the genuine production pipeline to stop-resume')
 exec(compile(ast.Module(body=functions,type_ignores=[]),'<exact operator guards>','exec'),scope)
 digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 (root/'source.txt').write_bytes(b'inert source');(root/'dist').mkdir();(root/'dist/output').write_bytes(b'inert output')
 inputs=[{'path':'source.txt','bytes':(root/'source.txt').stat().st_size,'sha256':digest(root/'source.txt')}]
 output={'path':'output','bytes':(root/'dist/output').stat().st_size,'sha256':digest(root/'dist/output')}
 doc={'inputs':inputs,'files':[output],'inputTreeSha256':'0'*64,'node':{},'nativeBuild':{'compiler':{'path':'compiler','bytes':1,'sha256':'a'},'git':{'path':'git','bytes':1,'sha256':'b'},'headers':[]}}
 manifest=root/'dist/manifest.json';manifest.write_text(json.dumps(doc));reports=root/'reports';reports.mkdir()
 config={'runtimeNode':{},'nativeToolsAndHeaders':[doc['nativeBuild']['compiler'],doc['nativeBuild']['git']],'runtimeInputs':inputs,'runtimeOutputPaths':['output'],'runtimeManifestPath':'dist/manifest.json'}
 scope['runtime'](config,reports,'valid');passed('exact runtime rows admitted')
 for name,mutate in [('duplicate runtime input refused',lambda d:d.update(inputs=d['inputs']+d['inputs'])),('missing runtime output refused',lambda d:d.update(files=[])),('stale runtime source hash refused',lambda d:d['inputs'][0].update(sha256='f'*64))]:
  altered=json.loads(json.dumps(doc));mutate(altered);manifest.write_text(json.dumps(altered));refuses(name,lambda:scope['runtime'](config,reports,'mutant'))
 manifest.write_text(json.dumps(doc))
 base=root/'node_modules';cache='.vite/cache/results.json'
 for name,body in [('chai/index.js',b'inert assertion'),('vitest/index.js',b'inert runner'),(cache,b'{"results":[]}')]:
  path=base/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
 (base/'linked').symlink_to('chai')
 population=[]
 for directory,dirs,files in os.walk(base,followlinks=False):
  paths=[Path(directory)]if Path(directory)==base else []
  paths.extend(Path(directory)/name for name in dirs+files)
  for path in paths:
   sample=path.lstat();relative='.'if path==base else str(path.relative_to(base));row=dict(path=relative,mode=stat.S_IMODE(sample.st_mode),uid=sample.st_uid,gid=sample.st_gid)
   if path.is_symlink():row.update(kind='symlink',target=os.readlink(path),resolved=str(path.resolve(strict=True)))
   elif path.is_dir():row['kind']='directory'
   elif relative==cache:row.update(kind='file',mutableResultCache=True)
   else:row.update(kind='file',bytes=sample.st_size,sha256=digest(path))
   population.append(row)
 installed={'installedTree':sorted(population,key=lambda row:row['path']),'mutableResultCachePath':cache}
 before=scope['installed_tree'](installed);passed('complete inert installed population admitted')
 (base/'chai/index.js').write_bytes(b'changed assertion');refuses('previously omitted chai dependency mutation refused',lambda:scope['installed_tree'](installed));(base/'chai/index.js').write_bytes(b'inert assertion')
 (base/'extra.js').write_bytes(b'extra code');refuses('extra installed code refused',lambda:scope['installed_tree'](installed));(base/'extra.js').unlink()
 (base/'linked').unlink();(base/'linked').symlink_to('vitest');refuses('symlink target mutation refused',lambda:scope['installed_tree'](installed));(base/'linked').unlink();(base/'linked').symlink_to('chai')
 (base/cache).write_bytes(b'{"results":[1]}');after=scope['installed_tree'](installed);assert before['sha256']!=after['sha256'];passed('exact known result cache bytes may change and are recorded')
 global_root=root/'global-npm';(global_root/'lib').mkdir(parents=True);(global_root/'lib/cli.js').write_bytes(b'inert required npm implementation')
 global_rows=[]
 for path in [global_root,global_root/'lib',global_root/'lib/cli.js']:
  sample=path.lstat();row={'path':'.'if path==global_root else str(path.relative_to(global_root)),'mode':stat.S_IMODE(sample.st_mode),'uid':sample.st_uid,'gid':sample.st_gid,'kind':'directory'if path.is_dir()else 'file'}
  if path.is_file():row.update(bytes=sample.st_size,sha256=digest(path))
  global_rows.append(row)
 global_config={'globalNpmRoot':str(global_root),'globalNpmTree':sorted(global_rows,key=lambda row:row['path'])}
 scope['installed_tree'](global_config,global_npm=True);passed('complete inert global npm population admitted')
 (global_root/'lib/cli.js').write_bytes(b'changed required npm implementation')
 refuses('previously omitted global npm lib/cli.js mutation refused',lambda:scope['installed_tree'](global_config,global_npm=True))
 full=scope['FULL_NAME'];selected={'fullName':full,'title':'runs the genuine production pipeline to stop-resume','ancestorTitles':['composed URL run with actual role processes'],'status':'passed'}
 report={'testResults':[{'assertionResults':[selected]+[{'status':'pending'}for _ in range(6)]}],'numTotalTests':7,'numPassedTests':1,'numFailedTests':0,'numPendingTests':6,'success':True}
 assert scope['report_result'](report,0)['accepted'];passed('exact selected PASS accepts')
 contradiction=json.loads(json.dumps(report));contradiction['testResults'][0]['assertionResults'][0]['status']='failed'
 refuses('selected FAIL with PASS aggregates refused',lambda:scope['report_result'](contradiction,0))
 contradiction.update(numPassedTests=0,numFailedTests=1,success=False)
 value=scope['report_result'](contradiction,1);assert value['populationValid']and not value['accepted'];passed('honest ordinary FAIL population remains complete eligible without acceptance')
 scope['_deadline']=time.monotonic()+.1;began=time.monotonic()
 try:scope['metadata']([sys.executable,'-c','import time;time.sleep(5)'])
 except subprocess.TimeoutExpired:pass
 else:raise AssertionError('hung metadata command admitted')
 elapsed=time.monotonic()-began;assert elapsed<3;passed('metadata subprocess timeout is finite',elapsedSeconds=elapsed)
 scope['_deadline']=time.monotonic()-1;refuses('expired phase refuses file verification',lambda:scope['verify']([dict(inputs[0],path=str(root/'source.txt'))]))
 scope['_deadline']=time.monotonic()+.1;record={'cleanupErrors':[]};scope['record']=record
 attempt_node=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='attempt')
 exec(compile(ast.Module(body=[attempt_node],type_ignores=[]),'<exact independent cleanup attempt>','exec'),scope)
 scope['attempt']('inert-timeout',lambda:scope['metadata']([sys.executable,'-c','import time;time.sleep(5)']))
 scope['attempt']('later-phase',lambda:record.update(laterPhaseAttempted=True))
 assert record['laterPhaseAttempted']and record['cleanupErrors'][0]['type']=='TimeoutExpired'
 receipt=root/'inert-terminal.json';receipt.write_text(json.dumps(dict(record,complete=False)));assert json.loads(receipt.read_text())['complete']is False
 passed('metadata timeout retained and later cleanup plus incomplete receipt remain reachable')
 scope['_deadline']=time.monotonic()+5;record={'forcedOwnedChildren':[{'pid':0,'signal':15}],'ownedDescendantsReaped':[]}
 scope['drain'](record);assert record['noOwnedChildren']and len(record['forcedOwnedChildren'])==1;passed('final drain preserves earlier forced-child evidence')
 try:os.waitpid(-1,os.WNOHANG)
 except ChildProcessError:passed('all inert children reaped')
 else:raise AssertionError('inert child remains')
result={'subject':'f51ba4da628e2979d33bce310383c97f3dcf3e7e','operatorSha256':hashlib.sha256(source.encode()).hexdigest(),'productExecuted':False,'controls':results,'passed':len(results),'failed':0}
(packet/'inert-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
