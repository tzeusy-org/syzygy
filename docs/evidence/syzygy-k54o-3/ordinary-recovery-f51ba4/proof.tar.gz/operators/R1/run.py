"""One original uninstrumented ordinary recovery; completion is distinct from PASS."""
import argparse, ctypes, datetime, hashlib, json, os, pathlib, signal, subprocess, tempfile, time
HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/home/orca/.tmp/f3-ordinary-store-read.70BHIdrK/w')
NODE='/home/orca/.nvm/versions/node/v24.6.0/bin/node'
NPM='/home/orca/.nvm/versions/node/v24.6.0/lib/node_modules/npm/bin/npm-cli.js'
TEST='packages/polaris-dossier/src/url-run-composed.test.ts'
FULL_NAME='composed URL run with actual role processes runs the genuine production pipeline to stop-resume'
BLOCKED=['NODE_OPTIONS','VITEST_MAX_THREADS','VITEST_MIN_THREADS','VITEST_MAX_FORKS','VITEST_MIN_FORKS','SYZYGY_COMPOSED_RETAIN','SYZYGY_F3_NATIVE_EVIDENCE_FILE']
def require(ok, message):
    if not ok: raise RuntimeError(message)

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''): digest.update(chunk)
    return digest.hexdigest()

def children():
    text = pathlib.Path('/proc/self/task/' + str(os.getpid()) + '/children').read_text()
    return [int(pid) for pid in text.split()]

def drain(record):
    """Reap only our children. Signal a still-owned child only through its pidfd."""
    reaped, forced = [], []
    record.update(noOwnedChildren=False, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
    began = time.monotonic()
    while True:
        while True:
            try: pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                record.update(noOwnedChildren=True, ownedDescendantsReaped=reaped, forcedOwnedChildren=forced)
                return
            if not pid: break
            reaped.append({'pid': pid, 'status': status})
        elapsed = time.monotonic() - began
        if elapsed > 20: raise RuntimeError('owned child drain exceeded 20s; private TMP retained')
        if elapsed > 10:
            for pid in children():
                try:
                    fd = os.pidfd_open(pid)
                    try:
                        # A direct owned child cannot recycle its PID before our waitpid.
                        if pid in children():
                            sig = signal.SIGTERM if elapsed < 15 else signal.SIGKILL
                            signal.pidfd_send_signal(fd, sig)
                            forced.append({'pid': pid, 'signal': int(sig)})
                    finally: os.close(fd)
                except ProcessLookupError: pass
        time.sleep(.05)

def stop_leader(child):
    # Only kill the new session while its original leader remains unreaped.
    if child is not None and child.returncode is None:
        try: os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try: child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            child.wait(timeout=5)

def git(*args):
    return subprocess.check_output(['/usr/bin/git',*args],cwd=ROOT).decode().strip()

def source(config):
    require(git('rev-parse','HEAD')==config['subject'] and git('rev-parse','HEAD^{tree}')==config['tree'],'subject/tree drift')
    require(not git('status','--porcelain','--untracked-files=all'),'ordinary observer requires clean committed source')

def verify(rows):
    for row in rows:
        path=pathlib.Path(row['path'])
        require(path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],'binding drift: '+str(path))
        require(subprocess.check_output(['/usr/bin/sha256sum','--',str(path)]).decode().split()[0]==row['sha256'],'independent hash drift: '+str(path))

def tools(config):
    expected=config['installedToolFiles']
    require(len(expected)==len(set(expected)),'duplicate installed-tool bindings')
    actual={str(p)for name in config['installedToolRoots']for p in(ROOT/'node_modules'/name).rglob('*')if p.is_file()}
    require(sorted(actual)==sorted(expected),'installed-tool population drift')
    verify(config['sourceAndTools']+config['nativeToolsAndHeaders']+[config['browser']])
    verify([dict(row,path=str(ROOT/row['path'])) for row in config['runtimeInputs']])

def runtime(config,out,phase):
    manifest=ROOT/config['runtimeManifestPath'];doc=json.loads(manifest.read_text());rows=[]
    native=doc['nativeBuild']; nativeRows=[native['compiler'],native['git'],*native['headers']]
    key=lambda row:(row['path'],row['bytes'],row['sha256'])
    require(len({row['path']for row in nativeRows})==len(nativeRows) and sorted(map(key,nativeRows))==sorted(map(key,config['nativeToolsAndHeaders'])),'actual native build tool/header population drift')
    require(doc['node']==config['runtimeNode'],'actual runtime Node identity drift')
    expected={row['path']:row for row in config['runtimeInputs']}
    require(len(expected)==len(config['runtimeInputs']),'duplicate expected runtime input')
    for population,base in [('inputs',ROOT),('files',manifest.parent)]:
        declared=doc[population];paths=[row['path']for row in declared]
        require(len(paths)==len(set(paths)),'duplicate actual runtime path')
        require(set(paths)==(set(expected)if population=='inputs'else set(config['runtimeOutputPaths'])),'runtime population drift')
        for row in declared:
            relative=pathlib.PurePosixPath(row['path'])
            require(not relative.is_absolute()and '..'not in relative.parts,'runtime path escape')
            if population=='inputs':require((row['bytes'],row['sha256'])==(expected[row['path']]['bytes'],expected[row['path']]['sha256']),'runtime source differs from bound commit')
            path=base/row['path'];verify([dict(row,path=str(path))])
            rows.append(dict(row,population=population,absolutePath=str(path)))
    value={'manifestSha256':sha(manifest),'manifestBytes':manifest.stat().st_size,'inputTreeSha256':doc['inputTreeSha256'],'inputs':len(doc['inputs']),'outputs':len(doc['files']),'rows':rows,'node':doc['node'],'nativeBuild':doc['nativeBuild']}
    (out/('runtime-'+phase+'.json')).write_text(json.dumps(value,indent=2)+'\n')
    return value

def interrupted(sig,frame):
    raise InterruptedError('operator signal '+str(sig))

def main(args):
    config=json.loads((HERE/'bindings.json').read_text())
    require(args.subject==config['subject'],'explicit actual bound subject required')
    out=pathlib.Path(args.output)
    require(out.is_absolute()and out.parent==HERE.parent and not out.exists(),'new owned outside output required')
    out.mkdir();scratch=None;identity=None;child=None;began=time.monotonic()
    record={'subject':config['subject'],'tree':config['tree'],'complete':False,'accepted':False,'exitCode':90,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testDeadlineMs':600000,'hookDeadlineMs':30000,'ordinaryConfiguredWorkers':True,'operatorWatchdogSeconds':900,'phases':[],'cleanupErrors':[],'operatorSha256':sha(pathlib.Path(__file__)),'bindingsSha256':sha(HERE/'bindings.json')}
    for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,interrupted)
    def run(name,command):
        nonlocal child
        row={'name':name,'command':command};record['phases'].append(row);start=time.monotonic()
        with(out/(name+'.log')).open('wb')as log:
            child=subprocess.Popen(command,cwd=ROOT,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=child.pid
            while True:
                remaining=900-(time.monotonic()-began)
                require(remaining>0,'operator900s watchdog expired')
                try:code=child.wait(timeout=min(45,remaining));break
                except subprocess.TimeoutExpired:print(json.dumps({'phase':name,'seconds':time.monotonic()-start,'logBytes':(out/(name+'.log')).stat().st_size}),flush=True)
        row.update(exitCode=code,seconds=time.monotonic()-start,logSha256=sha(out/(name+'.log')))
        (out/'progress.json').write_text(json.dumps(record,indent=2)+'\n')
        return code
    try:
        require(sha(pathlib.Path(__file__))==config['operatorSha256'],'operator packet drift')
        environment=dict(os.environ)
        for key in BLOCKED:require(not environment.get(key),'ordinary runner override: '+key)
        require(environment.get('SYZYGY_POC_BROWSER')==config['browser']['path'],'exact bound browser required')
        source(config);tools(config)
        scratch=pathlib.Path(tempfile.mkdtemp(prefix='f3rec-',dir='/home/orca/.tmp'));scratch.chmod(0o700);identity=scratch.stat()
        environment['TMPDIR']=str(scratch);environment['PATH']=str(pathlib.Path(NODE).parent)+':/usr/bin:/bin'
        require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'owned subreaper unavailable')
        require(run('build',[NODE,NPM,'run','build'])==0,'original build failed')
        before=runtime(config,out,'before-test');record['runtimeBefore']={k:v for k,v in before.items()if k not in ['rows','nativeBuild']}
        command=[NODE,'node_modules/vitest/vitest.mjs','run','--project','integration',TEST,'--testNamePattern=runs the genuine production pipeline to stop-resume$','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')]
        record['exitCode']=run('recovery',command)
        report=json.loads((out/'vitest.json').read_text());assertions=[a for f in report['testResults']for a in f['assertionResults']]
        selected=[a for a in assertions if a['status']in['passed','failed']];skipped=[a for a in assertions if a['status']in['pending','skipped']]
        require(len(assertions)==7 and len(selected)==1 and len(skipped)==6 and selected[0]['fullName']==FULL_NAME,'exact1selected6skipped/7 population required')
        require(selected[0]['title']=='runs the genuine production pipeline to stop-resume'and selected[0]['ancestorTitles']==['composed URL run with actual role processes'],'selected case identity drift')
        record['counts']={key:report[key]for key in['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
        require(report['numTotalTests']==7 and report['numPendingTests']==6 and report['numPassedTests']+report['numFailedTests']==1,'report counts mismatch')
        record['selectedAssertion']=selected[0];record['populationValid']=True
        after=runtime(config,out,'after-test');record['runtimeUnchangedDuringCase']=before==after
        require(record['runtimeUnchangedDuringCase'],'runtime changed during case')
        record['accepted']=record['exitCode']==0 and report['success']is True and report['numPassedTests']==1 and report['numFailedTests']==0
    except BaseException as error:
        record['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
        def attempt(phase,action):
            try:action()
            except BaseException as error:record['cleanupErrors'].append({'phase':phase,'type':type(error).__name__,'message':str(error)})
        attempt('leader-stop',lambda:stop_leader(child))
        attempt('owned-drain',lambda:drain(record))
        def final_bindings():
            source(config);tools(config);record['sourceToolsUnchanged']=True
        attempt('source-tools-final',final_bindings)
        def final_runtime():
            if record.get('runtimeBefore'):
                value=runtime(config,out,'final')
                require(before==value,'final built runtime drift');record['runtimeFinalUnchanged']=True
        attempt('runtime-final',final_runtime)
        def final_scratch():
            if scratch is not None:
                now=scratch.stat();require((now.st_uid,now.st_dev,now.st_ino)==(os.getuid(),identity.st_dev,identity.st_ino),'owned TMP identity drift')
                record.update(privateTMP=str(scratch),privateTMPTopLevel=sorted(p.name for p in scratch.iterdir()),privateTMPIdentityUnchanged=True)
        attempt('private-TMP-final',final_scratch)
        record['cleanupPendingSignals']=[int(sig)for sig in signal.sigpending()if sig in[signal.SIGINT,signal.SIGTERM]]
        record['complete']=bool(record.get('populationValid')and not record.get('error')and not record['cleanupErrors']and record.get('noOwnedChildren')and not record.get('forcedOwnedChildren')and record.get('sourceToolsUnchanged')and record.get('runtimeUnchangedDuringCase')and record.get('runtimeFinalUnchanged')and record.get('privateTMPIdentityUnchanged')and not record['cleanupPendingSignals'])
        if not record['complete']:record['accepted']=False
        record['elapsedSeconds']=time.monotonic()-began
        record['rawFiles']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(out.iterdir())if p.is_file()and p.name!='terminal.json']
        (out/'terminal.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps({'complete':record['complete'],'accepted':record['accepted'],'exitCode':record['exitCode'],'output':str(out),'error':record.get('error'),'cleanupErrors':record['cleanupErrors']}),flush=True)
    return record['exitCode']if record['complete'] else 90

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--subject',required=True);parser.add_argument('--output',required=True)
    raise SystemExit(main(parser.parse_args()))
