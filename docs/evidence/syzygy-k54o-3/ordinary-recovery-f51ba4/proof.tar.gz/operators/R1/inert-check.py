"""Inert operator guard/child-mask controls only. Never invokes product/build/test."""
import ast,hashlib,json,os,signal,subprocess,sys,tempfile
from pathlib import Path
packet=Path(__file__).resolve().parent;source=(packet/'run.py').read_text();tree=ast.parse(source)
call=next(n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and isinstance(n.func.value,ast.Name)and n.func.value.id=='subprocess'and n.func.attr=='Popen')
run=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='run')
assert not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='pthread_sigmask'for n in ast.walk(run))
assert all(k.arg!='preexec_fn'for k in call.keywords)
results=[]
with tempfile.TemporaryDirectory(prefix='rec-guard-',dir='/home/orca/.tmp')as tmp:
 root=Path(tmp);original=signal.pthread_sigmask(signal.SIG_BLOCK,set())
 try:
  for extra in [set(),{signal.SIGINT}]:
   intended=original|extra;signal.pthread_sigmask(signal.SIG_SETMASK,intended)
   logPath=root/'child.log'
   with logPath.open('wb')as log:
    scope={'subprocess':subprocess,'command':[sys.executable,'-c','import json,signal;print(json.dumps(sorted(int(x)for x in signal.pthread_sigmask(signal.SIG_BLOCK,set()))))'],'ROOT':root,'environment':dict(os.environ),'log':log}
    child=eval(compile(ast.Expression(body=call),'<exact ordinary Popen expression>','eval'),scope)
    assert child.wait(timeout=5)==0
   actual=json.loads(logPath.read_text());assert actual==sorted(int(x)for x in intended)
   results.append({'control':'exact Popen preserves intended entry mask','parentMask':sorted(int(x)for x in intended),'childMask':actual,'passed':True})
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,original)
 # Execute only exact operator verification functions against inert private byte fixtures.
 wanted={'require','sha','verify','runtime'}
 functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in wanted]
 scope={'json':json,'hashlib':hashlib,'pathlib':__import__('pathlib'),'subprocess':subprocess,'ROOT':root}
 exec(compile(ast.Module(body=functions,type_ignores=[]),'<exact operator guards>','exec'),scope)
 digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 (root/'source.txt').write_bytes(b'inert source');(root/'dist').mkdir();(root/'dist/output').write_bytes(b'inert output')
 rows=lambda p:[{'path':p,'bytes':(root/p).stat().st_size,'sha256':digest(root/p)}]
 inputs=rows('source.txt');output={'path':'output','bytes':(root/'dist/output').stat().st_size,'sha256':digest(root/'dist/output')}
 doc={'inputs':inputs,'files':[output],'inputTreeSha256':'0'*64,'node':{},'nativeBuild':{'compiler':{'path':'compiler','bytes':1,'sha256':'a'},'git':{'path':'git','bytes':1,'sha256':'b'},'headers':[]}}
 manifest=root/'dist/manifest.json';manifest.write_text(json.dumps(doc));reports=root/'reports';reports.mkdir()
 config={'runtimeNode':{},'nativeToolsAndHeaders':[doc['nativeBuild']['compiler'],doc['nativeBuild']['git']],'runtimeInputs':inputs,'runtimeOutputPaths':['output'],'runtimeManifestPath':'dist/manifest.json'}
 scope['runtime'](config,reports,'valid');results.append({'control':'exact runtime rows admitted','passed':True})
 def refuses(label,action):
  try:action()
  except RuntimeError:results.append({'control':label,'refused':True})
  else:raise AssertionError(label+' unexpectedly admitted')
 doc['inputs']=inputs+inputs;manifest.write_text(json.dumps(doc));refuses('duplicate actual runtime input',lambda:scope['runtime'](config,reports,'duplicate'))
 doc['inputs']=inputs;doc['files']=[];manifest.write_text(json.dumps(doc));refuses('missing actual runtime output',lambda:scope['runtime'](config,reports,'missing'))
 doc['files']=[output];manifest.write_text(json.dumps(doc));wrong=dict(config,runtimeInputs=[dict(inputs[0],sha256='f'*64)])
 refuses('stale source hash despite matching manifest file bytes',lambda:scope['runtime'](wrong,reports,'stale'))
assert source.index("run('build'")<source.index("runtime(config,out,'before-test')")<source.index("run('recovery'")
print(json.dumps({'scope':'inert operator guards and short Python child only; no product/build/test','operatorSha256':hashlib.sha256(source.encode()).hexdigest(),'results':results,'originalBuildBeforeRuntimeBeforeCase':True,'noMaskAroundPopen':True},indent=2))
