from pathlib import Path
import subprocess,json,hashlib,datetime
p=Path(__file__).parent;w=Path('/home/orca/orca/projects/syzygy/.worktrees/parallel-agents/syzygy-bpyt.59');rels=['packages/three-surface-poc-core/src/'+n for n in ['act-fields.ts','body-read-authority.test.ts','walkthrough-judgment.test.ts']];f=w/rels[0];before=f.read_bytes();old='Number.isFinite(instant) && new Date(instant).toISOString().slice(0, 10) === value';new='Number.isFinite(instant)';assert before.decode().count(old)==1
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();sources=[]
for rel in rels:
 data=(w/rel).read_bytes();blob=subprocess.check_output(['git','show',head+':'+rel],cwd=w);assert data==blob;sources.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'committedBytesEqual':True})
r={'subject':head,'sourceModuleAndTests':sources,'old':old,'new':new,'uniqueOccurrences':1,'reasonForAdditionalFocusedSequence':'First full focused M0 ran before code commit. This sequence binds clean committed product-source bytes before M0, mutant and restoration; it is targeted calendar behavior only, not a repeated broad suite.','commands':[]}
def run(name):
 args=['python3',str(p/'capture.py'),name,str(w),'npx','--no-install','vitest','run','--project','unit',rels[1],rels[2],'-t','calendar read-back','--reporter=json','--outputFile='+str(p/(name+'-vitest.json'))];r['commands'].append(args);return subprocess.call(args)
assert run('committed-M0')==0
try:
 f.write_text(before.decode().replace(old,new));r['mutantSourceSha256']=hashlib.sha256(f.read_bytes()).hexdigest();assert run('committed-equality-mutant')==1
finally:
 f.write_bytes(before);assert f.read_bytes()==before;r['restoredSourceSha256']=hashlib.sha256(f.read_bytes()).hexdigest()
assert run('committed-restored')==0
x=json.loads((p/'committed-equality-mutant-vitest.json').read_text());failures=[]
import re
for suite in x['testResults']:
 for test in suite['assertionResults']:
  if test['status']=='failed':
   for message in test['failureMessages']:
    match=re.match(r'AssertionError: ((consent|policy|registry|judgment)/(Date:|Expires:)/(2026-\d\d-\d\d)):',message);assert match;failures.append({'id':match[1],'message':message.split('\n')[0]})
ids=sorted(set(x['id'] for x in failures));expected=sorted(f'{g}/{field}/{date}' for g in ['consent','policy','registry','judgment'] for field in ['Date:','Expires:'] for date in ['2026-02-29','2026-02-30','2026-02-31','2026-04-31']);assert ids==expected and len(failures)==296
r.update({'M0':{'selectedPass':2,'unselected':467},'mutant':{'selectedFailed':2,'unselected':467,'failureAssertionCount':len(failures),'rows':ids,'allIntendedSemanticFailures':True,'validAndExistingRefusalFailures':[]},'restoration':{'selectedPass':2,'unselected':467},'failures':failures})
(p/'COMMITTED-PREDICATE-SEQUENCE.json').write_text(json.dumps(r,indent=2)+'\n');print({'subject':head,'M0':2,'mutantFailures':len(failures),'affectedRows':len(ids),'restoration':2})
