from pathlib import Path
import json,hashlib,collections
p=Path(__file__).parent
rolled=['2026-02-29','2026-02-30','2026-02-31','2026-04-31'];existing=['2026-02-32','2026-13-01','2026-00-10'];valid=['2026-02-28','2028-02-29','2026-04-30','2026-03-01']
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def mapping(rows):
 seen=collections.Counter();result={}
 for r in rows:
  if 'id' in r:key=r['id']
  else:
   stem=r['historyTitle']+'/'+digest(r['input']);seen[stem]+=1;key=stem+'/'+str(seen[stem])
  assert key not in result,key;result[key]=r
 return result
def leaves(a,b,path='$'):
 if type(a)!=type(b):return [{'path':path,'base':a,'candidate':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append({'path':path+'.'+k,'base':a.get(k,{'$missing':True}),'candidate':b.get(k,{'$missing':True})})
   else:out+=leaves(a[k],b[k],path+'.'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'base':a,'candidate':b}]
  return [r for i,(x,y) in enumerate(zip(a,b)) for r in leaves(x,y,path+f'[{i}]')]
 return [] if a==b else [{'path':path,'base':a,'candidate':b}]
def date_identity(row,stem):
 import re
 if stem=='body-read-authority':contexts=['consent','policy','registry'];records={k:row['input'][k]['actRecord']['text'] for k in contexts}
 else:contexts=['judgment'];records={'judgment':row['input']['judgment']['actRecord']['text']}
 for k,s in records.items():
  m=re.search(r'^Expires: (\S+)',s,re.M)
  if m:return k+'/Expires:/'+m[1]
 for k,s in records.items():
  d=re.search(r'^Date: (\S+)',s,re.M)[1]
  if d!='2026-01-01':return k+'/Date:/'+d
 return None
summary={'subjects':{k:json.loads((p/('SUBJECT-'+k+'.json')).read_text())['head'] for k in ['base','candidate']},'suites':[],'allowedDeltas':[],'unexpected':[],'dateRows':[],'historyRows':[],'originalRows':[],'proseRows':[],'baselineRows':[]}
for stem in ['body-read-authority','walkthrough-judgment']:
 a=mapping(json.loads((p/'diff-base'/(stem+'.json')).read_text()));b=mapping(json.loads((p/'diff-candidate'/(stem+'.json')).read_text()));assert set(a)==set(b),(set(a)-set(b),set(b)-set(a))
 counts=collections.Counter()
 for key,old in a.items():
  new=b[key];isdate='calendar read-back' in old.get('title','');prose='independently labelled valid prose' in old.get('title','');differences=leaves(old,new)
  if isdate:
   identity=date_identity(old,stem)
   if identity is None:
    assert not differences;summary['baselineRows'].append({'id':key,'suite':stem,'equal':True});counts['dateFamilyBaselines']+=1;continue
   d=identity.rsplit('/',1)[1];expectedChanged=d in rolled
   assert bool(differences)==expectedChanged,(identity,differences)
   target=identity.split('/')[0];field=identity.split('/')[1];case='act-instant-malformed' if field=='Date:' else 'expired'
   if target=='judgment':
    baselineOutcome=old['result']['outcome'];candidateOutcome=new['result']['outcome'];assert candidateOutcome['kind']==('lawful' if d in valid else 'unlawful')
    if d not in valid:assert candidateOutcome['caseId']==case and candidateOutcome['criterion']=='unknown-never-met'
    if expectedChanged:assert baselineOutcome['kind']=='lawful'
   else:
    assert new['result']['admits']==(d in valid);assert new['reads']==(1 if d in valid else 0)
    if d not in valid:assert new['result'][target]['caseId']==target+':'+case
    if expectedChanged:assert old['result']['admits'] and old['reads']==1
   category='newly-refused' if expectedChanged else 'valid-unchanged' if d in valid else 'already-refused-unchanged';counts[category]+=1
   row={'id':identity,'captureId':key,'category':category,'inputSha256':old['inputSha256'],'baseResultSha256':digest(old),'candidateResultSha256':digest(new),'changedPaths':len(differences)};summary['dateRows'].append(row)
   if expectedChanged:summary['allowedDeltas'].append({**row,'deltas':differences})
  else:
   assert not differences,(stem,key,differences)
   group='historyRows' if 'historyTitle'in old else 'proseRows' if prose else 'originalRows';summary[group].append({'id':key,'suite':stem,'equal':True,'sha256':digest(old)});counts[group]+=1
 summary['suites'].append({'suite':stem,'capturedRows':len(a),'baseOnly':[],'candidateOnly':[],'duplicateIds':[],'counts':dict(counts)})
assert len(summary['dateRows'])==88
expected={f'{g}/{f}/{d}' for g in ['consent','policy','registry','judgment'] for f in ['Date:','Expires:'] for d in rolled+existing+valid};assert {x['id'] for x in summary['dateRows']}==expected
assert collections.Counter(r['category'] for r in summary['dateRows'])=={'newly-refused':32,'already-refused-unchanged':24,'valid-unchanged':32}
summary['totals']={k:len(summary[k]) for k in ['originalRows','historyRows','proseRows','baselineRows','dateRows','allowedDeltas','unexpected']};summary['totals']['capturedRows']=sum(x['capturedRows'] for x in summary['suites'])
summary['comparison']='Full serialized input, correlation request/outcome, deterministic evaluation, observer/read count/disclosure and frozen-path census by semantic title + full input SHA-256 + explicit duplicate occurrence; full history/throws. No blanket byte-preservation claim for authorized date outputs.'
(p/'DIFFERENTIAL-REPORT.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary['totals']);print(summary['suites'])
