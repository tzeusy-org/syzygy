from pathlib import Path
import re,json,hashlib,sys,subprocess
p=Path(__file__).parent;target=p/'subject';w=Path('/home/orca/orca/projects/syzygy/.worktrees/parallel-agents/syzygy-bpyt.59');label=sys.argv[1];assert label in ['base','candidate','repeat']
run=p/('diff-'+label);run.mkdir(exist_ok=False);rows=[]
for stem,evaluator,appender in [('body-read-authority','evaluateBodyReadAuthority','appendEvaluation'),('walkthrough-judgment','evaluateWalkthroughJudgment','appendJudgmentEvaluation')]:
 rel='packages/three-surface-poc-core/src/'+stem+'.test.ts';base=(p/('baseline-'+stem+'.test.ts')).read_text();candidate=(w/rel).read_text();assert candidate.startswith(base);extra=candidate[len(base):];assert extra.count("  it('")==1
 original_sha=hashlib.sha256(base.encode()).hexdigest();full=base+extra
 if label=='base':
  for d in ['2026-02-29','2026-02-30','2026-02-31','2026-04-31']:
   assert full.count("['"+d+"', false]")==1;full=full.replace("['"+d+"', false]","['"+d+"', true]")
 # Calls alone are wrapped; fixture functions and original assertion bodies remain verbatim.
 original_calls=len(re.findall(r'\b'+evaluator+r'\(',full));full=re.sub(r'\b'+evaluator+r'\(',r'captureEvaluation(',full)
 append_calls=len(re.findall(r'\b'+appender+r'\(',full));full=re.sub(r'\b'+appender+r'\(',r'captureHistory(',full)
 vitest=str(target/'node_modules/vitest/dist/index.js');full=full.replace("from 'vitest'",'from '+repr(vitest))
 def path_import(m):
  name=m.group(1);leaf=name.rsplit('/',1)[-1];is_support=leaf=='test-frozen.js';path=target/('packages/three-surface-poc-core/src' if is_support else 'packages/three-surface-poc-core/dist')/leaf
  if is_support:path=path.with_suffix('.ts')
  return 'from '+repr(str(path))
 full=re.sub(r"from '(\./[^']+)'",path_import,full)
 full=full.replace("new URL('./walkthrough-judgment.ts', import.meta.url)",'new URL('+repr('file://'+str(target/'packages/three-surface-poc-core/src/walkthrough-judgment.ts'))+')')
 body=stem=='body-read-authority';observer="const reads = { count: 0 }; const observed = observeProjectShape({authority: result, read: () => { reads.count++; return 'read'; }}); const extras = {observed, reads: reads.count, disclosure: discloseAuthority(result)};" if body else 'const extras = {};'
 capture=r'''
import { afterAll as captureAfterAll } from VITEST;
import { writeFileSync as captureWrite } from 'node:fs';
const captureRows: unknown[] = [];
const captureSeen = new Map<string, number>();
function spell(value: any): any {
  if (value === undefined) return { $undefined: true };
  if (typeof value === 'function') return { $function: 'correlator response captured separately' };
  if (value instanceof Uint8Array) return { $bytes: Array.from(value) };
  if (Array.isArray(value)) return value.map(spell);
  if (typeof value === 'object' && value !== null) return Object.fromEntries(Object.keys(value).sort().map(k => [k, spell(value[k])]));
  return value;
}
function frozenPaths(value: any, path = '$'): any {
  if (typeof value !== 'object' || value === null) return [];
  return [[path, Object.isFrozen(value)], ...Object.entries(value).flatMap(([k,v]) => frozenPaths(v, path+'.'+k))];
}
function captureEvaluation(input: Parameters<typeof EVALUATOR>[0]): ReturnType<typeof EVALUATOR> {
  const title = expect.getState().currentTestName ?? 'collect';
  const serializedInput = spell(input);
  const inputSha256 = sha256(JSON.stringify(serializedInput));
  const key = title + '/' + inputSha256;
  const occurrence = (captureSeen.get(key) ?? 0) + 1; captureSeen.set(key, occurrence);
  const correlations: any[] = [];
  const original = input.correlate;
  const result = EVALUATOR({...input, correlate: (request: any) => { const response = original(request); correlations.push({request, response}); return response; }});
  OBSERVER
  captureRows.push({id: key+'/'+occurrence, title, inputSha256, occurrence, input: serializedInput, correlations: spell(correlations), result: spell(result), ...spell(extras), frozen: frozenPaths(result)});
  return result;
}
function captureHistory(...args: Parameters<typeof APPENDER>): ReturnType<typeof APPENDER> {
  const title = expect.getState().currentTestName ?? 'collect';
  try { const result = APPENDER(...args); captureRows.push({historyTitle:title, input:spell(args), result:spell(result), frozen:frozenPaths(result)}); return result; }
  catch(error) { captureRows.push({historyTitle:title, input:spell(args), error: String(error)}); throw error; }
}
captureAfterAll(() => captureWrite(OUTPUT, JSON.stringify(captureRows, null, 2)+'\n'));
'''.replace('VITEST',repr(vitest)).replace('EVALUATOR',evaluator).replace('APPENDER',appender).replace('OBSERVER',observer).replace('OUTPUT',repr(str(run/(stem+'.json'))))
 prose="\n\nit('GP-Q0 independently labelled valid prose alteration', () => {\n"
 if body:
  prose+="  for (const kind of ['consent', 'policy', 'registry'] as const) {\n    expect(captureEvaluation(inputs({[kind]: {record: {effect: AUTHORITIES[kind].effect + '\\nAn explanatory sentence preserves exactly this scope.'}}})).admits).toBe(true);\n  }\n"
 else:prose+="  expect(captureEvaluation(inputs({record: {effect: ACT.effect + '\\nAn explanatory sentence preserves exactly this scope.'}})).outcome.kind).toBe('lawful');\n"
 prose+="});\n"
 generated=run/(stem+'.test.ts');generated.write_text(capture+full+prose)
 rows.append({'sourcePath':rel,'baseSourceSha256':original_sha,'candidateSourceSha256':hashlib.sha256(candidate.encode()).hexdigest(),'verbatimOriginalBytes':len(base.encode()),'originalPrefixEqual':True,'suffixBytes':len(extra.encode()),'captureEvaluatorCallSites':original_calls,'captureHistoryCallSites':append_calls,'generatedSha256':hashlib.sha256(generated.read_bytes()).hexdigest(),'generatedPath':str(generated),'sourceImportMode':'own built evaluator modules, source-only frozen test helper; source condition for workspace package references','baseExpectationAdjustment':'only four engine-rolled dates expected valid' if label=='base' else 'none'})
config="import { defineConfig } from "+repr(str(target/'node_modules/vitest/dist/config.js'))+";\nexport default defineConfig({root:"+repr(str(target))+",ssr:{resolve:{conditions:['source','module','node','development|production']}},test:{include:["+repr(str(run/'*.test.ts'))+"],maxWorkers:'50%',setupFiles:["+repr(str(target/'vitest.setup.ts'))+","+repr(str(target/'vitest.unit-guard.setup.ts'))+"]}});\n"
(run/'vitest.config.mts').write_text(config)
(run/'FIXTURE-PROVENANCE.json').write_text(json.dumps({'label':label,'subject':subprocess.check_output(['git','rev-parse','HEAD'],cwd=target,text=True).strip(),'rows':rows,'duplicatePolicy':'Preserve every evaluation call: semantic test title plus full serialized input SHA-256, then occurrence suffix for repeated identical calls. History calls retain title, full input and result/throw. No input deduplication.','tagCorrelationAssumptions':'Synthetic resolved recording tag and injected correlator outcomes exactly from canonical factories. Altered prose is a parser differential, not hosted/live provenance verification.'},indent=2)+'\n')
print(run)
