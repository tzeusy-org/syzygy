import sys,json,subprocess,pathlib,datetime,os
own=pathlib.Path(__file__).resolve().parent
assert (own/"ROOT-RELEASE.json").is_file()
with (own/"DRIVER.json").open("x") as f:json.dump({"pid":os.getpid(),"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"lock":"/home/orca/.tmp/syzygy-full-suite-20261104.lock"},f)
print("DRIVER READY",flush=True)
for line in sys.stdin:
 task=json.loads(line)
 if task.get("action")=="finish":break
 argv=[sys.executable,str(own/"capture.py"),task["name"],task["cwd"],*task["argv"]]
 result=subprocess.run(argv)
 print(json.dumps({"driverTask":task["name"],"exitCode":result.returncode}),flush=True)
print("DRIVER FINISHED",flush=True)
