from pathlib import Path
import subprocess,json,hashlib,datetime
p=Path(__file__).parent;w=Path('/home/orca/orca/projects/syzygy/.worktrees/parallel-agents/syzygy-bpyt.59');f=w/'packages/three-surface-poc-core/src/act-fields.ts'
old='Number.isFinite(instant) && new Date(instant).toISOString().slice(0, 10) === value';new='Number.isFinite(instant)';before=f.read_bytes();text=before.decode();assert text.count(old)==1
r={'subject':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'old':old,'new':new,'uniqueOccurrences':1,'beforeSha256':hashlib.sha256(before).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'M0':'logs/focused-candidate.json','predicate':'UTC date read-back equality only; finite and spelling guards unchanged'}
try:
 f.write_text(text.replace(old,new));r['mutantSha256']=hashlib.sha256(f.read_bytes()).hexdigest()
 command=['python3',str(p/'capture.py'),'predicate-mutant',str(w),'npx','--no-install','vitest','run','--project','unit','packages/three-surface-poc-core/src/body-read-authority.test.ts','packages/three-surface-poc-core/src/walkthrough-judgment.test.ts','-t','calendar read-back','--reporter=json','--outputFile='+str(p/'mutant-vitest.json')]
 r['command']=command;r['exitCode']=subprocess.call(command)
finally:
 f.write_bytes(before);r['restoredSha256']=hashlib.sha256(f.read_bytes()).hexdigest();assert f.read_bytes()==before
 (p/'MUTANT-RECORD.json').write_text(json.dumps(r,indent=2)+'\n')
assert r['exitCode']==1
