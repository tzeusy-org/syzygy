from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).parent;w=p/'subject';label=sys.argv[1];rows=[]
for pattern in ['packages/three-surface-poc-core/src/**/*','packages/three-surface-poc-core/dist/**/*','packages/support/src/**/*','packages/support/dist/**/*']:
 for f in w.glob(pattern):
  if f.is_file():rows.append({'path':str(f.relative_to(w)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=w,text=True),'rows':rows,'tools':{}}
for name,path in [('lock','package-lock.json'),('typescript','node_modules/typescript/package.json'),('vitest','node_modules/vitest/package.json'),('esbuild','node_modules/esbuild/package.json')]:
 f=w/path;r['tools'][name]={'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'version':json.loads(f.read_text()).get('version')}
for name,cmd in [('node',['node','--version']),('npm',['npm','--version']),('git',['git','--version']),('python',['python3','--version'])]:r['tools'][name]=subprocess.check_output(cmd,text=True).strip()
(p/('SUBJECT-'+label+'.json')).write_text(json.dumps(r,indent=2)+'\n');print({'label':label,'head':r['head'],'files':len(rows),'status':r['status']})
