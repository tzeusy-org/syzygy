from pathlib import Path
import json,re,hashlib,collections
p=Path(__file__).parent;reports={}
for stem in ['body-read-authority','walkthrough-judgment']:
 rows=json.loads((p/'diff-candidate'/(stem+'.json')).read_text());native=json.loads((p/'diff-candidate/vitest.json').read_text());suite=next(r for r in native['testResults'] if r['name'].endswith(stem+'.test.ts'));original=[r for r in rows if 'id'in r and 'calendar read-back' not in r['title'] and 'independently labelled valid prose' not in r['title']];titles=collections.Counter(r['title'] for r in original)
 groups={}
 if stem=='body-read-authority':
  groups['closedInvalid']=[r['id'] for r in original if 'invalid cases (195)' in r['title']];assert len(groups['closedInvalid'])==195
  groups['validStateTriples']=[r['id'] for r in original if 'valid triple state-' in r['title']];assert len(groups['validStateTriples'])==8
  groups['nonHumanOwners']=[r['id'] for r in original if 'owner-non-human: one rule' in r['title'] and 'a human name' not in r['title']];assert len(groups['nonHumanOwners'])==96
  groups['humanOwners']=[r['id'] for r in original if 'a human name' in r['title']];assert len(groups['humanOwners'])==8
  groups['supersession']=[r['id'] for r in original if 'expected supersession target' in r['title']];assert len(groups['supersession'])==7
 else:
  groups['closedPresentInvalid']=[r['id'] for r in original if 'each present-invalid case records' in r['title'] and 'valid pair used as the mutation baseline' not in r['title']];assert len(groups['closedPresentInvalid'])==84
  groups['absentInstances']=[r['id'] for r in original if 'either absent case renders' in r['title'] and 'absence of the run record is reported' not in r['title']];assert len(groups['absentInstances'])==5
  groups['combinedAbsence']=[r['id'] for r in original if 'absence of the run record is reported' in r['title']];assert len(groups['combinedAbsence'])==1
  groups['nonHumanOwners']=[r['id'] for r in original if 'owner-non-human: one rule' in r['title'] and 'a human name' not in r['title']];assert len(groups['nonHumanOwners'])==31
  groups['humanOwners']=[r['id'] for r in original if 'a human name' in r['title']];assert len(groups['humanOwners'])==8
 grouped={i for v in groups.values() for i in v};groups['remainingScenarioCalls']=[r['id'] for r in original if r['id'] not in grouped]
 reports[stem]={'originalEvaluationCalls':len(original),'historyCalls':sum('historyTitle'in r for r in rows),'groups':{k:{'count':len(v),'ids':v} for k,v in groups.items()},'executedTests':len(suite['assertionResults']),'failedTests':[a['fullName'] for a in suite['assertionResults'] if a['status']!='passed'],'remainingScenarioTitles':{k:v for k,v in titles.items() if any(r['title']==k and r['id'] in groups['remainingScenarioCalls'] for r in original)}}
assert sum(x['originalEvaluationCalls'] for x in reports.values())==468
(p/'FULL-CORPUS-COVERAGE.json').write_text(json.dumps(reports,indent=2)+'\n');print({k:{'originalEvaluationCalls':v['originalEvaluationCalls'],'historyCalls':v['historyCalls'],'groups':{g:x['count'] for g,x in v['groups'].items()},'executedTests':v['executedTests'],'failedTests':v['failedTests']} for k,v in reports.items()})
