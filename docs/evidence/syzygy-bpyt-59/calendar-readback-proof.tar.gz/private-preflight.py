from pathlib import Path
import os,socket,json,hashlib,subprocess
p=Path(__file__).parent
assert os.environ['HOME']==str(p/'home')
assert os.environ['TMPDIR']=='/tmp'
assert not Path('/home/orca/orca/projects/syzygy/README.md').exists()
assert not Path('/home/orca/.ssh').exists()
assert not Path('/home/tze').exists()
assert not Path('/home/orca/.config').exists()
assert Path('/etc/resolv.conf').read_text()==(p/'etc-resolv.conf').read_text()
try:
 socket.create_connection(('1.1.1.1',443),timeout=1)
except OSError as error:network={'reachable':False,'exception':type(error).__name__,'errno':error.errno}
else:raise AssertionError('network escaped')
r={'home':os.environ['HOME'],'tmpdir':os.environ['TMPDIR'],'cwd':str(Path.cwd()),'sharedRootReadmeVisible':False,'credentialHomeVisible':False,'otherUserHomeVisible':False,'network':network,'lockfileSha256':hashlib.sha256((Path.cwd()/'package-lock.json').read_bytes()).hexdigest(),'syntheticOnly':True,'providerCalls':0,'observedRepositoryBodyReads':0,'installs':'exact105public lockfile cache/SRI + own offline npm ci completed before NodeNext'}
(p/'PRIVATE-PREFLIGHT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
