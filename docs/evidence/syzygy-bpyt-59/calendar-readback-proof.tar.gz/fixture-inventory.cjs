const fs=require('node:fs'),crypto=require('node:crypto');
const p=__dirname,ts=require(p+'/subject/node_modules/typescript');
const out=[];
for(const stem of ['body-read-authority','walkthrough-judgment']){
 const text=fs.readFileSync(p+'/baseline-'+stem+'.test.ts','utf8');const source=ts.createSourceFile(stem+'.test.ts',text,ts.ScriptTarget.Latest,true);const calls=[],arrays=[],each=[];
 const visit=n=>{if(ts.isCallExpression(n)&&n.expression.getText(source)==='inputs')calls.push({line:source.getLineAndCharacterOfPosition(n.getStart(source)).line+1,expression:n.getText(source)});
 if(ts.isVariableDeclaration(n)&&n.initializer){let init=n.initializer;while(ts.isAsExpression(init)||ts.isParenthesizedExpression(init))init=init.expression;if(ts.isArrayLiteralExpression(init))arrays.push({name:n.name.getText(source),rows:init.elements.length,line:source.getLineAndCharacterOfPosition(n.getStart(source)).line+1,sha256:crypto.createHash('sha256').update(init.getText(source)).digest('hex')});}
 if(ts.isCallExpression(n)&&ts.isPropertyAccessExpression(n.expression)&&n.expression.name.getText(source)==='each')each.push({line:source.getLineAndCharacterOfPosition(n.getStart(source)).line+1,expression:n.getText(source)});
 ts.forEachChild(n,visit);};visit(source);out.push({source:stem+'.test.ts',sourceSha256:crypto.createHash('sha256').update(text).digest('hex'),inputCalls:calls,arrays,parameterizedSites:each});
}
fs.writeFileSync(p+'/FULL-FIXTURE-STATIC-INVENTORY.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out.map(x=>({source:x.source,inputCalls:x.inputCalls.length,arrays:x.arrays.map(a=>[a.name,a.rows]),parameterizedSites:x.parameterizedSites.length}))));
